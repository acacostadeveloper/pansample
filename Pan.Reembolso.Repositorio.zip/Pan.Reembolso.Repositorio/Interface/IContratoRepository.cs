﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IContratoRepository
    {
        IEnumerable<Pan.Reembolso.Entidades.Contrato> ObterContrato();
        Pan.Reembolso.Entidades.Contrato ObterContrato(int id);
        Pan.Reembolso.Entidades.Contrato ObterContrato(string codigoContrato);
        int PersistirContrato(Pan.Reembolso.Entidades.Contrato values);
        void ExcluirContrato(int id);
    }
}
