﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class SistemaMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.SistemaDatabase>
    {
        public SistemaMap() 
        {
            this.HasKey(t   => t.idSistema);
            this.Property(t => t.idSistema).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[SISTEMA]");
            this.Property(t => t.idSistema).HasColumnName("ID_SISTEMA");
            this.Property(t => t.descricaoSistema).HasColumnName("DS_SISTEMA");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.dataAlteracao).HasColumnName("DT_ALTERACAO");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
        }
    }
}
