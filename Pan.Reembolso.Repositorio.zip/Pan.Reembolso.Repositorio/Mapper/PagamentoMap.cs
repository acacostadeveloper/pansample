﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class PagamentoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.PagamentoDatabase>
    {
        public PagamentoMap() 
        {
            this.HasKey(t   => t.idPagamento);
            this.Property(t => t.idPagamento).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[PAGAMENTO]");
            this.Property(t => t.idPagamento).HasColumnName("ID_PAGAMENTO");
            this.Property(t => t.idColigada).HasColumnName("ID_COLIGADA");
            this.Property(t => t.dataRegistro).HasColumnName("DT_REGISTRO_PAGAMENTO");
            this.Property(t => t.dataPagamento).HasColumnName("DT_PAGAMENTO");
            this.Property(t => t.tipoPagamento).HasColumnName("CD_TIPO_PAGAMENTO");
            this.Property(t => t.valorPagamento).HasColumnName("VL_PAGAMENTO");
        }
    }
}
