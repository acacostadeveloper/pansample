﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ColigadaMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ColigadaDatabase>
    {
        public ColigadaMap() 
        {
            this.HasKey(t   => t.idColigada);
            this.Property(t => t.idColigada).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[COLIGADA]");
            this.Property(t => t.idColigada).HasColumnName("ID_COLIGADA");
            this.Property(t => t.codigoColigada).HasColumnName("CD_COLIGADA");
            this.Property(t => t.nomeColigada).HasColumnName("NM_COLIGADA");
            this.Property(t => t.cnpjColigada).HasColumnName("CNPJ_COLIGADA");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.dataAlteracao).HasColumnName("DT_ALTERACAO");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
        }
    }
}
