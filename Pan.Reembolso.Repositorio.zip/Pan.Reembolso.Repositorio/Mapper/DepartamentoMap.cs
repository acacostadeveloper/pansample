﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class DepartamentoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.DepartamentoDatabase>
    {
        public DepartamentoMap() 
        {
            this.HasKey(t   => t.idDepartamento);
            this.Property(t => t.idDepartamento).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[DEPARTAMENTO]");
            this.Property(t => t.idDepartamento).HasColumnName("ID_DEPARTAMENTO");
            this.Property(t => t.codigoDepartamento).HasColumnName("CD_DEPARTAMENTO");
            this.Property(t => t.descricaoDepartamento).HasColumnName("DS_DEPARTAMENTO");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.dataAlteracao).HasColumnName("DT_ALTERACAO");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
        }
    }
}
