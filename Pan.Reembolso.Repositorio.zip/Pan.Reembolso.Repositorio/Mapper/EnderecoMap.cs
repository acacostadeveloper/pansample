﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class EnderecoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.EnderecoDatabase>
    {
        public EnderecoMap() 
        {
            this.HasKey(t   => t.idEndereco);
            this.Property(t => t.idEndereco).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[ENDERECO]");
            this.Property(t => t.idEndereco).HasColumnName("ID_ENDERECO");
            this.Property(t => t.idCliente).HasColumnName("ID_CLIENTE");
            this.Property(t => t.nomeLogradouro).HasColumnName("NM_LOGRADOURO");
            this.Property(t => t.numeroEndereco).HasColumnName("NO_ENDERECO");
            this.Property(t => t.complemento).HasColumnName("DS_COMPLEMENTO");
            this.Property(t => t.cep).HasColumnName("NO_CEP");
            this.Property(t => t.bairro).HasColumnName("NM_BAIRRO");
            this.Property(t => t.cidade).HasColumnName("NM_CIDADE");
            this.Property(t => t.uf).HasColumnName("CD_UF");
            this.Property(t => t.dataAtualizacao).HasColumnName("DT_ATUALIZACAO");
        }
    }
}
