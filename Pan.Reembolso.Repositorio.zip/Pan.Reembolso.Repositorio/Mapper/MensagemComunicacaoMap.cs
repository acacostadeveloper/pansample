﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MensagemComunicacaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.MensagemComunicacaoDatabase>
    {
        public MensagemComunicacaoMap() 
        {
            this.HasKey(t => t.idMensagemComunicacao);
            this.Property(t => t.idMensagemComunicacao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[MENSAGEM_COMUNICACAO]");
            this.Property(t => t.idMensagemComunicacao).HasColumnName("ID_MENSAGEM_COMUNICACAO");
            this.Property(t => t.descricaoMensagemComunicacao).HasColumnName("DS_MENSAGEM_COMUNICACAO");
            this.Property(t => t.tipoMensagemComunicacao).HasColumnName("CD_TIPO_COMUNICACAO");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
        }
    }
}
