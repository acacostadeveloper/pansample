﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContaReservaMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ContaReservaDatabase>
    {
        public ContaReservaMap() 
        {
            this.HasKey(t   => t.idConta);

            this.ToTable("[gestao_reembolso].[CONTA_RESERVA]");
            this.Property(t => t.idConta).HasColumnName("ID_CONTA");
            this.Property(t => t.cnpjSacado).HasColumnName("NO_CNPJ_SACADO");
            this.Property(t => t.sequenciaCnpjSacado).HasColumnName("NO_SEQUENCIA_SACADO");
            this.Property(t => t.nomeSacado).HasColumnName("NM_SACADO");
            this.Property(t => t.tipoPessoaSacado).HasColumnName("CD_TIPO_PESSOA_SACADO");
        }
    }
}
