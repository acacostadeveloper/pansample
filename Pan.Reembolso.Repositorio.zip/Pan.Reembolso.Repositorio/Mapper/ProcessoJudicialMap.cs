﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ProcessoJudicialMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ProcessoJudicialDatabase>
    {
        public ProcessoJudicialMap() 
        {
            this.HasKey(t   => t.idProcesso);
            this.Property(t => t.idProcesso).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[PROCESSO_JUDICIAL]");
            this.Property(t => t.idProcesso).HasColumnName("ID_PROCESSO");
            this.Property(t => t.idContrato).HasColumnName("ID_CONTRATO");
            this.Property(t => t.idProcessoOrigem).HasColumnName("ID_PROCESSO_SISTEMA_ORIGEM");
            this.Property(t => t.tituloProcesso).HasColumnName("DS_TITULO_PROCESSO");
        }
    }
}
