﻿using System;
using System.Linq;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ReembolsoRepository : IReembolsoRepository
    {
        private PanReembolsoContext _contexto;

        public ReembolsoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Reembolso ObterReembolso(int id) 
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  where _reemb.idReembolso == id  
                                  select new Entidades.Reembolso()
                                  {
                                      idLote = _reemb.idLote,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(id);
                    resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(id);
                    resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(id);
                    resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(id);
                }

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.Reembolso ObterReembolso(string codigoContrato) 
        {
            return null; 
        }

        public void PersistirReembolso(Entidades.Reembolso values, string idLote) 
        {
            try 
            {
                var contratoRep = new ContratoRepository();
                int idContrato = contratoRep.PersistirContrato(values.contrato);

                Entidades.DatabaseEntities.ReembolsoDatabase item = new Entidades.DatabaseEntities.ReembolsoDatabase
                {
                    idLote = idLote,
                    idContrato = idContrato,
                    dataSolicitacao = values.dataSolicitacao,
                    valorReembolso = values.valorReembolso,
                    statusReembolso = values.statusReembolso,
                    codigoUsuarioInclusao = values.usuario.codigoUsuario,
                    idDepartamento = _contexto.DepartamentoRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoDepartamento == values.departamento.codigoDepartamento)
                                                                .FirstOrDefault().idDepartamento
                };

                _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Add(item);
                _contexto.SaveChanges();
                values.numeroReembolso = item.idReembolso;
            }
            catch (Exception ex) 
            {
                throw ex; 
            }
        }


        public void ExcluirReembolso(int id) 
        { 
            // todo
        }
    }
}
