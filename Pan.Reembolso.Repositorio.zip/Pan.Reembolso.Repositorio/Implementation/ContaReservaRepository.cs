﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ContaReservaRepository
    {
        private PanReembolsoContext _contexto;

        public ContaReservaRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Reserva ObterContaReservaPorNumeroRequisicao(string numeroRequisicao)
        {
            try
            {
                var resultItem = (from _msgtr in _contexto.MensagemTransferenciaRepository
                                  join _ccres in _contexto.ContaReservaRepository on _msgtr.idContaReserva equals _ccres.idConta 
                                  join _contR in _contexto.ContaRepository on _ccres.idConta equals _contR.idConta
                                  where _msgtr.numeroRequisicao == numeroRequisicao
                                  select new Pan.Reembolso.Entidades.Reserva()
                                  {
                                      cnpjSacado = _ccres.cnpjSacado,
                                      nomeSacado = _ccres.nomeSacado,
                                      tipoPessoaSacado = _ccres.tipoPessoaSacado,
                                      numeroBanco = _contR.numeroBanco,
                                      numeroAgencia = _contR.numeroAgencia,
                                      digitoAgencia = _contR.digitoAgencia,
                                      numeroConta = _contR.numeroConta,
                                      digitoConta = _contR.digitoConta,
                                      tipoConta = _contR.tipoConta
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
