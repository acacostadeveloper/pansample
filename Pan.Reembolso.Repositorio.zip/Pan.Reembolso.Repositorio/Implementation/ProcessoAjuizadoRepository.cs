﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ProcessoAjuizadoRepository
    {
        private PanReembolsoContext _contexto;

        public ProcessoAjuizadoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IList<Pan.Reembolso.Entidades.ProcessoJudicial> ObterProcessoPorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository  
                                  join _proce in _contexto.ProcessoJudicialRepository on _contr.idContrato equals _proce.idContrato
                                  where _contr.codigoContrato == numeroContrato
                                  select new Pan.Reembolso.Entidades.ProcessoJudicial()
                                  {
                                      numeroProcesso = "",
                                      tituloProcesso = _proce.tituloProcesso
                                  }
                ).ToList();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
