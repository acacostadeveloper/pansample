﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ColigadaRepository
    {
        private PanReembolsoContext _contexto;

        public ColigadaRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Coligada ObterColigadaPorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository 
                                  join _colig in _contexto.ColigadaRepository on _contr.idColigada equals _colig.idColigada
                                  where _contr.codigoContrato == numeroContrato
                                  select new Pan.Reembolso.Entidades.Coligada()
                                  {
                                      cnpjColigada = _colig.cnpjColigada,
                                      codigoColigada = _colig.codigoColigada,
                                      nomeColigada = _colig.nomeColigada
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.Coligada ObterColigadaPorCodigo(string codigoColigada) 
        {
            var coligada = new Pan.Reembolso.Entidades.Coligada();



            return coligada;
        }
    }
}
