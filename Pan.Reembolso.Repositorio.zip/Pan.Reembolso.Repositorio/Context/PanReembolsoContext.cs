﻿using System.Data.Entity;
using Pan.Reembolso.Repositorio.Mapper;

namespace Pan.Reembolso.Repositorio.Context
{
    public class PanReembolsoContext : DbContext 
    {
        public PanReembolsoContext() : base("name=PanReembolsoContext") {}

        public DbSet<Entidades.DatabaseEntities.ClienteDatabase> ClienteRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ColigadaDatabase> ColigadaRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ComunicacaoDatabase> ComunicacaoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ContaCreditoDatabase> ContaCreditoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ContaDatabase> ContaRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ContaReservaDatabase> ContaReservaRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ContratoDatabase> ContratoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.DepartamentoDatabase> DepartamentoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.EnderecoDatabase> EnderecoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.MensagemComunicacaoDatabase> MensagemComunicacaoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.MensagemTransferenciaDatabase> MensagemTransferenciaRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.MensagemPadraoDatabase> MensagemPadraoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.MensagemPagamentoDatabase> MensagemPagamentoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.PagamentoDatabase> PagamentoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ProcessoJudicialDatabase> ProcessoJudicialRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ProdutoDatabase> ProdutoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ReembolsoComunicacaoDatabase> ReembolsoComunicacaoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ReembolsoDatabase> ReembolsoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.ReembolsoPagamentoDatabase> ReembolsoPagamentoRepository { get; set; }
        public DbSet<Entidades.DatabaseEntities.SistemaDatabase> SistemaRepository { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ClienteMap());
            modelBuilder.Configurations.Add(new ColigadaMap());
            modelBuilder.Configurations.Add(new ComunicacaoMap());
            modelBuilder.Configurations.Add(new ContaCreditoMap());
            modelBuilder.Configurations.Add(new ContaMap());
            modelBuilder.Configurations.Add(new ContaReservaMap());
            modelBuilder.Configurations.Add(new ContratoMap());
            modelBuilder.Configurations.Add(new DepartamentoMap());
            modelBuilder.Configurations.Add(new EnderecoMap());
            modelBuilder.Configurations.Add(new MensagemComunicacaoMap());
            modelBuilder.Configurations.Add(new MensagemMap());
            modelBuilder.Configurations.Add(new MensagemPadraoMap());
            modelBuilder.Configurations.Add(new MensagemPagamentoMap());
            modelBuilder.Configurations.Add(new PagamentoMap());
            modelBuilder.Configurations.Add(new ProcessoJudicialMap());
            modelBuilder.Configurations.Add(new ProdutoMap());
            modelBuilder.Configurations.Add(new ReembolsoComunicacaoMap());
            modelBuilder.Configurations.Add(new ReembolsoMap());
            modelBuilder.Configurations.Add(new ReembolsoPagamentoMap());
            modelBuilder.Configurations.Add(new SistemaMap());
        }
    }
}
