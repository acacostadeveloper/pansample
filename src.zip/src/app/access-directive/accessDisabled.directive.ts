import { Directive, Input, ElementRef, Renderer } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../guards/auth.service';

@Directive({
  selector: '[panAccessDisabled]'
})

export class AccessDisabledDirective {
  @Input() panAccessDisabled: boolean;

  constructor(public el: ElementRef,
    public renderer: Renderer,
    private route: ActivatedRoute,
    private authService: AuthService) { }

  ngOnInit() {
    if (!this.authService.verificarActionName(this.el.nativeElement.id, this.route.snapshot.url.join(''))) {
      this.el.nativeElement.disabled = true
    }
  }
}
