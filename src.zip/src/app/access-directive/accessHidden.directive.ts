import { Directive, Input, ElementRef, Renderer } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../guards/auth.service';

@Directive({
    selector: '[panAccessHidden]'
})

export class AccessHiddenDirective {
    @Input() panAccessHidden: string;

    constructor(public el: ElementRef, 
                public renderer: Renderer, 
                private route: ActivatedRoute,
                private authService: AuthService) { }

    ngOnInit() {
        if(!this.authService.verificarActionName(this.el.nativeElement.id, this.route.snapshot.url.join(''))){
            this.renderer.setElementStyle(this.el.nativeElement, 'display', 'none');
        }
    }
}
