import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { HttpClient } from '@angular/common/http'
import { AppConfig } from '../Helpers/app.config';

@Injectable({
  providedIn: 'root'
})
export class ProdutoService {

  constructor(private http: HttpClient) { }

  obterProdutos(): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}produto/obter`)
  }
}
