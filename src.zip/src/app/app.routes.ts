import { Routes } from '@angular/router'

import { HomeComponent } from './home/home.component'
import { IncluirReembolsoComponent } from './reembolso/incluir-reembolso/incluir-reembolso.component';
import { ConsultarReembolsoComponent } from './reembolso/consultar-reembolso/consultar-reembolso.component';
import { DetalheReembolsoComponent } from './reembolso/detalhe-reembolso/detalhe-reembolso.component';
import { AprovarReembolsoComponent } from './reembolso/aprovar-reembolso/aprovar-reembolso.component';
import { ConsultarDadosBancariosComponent } from './dados-bancarios/consultar-dados-bancarios/consultar-dadosBancarios.component';
import { ConsultarClienteComponent } from './Cliente/consultar-cliente/consultar-cliente.component';
import { RetiradaUsoInternoComponent } from './retirada-uso-interno/retirada-interno.component';
import { ConsultarIntegracaoComponent } from './reembolso/consultar-integracao/consultar-integracao.component';
import { AuthGuard } from './guards/auth.guard';
import { ErrorComponent } from './error/error.component';
import { EstornarReembolsoComponent } from './reembolso/estornar-reembolso/estornar-reembolso.component';
import { LogoutComponent } from './logout/logout.component';
import { ConsultarRetiradaComponent } from './retirada-uso-interno/consultar-retirada-interno/consultar-retirada.component';
import { RelResumoMovimentacaoComponent } from './relatorios/rel-resumo-movimentacao/rel-resumo-movimentacao.component';
import { RelPosicaoComponent } from './relatorios/rel-posicao/rel-posicao.component';
import { RelPosicaoEstoqueComponent } from './relatorios/rel-posicao-estoque/rel-posicao-estoque.component';
import { RelEstoqueMotivoBloqueioComponent } from './relatorios/rel-estoque-motivo-bloqueio/rel-estoque-motivo-bloqueio.component';
import { RelHistoricoLoteReembolsoComponent } from './relatorios/rel-historico-lote-reembolso/rel-historico-lote-reembolso.component';
import { RelValorRetiradaConsolidadoComponent } from './relatorios/rel-valor-retirada-consolidado/rel-valor-retirada-consolidado.component';
import { RelValorRetiradaAnaliticoComponent } from './relatorios/rel-valor-retirada-analitico/rel-valor-retirada-analitico.component';
import { RelComunicacaoConsolidadoComponent } from './relatorios/rel-comunicacao-consolidado/rel-comunicacao-consolidado.component';
import { RelReembolsoAnaliticoComponent } from './relatorios/rel-reembolso-analitico/rel-reembolso-analitico.component';

export const ROUTES: Routes = [
  { path: '', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'incluir-reembolso', component: IncluirReembolsoComponent, canActivate: [AuthGuard] },
  { path: 'consultar-reembolso', component: ConsultarReembolsoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard]},
  { path: 'estornar-reembolso', component: EstornarReembolsoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard]},
  { path: 'aprovar-reembolso', component: AprovarReembolsoComponent, canActivate: [AuthGuard] },
  { path: 'detalhe-reembolso/:id', component: DetalheReembolsoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'consultar-dadosBancarios', component: ConsultarDadosBancariosComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'consultar-clientes', component: ConsultarClienteComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'retirada-uso-interno', component: RetiradaUsoInternoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'consultar-integracao', component: ConsultarIntegracaoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'consultar-retirada', component: ConsultarRetiradaComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-resumo-movimentacao', component: RelResumoMovimentacaoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-posicao', component: RelPosicaoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-posicao-estoque', component: RelPosicaoEstoqueComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-estoque-motivo-bloqueio', component: RelEstoqueMotivoBloqueioComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-historico-lote-reembolso', component: RelHistoricoLoteReembolsoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-valor-retirada-consolidado', component: RelValorRetiradaConsolidadoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-valor-retirada-analitico', component: RelValorRetiradaAnaliticoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-comunicacao-consolidado', component: RelComunicacaoConsolidadoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'rel-reembolso-analitico', component: RelReembolsoAnaliticoComponent, runGuardsAndResolvers: "always", canActivate: [AuthGuard] },
  { path: 'erro', component: ErrorComponent, runGuardsAndResolvers: "always" },
  { path: 'logout', component: LogoutComponent, runGuardsAndResolvers: "always" },
]
