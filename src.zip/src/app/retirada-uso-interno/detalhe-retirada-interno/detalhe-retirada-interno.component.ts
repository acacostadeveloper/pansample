import { Component, OnInit, ViewContainerRef, ViewChild } from '@angular/core'
import { ModalDialogService } from 'ngx-modal-dialog'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'
import { fadeInOut, cabecalhoAnimation, detalheAnimation } from '../../Helpers/animacoes'
import { PopUpModal } from '../../Helpers/popUpModal'
import { ReembolsoResult } from '../../models/reembolsoResult.model'
import { DetalheReembolsoComponent } from '../../reembolso/detalhe-reembolso/detalhe-reembolso.component'

@Component({
  selector: 'pan-detalhe-retirada-uso-interno',
  templateUrl: './detalhe-retirada-interno.component.html',
  animations: [cabecalhoAnimation, detalheAnimation, fadeInOut]
})

export class DetalheRetiradaInternoComponent implements OnInit {
  @ViewChild("detalheReembolso")
  public detalheReembolso: DetalheReembolsoComponent
  
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)

  public reembolsoResult: ReembolsoResult = new ReembolsoResult()

  mostraCabecalhoAnimacao: string
  mostraDetalheAnimacao: string

  public mostraDetalhe: boolean
  
  constructor(
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
  ) {

  }

  mostrarDetalhe(idReembolso: number) {
    this.mostraDetalhe = true
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()

    this.detalheReembolso.obterReembolso(idReembolso)
  }

  ocultarDetalhe() {
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  ngOnInit() {
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = "true"
    this.mostraDetalheAnimacao = "false"
  }
}
