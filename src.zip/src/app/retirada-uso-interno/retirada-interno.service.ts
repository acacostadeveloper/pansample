import { Injectable } from '@angular/core'
import { Observable, of } from 'rxjs'
import { HttpClient } from '@angular/common/http'
import { tap, catchError } from 'rxjs/operators'
import { RetiradaUsoInterno } from '../models/retiradaUsoInterno.model'
import { FuncoesApoio } from '../Helpers/funcoesApoio';
import { UploadFile } from '../models/uploadFile.model';
import { AppConfig } from '../Helpers/app.config';

@Injectable({
  providedIn: 'root'
})
export class RetiradaInternoService {

  constructor(private http: HttpClient) { }

  efetuarRetiradaLote(uploadFile: UploadFile): Observable<any> {
    return this.http.post<UploadFile[]>(`${AppConfig.settings.apiServer}pagamento/upload`, uploadFile
    ).pipe(
      tap(data => data),
      catchError(FuncoesApoio.handleError),
    );
  }


  efetuarRetirada(retiradaUsoInterno: RetiradaUsoInterno): Observable<any> {
    return this.http.post<any>(`${AppConfig.settings.apiServer}pagamento/retirada`, retiradaUsoInterno).pipe(
      tap(data => data),
      catchError(
        (response: Response) => {
          return of(response)

        }
      ),
    )
  }

  obterMotivosRetencao(): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}MotivoRetencao`)
  }

  obterProcessosSaida(): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}processoRegistro/saida`)
  }

  obterRetiradas(
    idLote: string,
    dataIni: string,
    dataFim: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}pagamento/lote`,
        {
          params: {
            idLote: idLote,
            dataIni: dataIni,
            dataFim: dataFim
          }
        }
      ).pipe(
        tap(data => data),
        catchError(
          (response: Response) => {
            return of(response)

          }
        )
      )
  }

  obterPagamentos(
    cpfCnpj: string,
    codigoProduto: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}pagamento/retirada`,
        {
          params: {
            cpfCnpj: cpfCnpj,
            codigoProduto: codigoProduto
          }
        }
      ).pipe(
        tap(data => data),
        catchError(
          (response: Response) => {
            return of(response)

          }
        )
      )
  }
}
