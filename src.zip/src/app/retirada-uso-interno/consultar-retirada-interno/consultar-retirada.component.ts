import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef } from '@angular/core'
import { ModalDialogService } from 'ngx-modal-dialog' //https://github.com/Greentube/ngx-modal/blob/master/demo/src/app/app.component.ts#L30-L32
import { HttpErrorResponse } from '@angular/common/http'
import { PopUpModal } from '../../Helpers/popUpModal'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'
import { FormGroup, FormBuilder } from '@angular/forms'
import { cabecalhoAnimation } from '../../Helpers/animacoes'
import { ActivatedRoute } from '@angular/router';
import { IMyDpOptions } from 'mydatepicker';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { RetiradaInternoService } from '../retirada-interno.service';
import { ConsultaRetirada } from '../../models/RetiradaUsoInterno/consultaRetirada.model';

@Component({
  selector: 'pan-consultar-retirada',
  templateUrl: './consultar-retirada.component.html',
  animations: [cabecalhoAnimation]
})
export class ConsultarRetiradaComponent implements OnInit {
  public retiradas: ConsultaRetirada[] = []
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)

  mostraCabecalhoAnimacao: string

  sortAscendente: boolean = true
  mostraDetalhe: boolean = false

  p: number = 1
  collection: any[] = this.retiradas

  public form: FormGroup

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }

  constructor(
    private formBuilder: FormBuilder,
    private retiradaInternoService: RetiradaInternoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private route: ActivatedRoute
  ) { }

  mostrarDetalhe(retirada: ConsultaRetirada){
    retirada.integracao.mostraDetalhe = !retirada.integracao.mostraDetalhe 
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      filterDtInicial: [null],
      filterDtFinal: [null],
      filterIdLote: [null]
    })
    this.mostraCabecalhoAnimacao = "true"
    let idLote = this.route.snapshot.queryParams['idLote'];
    if (idLote != null) {
      this.form.patchValue({ filterIdLote: idLote })
      this.carregarRetiradas()
    }
    else {
      this.iniciarDatas()
    }
  }

  iniciarDatas(): void {
    let date: Date = new Date()
    this.form.patchValue({ filterDtInicial: { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 } } })
    this.form.patchValue({ filterDtFinal: { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } } })
  }

  carregarRetiradas(mostrarMensagem: boolean = false) {
    if (this.validarCampos()) {
      this.spinnerService.show()
      this
      .retiradaInternoService
      .obterRetiradas(
        this.form.get('filterIdLote').value,
        FuncoesApoio.formatarDataInicial(this.form.get('filterDtInicial').value),
        FuncoesApoio.formatarDataFinal(this.form.get('filterDtFinal').value)
      )
        .subscribe(
          (data: any) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse = data
              this.spinnerService.hide()
              if (retorno.status == 502) {
                this.retiradas = []
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com estes parâmetros")
                }
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText)
              }

            }
            else {
              this.spinnerService.hide()
              if (data == null || data.Retiradas.length == 0) {
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com estes parâmetros")
                }
                this.retiradas = []
              }
              else {
                this.retiradas = data.Retiradas
              }
            }
          }
        ),
        error => {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
        }
    }
  }


  limparFiltros() {
    this.form.patchValue({ filterIdLote: "" })
    this.form.patchValue({ filterDtInicial: null })
    this.form.patchValue({ filterDtFinal: null })
  }

  ordenarCampos(propriedade: string) {
    if (this.sortAscendente) {
      this.retiradas.sort((a, b) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
    }
    else {
      this.retiradas.sort((b, a) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
    }

    this.sortAscendente = !this.sortAscendente
  }

  validarCampos() {
    let mensagemRetorno: string = ""

    if (!this.form.valid) {
      mensagemRetorno = mensagemRetorno + "- Campos inválidos.<br>"
    }

    if (
      (this.form.get('filterDtInicial').value == undefined || this.form.get('filterDtInicial').value == null) ||
      (this.form.get('filterDtFinal').value == undefined || this.form.get('filterDtFinal').value == null)
    ) {
      this.form.patchValue({ filterDtInicial: null })
      this.form.patchValue({ filterDtFinal: null })
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.form.get('filterDtInicial').value, this.form.get('filterDtFinal').value)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>"
      }
    }

    if (
      (this.form.get('filterIdLote').value == undefined || this.form.get('filterIdLote').value == null || this.form.get('filterIdLote').value == "") &&
      (this.form.get('filterDtInicial').value == null || this.form.get('filterDtFinal').value == null)
    ) {
      mensagemRetorno = mensagemRetorno + "- Informe ao menos um campo válido para a pesquisa.<br>"
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }
}

