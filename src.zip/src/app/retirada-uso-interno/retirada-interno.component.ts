import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef } from '@angular/core'
import { HttpErrorResponse } from '@angular/common/http'
import { ModalDialogService } from 'ngx-modal-dialog'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'
import { fadeInOut, cabecalhoAnimation, detalheAnimation } from '../Helpers/animacoes'
import { Produto } from '../models/produto.model'
import { ProdutoService } from '../produto/produto.service'
import { PopUpModal } from '../Helpers/popUpModal'
import { RetiradaInternoService } from './retirada-interno.service'
import { RetiradaUsoInterno } from '../models/retiradaUsoInterno.model'
import { DetalheRetiradaInternoComponent } from './detalhe-retirada-interno/detalhe-retirada-interno.component'
import { ProcessosSaida } from '../models/processosSaida.model'
import { AuthService } from '../guards/auth.service';
import { FuncoesApoio } from '../Helpers/funcoesApoio';
import { UploadFile } from '../models/uploadFile.model';

@Component({
  selector: 'pan-retirada-uso-interno',
  templateUrl: './retirada-interno.component.html',
  animations: [cabecalhoAnimation, detalheAnimation, fadeInOut]
})
export class RetiradaUsoInternoComponent implements OnInit {
  @ViewChild("txtValor")
  public txtValor: ElementRef

  @ViewChild("comboProcessoSaida")
  public comboProcessoSaida: ElementRef
  

  @ViewChild("DetalheRetirada")
  public detalheRetirada: DetalheRetiradaInternoComponent

  @ViewChild("txtArquivo")
  public txtArquivo: ElementRef

  produtos: Produto[]
  processosSaida: ProcessosSaida[]
  retiradaUsoInterno: RetiradaUsoInterno
  valorTotal: number

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)
  mostraCabecalhoAnimacao: string
  mostraDetalheAnimacao: string
  public mostraDetalhe: boolean
  mostrarRetorno: boolean

  mostrarLinkLote: boolean = false
  idLote: number

  filterIdProduto: string
  filterCpfClientes: string

  constructor(
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private produtoService: ProdutoService,
    private retiradaInternoService: RetiradaInternoService,
    private authService: AuthService
  ) {

  }

  ngOnInit() {
    this.carregarProdutos()
    this.carregarProcessosSaida()
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = "true"
    this.mostraDetalheAnimacao = "false"
    this.mostrarRetorno = false
  }

  validaCamposLote() {
    let mensagemRetorno: string = "";

    if (this.txtArquivo.nativeElement.files.length == 0) {
      mensagemRetorno = mensagemRetorno + "- Favor informar o arquivo.<br>";
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  efetuarRetirada() {
    if (this.validarCamposPost()) {

      this.spinnerService.show()
      this.retiradaUsoInterno.usuario = this.authService.usuario.userId

      this.retiradaInternoService.efetuarRetirada(this.retiradaUsoInterno).subscribe(
        data => {
          if (data instanceof HttpErrorResponse) {
            this.detalheRetirada.reembolsoResult = undefined
            this.mensagem.mensagemOkModal("Ocorreu o erro ao efetuar a retirada: " + data.statusText)
          }
          else {
            if (data.Success == false) {
              this.detalheRetirada.reembolsoResult = undefined
              this.mensagem.mensagemOkModal("Ocorreu o erro ao efetuar a retirada: " + data.MessageError)
            }
            else {
              this.mensagem.mensagemOkModal("Registro efetuado com sucesso")
              this.mostrarRetorno = true
              this.montarDetalhePagamento(data)
              this.carregarPagamentosARealizar()
            }
          }
          this.spinnerService.hide()
        },
        error => {
          if (error instanceof HttpErrorResponse) {
            this.mensagem.mensagemOkModal("Ocorreu o erro: " + error.statusText)
          }
          this.spinnerService.hide()
        },
      )
    }
  }


  efetuarRetiradaLote() {
    var arquivo: string
    var self = this
    if (this.validaCamposLote()) {
      this.spinnerService.show();

      var uploadFile: UploadFile = new UploadFile()

      var reader = new FileReader();
      reader.readAsArrayBuffer(this.txtArquivo.nativeElement.files[0])
      uploadFile.nomeDocumento = this.txtArquivo.nativeElement.files[0].name

      reader.onload = function (e, http = this.http) {
        var arrayBuffer = reader.result;

        var bytes = FuncoesApoio.arrayBufferToBase64String(<ArrayBuffer>arrayBuffer)

        uploadFile.arrayBytesDocumento = bytes

        self.retiradaInternoService.efetuarRetiradaLote(uploadFile).subscribe(
          data => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data
              self.spinnerService.hide()
              self.mensagem.mensagemOkModal("Ocorreu o erro ao fazer o upload do arquivo:<br><br>" + data.statusText)
              self.mostrarLinkLote = false
            }
            else {
              self.spinnerService.hide()
              if (data.Success == false) {
                self.mensagem.mensagemOkModal("Ocorreu o erro ao fazer o upload do arquivo:<br><br>" + data.MessageError)
                self.mostrarLinkLote = false
              }
              else {
                self.mensagem.mensagemOkModal("Arquivo enviado com sucesso. Lote de retorno: " + data.idLoteIntegracao)
                self.idLote = data.idLoteIntegracao
                self.mostrarLinkLote = true
                self.txtArquivo.nativeElement.value = ""
              }
            }
          },
          error => {
            self.spinnerService.hide();
            self.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
            self.mostrarLinkLote = false
          },
        );
      }
    }
  }

  limparFiltros() {
    this.filterIdProduto = ""
    this.filterCpfClientes = ""
    this.valorTotal = 0
    this.mostrarRetorno = false
  }

  mostrarDetalhe() {
    this.mostraDetalhe = true
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()

  }

  ocultarDetalhe() {
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()

    this.retiradaUsoInterno = null
    this.mostrarRetorno = false
    this.limparFiltros()
  }

  carregarProcessosSaida() {
    this
      .retiradaInternoService
      .obterProcessosSaida()
      .subscribe(
        (data: any) => {
          this.processosSaida = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + " ao carregar a lista de motivos")
      }
  }
  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + "ao carregar a lista de produtos")
      }

  }

  validarCamposConsulta() {
    let mensagemRetorno: string = ""

    if (this.filterCpfClientes == undefined || this.filterCpfClientes == "") {
      mensagemRetorno = mensagemRetorno + "- Favor preencher o número do cpf.<br>"
    }

    if (this.filterIdProduto == undefined || this.filterIdProduto == "") {
      mensagemRetorno = mensagemRetorno + "- Favor preencher o campo produto.<br>"
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }

  validarCamposPost() {
    let mensagemRetorno: string = ""

    if (this.retiradaUsoInterno.codigoProcesso == undefined) {
      mensagemRetorno = mensagemRetorno + "- Favor preencher o codigo Processo de saída.<br>"
    }
    else {
      this.retiradaUsoInterno.justificativa = this.processosSaida.find(x => x.codigoProcessoRegistro == this.retiradaUsoInterno.codigoProcesso).processoRegistro
    }

    this.retiradaUsoInterno.items.forEach(i => {
      if (i.valorSolicitado > i.valorDisponivel) {
        mensagemRetorno = mensagemRetorno + "- Valor da retirada do contrato " + i.codigoContrato + " não pode ser maior que valor total.<br>"
      }
    })

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }

  montarDetalhePagamento(data: any) {
    this.detalheRetirada.reembolsoResult = data
  }

  carregarPagamentosARealizar(mostrarMensagem: boolean = false) {
    if (this.validarCamposConsulta()) {
      this.spinnerService.show()
      this
        .retiradaInternoService
        .obterPagamentos(
          this.filterCpfClientes,
          this.filterIdProduto
        )
        .subscribe(
          (data: any) => {
            this.spinnerService.hide()
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse
              retorno = data
              if (retorno.status == 502) {
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                }
                this.retiradaUsoInterno = null
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText)
              }

            }
            else {
              if (data.Retiradas.length == 0) {
                if (mostrarMensagem == true) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                }
              }
              else {
                this.mostrarDetalhe()
                this.retiradaUsoInterno = data.Retiradas[0]
                this.retiradaUsoInterno.codigoProduto = this.retiradaUsoInterno.produto.codigoProduto
                this.retiradaUsoInterno.items.forEach(i => {
                  i.valorSolicitado = i.valorDisponivel
                  i.retiradaTotal = true
                })
              }
            }
          }
        ),
        error => {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
        }
    }
  }
}
