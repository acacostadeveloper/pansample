import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../guards/auth.service';
import { GlobalService } from '../Helpers/global.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'pan-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  public msgSpinner: string
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    )

  mnuConsultarReembolso: boolean
  mnuIncluirReembolso: boolean
  mnuAprovarReembolso: boolean
  mnuRetiradaUsoInterno: boolean
  mnuConsultaIntegracao: boolean
  mnuConsultaRetirada: boolean
  mnuConsultarClientes: boolean
  mnuConsultarDadosBancarios: boolean
  mnuEmitirRelatorios: boolean
  mnuValoresRestituir: boolean
  mnuEstornarReembolso: boolean
  mnuHomeLogout: boolean
  mnuRelResumoMovimentacao: boolean
  mnuRelPosicao: boolean
  mnuRelPosicaoEstoque: boolean
  mnuRelEstoqueMotivoBloqueio: boolean
  mnuRelHistoricoLoteReembolso: boolean
  mnuRelValorRetiradaConsolidado: boolean
  mnuRelValorRetiradaAnalitico: boolean
  mnuRelComunicacaoConsolidado: boolean
  mnuRelReembolsoAnalitico: boolean

  constructor(private breakpointObserver: BreakpointObserver,
    private authService: AuthService,
    private spinnerService: Ng4LoadingSpinnerService,
    private globalService: GlobalService) {
  }

  alterarRota() {
    this.globalService.alterarRota()
  }

  carregarPermissoes() {
    this.mnuConsultarReembolso = this.authService.verificarServiceName('consultar-reembolso')
    this.mnuIncluirReembolso = this.authService.verificarServiceName('incluir-reembolso')
    this.mnuAprovarReembolso = this.authService.verificarServiceName('aprovar-reembolso')
    this.mnuRetiradaUsoInterno = this.authService.verificarServiceName('retirada-uso-interno')
    this.mnuConsultaIntegracao = this.authService.verificarServiceName('consultar-integracao')
    this.mnuConsultarClientes = this.authService.verificarServiceName('consultar-clientes')
    this.mnuConsultarDadosBancarios = this.authService.verificarServiceName('consultar-dadosBancarios')
    this.mnuEmitirRelatorios = this.authService.verificarServiceName('emitir-relatorios')
    this.mnuEstornarReembolso = this.authService.verificarServiceName('estornar-reembolso')
    this.mnuConsultaRetirada = this.authService.verificarServiceName('consultar-retirada')
    this.mnuRelResumoMovimentacao = this.authService.verificarServiceName('rel-resumo-movimentacao')
    this.mnuRelPosicao = this.authService.verificarServiceName('rel-posicao')
    this.mnuRelPosicaoEstoque = this.authService.verificarServiceName('rel-posicao-estoque')
    this.mnuRelEstoqueMotivoBloqueio = this.authService.verificarServiceName('rel-estoque-motivo-bloqueio')
    this.mnuRelHistoricoLoteReembolso = this.authService.verificarServiceName('rel-historico-lote-reembolso')
    this.mnuRelValorRetiradaConsolidado = this.authService.verificarServiceName('rel-valor-retirada-consolidado')
    this.mnuRelValorRetiradaAnalitico = this.authService.verificarServiceName('rel-valor-retirada-analitico')
    this.mnuRelComunicacaoConsolidado = this.authService.verificarServiceName('rel-comunicacao-consolidado')
    this.mnuRelReembolsoAnalitico = this.authService.verificarServiceName('rel-reembolso-analitico')
    this.mnuHomeLogout = this.authService.usuario != null

    //verifica se algum item do menu de valores a restituir esta ativo para exibicao ate colocar menu dinamico
    //valores a restituir
    if (
      this.mnuConsultarReembolso ||
      this.mnuIncluirReembolso ||
      this.mnuAprovarReembolso ||
      this.mnuRetiradaUsoInterno ||
      this.mnuConsultaIntegracao ||
      this.mnuConsultaRetirada
    ) {
      this.mnuValoresRestituir = true
    }
    else {
      this.mnuValoresRestituir = false
    }

    //relatorios
    if (
      this.mnuRelResumoMovimentacao ||
      this.mnuRelPosicao ||
      this.mnuRelPosicaoEstoque ||
      this.mnuRelEstoqueMotivoBloqueio ||
      this.mnuRelHistoricoLoteReembolso ||
      this.mnuRelValorRetiradaConsolidado ||
      this.mnuRelValorRetiradaAnalitico ||
      this.mnuRelComunicacaoConsolidado ||
      this.mnuRelReembolsoAnalitico
    ) {
      this.mnuEmitirRelatorios = true
    }
    else {
      this.mnuEmitirRelatorios = false
    }
  }

  ngOnInit() {
    this.carregarPermissoes()
    this.authService.change.subscribe(data => {
      this.carregarPermissoes()
    });
    this.authService.loadSpinner.subscribe(data => {
      if(data != undefined) {
        this.msgSpinner = data
        this.spinnerService.show()
      }
      else {
        this.msgSpinner = ""
        this.spinnerService.hide()
      }
    });
    
  }




}
