import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { Reembolso } from '../models/reembolso.model'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { catchError, tap } from 'rxjs/operators'
import { EnvioStatusPagamento } from '../models/AprovarReembolso/EnvioStatusPagamento'
import { FuncoesApoio } from '../Helpers/funcoesApoio'
import { UploadFile } from '../models/uploadFile.model';
import { AppConfig } from '../Helpers/app.config';


@Injectable({
  providedIn: 'root'
})
export class ReembolsoService {

  constructor(private http: HttpClient) { }

  adicionarReembolsoLote(uploadFile: UploadFile): Observable<any> {
    return this.http.post<UploadFile[]>(`${AppConfig.settings.apiServer}reembolso/upload`, uploadFile
    ).pipe(
      tap(data => data),
      catchError(FuncoesApoio.handleError),
    );
  }


  adicionarReembolso(reembolso: Reembolso): Observable<any> {
    let listaReembolso: Reembolso[] = []
    listaReembolso.push(reembolso)
    return this.http.post<Reembolso[]>(`${AppConfig.settings.apiServer}reembolso`, listaReembolso).pipe(
      catchError(FuncoesApoio.handleError),
    )
  }

  aprovarReembolso(envioStatusPagamento: EnvioStatusPagamento): Observable<any> {
    return this.http.post<EnvioStatusPagamento>(`${AppConfig.settings.apiServer}pagamento`, envioStatusPagamento).pipe(
      catchError(FuncoesApoio.handleError),
    )
  }

  deletarReembolsoList(reembolsos: Reembolso[]): Observable<any> {

    let success = new Observable<any>()

    reembolsos.forEach(element => {
      if (element.estornar == true) {
        success = this.http.delete(`${AppConfig.settings.apiServer}reembolso/` + element.idReembolso).pipe(
          tap(data => data),
          catchError(FuncoesApoio.handleError),
        )
      }
    })

    return success
  }

  deletarReembolso(parametro: number): Observable<any> {
    return this.http.delete(`${AppConfig.settings.apiServer}reembolso/` + parametro).pipe(
      tap(data => {
        return data
      }),
      catchError(FuncoesApoio.handleError),
    )
  }

  obterReembolso(
    idReembolso: number
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}reembolso/` + idReembolso,
      ).pipe(
        tap(data => {
          return data
        }),
        catchError(FuncoesApoio.handleError)
      )
  }

  obterHistoricoPagamentos(
    idReembolso: number
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}pagamento/historico/` + idReembolso,
      ).pipe(
        tap(data => {
          return data
        }),
        catchError(FuncoesApoio.handleError)
      )
  }

  obterPagamentosARealizar(
    dtInicial: string,
    dtFinal: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}pagamento`,
        {
          params: {
            dtInicial: dtInicial,
            dtFinal: dtFinal,
            statusReembolso: "Registrado"
          }
        }
      ).pipe(
        tap(data => {
          return data
        }),
        catchError(FuncoesApoio.handleError)
      )
  }

  obterintegracoes(
    idLote: string,
    dtInicial: string,
    dtFinal: string

  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}integracao/list`,
        {
          params: {
            idLote: idLote,
            dtInicial: dtInicial,
            dtFinal: dtFinal
          }
        }
      ).pipe(
        tap(data => {
          return data
        }),
        catchError(FuncoesApoio.handleError)
      )
  }

  exportarCSV(
    dtInicial: string,
    dtFinal: string
  ): Observable<any> {
    return this.http.get(`${AppConfig.settings.apiServer}pagamento/exportar`, {
      params: {
        dtInicial: dtInicial,
        dtFinal: dtFinal,
        statusReembolso: "Registrado"
      },
      headers: new HttpHeaders({
        'Content-Type': 'application/octet-stream',
      }), responseType: 'blob'
    }).pipe(
      tap(data => {
        return data
      }
      )
    );
  }

  obterReembolsos(
    idLote: string,
    idProduto: string,
    dtInicial: string,
    dtFinal: string,
    cpfCliente: string,
    statusReembolso: string[],
    idReembolso: string,
    idMotivoBloqueio: string
  ): Observable<any> {

    return this.http
      .get(`${AppConfig.settings.apiServer}reembolso/list`,
        {
          params: {
            idLote: idLote,
            idProduto: idProduto,
            dtInicial: dtInicial,
            dtFinal: dtFinal,
            cpfCliente: cpfCliente,
            statusReembolso: statusReembolso,
            idReembolso: idReembolso,
            idMotivoBloqueio: idMotivoBloqueio
          }
        }
      ).pipe(
        tap(data => {
          return data
        }),
        catchError(FuncoesApoio.handleError)
      )
  }
}



