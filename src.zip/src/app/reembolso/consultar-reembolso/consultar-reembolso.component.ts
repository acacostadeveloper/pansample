import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef } from '@angular/core'
import { ReembolsoService } from '../reembolso.service'
import { Produto } from '../../models/produto.model'
import { ProdutoService } from '../../produto/produto.service'
import { IMyDpOptions, IMyDateModel, MyDatePicker } from 'mydatepicker'
import { ModalDialogService } from 'ngx-modal-dialog' //https://github.com/Greentube/ngx-modal/blob/master/demo/src/app/app.component.ts#L30-L32
import { HttpErrorResponse } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { ReembolsoConsulta } from '../../models/reembolsoConsulta.model'
import { FuncoesApoio } from '../../Helpers/funcoesApoio'
import { PopUpModal } from '../../Helpers/popUpModal'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'
import { DetalheReembolsoComponent } from '../detalhe-reembolso/detalhe-reembolso.component'
import { DadosBancariosService } from '../../dados-bancarios/dados-bancarios.service'
import { FormGroup, FormBuilder } from '@angular/forms'
import { cabecalhoAnimation, detalheAnimation } from '../../Helpers/animacoes'
import { AuthService } from '../../guards/auth.service';
import { GlobalService } from '../../Helpers/global.service';
import { MotivoBloqueio } from '../../models/motivoBloqueio.model';
import { MotivoBloqueioService } from '../../motivo-bloqueio/motivo-bloqueio.service';

@Component({
  selector: 'pan-consultar-reembolso',
  templateUrl: './consultar-reembolso.component.html',
  styleUrls: ['./consultar-reembolso.component.css'],
  animations: [cabecalhoAnimation, detalheAnimation]
})
export class ConsultarReembolsoComponent implements OnInit {
  @ViewChild("detalheReembolso")
  public detalheReembolso: DetalheReembolsoComponent

  @ViewChild("txtDataInicial")
  public txtDataInicial: MyDatePicker

  @ViewChild("txtDataFinal")
  public txtDataFinal: MyDatePicker

  @ViewChild("chkSelecionarTodos")
  private chkSelecionarTodos: ElementRef

  public reembolsos: ReembolsoConsulta[] = []
  reembolso = new ReembolsoConsulta()
  produtos: Produto[]
  motivosBloqueio: MotivoBloqueio[]
  statusReembolsos = environment.StatusReembolso
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)
  msgSpinner: string

  mostraCabecalhoAnimacao: string
  mostraDetalheAnimacao: string

  sortAscendente: boolean = true

  p: number = 1
  collection: any[] = this.reembolsos

  public mostraDetalhe: boolean
  public form: FormGroup

  //Filtros:
  filterIdLote: string
  filterIdReembolso: string
  filterIdProduto: string
  filterDtInicial: IMyDateModel
  filterDtFinal: IMyDateModel
  filterCpfClientes: string
  filterStatusReembolso: string
  statusReembolso: string[]
  filterIdMotivoBloqueio: string
 
  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }

  constructor(
    private reembolsoService: ReembolsoService,
    private produtoService: ProdutoService,
    private motivoBloqueioService: MotivoBloqueioService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private globalService: GlobalService,
  ) {
  }

  ngOnInit() {
    this.carregarProdutos()
    this.carregarMotivosBloqueio()
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = "true"
    this.mostraDetalheAnimacao = "false"
    this.globalService.changeRoute.subscribe(data => {
      this.ocultarDetalhe()
    })
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }
  }

  carregarMotivosBloqueio() {
    this
      .motivoBloqueioService
      .obterMotivosBloqueio()
      .subscribe(
        (data: MotivoBloqueio[]) => {
          this.motivosBloqueio = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }

  }

  selecionarTodos(checkbox: any) {
    this.reembolsos.forEach(element => {
      if (element.permiteEstorno) {
        element.estornar = checkbox.srcElement.checked
      }
    })
  }

  carregarReembolsos(mostrarMensagem: boolean = false) {
    if (this.validarCampos()) {
      this.spinnerService.show()
      this
        .reembolsoService
        .obterReembolsos(
          this.filterIdLote,
          this.filterIdProduto,
          FuncoesApoio.formatarDataInicial(this.filterDtInicial),
          FuncoesApoio.formatarDataFinal(this.filterDtFinal),
          this.filterCpfClientes,
          this.statusReembolso,
          this.filterIdReembolso,
          this.filterIdMotivoBloqueio
        )
        .subscribe(
          (data: ReembolsoConsulta[]) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse = data
              this.spinnerService.hide()
              if (retorno.status == 502) {
                this.reembolsos = []
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                }
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText)
              }

            }
            else {
              this.spinnerService.hide()
              if (data == null) {
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                }
                this.reembolsos = []
              }
              else {
                this.reembolsos = data
              }
            }
          }
        ),
        error => {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
        }

    }
  }

  deletarReembolsos() {
    let qtdeAlteracao: number
    let registroAtual: number = 1

    this.spinnerService.show()

    let ids = this.reembolsos.map(function (item) {
      return { idReembolso: item.idReembolso, estornar: item.estornar }
    }).filter(x => x.estornar == true)

    qtdeAlteracao = ids.length

    let loop = (id: any) => {
      this.msgSpinner = "Estornando registro " + registroAtual + " de " + qtdeAlteracao
      this.reembolsoService.deletarReembolso(id.idReembolso).subscribe(
        data => {
          if (data instanceof HttpErrorResponse) {
            this.spinnerService.hide()
            this.mensagem.mensagemOkModal("Erro ao estornar o reembolso " + id.idReembolso + " alguns registros não puderam ser deletados.<br><br>")
            this.carregarReembolsos()
            return
          }
          else {
            if (ids.length == 0) {
              this.spinnerService.hide()
              this.mensagem.mensagemOkModal("Registros estornados com sucesso.")
              this.carregarReembolsos()
            }
            else {
              registroAtual++
              loop(ids.shift())
            }
          }
        },
        error => {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Erro ao estornar o reembolso " + id.idReembolso + " alguns registros não puderam ser deletados.<br><br>" + error)
          this.carregarReembolsos()
          return
        },
      )
    }

    loop(ids.shift())
  }

  public deletarReembolso(idReembolso: number) {
    this.spinnerService.show()
    this.reembolsoService.deletarReembolso(idReembolso).subscribe(
      data => {
        if (data instanceof HttpErrorResponse) {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Erro ao estornar o reembolso: " + data.statusText)
          return
        }
        else {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Registro estornado com sucesso.")
          this.carregarReembolsos()
        }
      },
      error => {
        this.spinnerService.hide()
        this.mensagem.mensagemOkModal(error)
      },
    )

  }

  
  confirmarDeletarReembolso(idReembolso: number) {
    const _self = this
    this.mensagem.mensagemOkNoModal("Deseja estornar o reembolso ",
      function () {
        _self.deletarReembolso(idReembolso)
      })
  }

  confirmarDeletarReembolsos() {
    const _self = this
    this.mensagem.mensagemOkNoModal("Deseja estornar os reembolsos selecionados ?",
      function () {
        _self.deletarReembolsos()
      })
  }

  mostrarDetalhe(idReembolso: number) {
    this.mostraDetalhe = true
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()

    this.detalheReembolso.obterReembolso(idReembolso)
  }

  ocultarDetalhe() {
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  montarStatusReembolso() {
    let retorno = this.statusReembolsos.find(item => item.entrada === this.filterStatusReembolso)
    return retorno.saida.split(",")
  }

  limparFiltros() {
    this.filterIdLote = ""
    this.filterIdReembolso = ""
    this.filterIdProduto = ""
    this.filterDtInicial = null
    this.filterDtFinal = null
    this.filterCpfClientes = ""
    this.filterStatusReembolso = null
    this.statusReembolso = undefined
    this.msgSpinner = ""
    this.filterIdMotivoBloqueio = null
  }

  ordenarCampos(propriedade: string) {
    if (this.sortAscendente) {
      this.reembolsos.sort((a, b) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
    }
    else {
      this.reembolsos.sort((b, a) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
    }

    this.sortAscendente = !this.sortAscendente
  }

  validarCampos() {
    let mensagemRetorno: string = ""

    if (this.filterCpfClientes == undefined) {
      this.filterCpfClientes = ""
    }

    if(this.filterIdProduto == undefined || this.filterIdProduto.trim() == ""){
      this.filterIdProduto = ""
    }

    if (this.filterStatusReembolso == undefined || this.filterStatusReembolso == null) {
      this.statusReembolso = []
    }
    else {
      this.statusReembolso = this.montarStatusReembolso()
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null
      this.filterDtFinal = null
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>"
      }
    }

    if (this.txtDataInicial.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Inicial inválida.<br>"
    }

    if (this.txtDataFinal.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Final inválida.<br>"
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }
}

