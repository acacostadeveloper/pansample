import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core'
import { AngularFileUploaderComponent } from "angular-file-uploader"
import { ElementRef } from '@angular/core'
import { ReembolsoService } from '../reembolso.service'
import { Reembolso } from '../../models/reembolso.model'
import { environment } from '../../../environments/environment'
import { FormControl, Validators } from '@angular/forms'
import { ProdutoService } from '../../produto/produto.service'
import { Produto } from '../../models/produto.model'
import { ModalDialogService } from 'ngx-modal-dialog'
import { Sigla } from '../../models/sigla.model'
import { SiglaService } from '../../sigla/sigla.service'
import { HttpErrorResponse } from '@angular/common/http'
import { PopUpModal } from '../../Helpers/popUpModal'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'
import { ProcessoRegistro } from '../../models/processoRegistro.model'
import { ProcessoRegistroService } from '../../processo-registro/processo-registro.service'
import { fadeInOut } from '../../Helpers/animacoes'
import { AuthService } from '../../guards/auth.service';
import { UploadFile } from '../../models/uploadFile.model';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';

@Component({
  selector: 'pan-incluir-reembolso',
  templateUrl: './incluir-reembolso.component.html',
  styleUrls: ['./incluir-reembolso.component.css'],
  animations: [ fadeInOut ]
})
export class IncluirReembolsoComponent implements OnInit {
  @ViewChild("txtUploader")
  private txtUploader: ElementRef

  @ViewChild('fileUpload1')
  private fileUpload1: AngularFileUploaderComponent

  @ViewChild("form")
  private form: ElementRef

  @ViewChild("txtValor")
  private txtValor: ElementRef

  @ViewChild("txtCpf")
  private txtCpf: ElementRef

  @ViewChild("txtArquivo")
  public txtArquivo: ElementRef

  rateControl = new FormControl("", [Validators.max(100), Validators.min(0)])

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)

  nomeCliente: string
  reembolso = new Reembolso()
  produtos: Produto[]
  processosRegistro: ProcessoRegistro[]
  siglas: Sigla[]

  meses = environment.meses
  anoAtual: number = (new Date()).getFullYear()
  anos: number[] = []
  mostrarLinkLote: boolean = false
  idLote: number

  public hasBaseDropZoneOver: boolean = false
  public hasAnotherDropZoneOver: boolean = false
  public successUpLoad: any
  public errorUpLoad: any
  
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e
  }

  constructor(
    private reembolsoService: ReembolsoService,
    private produtoService: ProdutoService,
    private processoRegistroService: ProcessoRegistroService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private siglaService: SiglaService,
    private spinnerService: Ng4LoadingSpinnerService,
    private authService: AuthService
  ) { }

  ngOnInit():
    void {
    this.spinnerService.show()
    this.carregarAnos()
    this.carregarProdutos()
    this.carregarProcessosRegistro()
    this.carregarSiglas()
    this.inicializaCombos()
    this.spinnerService.hide()
  }

  validaCamposLote() {
    let mensagemRetorno: string = "";

    if (this.txtArquivo.nativeElement.files.length == 0) {
      mensagemRetorno = mensagemRetorno + "- Favor informar o arquivo.<br>";
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  inserirReembolsoLote() {
    var arquivo: string
    var self = this
    if (this.validaCamposLote()) {
      this.spinnerService.show();

      var uploadFile: UploadFile = new UploadFile()

      var reader = new FileReader();
      reader.readAsArrayBuffer(this.txtArquivo.nativeElement.files[0])
      uploadFile.nomeDocumento = this.txtArquivo.nativeElement.files[0].name

      reader.onload = function (e, http = this.http) {
        var arrayBuffer = reader.result;

        var bytes = FuncoesApoio.arrayBufferToBase64String(<ArrayBuffer>arrayBuffer)

        uploadFile.arrayBytesDocumento = bytes

        self.reembolsoService.adicionarReembolsoLote(uploadFile).subscribe(
          data => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data
              self.spinnerService.hide()
              self.mensagem.mensagemOkModal("Ocorreu o erro ao fazer o upload do arquivo:<br><br>" + data.statusText)
              self.mostrarLinkLote = false
            }
            else {
              self.spinnerService.hide()
              if (data.Success == false) {
                self.mensagem.mensagemOkModal("Ocorreu o erro ao fazer o upload do arquivo:<br><br>" + data.MessageError)
                self.mostrarLinkLote = false
              }
              else {
                self.mensagem.mensagemOkModal("Arquivo enviado com sucesso. Lote de retorno: " + data)
                self.idLote = data
                self.mostrarLinkLote = true
                self.txtArquivo.nativeElement.value = ""
              }
            }
          },
          error => {
            self.spinnerService.hide();
            self.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
            self.mostrarLinkLote = false
          },
        );
      }
    }
  }

  inserirReembolso() {
    if (this.validaCampos()) {

      this.spinnerService.show()

      this.reembolso.contrato.cliente.tipoPessoa = "F"
      this.reembolso.departamento.codigoDepartamento = environment.codigoDepartamento
      this.reembolso.contrato.coligada.codigoColigada = environment.codigoColigada
      
      //retirar colocado para teste
      this.reembolso.usuarioInclusao = this.authService.usuario.userId

      this.reembolsoService.adicionarReembolso(this.reembolso).subscribe(
        data => {
          if (data instanceof HttpErrorResponse) {
            this.mensagem.mensagemOkModal("Ocorreu o erro ao inserir o reembolso: " + data.statusText)
          }
          else {
            if (data.Success == true) {
              this.mensagem.mensagemOkModal("Registro inserido com sucesso")
            }
            else
            {
              this.mensagem.mensagemOkModal("Ocorreu o erro ao inserir o reembolso: " + data.MessageError)
            }
          }
          this.spinnerService.hide()
        },
        error => {
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
          this.spinnerService.hide()
        },
      )
    }
  }

  DocUpload(response: any){
    if (response.status == 200)
    {
      this.mensagem.mensagemOkModal("Arquivo enviado com sucesso. Lote de retorno: " + response.response)
      this.idLote = response.response
      this.mostrarLinkLote = true

    }
    else
    {
      this.mensagem.mensagemOkModal("Não foi possível dar o upload do arquivo: " + response.statusText)
      this.mostrarLinkLote = false
    }
  }

  validaCampos() {
    let mensagemRetorno: string = ""

    if (this.reembolso.contrato.cliente.nomeCliente == "" ||
      this.reembolso.contrato.cliente.nomeCliente == undefined ||
      this.reembolso.contrato.cliente.nomeCliente == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Nome deve ser preenchido.<br>"
    }

    if (this.reembolso.contrato.numeroContrato == "" ||
      this.reembolso.contrato.numeroContrato == undefined ||
      this.reembolso.contrato.numeroContrato == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número Contrato deve ser preenchido.<br>"
    }

    if (this.reembolso.valorReembolso == "" ||
      this.reembolso.valorReembolso == undefined ||
      this.reembolso.valorReembolso == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Valor Reembolso deve ser preenchido.<br>"
    }

    if (this.reembolso.contrato.convenio == "" ||
      this.reembolso.contrato.convenio == undefined ||
      this.reembolso.contrato.convenio == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Convênio deve ser preenchido.<br>"
    }

    if (this.reembolso.mesCompetencia == undefined ||
      this.reembolso.mesCompetencia == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Mês deve ser preenchido.<br>"
    }

    if (this.reembolso.anoCompetencia == undefined ||
      this.reembolso.anoCompetencia == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Ano deve ser preenchido.<br>"
    }

    if (this.reembolso.contrato.cliente.numeroCpfCnpj == "" ||
      this.reembolso.contrato.cliente.numeroCpfCnpj == undefined ||
      this.reembolso.contrato.cliente.numeroCpfCnpj == null) {
      mensagemRetorno = mensagemRetorno + "- Campo CPF deve ser preenchido.<br>"
    }

    if (this.reembolso.sigla.codigoSigla == "" ||
      this.reembolso.sigla.codigoSigla == undefined ||
      this.reembolso.sigla.codigoSigla == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Sigla deve ser preenchido.<br>"
    }

    if (this.reembolso.processoRegistro.codigoProcessoRegistro == "" ||
      this.reembolso.processoRegistro.codigoProcessoRegistro == undefined ||
      this.reembolso.processoRegistro.codigoProcessoRegistro == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Código Processo Entrada deve ser preenchido.<br>"
    }

    if (this.reembolso.contrato.produto.codigoProduto == "" ||
      this.reembolso.contrato.produto.codigoProduto == undefined ||
      this.reembolso.contrato.produto.codigoProduto == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Produto deve ser preenchido.<br>"
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }

  carregarAnos() {
    for (let i = this.anoAtual - 10; i < this.anoAtual; i++) {
      this.anos.push(i + 1);
    }
  }

  carregarSiglas() {
    this
      .siglaService
      .obterSiglas()
      .subscribe(
        (data: Sigla[]) => {
          this.siglas = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + " ao carregar as siglas")
      }
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + " ao carregar os produtos")
      }
  }

  carregarProcessosRegistro() {
    this
      .processoRegistroService
      .obterProcessos()
      .subscribe(
        (data: ProcessoRegistro[]) => {
          this.processosRegistro = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + " ao carregar os processos de registro")
      }
  }

  inicializaCombos() {
    this.reembolso.contrato.produto.codigoProduto = null
    this.reembolso.mesCompetencia = null
    this.reembolso.anoCompetencia = this.anoAtual
    this.reembolso.sigla.codigoSigla = null
    this.reembolso.processoRegistro.codigoProcessoRegistro = null
  }

  limparCampos() {
    this.reembolso = new Reembolso()
    this.inicializaCombos()
    this.txtValor.nativeElement.value = ""
    this.txtCpf.nativeElement.value = ""
    this.mostrarLinkLote = false
  }

}


