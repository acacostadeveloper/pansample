import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { Reembolso } from '../../models/reembolso.model';
import { AlterarDadosBancariosComponent } from '../../dados-bancarios/alterar-dados-bancarios/alterar-dadosBancarios.component';
import { ConsultaDadosBancarios } from '../../models/DadosBancarios/consultaDadosBancarios.model';
import { ModalDialogService } from 'ngx-modal-dialog';
import { HistoricoPagamento } from '../../models/historicoPagamento.model';
import { PopUpModal } from '../../Helpers/popUpModal';

@Component({
  selector: 'pan-detalhe-reembolso',
  templateUrl: './detalhe-reembolso.component.html',
  styleUrls: ['./detalhe-reembolso.component.css']
})
export class DetalheReembolsoComponent implements OnInit {
  @ViewChild("dadosBancariosComponent")
  public dadosBancariosComponent: AlterarDadosBancariosComponent

  reembolso = new Reembolso()
  historicoPagamentos: HistoricoPagamento[]
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)

  sortAscendente: boolean = true

  pageHistorico: number = 1
  pageComunicacao: number = 1
  pagePagamentos: number = 1
  collection: any[] = this.reembolso.historicoReembolso

  @Output() fechaDetalhe = new EventEmitter<any>()

  fecharDetalhe() {
    this.fechaDetalhe.next()
  }

  constructor(
    private reembolsoService: ReembolsoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
  ) {

  }

  ngOnInit() {

  }

  public obterReembolso(idReembolso: number) {
    this
      .reembolsoService
      .obterReembolso(
        idReembolso
      )
      .subscribe(
        (data: Reembolso) => {
          if(data!=null){
          this.reembolso = data
          this.preencheDados()
          }
          else {
            this.mensagem.mensagemOkModal("Ocorreu um erro ao carregar o detalhe do reembolso")    
          }
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }
  }

  ordenarCampos(propriedade: string) {
    if (propriedade == "evento.codigoEvento") {
      if (this.sortAscendente) {
        this.reembolso.historicoReembolso.sort((a, b) => a.evento.codigoEvento < b.evento.codigoEvento ? -1 : a.evento.codigoEvento > b.evento.codigoEvento ? 1 : 0)
      }
      else {
        this.reembolso.historicoReembolso.sort((b, a) => a.evento.codigoEvento < b.evento.codigoEvento ? -1 : a.evento.codigoEvento > b.evento.codigoEvento ? 1 : 0)
      }
    }
    else {
      if (this.sortAscendente) {
        this.reembolso.historicoReembolso.sort((a, b) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
      }
      else {
        this.reembolso.historicoReembolso.sort((b, a) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
      }
    }

    this.sortAscendente = !this.sortAscendente
  }

  obterHistoricoPagamentos(){
      this
        .reembolsoService
        .obterHistoricoPagamentos(
          this.reembolso.idReembolso
        )
        .subscribe(
        (data: HistoricoPagamento[]) => {
            this.historicoPagamentos = data
          }
        ),
        error => {
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
        }
  }

  preencheDados() {
    this.dadosBancariosComponent.consultaDadosBancarios = ConsultaDadosBancarios.preencheDadosBancarios(this.reembolso.contrato.cliente)
    this.dadosBancariosComponent.fieldsLock = true

    this.obterHistoricoPagamentos()
    
  }
}
