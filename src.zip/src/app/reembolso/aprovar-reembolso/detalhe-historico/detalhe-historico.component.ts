import { Component, OnInit, Input } from '@angular/core';
import { HistoricoPagamentosAprovar } from '../../../models/AprovarReembolso/historicoPagamentosAprovar.model';

@Component({
  selector: 'pan-detalhe-historico',
  templateUrl: './detalhe-historico.component.html'
})
export class DetalheHistoricoComponent implements OnInit {
  public historico: HistoricoPagamentosAprovar;

  @Input() historicoDetalhe: HistoricoPagamentosAprovar

  constructor() {

  }

  ngOnInit() {
    this.historico = this.historicoDetalhe
  }
}
