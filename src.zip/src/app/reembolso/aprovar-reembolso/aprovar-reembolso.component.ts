import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef, HostListener } from '@angular/core'
import { ReembolsoService } from '../reembolso.service'
import { ModalDialogService } from 'ngx-modal-dialog'
import { IMyDpOptions } from 'mydatepicker'
import { FuncoesApoio } from '../../Helpers/funcoesApoio'
import { HttpErrorResponse } from '@angular/common/http'
import { PagamentosARealizar } from '../../models/AprovarReembolso/pagamentosARealizar.model'
import { HistoricoPagamentosAprovar } from '../../models/AprovarReembolso/historicoPagamentosAprovar.model'
import { AprovarPagamentos } from '../../models/AprovarReembolso/aprovarPagamentos.model'
import { PopUpModal } from '../../Helpers/popUpModal'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'
import { EnvioStatusPagamento } from '../../models/AprovarReembolso/EnvioStatusPagamento'
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { fadeInOut } from '../../Helpers/animacoes'
import { DetalheHistoricoComponent } from './detalhe-historico/detalhe-historico.component'
import { AuthService } from '../../guards/auth.service'
import { saveAs } from 'file-saver'

@Component({
  selector: 'pan-aprovar-reembolso',
  templateUrl: './aprovar-reembolso.component.html',
  styleUrls: ['./aprovar-reembolso.component.css'],
  animations: [fadeInOut]
})
export class AprovarReembolsoComponent implements OnInit {

  @ViewChild("btnMotivoRejeitado")
  private btnMotivoRejeitado: ElementRef

  @ViewChild("btnRejeitar")
  private btnRejeitar: ElementRef

  @ViewChild("cmbMotivo")
  private cmbMotivo: ElementRef

  @ViewChild("chkSelecionarTodos")
  private chkSelecionarTodos: ElementRef

  @ViewChild("historicoComponent")
  private historicoComponent: DetalheHistoricoComponent

  public reembolsos: PagamentosARealizar[] = []
  reembolso = new PagamentosARealizar()
  historico: HistoricoPagamentosAprovar
  motivosRejeicao: string[] = []
  funcaoRejeitar: Function
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)
  qtdeEstornar: number
  valorTotalEstornar: number
  valorTotalMedio: number
  valorMaior: number
  public form: FormGroup
  sortAscendente: boolean = true
  mostraPainelCongelado: boolean = false
  msgSpinner: string

  p: number = 1
  collection: any[] = this.reembolsos

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }

  constructor(
    private formBuilder: FormBuilder,
    public el: ElementRef,
    private reembolsoService: ReembolsoService,
    private modalService: ModalDialogService,
    private spinnerService: Ng4LoadingSpinnerService,
    private viewRef: ViewContainerRef,
    private authService: AuthService) {
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    const componentPosition = this.el.nativeElement.offsetTop
    const scrollPosition = window.pageYOffset
    if (scrollPosition >= 400) {
      this.mostraPainelCongelado = true
    } else {
      this.mostraPainelCongelado = false
    }

  }

  iniciarDatas(): void {
    let date: Date = new Date()
    this.form.patchValue({ filterDtInicial: { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } } })
    this.form.patchValue({ filterDtFinal: { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } } })
  }

  ngOnInit() {
    this.qtdeEstornar = this.reembolsos.map(reembolsos => reembolsos.selecionado).length

    this.form = this.formBuilder.group({
      filterDtInicial: [null, Validators.required],
      filterDtFinal: [null, Validators.required]
    })

    this.iniciarDatas()
  }

  ordenarCampos(propriedade: string) {
    if (this.sortAscendente) {
      this.reembolsos.sort((a, b) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
    }
    else {
      this.reembolsos.sort((b, a) => a[propriedade] < b[propriedade] ? -1 : a[propriedade] > b[propriedade] ? 1 : 0)
    }

    this.sortAscendente = !this.sortAscendente
  }

  atualizarInformacoes() {

    this.valorTotalEstornar = 0
    this.valorMaior = 0
    this.valorTotalMedio = 0

    this.qtdeEstornar = this.reembolsos.map(reembolsos => reembolsos.selecionado).filter(x => x == true).length

    var valoresTotais = this.reembolsos.map(function (item) {
      return { valor: item.valor, selecionado: item.selecionado }
    })

    valoresTotais.forEach(element => {
      if (element.selecionado == true) {
        if (element.valor > this.valorMaior) {
          this.valorMaior = element.valor
        }
        this.valorTotalEstornar = this.valorTotalEstornar + element.valor
      }
    })

    this.valorTotalMedio = this.valorTotalEstornar / this.qtdeEstornar
  }

  limparFiltros() {
    this.iniciarDatas()
    this.msgSpinner = ""
  }

  selecionarTodos(checkbox: any) {
    this.reembolsos.forEach(element => {
      element.selecionado = checkbox.srcElement.checked
    })
    this.atualizarInformacoes()
  }

  confirmarStatusReembolsos(mensagem: string, aprovar: boolean) {
    const _self = this

    this.mensagem.mensagemOkNoModal(mensagem,
      function () { _self.alterarStatusReembolsos(aprovar) })
  }

  confirmarStatusReembolso(reembolso: PagamentosARealizar, mensagem: string, aprovar: boolean) {
    const _self = this

    this.mensagem.mensagemOkNoModal(mensagem,
      function () { _self.alterarStatusReembolso(reembolso, aprovar) }
    )
  }

  alterarStatusReembolsos(aprovar: boolean) {
    this.spinnerService.show()
    let qtdeAlteracao: number
    let registroAtual: number = 1

    let ids = this.reembolsos.map(function (item) {
      return { numeroCpfCnpj: item.numeroCpfCnpj, selecionado: item.selecionado, ids: item.ids }
    }).filter(x => x.selecionado == true)

    qtdeAlteracao = ids.length

    let mensagem: string

    if (!aprovar) {
      mensagem = "Mensagem reprovação padrão"
    }

    let loop = (reembolso: any) => {
      this.msgSpinner = "Alterando registro " + registroAtual + " de " + qtdeAlteracao
      this.reembolsoService.aprovarReembolso(this.montarModelAprovar(reembolso, aprovar, mensagem)).subscribe(
        (data) => {
          if (data instanceof HttpErrorResponse) {
            this.spinnerService.hide()
            this.mensagem.mensagemOkModal("Erro ao alterar o reembolso de cpf/cnpj:" + reembolso.numeroCpfCnpj + ", " + data.statusText + " alguns registros não puderam ser alterados.")
            this.carregarPagamentosARealizar()
            return
          }
          else {
            if (ids.length == 0) {
              this.spinnerService.hide()
              this.mensagem.mensagemOkModal("Status alterados com sucesso.")
              this.carregarPagamentosARealizar()
            }
            else {
              registroAtual++
              loop(ids.shift())
            }
          }
        },
        error => {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Erro ao alterar o reembolso de cpf/cnpj:" + reembolso.numeroCpfCnpj + " alguns registros não puderam ser alterados.<br><br>" + error)
          this.carregarPagamentosARealizar()
          return
        },
      )
    }
    loop(ids.shift())
  }

  alterarStatusReembolso(reembolso: PagamentosARealizar, aprovar: boolean) {
    this.spinnerService.show()
    let mensagem: string

    if (!aprovar) {
      mensagem = "Mensagem reprovação padrão"
    }

    this.reembolsoService.aprovarReembolso(this.montarModelAprovar(reembolso, aprovar, mensagem)).subscribe(
      data => {
        if (data instanceof HttpErrorResponse) {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Erro ao alterar o reembolso de cpf/cnpj:" + reembolso.numeroCpfCnpj + ", " + data.statusText + " o processo será abortado")
          return
        }
        else {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Status Reembolso alterado com sucesso.")
          this.carregarPagamentosARealizar()
        }
      },
      error => {
        this.spinnerService.hide()
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      },
    )
  }

  montarModelAprovar(reembolso: PagamentosARealizar, aprovar: boolean, mensagemErro?: string): EnvioStatusPagamento {
    let pagamentosALiberar: EnvioStatusPagamento = new EnvioStatusPagamento()

    pagamentosALiberar.ids = reembolso.ids.slice()
    pagamentosALiberar.mensagemErro = mensagemErro

    if (aprovar) {
      pagamentosALiberar.status = "PagamentoLiberado"
    }
    else {
      pagamentosALiberar.status = "Bloqueado"
    }
    pagamentosALiberar.usuario = this.authService.usuario.userId
    pagamentosALiberar.numeroCpfCnpj = reembolso.numeroCpfCnpj

    return pagamentosALiberar
  }

  validarCampos() {
    let mensagemRetorno: string = ""

    if (!this.form.valid) {
      mensagemRetorno = mensagemRetorno + "- Campos inválidos.<br>"
    }

    if (this.form.get('filterDtInicial').value == undefined || this.form.get('filterDtInicial').value == null ||
      this.form.get('filterDtFinal').value == undefined || this.form.get('filterDtFinal').value == null) {
      mensagemRetorno = mensagemRetorno + "- Informe as datas para consulta.<br>"
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.form.get('filterDtInicial').value, this.form.get('filterDtFinal').value)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>"
      }
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }

  exportarCSV() {
    var fileName: string
    this.msgSpinner = ""

    if (this.validarCampos()) {
      this.spinnerService.show()

      fileName = "Pagtos" + "_" + FuncoesApoio.formatarDataDDMMYYYY(this.form.get('filterDtInicial').value)
      fileName = fileName + "_" + FuncoesApoio.formatarDataDDMMYYYY(this.form.get('filterDtInicial').value) + ".csv"

      this
        .reembolsoService
        .exportarCSV(
          FuncoesApoio.formatarDataInicial(this.form.get('filterDtInicial').value),
          FuncoesApoio.formatarDataFinal(this.form.get('filterDtFinal').value)
        )
        .subscribe(res => {
          saveAs(res, fileName)
          this.spinnerService.hide()
        });
    }
  }

  carregarPagamentosARealizar(mostrarMensagem: boolean = false) {
    this.msgSpinner = ""

    if (this.validarCampos()) {
      this.spinnerService.show()
      this
        .reembolsoService
        .obterPagamentosARealizar(
          FuncoesApoio.formatarDataInicial(this.form.get('filterDtInicial').value),
          FuncoesApoio.formatarDataFinal(this.form.get('filterDtFinal').value)
        )
        .subscribe(
          (data: AprovarPagamentos) => {
            this.spinnerService.hide()
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse
              retorno = data
              if (retorno.status == 502) {
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                }
                this.reembolsos = []
                this.historico = null
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText)
              }

            }
            else {
              this.reembolsos = data.pagamentos
              if (this.reembolsos.length == 0) {
                if (mostrarMensagem) {
                  this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                }
                this.reembolsos = []
                this.historico = null
              }
              else {
                if (data.historicoPagamentos.historico10 != null &&
                  data.historicoPagamentos.historico30 != null &&
                  data.historicoPagamentos.historico60 != null) {

                  this.historico = data.historicoPagamentos

                  if (this.historicoComponent != undefined && data.historicoPagamentos != null) {
                    this.historicoComponent.historico = data.historicoPagamentos
                  }
                  this.atualizarInformacoes()
                }
              }

            }
          }
        ),
        error => {
          this.spinnerService.hide()
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
        }
    }
  }
}
