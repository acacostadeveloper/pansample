import { Injectable, Output, EventEmitter } from '@angular/core'
import { Observable } from 'rxjs'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { tap, catchError } from 'rxjs/operators';
import { FuncoesApoio } from '../Helpers/funcoesApoio';
import { Usuario } from '../models/usuario.model';
import { AppConfig } from '../Helpers/app.config';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public usuario: Usuario

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Authorization': ''
    }),
    withCredentials: true
  };

  obterUsuario(
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}token/getuser`).pipe(
        tap(data => {
          return data
        }),
        catchError(FuncoesApoio.handleError)
      )
  }

  @Output() change: EventEmitter<void> = new EventEmitter();
  @Output() loadSpinner: EventEmitter<string> = new EventEmitter();

  atualizarDados() {
    this.change.emit();
  }

  acionarSpinner(msgSpinner?: string) {
    this.loadSpinner.emit(msgSpinner);
  }

  logout(){
    this.usuario = null
    localStorage.removeItem('currentUser')
    this.atualizarDados()
  }

  public verificarServiceName(serviceName: string): boolean {
    let usuario: Usuario
    let retorno: boolean = false
    
    if (this.usuario != null && this.usuario != undefined) {
      this.usuario.roles.forEach(element => {
        if (element.services != null && element.services != undefined) {
          let service = element.services.find(x => x.serviceName == serviceName)
          if (service != undefined) {
            retorno = true
          }
        }
      })

    }
    return retorno
  }

  public verificarActionName(actionName: string, serviceName: string): boolean {
    let usuario: Usuario
    let retorno: boolean = false

    if (this.usuario != null && this.usuario != undefined) {
      this.usuario.roles.forEach(element => {
        if (element.services != null && element.services != undefined) {
        let service = element.services.find(x => x.serviceName == serviceName)
          if (service != undefined && service != null) {
            let action = service.actions.find(x => x.actionName == actionName)
            if (action != undefined) {
              if (action.active == true) {
                retorno = true
              }
            }
          }
        }
      })
    }
    return retorno
  }

}
