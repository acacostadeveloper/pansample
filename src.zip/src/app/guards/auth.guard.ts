import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Usuario } from '../models/usuario.model';
import { AuthService } from './auth.service';
import { environment } from '../../environments/environment'
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router,
    private authService: AuthService) { }

  usuario: Usuario

  ngOnInit() {

  }

  logUsuario() {
    this.authService.acionarSpinner("Aguarde, realizando processo de autenticação...")
    let retAuth: any
    this.authService.obterUsuario().subscribe(data => {
      if (data instanceof HttpErrorResponse) {
        this.authService.acionarSpinner()
        this.router.navigate(['/erro'], { queryParams: { mensagem: 'Ocorreu o erro: ' + data.statusText + ' ao acessar o sistema. Contate o administrador' } });
      }
      else {
        retAuth = data
        if (retAuth != null && retAuth != undefined) {
          localStorage.setItem('currentUser', JSON.stringify(retAuth))
          this.authService.usuario = JSON.parse(localStorage.getItem('currentUser'))
          this.authService.atualizarDados()
          this.authService.acionarSpinner()
          this.router.navigate(['']);
        }
      }
    })
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (localStorage.getItem('currentUser') == null) {
      this.logUsuario()
    }
    else {
      this.authService.usuario = JSON.parse(localStorage.getItem('currentUser'))
      //verifica se login expirou
      if ((<any>new Date() - <any>new Date(this.authService.usuario.timestamp)) > environment.expiraToken) {
        this.authService.logout()
        this.logUsuario()
      }
      else {
        if (this.authService.verificarServiceName(route.routeConfig.path) || route.routeConfig.path == '') {
          this.authService.usuario = JSON.parse(localStorage.getItem('currentUser'))
          this.authService.atualizarDados()
          return true;
        }
        else {
          this.router.navigate(['/erro'], { queryParams: { mensagem: 'Desculpe, você não esta autorizado a acessar este sistema' } });
        }
      }
    }
    return false;
  }
}
