import { Component, OnInit } from '@angular/core'
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'pan-error',
  templateUrl: './error.component.html'
})
export class ErrorComponent implements OnInit {
  public mensagemError: string

  constructor(
    private route: ActivatedRoute
  ) {
    this.route.queryParams.subscribe(params => {
      this.mensagemError = params['mensagem'];
    });
  }

  ngOnInit() {
  }
}

