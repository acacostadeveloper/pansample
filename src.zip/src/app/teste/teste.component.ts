// import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef } from '@angular/core';
// import { AutoComplete, Payload } from '../models/autoComplete.model';
// import { ClienteService } from '../Cliente/cliente.service';
// import { Cliente } from '../models/cliente.model';

// @Component({
//   selector: 'pan-teste',
//   templateUrl: './teste.component.html'
// })
// export class TesteComponent implements OnInit {
//   public nome: AutoComplete
//   public nomes: Array<AutoComplete> = new Array<AutoComplete>();

//   ngOnInit(): void {
//     this.carregarNomes()
//     this.carregarAutoComplete()
//   }

//   constructor(private clienteService: ClienteService) {

//   }

//   carregarNomes() {


//     this.nome = new AutoComplete()
//     this.nome.id = "1"
//     this.nome.payload = new Payload()
//     this.nome.payload.label = "Joao"

//     this.nomes.push(this.nome)

//     this.nome = new AutoComplete()
//     this.nome.id = "2"
//     this.nome.payload = new Payload()
//     this.nome.payload.label = "Leila"

//     this.nomes.push(this.nome)
//   }

//   carregarAutoComplete() {
//     this
//       .clienteService
//       .obterClientes(
//         null,
//         "sant",
//       )
//       .subscribe(
//         (data: Cliente[]) => {
//           console.log(data)
//           data.forEach(element => {
//             this.nome = new AutoComplete()
//             this.nome.id = element.numeroCpfCnpj
//             this.nome.payload = new Payload()
//             this.nome.payload.label = element.nomeCliente
//             this.nomes.push(this.nome)
//           })
//         }
//       )
//       ;
//   }


//   name = 'Angular 5';
//   selectedItem: any = '';
//   inputChanged: any = '';

//   // items2: any[] = [{id: 0, payload: {label: 'Tom'}},
//   //   {id: 1, payload: {label: 'John'}},
//   //   {id: 2, payload: {label: 'Lisa'}},
//   //   {id: 3, payload: {label: 'Js'}},
//   //   {id: 4, payload: {label: 'Java'}},
//   //   {id: 5, payload: {label: 'c'}},
//   //   {id: 6, payload: {label: 'vc'}}
//   // ];

//   items2: any[] = this.nomes
//   //   {id: 1, payload: {label: 'John'}},
//   //   {id: 2, payload: {label: 'Lisa'}},
//   //   {id: 3, payload: {label: 'Js'}},
//   //   {id: 4, payload: {label: 'Java'}},
//   //   {id: 5, payload: {label: 'c'}},
//   //   {id: 6, payload: {label: 'vc'}}
//   // ];

//   config2: any = { 'placeholder': 'test', 'sourceField': ['payload', 'label'] };

//   onSelect(item: any) {
//     this.selectedItem = item;
//   }

//   onInputChangedEvent(val: string) {
//     this.inputChanged = val;
//   }


// }

