import { APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { ROUTES } from './app.routes';
import { MenuComponent } from './menu/menu.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule } from '@angular/material';
import { IncluirReembolsoComponent } from './reembolso/incluir-reembolso/incluir-reembolso.component'
import { FileUploadModule } from 'ng2-file-upload'
import { AngularFileUploaderModule } from "angular-file-uploader";
import { CurrencyMaskModule } from "ng2-currency-mask";
import { NgxMaskModule } from 'ngx-mask'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ConsultarReembolsoComponent } from './reembolso/consultar-reembolso/consultar-reembolso.component';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalDialogModule } from 'ngx-modal-dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material';
import { MatInputModule } from '@angular/material';
import { MatTableModule } from '@angular/material/table';
import { LOCALE_ID } from '@angular/core';
import localePt from '@angular/common/locales/pt';
import { registerLocaleData } from '@angular/common';
import { DetalheReembolsoComponent } from './reembolso/detalhe-reembolso/detalhe-reembolso.component';
import { AprovarReembolsoComponent } from './reembolso/aprovar-reembolso/aprovar-reembolso.component';
import { DetalheHistoricoComponent } from './reembolso/aprovar-reembolso/detalhe-historico/detalhe-historico.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { NgxPaginationModule } from 'ngx-pagination';
import { AlterarDadosBancariosComponent } from './dados-bancarios/alterar-dados-bancarios/alterar-dadosBancarios.component';
import { ConsultarDadosBancariosComponent } from './dados-bancarios/consultar-dados-bancarios/consultar-dadosBancarios.component';
import { Ng2BRPipesModule } from 'ng2-brpipes';
import { ConsultarClienteComponent } from './Cliente/consultar-cliente/consultar-cliente.component';
import { EnderecoClienteComponent } from './Cliente/endereco-cliente/endereco-cliente.component';
import { TransferenciaDireitoComponent } from './Cliente/transferencia-direito/transferencia-direito.component';
import { RetiradaUsoInternoComponent } from './retirada-uso-interno/retirada-interno.component';
import { DetalheRetiradaInternoComponent } from './retirada-uso-interno/detalhe-retirada-interno/detalhe-retirada-interno.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ConsultarIntegracaoComponent } from './reembolso/consultar-integracao/consultar-integracao.component';
import { AutoCompleteNomeComponent } from './auto-complete-nome/auto-complete-nome.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { WinAuthInterceptor } from './interceptors/winAuthInterceptor';
import { AuthGuard } from './guards/auth.guard';
import { ErrorComponent } from './error/error.component';
import { AccessHiddenDirective } from './access-directive/accessHidden.directive';
import { AccessDisabledDirective } from './access-directive/accessDisabled.directive';
import { EstornarReembolsoComponent } from './reembolso/estornar-reembolso/estornar-reembolso.component';
import { LogoutComponent } from './logout/logout.component';
import { ConsultarRetiradaComponent } from './retirada-uso-interno/consultar-retirada-interno/consultar-retirada.component';
import { SSRSReportViewerModule } from './modules/reportviewer/reportviewer.module';
import { RelResumoMovimentacaoComponent } from './relatorios/rel-resumo-movimentacao/rel-resumo-movimentacao.component';
import { RelPosicaoComponent } from './relatorios/rel-posicao/rel-posicao.component';
import { RelPosicaoEstoqueComponent } from './relatorios/rel-posicao-estoque/rel-posicao-estoque.component';
import { RelEstoqueMotivoBloqueioComponent } from './relatorios/rel-estoque-motivo-bloqueio/rel-estoque-motivo-bloqueio.component';
import { RelHistoricoLoteReembolsoComponent } from './relatorios/rel-historico-lote-reembolso/rel-historico-lote-reembolso.component';
import { RelValorRetiradaConsolidadoComponent } from './relatorios/rel-valor-retirada-consolidado/rel-valor-retirada-consolidado.component';
import { RelValorRetiradaAnaliticoComponent } from './relatorios/rel-valor-retirada-analitico/rel-valor-retirada-analitico.component';
import { RelComunicacaoConsolidadoComponent } from './relatorios/rel-comunicacao-consolidado/rel-comunicacao-consolidado.component';
import { RelReembolsoAnaliticoComponent } from './relatorios/rel-reembolso-analitico/rel-reembolso-analitico.component';
import { AppConfig } from './Helpers/app.config';

registerLocaleData(localePt);

export function initializeApp(appConfig: AppConfig) {
  return () => appConfig.load();
}

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    MenuComponent,
    IncluirReembolsoComponent,
    ConsultarReembolsoComponent,
    EstornarReembolsoComponent,
    DetalheReembolsoComponent,
    AprovarReembolsoComponent,
    DetalheHistoricoComponent,
    AlterarDadosBancariosComponent,
    ConsultarDadosBancariosComponent,
    ConsultarClienteComponent,
    EnderecoClienteComponent,
    TransferenciaDireitoComponent,
    RetiradaUsoInternoComponent,
    DetalheRetiradaInternoComponent,
    ConsultarIntegracaoComponent,
    AutoCompleteNomeComponent,
    ErrorComponent,
    AccessHiddenDirective,
    AccessDisabledDirective,
    LogoutComponent,
    ConsultarRetiradaComponent,
    RelResumoMovimentacaoComponent,
    RelPosicaoComponent,
    RelPosicaoEstoqueComponent,
    RelEstoqueMotivoBloqueioComponent,
    RelHistoricoLoteReembolsoComponent,
    RelValorRetiradaConsolidadoComponent,
    RelValorRetiradaAnaliticoComponent,
    RelComunicacaoConsolidadoComponent,
    RelReembolsoAnaliticoComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(ROUTES, { onSameUrlNavigation: 'reload' }),
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    FileUploadModule,
    AngularFileUploaderModule,
    CurrencyMaskModule,
    NgxMaskModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MyDatePickerModule,
    ModalDialogModule.forRoot(),
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    NgxSpinnerModule,
    Ng4LoadingSpinnerModule.forRoot(),
    NgxPaginationModule,
    Ng2BRPipesModule,
    NgbModule,
    SSRSReportViewerModule
  ],
  exports: [
    MatExpansionModule,
    RouterModule,
    Ng2BRPipesModule
  ],
  providers: [
    AuthGuard,
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: WinAuthInterceptor,
      multi: true
    },
    AppConfig,
       { provide: APP_INITIALIZER,
         useFactory: initializeApp,
         deps: [AppConfig], multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
