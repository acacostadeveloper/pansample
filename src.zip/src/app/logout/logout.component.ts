import { Component } from '@angular/core';
import { AuthService } from '../guards/auth.service';

@Component({
  selector: 'pan-logout',
  templateUrl: './logout.component.html'
})
export class LogoutComponent {
  constructor(
    private authService: AuthService) {
  }

  ngOnInit() {
    this.authService.logout()
  }
}
