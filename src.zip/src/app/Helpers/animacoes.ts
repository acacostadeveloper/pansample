import { trigger, state, animate, transition, style } from '@angular/animations';

export const cabecalhoAnimation =
    trigger('cabecalho', [
        state('true', style({ opacity: '1' })),
        state('false', style({ opacity: '0', display: 'none' })),
        transition('* => true', [animate('500ms ease-out')])
    ])


export const detalheAnimation =
    trigger('detalhe', [
        state('true', style({ opacity: '1' })),
        state('false', style({ opacity: '0', display: 'none' })),
        transition('* => true', [animate('500ms ease-out')])
    ])

export const fadeInOut =
    trigger('fadeInOut', [
        transition(':enter', [   // :enter is alias to 'void => *'
            style({ opacity: 0 }),
            animate(500, style({ opacity: 1 }))
        ]),
        transition(':leave', [   // :leave is alias to '* => void'
            animate(500, style({ opacity: 0 }))
        ])
    ])
