import { IMyDateModel } from "mydatepicker"
import { HttpErrorResponse } from "@angular/common/http"
import { of } from "rxjs"

export class FuncoesApoio {
  static verificarDataFinalMenor(dataInicial, dataFinal) {
    let _dataInicial: IMyDateModel
    let _dataFinal: IMyDateModel

    _dataInicial = dataInicial
    _dataFinal = dataFinal

    if (_dataFinal.epoc < _dataInicial.epoc) {
      return true
    }
    else {
      return false
    }
  }

  static sleep(milliseconds) {
    var start = new Date().getTime()
    for (var i = 0; i < 1e7; i++) {
      if ((new Date().getTime() - start) > milliseconds) {
        break;
      }
    }
  }

  static formatarData(date: IMyDateModel) {
    let retorno: string
    if (date == undefined || date == null) {
      retorno = ""
    }
    else {
      retorno = date.date.month + "/" + date.date.day + "/" + date.date.year
    }
    return retorno
  }

  static formatarDataDD_MM_YYYY(date: IMyDateModel) {
    let retorno: string
    if (date == undefined || date == null) {
      retorno = ""
    }
    else {
      retorno = date.date.day  + "/" + date.date.month + "/" + date.date.year
    }
    return retorno
  }

  static formatarDataDDMMYYYY(date: IMyDateModel) {
    let retorno: string
    if (date == undefined || date == null) {
      retorno = ""
    }
    else {
      retorno = date.date.day.toString() + date.date.month.toString() + date.date.year.toString()
    }
    return retorno
  }

  static formatarDataInicial(date: IMyDateModel) {
    let retorno: string
    if (date == undefined || date == null) {
      retorno = ""
    }
    else {
      retorno = date.date.month + "/" + date.date.day + "/" + date.date.year + " 00:00:00"
    }
    return retorno
  }

  static formatarDataFinal(date: IMyDateModel) {
    let retorno: string
    if (date == undefined || date == null) {
      retorno = ""
    }
    else {
      retorno = date.date.month + "/" + date.date.day + "/" + date.date.year + " 23:59:59"
    }
    return retorno
  }

  static arrayBufferToBase64String(buffer: ArrayBuffer) {
    let binaryString = ''
    var bytes = new Uint8Array(buffer)
    for (var i = 0; i < bytes.byteLength; i++) {
      binaryString += String.fromCharCode(bytes[i]);
    }

    return window.btoa(binaryString)
  }

  static getUrlWithoutParameters(url: string): string {
    return url.substring(0, url.indexOf("?"));
  }

  static handleError(err: HttpErrorResponse) {
    let errorMessage = ''
    if (err.status != 502) { //no content
      if (err.error instanceof ErrorEvent) {
        errorMessage = `Um erro ocorreu: ${err.error.message}`
      } else {
        errorMessage = `Servidor retornou o código: ${err.status}, a mensagem de erro é: ${err.message}`
      }
      console.error(errorMessage)
    }
    return of(err)
  }

  static verificaURLExterna(url: string)
  {
    //TODO: colocar em arquivo de configuracao
    if(FuncoesApoio.getUrlWithoutParameters(url) == "http://cep.bldstools.com/"){
      return true
    }

    return false
  }
}
