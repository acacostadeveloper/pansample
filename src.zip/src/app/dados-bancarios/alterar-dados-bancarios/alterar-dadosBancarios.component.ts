import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef } from '@angular/core';
import { DadosBancariosService } from '../dados-bancarios.service';
import { ConsultaDadosBancarios } from '../../models/DadosBancarios/consultaDadosBancarios.model';
import { HttpErrorResponse } from '@angular/common/http';
import { ModalDialogService } from 'ngx-modal-dialog';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { PopUpModal } from '../../Helpers/popUpModal';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../guards/auth.service';

@Component({
  selector: 'pan-alterar-dados-bancarios',
  templateUrl: './alterar-dadosBancarios.component.html',
  styleUrls: ['./alterar-dadosBancarios.component.css']
})
export class AlterarDadosBancariosComponent implements OnInit {
  public consultaDadosBancarios: ConsultaDadosBancarios
  public fieldsLock: boolean = true

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  tipoContas = environment.TipoConta;

  @Input() public mostrarDadosAdicionais: boolean = true
  @Input() public mostrarBotaoVoltar: boolean = true

  @Output() fechaDetalhe = new EventEmitter<any>();
  @Output() onDadosAlterados = new EventEmitter<any>();
  @Output() onDadosAlteradosErro = new EventEmitter<any>();

  constructor(
    private dadosbancariosService: DadosBancariosService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private authService: AuthService
  ) {

  }

  ngOnInit() {

  }

  alterarBloqueio() {
    if (this.authService.verificarActionName("btnAlterarDadosBancarios", "consultar-dadosBancarios") == false) {
      this.mensagem.mensagemOkModal("Usuário não tem autorização para executar esta ação")
    }
    else {
      this.fieldsLock = !this.fieldsLock
    }
  }

  fecharDetalhe() {
    this.fechaDetalhe.next();
  }

  validaCampos() {
    let mensagemRetorno: string = "";

    if (this.authService.verificarActionName("btnAlterarDadosBancarios", "consultar-dadosBancarios") == false) {
      this.mensagem.mensagemOkModal("Usuário não tem autorização para executar esta ação")
      return false
    }

    this.consultaDadosBancarios.numeroCpfCnpj = this.consultaDadosBancarios.numeroCpfCnpj.trim()
    this.consultaDadosBancarios.tipoConta = this.consultaDadosBancarios.tipoConta.trim()
    this.consultaDadosBancarios.numeroBanco = this.consultaDadosBancarios.numeroBanco.trim()
    this.consultaDadosBancarios.numeroConta = this.consultaDadosBancarios.numeroConta.trim()
    this.consultaDadosBancarios.digitoConta = this.consultaDadosBancarios.digitoConta.trim()
    this.consultaDadosBancarios.numeroAgencia = this.consultaDadosBancarios.numeroAgencia.trim()
    this.consultaDadosBancarios.digitoAgencia = this.consultaDadosBancarios.digitoAgencia.trim()

    if (this.consultaDadosBancarios.numeroCpfCnpj == "" ||
      this.consultaDadosBancarios.numeroCpfCnpj == undefined ||
      this.consultaDadosBancarios.numeroCpfCnpj == null) {
      mensagemRetorno = mensagemRetorno + "- Ocorreu um erro ao localizar o Cpf.<br>";
    }

    if (this.consultaDadosBancarios.tipoConta == "" ||
      this.consultaDadosBancarios.tipoConta == undefined ||
      this.consultaDadosBancarios.tipoConta == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Tipo Conta deve ser preenchido.<br>";
    }

    if (this.consultaDadosBancarios.numeroBanco == "" ||
      this.consultaDadosBancarios.numeroBanco == undefined ||
      this.consultaDadosBancarios.numeroBanco == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número Banco deve ser preenchido.<br>";
    }

    if (this.consultaDadosBancarios.numeroConta == "" ||
      this.consultaDadosBancarios.numeroConta == undefined ||
      this.consultaDadosBancarios.numeroConta == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número Conta deve ser preenchido.<br>";
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  alterarDadosBancarios() {
    if (this.validaCampos()) {

      this.spinnerService.show();
      this.dadosbancariosService.alterarDadosBancarios(this.consultaDadosBancarios).subscribe(
        data => {
          if (data instanceof HttpErrorResponse) {
            var retorno: HttpErrorResponse;
            retorno = data;
            this.spinnerService.hide();
            this.mensagem.mensagemOkModal("Ocorreu o erro ao alterar o dado bancário:<br><br>" + data.statusText);
          }
          else {
            this.spinnerService.hide();
            if (data.Success == true) {
              this.mensagem.mensagemOkModal("Dados alterados com sucesso");
              this.onDadosAlterados.next();
            }
            else {
              this.mensagem.mensagemOkModal("Ocorreu um erro ao alterar os dados bancários:<br><br>" + data.MessageError);
              this.onDadosAlteradosErro.next();
            }
            this.fieldsLock = true;
          }

        },
        error => {
          this.spinnerService.hide();
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
        },
      );
    }
  }
}
