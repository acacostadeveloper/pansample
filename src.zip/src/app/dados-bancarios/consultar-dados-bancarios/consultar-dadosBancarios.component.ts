import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef, ViewChild } from '@angular/core';
import { DadosBancariosService } from '../dados-bancarios.service';
import { ConsultaDadosBancarios } from '../../models/DadosBancarios/consultaDadosBancarios.model';
import { ModalDialogService } from 'ngx-modal-dialog';
import { PopUpModal } from '../../Helpers/popUpModal';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { AlterarDadosBancariosComponent } from '../alterar-dados-bancarios/alterar-dadosBancarios.component';
import { cabecalhoAnimation, detalheAnimation } from '../../Helpers/animacoes';
import { AutoCompleteNomeComponent } from '../../auto-complete-nome/auto-complete-nome.component';

@Component({
    selector: 'pan-consultar-dados-bancarios',
    templateUrl: './consultar-dadosBancarios.component.html',
    animations: [cabecalhoAnimation, detalheAnimation]
})
export class ConsultarDadosBancariosComponent implements OnInit {
    @ViewChild("alterarDadosBancarios")
    public dadosBancariosComponent: AlterarDadosBancariosComponent

    @ViewChild("txtNome")
    public txtNome: AutoCompleteNomeComponent

    public consultasDadosBancarios: ConsultaDadosBancarios[] = []
    consultaDadosBancarios = new ConsultaDadosBancarios()
    consultaDadosBancariosOriginal = new ConsultaDadosBancarios()

    public mostraDetalhe: boolean
    mostraCabecalhoAnimacao: string
    mostraDetalheAnimacao: string

    filterCpfClientes: string
    filterNomeClientes: string

    mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef)

    constructor(
        private dadosbancariosService: DadosBancariosService,
        private modalService: ModalDialogService,
        private viewRef: ViewContainerRef,
        private spinnerService: Ng4LoadingSpinnerService
    ) {

    }

    ngOnInit() {
        this.mostraDetalhe = false;
        this.mostraCabecalhoAnimacao = "true";
        this.mostraDetalheAnimacao = "false";
    }

    ocultarDetalhe() {
        this.mostraDetalhe = false;
        this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
        this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
    }

    mostrarDetalhe(consultaDadosBancarios: ConsultaDadosBancarios) {
        this.mostraDetalhe = true;
        this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
        this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()

        this.dadosBancariosComponent.consultaDadosBancarios = consultaDadosBancarios
        this.consultaDadosBancariosOriginal = Object.assign({}, consultaDadosBancarios)
    }

    onDadosAlteradosErro() {
        this.dadosBancariosComponent.consultaDadosBancarios = this.consultaDadosBancariosOriginal
    }

    limparFiltros() {
        this.filterCpfClientes = ""
        this.filterNomeClientes = ""
    }

    validarCampos() {
        this.filterNomeClientes = this.txtNome.value
        
        let mensagemRetorno: string = ""

        if ((this.filterCpfClientes == undefined || this.filterCpfClientes.trim() == "") &&
            (this.filterNomeClientes == undefined || this.filterNomeClientes.trim() == "")) {
            mensagemRetorno = mensagemRetorno + "- Favor preencher ao menos 1 campo para pesquisa.<br>"
        }

        if (this.filterCpfClientes == undefined || this.filterCpfClientes.trim() == "") this.filterCpfClientes = ""
        if (this.filterNomeClientes == undefined || this.filterNomeClientes.trim() == "") this.filterNomeClientes = ""

        if (this.filterNomeClientes != "" && this.filterNomeClientes.length < 3) {
            mensagemRetorno = mensagemRetorno + "- Campo nome deve ter ao menos 3 caracteres.<br>"
        }

        if (mensagemRetorno == "") {
            return true
        }
        else {
            this.mensagem.mensagemOkModal(mensagemRetorno)
            return false
        }
    }

    carregarDadosBancarios() {
        if (this.validarCampos()) {
            this.spinnerService.show()
            this
                .dadosbancariosService
                .obterDadosBancarios(
                    this.filterCpfClientes,
                    this.filterNomeClientes,
                )
                .subscribe(
                    (data: ConsultaDadosBancarios[]) => {
                        if (data instanceof HttpErrorResponse) {
                            var retorno: HttpErrorResponse = data
                            this.spinnerService.hide();
                            if (retorno.status == 502) {
                                this.consultasDadosBancarios = []
                            }
                            else {
                                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText)
                            }

                        }
                        else {
                            this.spinnerService.hide();
                            if (data == null || data.length == 0) {
                                this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro")
                                this.consultasDadosBancarios = []
                            }
                            else {
                                this.consultasDadosBancarios = data
                            }
                        }
                    }
                ),
                error => {
                    this.spinnerService.hide()
                    this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
                }
        }
    }
}
