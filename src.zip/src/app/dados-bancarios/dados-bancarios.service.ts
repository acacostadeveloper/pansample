import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, tap } from 'rxjs/operators';
import { ConsultaDadosBancarios } from '../models/DadosBancarios/consultaDadosBancarios.model';
import { FuncoesApoio } from '../Helpers/funcoesApoio';
import { AppConfig } from '../Helpers/app.config';

@Injectable({
  providedIn: 'root'
})
export class DadosBancariosService {
  httpOptionsHeader = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*'
    })
  }

  constructor(private http: HttpClient) { }

  alterarDadosBancarios(consultaDadosBancarios: ConsultaDadosBancarios): Observable<any> {
    return this.http.post<ConsultaDadosBancarios[]>(`${AppConfig.settings.apiServer}cliente/conta`, consultaDadosBancarios).pipe(
      catchError(FuncoesApoio.handleError),
    );
  }

  obterDadosBancarios(
    numeroCpfCnpj: string,
    nomeCliente: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}cliente/conta`,
        {
          params: {
            numeroCpfCnpj: numeroCpfCnpj,
            nomeCliente: nomeCliente
          }
        }
      ).pipe(
        tap(data => data),
        catchError(FuncoesApoio.handleError)
      )
  }
}
