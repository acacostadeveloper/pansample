import { Component, OnInit } from '@angular/core';
import { Usuario } from '../models/usuario.model';
import { AuthService } from '../guards/auth.service';

@Component({
  selector: 'pan-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  usuario: Usuario

  constructor(private authServiceService: AuthService) { }

  mostrarUsuario(){
    if (JSON.parse(localStorage.getItem('currentUser')) != null) {
      this.usuario = JSON.parse(localStorage.getItem('currentUser'));
    }
    else {
      this.usuario = null
    }
  }

  ngOnInit() {
    this.mostrarUsuario()
    this.authServiceService.change.subscribe(data => {
      this.mostrarUsuario()
    });
  }

}
