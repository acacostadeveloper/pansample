import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef, HostListener } from '@angular/core'
import { IMyDateModel, IMyDpOptions, MyDatePicker } from 'mydatepicker';
import { environment } from '../../../environments/environment';
import { PopUpModal } from '../../Helpers/popUpModal';
import { ModalDialogService } from 'ngx-modal-dialog';
import { MotivoBloqueioService } from '../../motivo-bloqueio/motivo-bloqueio.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MotivoBloqueio } from '../../models/motivoBloqueio.model';
import { cabecalhoAnimation, detalheAnimation } from '../../Helpers/animacoes';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { SiglaService } from '../../sigla/sigla.service';
import { Sigla } from '../../models/sigla.model';
import { ProcessoRegistro } from '../../models/processoRegistro.model';
import { ProcessoRegistroService } from '../../processo-registro/processo-registro.service';
import { AppConfig } from '../../Helpers/app.config';
import { MotivoEntrada } from '../../models/motivoEntrada.model';
import { MotivoEntradaService } from '../../motivo-entrada/motivo-entrada.service';

@Component({
  selector: 'pan-rel-posicao-estoque',
  templateUrl: './rel-posicao-estoque.component.html',
  animations: [cabecalhoAnimation, detalheAnimation]
})
export class RelPosicaoEstoqueComponent implements OnInit {
  @ViewChild("btnVisualizar")
  public btnVisualizar: HTMLElement

  @ViewChild("txtDataInicial")
  public txtDataInicial: MyDatePicker

  @ViewChild("txtDataFinal")
  public txtDataFinal: MyDatePicker

  //"SampleMultipleStringParameter": ["Parameter1", "Parameter2"]
  reportServer: string = '';
  reportUrl: string = '';
  showParameters: string = "false"; //true, false, collapsed
  parameters: any
  language: string = "pt-br";
  width: number = 100;
  height: number = 100;
  toolbar: string = "true";

  mostraCabecalhoAnimacao: string
  mostraDetalheAnimacao: string
  mostraDetalhe: boolean

  //Filtros:
  filterDtInicial: IMyDateModel
  filterDtFinal: IMyDateModel
  filterCpfClientes: string
  filterMatricula: string
  filterContrato: string
  filterConvenio: string
  filterStatusReembolso: string
  filterSigla: string
  statusReembolso: string[]
  filterIdMotivoBloqueio: string
  filterIdMotivoEntrada: string
  statusReembolsos = environment.StatusReembolso

  motivosBloqueio: MotivoBloqueio[]
  siglas: Sigla[]
  motivosEntrada: MotivoEntrada[]

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  constructor(
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private motivoBloqueioService: MotivoBloqueioService,
    private motivoEntradaService: MotivoEntradaService,
    private spinnerService: Ng4LoadingSpinnerService,
    private siglaService: SiglaService
  ) { }

  @HostListener('change', ['$event'])
  atualizaRelatorio() {
    this.ocultarDetalhe()
  }

  ngOnInit() {
    this.carregarMotivosBloqueio()
    this.carregarSiglas()
    this.carregarMotivosEntrada()
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = "true"
    this.mostraDetalheAnimacao = "false"
  }

  ocultarDetalhe() {
    this.mostraDetalhe = false
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  mostrarDetalhe() {
    this.mostraDetalhe = true
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  carregarSiglas() {
    this
      .siglaService
      .obterSiglas()
      .subscribe(
        (data: Sigla[]) => {
          this.siglas = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + " ao carregar as siglas")
      }
  }

  carregarMotivosEntrada() {
    this
      .motivoEntradaService
      .obterMotivosEntrada()
      .subscribe(
        (data: MotivoEntrada[]) => {
          this.motivosEntrada = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error + " ao carregar os motivos de entrada")
      }
  }

  carregarMotivosBloqueio() {
    this
      .motivoBloqueioService
      .obterMotivosBloqueio()
      .subscribe(
        (data: MotivoBloqueio[]) => {
          this.motivosBloqueio = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }

  }

  limparFiltros() {
    this.filterDtInicial = null
    this.filterDtFinal = null
    this.filterCpfClientes = null
    this.filterStatusReembolso = null
    this.statusReembolso = undefined
    this.filterIdMotivoBloqueio = null
    this.filterMatricula = null
    this.filterContrato = null
    this.filterConvenio = null
    this.filterSigla = null
    this.filterIdMotivoEntrada = null
    this.ocultarDetalhe()
  }

  validarCampos() {
    let mensagemRetorno: string = ""

    if (this.filterCpfClientes == undefined) {
      this.filterCpfClientes = null
    }

    if (this.filterStatusReembolso == undefined || this.filterStatusReembolso == null) {
      this.statusReembolso = []
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null
      this.filterDtFinal = null
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>"
      }
    }

    if (this.txtDataInicial.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Inicial inválida.<br>"
    }

    if (this.txtDataFinal.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Final inválida.<br>"
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }

  exibirRelatorio() {
    if (this.validarCampos()) {
      this.mostrarDetalhe()
      this.reportServer = AppConfig.settings.apiReports;
      this.reportUrl = 'SSA/RelatorioPosicaoEstoque';
      this.parameters = {
        "dataInclusaoIni": this.filterDtInicial == null ? null : FuncoesApoio.formatarDataDD_MM_YYYY(this.filterDtInicial),
        "dataInclusaoFim": this.filterDtFinal == null ? null : FuncoesApoio.formatarDataDD_MM_YYYY(this.filterDtFinal),
        "cpf": this.filterCpfClientes == null || this.filterCpfClientes.trim() == "" ? null : this.filterCpfClientes,
        "matricula": this.filterMatricula == null || this.filterCpfClientes.trim() == "" ? null : this.filterMatricula,
        "contrato": this.filterContrato == null || this.filterCpfClientes.trim() == "" ? null : this.filterContrato,
        "convenio": this.filterConvenio == null || this.filterCpfClientes.trim() == "" ? null : this.filterConvenio,
        "status": this.filterStatusReembolso == null ? null : this.filterStatusReembolso,
        "sigla": this.filterSigla == null ? null : this.filterSigla,
        "motivoBloqueio": this.filterIdMotivoBloqueio == null ? null : this.filterIdMotivoBloqueio,
        "motivoEntrada": this.filterIdMotivoEntrada == null ? null : this.filterIdMotivoEntrada,
      };
    }
  }
}
