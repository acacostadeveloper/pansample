import { Component, OnInit, ViewContainerRef, ViewChild, ElementRef, HostListener } from '@angular/core'
import { IMyDateModel, IMyDpOptions, MyDatePicker } from 'mydatepicker';
import { environment } from '../../../environments/environment';
import { PopUpModal } from '../../Helpers/popUpModal';
import { ModalDialogService } from 'ngx-modal-dialog';
import { MotivoBloqueioService } from '../../motivo-bloqueio/motivo-bloqueio.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MotivoBloqueio } from '../../models/motivoBloqueio.model';
import { cabecalhoAnimation, detalheAnimation } from '../../Helpers/animacoes';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { SiglaService } from '../../sigla/sigla.service';
import { Sigla } from '../../models/sigla.model';
import { ProcessoRegistro } from '../../models/processoRegistro.model';
import { ProcessoRegistroService } from '../../processo-registro/processo-registro.service';
import { AppConfig } from '../../Helpers/app.config';

@Component({
  selector: 'pan-rel-historico-lote-reembolso',
  templateUrl: './rel-historico-lote-reembolso.component.html',
  animations: [cabecalhoAnimation, detalheAnimation]
})
export class RelHistoricoLoteReembolsoComponent implements OnInit {
  @ViewChild("btnVisualizar")
  public btnVisualizar: HTMLElement

  @ViewChild("txtDataInicial")
  public txtDataInicial: MyDatePicker

  @ViewChild("txtDataFinal")
  public txtDataFinal: MyDatePicker

  //"SampleMultipleStringParameter": ["Parameter1", "Parameter2"]
  reportServer: string = '';
  reportUrl: string = '';
  showParameters: string = "false"; //true, false, collapsed
  parameters: any
  language: string = "pt-br";
  width: number = 100;
  height: number = 100;
  toolbar: string = "true";

  mostraCabecalhoAnimacao: string
  mostraDetalheAnimacao: string
  mostraDetalhe: boolean

  //Filtros:
  filterDtInicial: IMyDateModel
  filterDtFinal: IMyDateModel
  filterLote: string
  filterUsuarioInclusao: string
  
  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  constructor(
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private siglaService: SiglaService
  ) { }

  @HostListener('change', ['$event'])
  atualizaRelatorio() {
    this.ocultarDetalhe()
  }

  ngOnInit() {
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = "true"
    this.mostraDetalheAnimacao = "false"
  }

  ocultarDetalhe() {
    this.mostraDetalhe = false
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  mostrarDetalhe() {
    this.mostraDetalhe = true
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  limparFiltros() {
    this.filterDtInicial = null
    this.filterDtFinal = null
    this.filterLote = null
    this.filterUsuarioInclusao = null
    this.ocultarDetalhe()
  }

  validarCampos() {
    let mensagemRetorno: string = ""

    if (this.filterLote == undefined) {
      this.filterLote = null
    }

    if (this.filterUsuarioInclusao == undefined) {
      this.filterUsuarioInclusao = null
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null
      this.filterDtFinal = null
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>"
      }
    }

    if (this.txtDataInicial.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Inicial inválida.<br>"
    }

    if (this.txtDataFinal.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Final inválida.<br>"
    }

    if (mensagemRetorno == "") {
      return true
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno)
      return false
    }
  }

  exibirRelatorio() {
    if (this.validarCampos()) {
      this.mostrarDetalhe()
      this.reportServer = AppConfig.settings.apiReports;
      this.reportUrl = 'SSA/RelatorioHistoricoLoteReembolso';
      this.parameters = {
        "dt_inclusaoInicial": this.filterDtInicial == null ? null : FuncoesApoio.formatarDataDD_MM_YYYY(this.filterDtInicial),
        "dt_inclusaoFinal": this.filterDtFinal == null ? null : FuncoesApoio.formatarDataDD_MM_YYYY(this.filterDtFinal),
        "lote": this.filterLote == null || this.filterLote.trim() == "" ? null : this.filterLote,
        "usuarioInclusao": this.filterUsuarioInclusao == null || this.filterUsuarioInclusao.trim() == "" ? null : this.filterUsuarioInclusao,
      };
    }
  }
}
