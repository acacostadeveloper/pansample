export class ProcessoRegistro {
    codigoProcessoRegistro: string
    processoRegistro: string
}