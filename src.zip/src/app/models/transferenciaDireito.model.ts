import { Cliente } from "./cliente.model"
import { ContaCredito } from "./contaCredito.model"

export class TransferenciaDireito {
    idTransferenciaDireito: number
    cliente: Cliente = new Cliente()
    numeroCpfCnpj: string
    sequenciaCpfCnpj: string
    tipoPesssoa: string
    nome: string
    contaCreditoTerceiro: ContaCredito = new ContaCredito()
    dtInicioVigencia: string
    dtFimVigencia?: string
    indicadorAtivo: string
    usuarioInclusao: string
    documento: string
    linkDocumento: string
}