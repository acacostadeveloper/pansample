export class ReembolsoConsulta {
    idReembolso: number
    idLote: number
    nomeProduto: string
    dtInclusao: string
    cpfCnpj: string
    codigoContrato: string
    nomeCliente: string
    valorReembolso: string
    statusReembolso: string[] = []
    permiteEstorno: string
    estornar: boolean
    mesCompetencia: number
    anoCompetencia: number
    convenio: string
    descricaoMotivoBloqueio: string
    statusUsuario: string
    indicadorTombado: string
    tipoPagamentoLegado: string
}