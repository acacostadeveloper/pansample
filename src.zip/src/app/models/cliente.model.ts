import { Endereco } from "./endereco.model";
import { ContaCredito } from "./contaCredito.model";

export class Cliente {
    contaCredito: ContaCredito = new ContaCredito()
    endereco: Endereco = new Endereco()
    numeroDDDCelular: string
    numeroCelular: string
    numeroDDDFixo: string
    numeroFixo: string
    numeroCpfCnpj: string
    nomeCliente: string
    tipoPessoa: string
    registroObito: string
    obito: boolean
    matricula: string
}
