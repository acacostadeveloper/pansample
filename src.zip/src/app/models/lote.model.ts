export class Lote{
    idLote: string
    lote: string 
}