import { Produto } from "./produto.model";
import { Cliente } from "./cliente.model";
import { Coligada } from "./coligada.model";
import { HistoricoFinanceiro } from "./historicoFinanceiro.model";

export class Contrato {
    produto: Produto = new Produto() 
    cliente: Cliente = new Cliente()
    coligada: Coligada = new Coligada()
    processoAjuizado: string[]
    numeroContrato: string
    statusContrato: string
    convenio: string
    dataStatus: string
    historicoFinanceiro: HistoricoFinanceiro = new HistoricoFinanceiro()
    
}
