export class MotivoEntrada {
    idMotivoEntrada: number
    descricaoMotivoEntrada: string
    tipoMotivoEntrada: string
    idSigla: number
    dtInclusao: string
    dtAlteracao: string
    indicadorAtivo: string
}
