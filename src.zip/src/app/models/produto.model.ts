import { SistemaProduto } from "./sistemaProduto.model";

export class Produto {
    sistemaProduto: SistemaProduto = new SistemaProduto()
    codigoCarteira: string
    codigoEvento: string
    codigoProduto: string
    nomeProduto: string
}