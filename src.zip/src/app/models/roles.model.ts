
export class Roles {
  roleId: string
  services: Services[]

}

export class Services {
  serviceName: string
  actions: Actions[]
}

export class Actions {
  actionName: string
  active: boolean
}
