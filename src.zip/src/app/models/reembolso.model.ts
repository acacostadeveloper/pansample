import { Departamento } from "./departamento.model"
import { Contrato } from "./contrato.model"
import { Sigla } from "./sigla.model"
import { ProcessoRegistro } from "./processoRegistro.model"
import { Lote } from "./lote.model"
import { HistoricoReembolso } from "./historicoReembolso.model"
import { Comunicacao } from "./comunicacao.model"
import { MotivoBloqueio } from "./motivoBloqueio.model";

export class Reembolso {
  idReembolso: number
  pagamento: string
  usuarioInclusao: string
  usuarioAlteracao: string
  usuarioAprovacao: string
  departamento: Departamento = new Departamento()
  contrato: Contrato = new Contrato()
  dataSolicitacao: string
  numeroReembolso: number
  valorReembolso: string
  mesCompetencia: number
  anoCompetencia: number
  sigla: Sigla = new Sigla()
  lote: Lote = new Lote()
  statusReembolso: string
  processoRegistro: ProcessoRegistro = new ProcessoRegistro()
  integracao: string
  mensagemErro: string
  dtInclusao: string
  permiteEstorno: boolean
  estornar: boolean
  historicoReembolso: Array<HistoricoReembolso> = new Array<HistoricoReembolso>()
  comunicacoes: Array<Comunicacao> = new Array<Comunicacao>()
  motivoBloqueio: MotivoBloqueio  = new MotivoBloqueio()
  statusUsuario: string
  indicadorTombado: string
  tipoPagamentoLegado: string
}

