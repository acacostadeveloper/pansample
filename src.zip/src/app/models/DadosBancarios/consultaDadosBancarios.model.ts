import { Cliente } from "../cliente.model";

export class ConsultaDadosBancarios {
    idCliente: number
    nomeCliente: string
    numeroCpfCnpj: string
    numeroBanco?: string
    numeroAgencia?: string
    digitoAgencia?: string
    numeroConta?: string
    digitoConta?:string
    tipoConta?: string
    fraude?: string

  public static preencheDadosBancarios(cliente: Cliente): ConsultaDadosBancarios  {
      let consultaDadosBancarios = new ConsultaDadosBancarios()

      consultaDadosBancarios.numeroCpfCnpj = cliente.numeroCpfCnpj
      consultaDadosBancarios.nomeCliente = cliente.nomeCliente
      
      if (cliente.contaCredito != null || cliente.contaCredito != undefined) {
        consultaDadosBancarios.tipoConta = cliente.contaCredito.tipoConta == null ? "" : cliente.contaCredito.tipoConta
        consultaDadosBancarios.numeroBanco = cliente.contaCredito.numeroBanco == null ? "" : cliente.contaCredito.numeroBanco
        consultaDadosBancarios.numeroAgencia = cliente.contaCredito.numeroAgencia == null ? "" : cliente.contaCredito.numeroAgencia
        consultaDadosBancarios.digitoAgencia = cliente.contaCredito.digitoAgencia == null ? "" : cliente.contaCredito.digitoAgencia
        consultaDadosBancarios.numeroConta = cliente.contaCredito.numeroConta == null ? "" : cliente.contaCredito.numeroConta
        consultaDadosBancarios.digitoConta = cliente.contaCredito.digitoConta == null ? "" : cliente.contaCredito.digitoConta
      }
      else {
        consultaDadosBancarios.tipoConta = ""
        consultaDadosBancarios.numeroBanco = ""
        consultaDadosBancarios.numeroAgencia = ""
        consultaDadosBancarios.digitoAgencia = ""
        consultaDadosBancarios.numeroConta = ""
        consultaDadosBancarios.digitoConta = ""
      }

      return consultaDadosBancarios
      
    }
}
