export class MotivoRetencao {
    idMotivoRetencao: number
    descricaoMotivoRetencao: string
}