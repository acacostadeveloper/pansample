export class AutoComplete {
    id: string
    payload: Payload
}

export class Payload {
    label:string
}