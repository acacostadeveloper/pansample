import { PagamentoEfetuado } from "./pagamentoEfetuado.model"
import { Reembolso } from "./reembolso.model"

export class ReembolsoResult {
    PagamentoEfetuado: PagamentoEfetuado = new PagamentoEfetuado()
    Reembolsos: Array<Reembolso> = new Array<Reembolso>()
    MessageError: string
}