export class UploadFile {
  nomeDocumento: string
  arrayBytesDocumento: string
}
