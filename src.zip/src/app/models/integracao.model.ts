export class Integracao {
    idIntegracao: number
    idReembolso: number
    idLoteIntegracao: number
    idLoteReembolso: string
    cliente: string
    contrato: string
    valorReembolso: number
    convenio: string
    matricula: string
    cpfCnpj: string
    mesCompetencia: number
    anoCompetencia: number
    sigla: string
    processoEntrada: string
    produto: string
    status: string
    mensagemErro: string
    usuarioInclusao: string
    dataInclusao: string
    dataIntegracao: string
}