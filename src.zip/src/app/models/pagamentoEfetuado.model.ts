import { Reembolso } from "./reembolso.model";

export class PagamentoEfetuado {
    dataPagamento: string
    dataRegistroPagamento: string
    favorecido: string
    listaReembolsos: Array<Reembolso> = new Array<Reembolso>()
    numeroPagamento: number
    processoRegistro: string
    statusPagamento: string
    tipoPagamento: string
    valorPagamento: number
}