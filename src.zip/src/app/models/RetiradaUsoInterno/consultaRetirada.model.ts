import { Reembolso } from "../reembolso.model";

export class ConsultaRetirada {
    integracao: ConsultaRetiradaIntegracao
    idPagamento: string
    listaReembolsos: Array<Reembolso> = new Array<Reembolso>()
}

export class ConsultaRetiradaIntegracao {
    Pagamento: string
    codigoLoteIntegracao: string
    codigoProcessoRegistro: string
    codigoProduto: string
    codigoStatusIntegracao: string
    dataInclusao: string
    idIntegracao: number
    mensagemErro: string
    numeroCpfCnpj: string
    usuarioInclusao: string
    valorRetirada: number
    mostraDetalhe: boolean = false
}
