export class Evento {
    codigoEvento: string
    eventoContabil: string
    fluxo: string
}

