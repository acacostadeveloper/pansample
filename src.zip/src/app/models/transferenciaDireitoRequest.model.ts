import { ContaCredito } from "./contaCredito.model"

export class TransferenciaDireitoRequest {
  idTransferenciaDireito: number
  numeroCpfCnpjCliente: string
  numeroCpfCnpjTerceiro: string
  nomeTerceiro: string
  contaCreditoTerceiro: ContaCredito = new ContaCredito()
  dtInicioVigencia: string
  dtFimVigencia?: string
  indicadorAtivo: string
  usuarioInclusao: string
  nomeDocumento: string
  arrayBytesDocumento: string
}
