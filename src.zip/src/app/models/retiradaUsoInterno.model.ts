import { Produto } from "./produto.model"

export class RetiradaUsoInterno {
    cpfCnpj: string
    nomeCliente: string
    valor: number
    ids: Array<Number> = new Array<Number>()
    codigoProduto: string
    produto: Produto = new Produto()
    retiradatotal: boolean
    justificativa: string
    usuario: string
    codigoProcesso: number
    items: Array<ItemRetiradaUsoInterno> = new Array<ItemRetiradaUsoInterno>()
}

export class ItemRetiradaUsoInterno {
    codigoContrato: string
    valorDisponivel: number
    valorSolicitado: number
    retiradaTotal: boolean
    ids: Array<Number> = new Array<Number>()
}
