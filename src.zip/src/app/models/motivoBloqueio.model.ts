export class MotivoBloqueio {
    idMotivoBloqueio: number
    descricaoMotivoBloqueio: string
}