export class HistoricoPagamento{
    tipo: string
    status: string
    valor: number
    dataInclusao: string
    dataPagamento: string
}