export class Coligada {
    codigoColigada: string
    cnpjColigada: string
    nomeColigada: string
}