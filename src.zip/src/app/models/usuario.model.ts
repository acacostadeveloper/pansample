import { Roles } from "./roles.model";

export class Usuario {
  userId: string
  nome: string
  token: string
  roles: Roles[]
  timestamp: Date
}
