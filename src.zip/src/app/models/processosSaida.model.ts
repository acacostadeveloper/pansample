export class ProcessosSaida {
    codigoProcessoRegistro: number
    processoRegistro: string
}