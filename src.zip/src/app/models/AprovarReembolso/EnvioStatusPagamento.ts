export class EnvioStatusPagamento{
    ids: number[]=[]
    status: string
    mensagemErro: string
    usuario: string
    numeroCpfCnpj: string
}