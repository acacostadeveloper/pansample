import { MotivosRejeicao } from "./motivosRejeicao.model";

export class PagamentosARealizar{
    numeroCpfCnpj: string
    nomeCliente: string
    valor: number
    ids: number[]
    selecionado: boolean = true
}