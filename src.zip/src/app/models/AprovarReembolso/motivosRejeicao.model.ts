export class MotivosRejeicao{
    motivo: string
}