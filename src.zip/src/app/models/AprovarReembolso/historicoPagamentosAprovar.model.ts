export class HistoricoPagamentosAprovar{
    historico10:{total:string , media: string}
    historico30:{total:string , media: string}
    historico60:{total:string , media: string}
}
