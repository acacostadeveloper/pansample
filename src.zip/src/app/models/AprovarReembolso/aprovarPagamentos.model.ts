import { PagamentosARealizar } from "./pagamentosARealizar.model";
import { HistoricoPagamentosAprovar } from "./historicoPagamentosAprovar.model";

export class AprovarPagamentos{
    pagamentos: Array<PagamentosARealizar> = new Array<PagamentosARealizar>();
    historicoPagamentos: HistoricoPagamentosAprovar
}