import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef, ElementRef, ViewChild } from '@angular/core';
import { ClienteService } from '../cliente.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ModalDialogService } from 'ngx-modal-dialog';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { PopUpModal } from '../../Helpers/popUpModal';
import { Cliente } from '../../models/cliente.model';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../guards/auth.service';

@Component({
  selector: 'pan-endereco-cliente',
  templateUrl: './endereco-cliente.component.html'
})
export class EnderecoClienteComponent implements OnInit {
  @ViewChild("txtCep")
  public txtCep: ElementRef

  public fieldsLock: boolean = true
  public cliente: Cliente

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  estados = environment.estados;

  @Output() fechaDetalhe = new EventEmitter<any>();
  @Output() onDadosAlterados = new EventEmitter<any>();
  @Output() onDadosAlteradosErro = new EventEmitter<any>();

  constructor(
    private clienteService: ClienteService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private authService: AuthService
  ) {

  }

  ngOnInit() {
  }

  alterarBloqueio() {
    if (this.authService.verificarActionName("alterar-endereco", "consultar-clientes") == false) {
      this.mensagem.mensagemOkModal("Usuário não tem autorização para executar esta ação")
    }
    else {
      this.fieldsLock = !this.fieldsLock
    }
  }

  fecharDetalhe() {
    this.fechaDetalhe.next();
  }

  validaCampos() {
    let mensagemRetorno: string = "";

    if (this.authService.verificarActionName("alterar-endereco", "consultar-clientes") == false) {
      this.mensagem.mensagemOkModal("Usuário não tem autorização para executar esta ação")
      return false
    }

    if (this.cliente.endereco.nomeLogradouro == "" ||
      this.cliente.endereco.nomeLogradouro == undefined ||
      this.cliente.endereco.nomeLogradouro == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Nome do Lougradouro deve ser preenchido.<br>";
    }

    if (this.cliente.endereco.bairro == "" ||
      this.cliente.endereco.bairro == undefined ||
      this.cliente.endereco.bairro == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Bairro deve ser preenchido.<br>";
    }

    if (this.cliente.endereco.cidade == "" ||
      this.cliente.endereco.cidade == undefined ||
      this.cliente.endereco.cidade == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Cidade deve ser preenchido.<br>";
    }

    if (this.cliente.endereco.estado == "" ||
      this.cliente.endereco.estado == undefined ||
      this.cliente.endereco.estado == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Estado deve ser preenchido.<br>";
    }

    if (this.cliente.endereco.numero == "" ||
      this.cliente.endereco.numero == undefined ||
      this.cliente.endereco.numero == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número deve ser preenchido.<br>";
    }

    if (this.cliente.endereco.cep == "" ||
      this.cliente.endereco.cep == undefined ||
      this.cliente.endereco.cep == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Cep deve ser preenchido.<br>";
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  buscaCep() {
    this.spinnerService.show();
    this.clienteService.buscarCep(this.txtCep.nativeElement.value).subscribe(
      data => {
        this.spinnerService.hide();
        if (data.code == 200) {
          this.cliente.endereco.nomeLogradouro = data.result.logradouro
          this.cliente.endereco.bairro = data.result.bairro
          this.cliente.endereco.cidade = data.result.localidade
          this.cliente.endereco.estado = data.result.uf
          this.cliente.endereco.numero = ""
          this.cliente.endereco.complemento = ""
        }
      }
    );
  }

  alterarEndereco() {
    if (this.validaCampos()) {

      this.spinnerService.show();
      this.clienteService.alterarCliente(this.cliente).subscribe(
        data => {
          if (data instanceof HttpErrorResponse) {
            var retorno: HttpErrorResponse;
            retorno = data;
            this.spinnerService.hide();
            this.mensagem.mensagemOkModal("Ocorreu o erro ao alterar o dados de endereço:<br><br>" + data.statusText);
          }
          else {
            this.spinnerService.hide();
            if (data.Success == true) {
              this.mensagem.mensagemOkModal("Dados alterados com sucesso");
              this.onDadosAlterados.next();
            }
            else {
              this.mensagem.mensagemOkModal("Ocorreu um erro ao alterar o endereço:<br><br>" + data.MessageError);
              this.onDadosAlteradosErro.next();
            }
            this.fieldsLock = true;
          }

        },
        error => {
          this.spinnerService.hide();
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
        },
      );
    }
  }
}
