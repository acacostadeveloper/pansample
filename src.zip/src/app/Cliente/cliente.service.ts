import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { Cliente } from '../models/cliente.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, tap } from 'rxjs/operators';
import { TransferenciaDireitoRequest } from '../models/transferenciaDireitoRequest.model';
import { FuncoesApoio } from '../Helpers/funcoesApoio';
import { AppConfig } from '../Helpers/app.config';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  httpOptionsHeader = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*'
    })
  };

  constructor(private http: HttpClient) { }

  buscarCep(
    cep: string
  ): Observable<any> {
    return this.http
      .get(`http://cep.bldstools.com/?cep=` + cep,
      ).pipe(
        tap(data => data),
        catchError(FuncoesApoio.handleError)
      );
  }

  obterCliente(
    numeroCpfCnpj: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}cliente/` + numeroCpfCnpj,
      ).pipe(
        tap(data => data),
        catchError(FuncoesApoio.handleError)
      );
  }

  alterarCliente(cliente: Cliente): Observable<any> {
    return this.http.post<Cliente[]>(`${AppConfig.settings.apiServer}cliente`, cliente).pipe(
      catchError(FuncoesApoio.handleError),
    );
  }

  obterTransferenciasDireito(
    numeroCpfCnpj: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}cliente/transferencia`,
        {
          params: {
            numeroCpfCnpj: numeroCpfCnpj
          }
        }
      ).pipe(
        tap(data => data),
        catchError(FuncoesApoio.handleError)
      );
  }

  persistirTransferenciaDireito(transferenciaDireito: TransferenciaDireitoRequest): Observable<any> {
    return this.http.post<TransferenciaDireitoRequest[]>(`${AppConfig.settings.apiServer}cliente/transferencia`, transferenciaDireito).pipe(
      catchError(FuncoesApoio.handleError),
    );
  }

  obterDocumentoTransferencia(
    idTransferenciaDireito: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}cliente/transferencia/documento/`,
        {
          params: {
            idTransferenciaDireito: idTransferenciaDireito
          }
          , responseType: "text"
        }
      ).pipe(
        tap(data => data),
        catchError(FuncoesApoio.handleError)
      );
  }

  obterClientes(
    cpfCliente: string,
    nomeCliente: string,
    idLote: string,
    idProduto: string,
    dtInicial: string,
    dtFinal: string,
    statusReembolso: string[],
    idReembolso: string,
    idMotivoBloqueio: string
  ): Observable<any> {
    return this.http
      .get(`${AppConfig.settings.apiServer}cliente`,
        {
          params: {
            idLote: idLote,
            codigoProduto: idProduto,
            dtInicial: dtInicial,
            dtFinal: dtFinal,
            cpfCliente: cpfCliente,
            statusReembolso: statusReembolso,
            idReembolso: idReembolso,
            idMotivoBloqueio: idMotivoBloqueio,
            nomeCliente: nomeCliente
          }
        }
      ).pipe(
        tap(data => data),
        catchError(FuncoesApoio.handleError)
      );
  }
}
