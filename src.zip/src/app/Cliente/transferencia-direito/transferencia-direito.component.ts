import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef, ViewChild, ElementRef } from '@angular/core';
import { ClienteService } from '../cliente.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ModalDialogService } from 'ngx-modal-dialog';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { PopUpModal } from '../../Helpers/popUpModal';
import { TransferenciaDireitoRequest } from '../../models/transferenciaDireitoRequest.model';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { environment } from '../../../environments/environment';
import { IMyDateModel, MyDatePicker, IMyDpOptions } from 'mydatepicker';
import { TransferenciaDireito } from '../../models/transferenciaDireito.model';
import { AuthService } from '../../guards/auth.service';
import { AppConfig } from '../../Helpers/app.config';

@Component({
  selector: 'pan-transferencia-direito',
  templateUrl: './transferencia-direito.component.html',
  styleUrls: ['./transferencia-direito.component.css']
})
export class TransferenciaDireitoComponent implements OnInit {
  @ViewChild("txtArquivo")
  public txtArquivo: ElementRef

  @ViewChild("txtCpf")
  public txtCpf: ElementRef

  @ViewChild("txtDataVigenciaInicial")
  public txtDataVigenciaInicial: MyDatePicker

  @ViewChild("txtDataVigenciaFinal")
  public txtDataVigenciaFinal: MyDatePicker

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };

  public transferenciasDireito: TransferenciaDireito[] = [];
  public transferenciaDireitoRequest: TransferenciaDireitoRequest = new TransferenciaDireitoRequest()
  public transferenciaDireito: TransferenciaDireito

  dataVigenciaInicial: IMyDateModel
  dataVigenciaFinal: IMyDateModel

  public fieldsLock: boolean = true
  public mostraDetalhe: boolean;

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  tipoContas = environment.TipoConta;

  @Output() onDadosAlterados = new EventEmitter<any>();
  @Output() onDadosAlteradosErro = new EventEmitter<any>();


  constructor(
    private clienteService: ClienteService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private authService: AuthService
  ) {

  }

  ngOnInit() {
    this.mostraDetalhe = false;
  }

  ocultarDetalhe() {
    this.mostraDetalhe = false;
  }

  mostrarDetalhe() {
    this.mostraDetalhe = true;
  }

  validaCampos() {
    let mensagemRetorno: string = "";

    this.transferenciaDireitoRequest.numeroCpfCnpjCliente = this.transferenciaDireito.cliente.numeroCpfCnpj

    if (this.transferenciaDireitoRequest.numeroCpfCnpjTerceiro == "" ||
      this.transferenciaDireitoRequest.numeroCpfCnpjTerceiro == undefined ||
      this.transferenciaDireitoRequest.numeroCpfCnpjTerceiro == null) {
      mensagemRetorno = mensagemRetorno + "- informe o número do Cpf do favorecido.<br>";
    }

    if (this.transferenciaDireitoRequest.nomeTerceiro == "" ||
      this.transferenciaDireitoRequest.nomeTerceiro == undefined ||
      this.transferenciaDireitoRequest.nomeTerceiro == null) {
      mensagemRetorno = mensagemRetorno + "- informe o nome do favorecido.<br>";
    }

    if (this.transferenciaDireitoRequest.contaCreditoTerceiro.tipoConta == "" ||
      this.transferenciaDireitoRequest.contaCreditoTerceiro.tipoConta == undefined ||
      this.transferenciaDireitoRequest.contaCreditoTerceiro.tipoConta == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Tipo Conta do favorecido deve ser preenchido.<br>";
    }
    else {
      this.transferenciaDireitoRequest.contaCreditoTerceiro.tipoConta = this.transferenciaDireitoRequest.contaCreditoTerceiro.tipoConta.trim()
    }

    if (this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroBanco == "" ||
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroBanco == undefined ||
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroBanco == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número Banco do favorecido deve ser preenchido.<br>";
    }
    else {
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroBanco = this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroBanco.trim()
    }

    if (this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroConta == "" ||
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroConta == undefined ||
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroConta == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número Conta do favorecido deve ser preenchido.<br>";
    }
    else {
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroConta = this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroConta.trim()
    }

    if (this.txtDataVigenciaInicial.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data vigência Inicial inválida.<br>";
    }

    if (this.txtDataVigenciaFinal.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data vigência Final inválida.<br>";
    }

    if (this.transferenciaDireitoRequest.numeroCpfCnpjCliente == undefined ||
      this.transferenciaDireitoRequest.numeroCpfCnpjCliente == null) {
      mensagemRetorno = mensagemRetorno + "- Não foi possivel localizar o cliente.<br>";
    }


    if (this.dataVigenciaInicial == undefined || this.dataVigenciaInicial == null) {
      mensagemRetorno = mensagemRetorno + "- Informe a data inicial da vigência.<br>";
    }
    else {
      this.transferenciaDireitoRequest.dtInicioVigencia = FuncoesApoio.formatarData(this.dataVigenciaInicial)
      if (this.dataVigenciaFinal != undefined || this.dataVigenciaFinal != null) {
        if (FuncoesApoio.verificarDataFinalMenor(this.dataVigenciaInicial, this.dataVigenciaFinal)) {
          mensagemRetorno = mensagemRetorno + "- Data vigência final deve ser maior que data vigência inicial.<br>";
        }
        else {
          this.transferenciaDireitoRequest.dtFimVigencia = FuncoesApoio.formatarData(this.dataVigenciaFinal)
        }
      }
    }

    if (this.transferenciaDireitoRequest.contaCreditoTerceiro.digitoConta != undefined) {
      this.transferenciaDireitoRequest.contaCreditoTerceiro.digitoConta = this.transferenciaDireitoRequest.contaCreditoTerceiro.digitoConta.trim()
    }

    if (this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroAgencia != undefined) {
      this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroAgencia = this.transferenciaDireitoRequest.contaCreditoTerceiro.numeroAgencia.trim()
    }

    if (this.transferenciaDireitoRequest.contaCreditoTerceiro.digitoAgencia != undefined) {
      this.transferenciaDireitoRequest.contaCreditoTerceiro.digitoAgencia = this.transferenciaDireitoRequest.contaCreditoTerceiro.digitoAgencia.trim()
    }

    if (this.txtArquivo.nativeElement.files.length == 0) {
      mensagemRetorno = mensagemRetorno + "- É necessário inserir um documento comprovatório.<br>";
    }
    else {
      this.transferenciaDireitoRequest.nomeDocumento = this.txtArquivo.nativeElement.files[0].name
    }

    this.transferenciaDireitoRequest.usuarioInclusao = this.authService.usuario.userId
    this.transferenciaDireitoRequest.indicadorAtivo = "1"

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  obterDocumentoTransferencia(idTransferenciaDireito: number) {
    this
      .clienteService
      .obterDocumentoTransferencia(
        idTransferenciaDireito.toString()
      )
      .subscribe(res => {
        //var blob = new Blob([res], { type: 'application/octet-stream' });
        var blob = new Blob([res], {
          type: 'application/octet-stream'
        });
        var url = window.URL.createObjectURL(blob);
        window.open(url);
      });
  }

  montarLinkDocumento() {
    this.transferenciasDireito.forEach(element => {
      element.linkDocumento = AppConfig.settings.apiServer + "cliente/transferencia/documento?idTransferenciaDireito=" + element.idTransferenciaDireito
    })
  }

  public carregarTransferenciasDeDireito() {
    this.spinnerService.show();
    this
      .clienteService
      .obterTransferenciasDireito(
        this.transferenciaDireito.cliente.numeroCpfCnpj
      )
      .subscribe(
        (data: TransferenciaDireito[]) => {
          if (data instanceof HttpErrorResponse) {
            var retorno: HttpErrorResponse = data;
            this.spinnerService.hide();
            if (retorno.status == 502) {
              this.transferenciasDireito = [];
            }
            else {
              this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText);
            }

          }
          else {
            this.spinnerService.hide()
            if (data == null || data.length == 0) {
              this.transferenciasDireito = []
            }
            else {
              this.transferenciasDireito = data
              this.montarLinkDocumento()
            }
          }
        }
      ),
      error => {
        this.spinnerService.hide();
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }
      ;
  }

  limpaCampos() {
    this.transferenciaDireitoRequest = new TransferenciaDireitoRequest()
    this.dataVigenciaInicial = null
    this.dataVigenciaFinal = null
    this.txtCpf.nativeElement.value = ""
    this.txtArquivo.nativeElement.value = ""
  }


  alterarTransferenciaDireito() {
    var self = this
    if (this.validaCampos()) {
      this.spinnerService.show();

      var reader = new FileReader();
      reader.readAsArrayBuffer(this.txtArquivo.nativeElement.files[0])

      reader.onload = function (e, http = this.http) {
        var arrayBuffer = reader.result;

        var bytes = FuncoesApoio.arrayBufferToBase64String(<ArrayBuffer>arrayBuffer)

        self.transferenciaDireitoRequest.arrayBytesDocumento = bytes

        self.clienteService.persistirTransferenciaDireito(self.transferenciaDireitoRequest).subscribe(
          data => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data
              self.spinnerService.hide()
              self.mensagem.mensagemOkModal("Ocorreu o erro ao alterar realizar a transferência de direito:<br><br>" + data.statusText)
            }
            else {
              self.spinnerService.hide()

              if (data.Success == true) {
                self.mensagem.mensagemOkModal("Dados alterados com sucesso")
                self.onDadosAlterados.next()
                self.fieldsLock = true
                self.carregarTransferenciasDeDireito()
                self.mostraDetalhe = false
                self.limpaCampos()              }
              else {
                self.mensagem.mensagemOkModal("Ocorreu um erro ao alterar os dados bancários:<br><br>" + data.MessageError);
                self.onDadosAlteradosErro.next();
              }              
            }
          },
          error => {
            self.spinnerService.hide();
            self.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
          },
        );
      }
    }
  }
}
