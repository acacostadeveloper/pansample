import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef, ViewChild } from '@angular/core';
import { ModalDialogService } from 'ngx-modal-dialog';
import { PopUpModal } from '../../Helpers/popUpModal';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HttpErrorResponse } from '@angular/common/http';
import { Cliente } from '../../models/cliente.model';
import { ClienteService } from '../cliente.service';
import { AlterarDadosBancariosComponent } from '../../dados-bancarios/alterar-dados-bancarios/alterar-dadosBancarios.component';
import { ConsultaDadosBancarios } from '../../models/DadosBancarios/consultaDadosBancarios.model';
import { EnderecoClienteComponent } from '../endereco-cliente/endereco-cliente.component';
import { TransferenciaDireitoComponent } from '../transferencia-direito/transferencia-direito.component';
import { detalheAnimation, cabecalhoAnimation } from '../../Helpers/animacoes';
import { TransferenciaDireito } from '../../models/transferenciaDireito.model';
import { AutoCompleteNomeComponent } from '../../auto-complete-nome/auto-complete-nome.component';
import { AuthService } from '../../guards/auth.service';
import { GlobalService } from '../../Helpers/global.service';
import { MotivoBloqueioService } from '../../motivo-bloqueio/motivo-bloqueio.service';
import { ProdutoService } from '../../produto/produto.service';
import { Produto } from '../../models/produto.model';
import { MotivoBloqueio } from '../../models/motivoBloqueio.model';
import { IMyDateModel, IMyDpOptions, MyDatePicker } from 'mydatepicker';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'pan-consultar-cliente',
  templateUrl: './consultar-cliente.component.html',
  animations: [cabecalhoAnimation, detalheAnimation]
})

export class ConsultarClienteComponent implements OnInit {
  @ViewChild("dadosBancariosComponent")
  public dadosBancariosComponent: AlterarDadosBancariosComponent

  @ViewChild("transferenciaDireitoComponent")
  public transferenciaDireitoComponent: TransferenciaDireitoComponent

  @ViewChild("enderecoComponent")
  public enderecoComponent: EnderecoClienteComponent

  @ViewChild("txtNome")
  public txtNome: AutoCompleteNomeComponent

  @ViewChild("txtDataInicial")
  public txtDataInicial: MyDatePicker

  @ViewChild("txtDataFinal")
  public txtDataFinal: MyDatePicker

  public clientes: Cliente[] = [];
  cliente = new Cliente();

  public mostraDetalhe: boolean;
  mostraCabecalhoAnimacao: string;
  mostraDetalheAnimacao: string;

  //Filtros:
  filterIdLote: string
  filterIdReembolso: string
  filterIdProduto: string
  filterDtInicial: IMyDateModel
  filterDtFinal: IMyDateModel
  filterCpfClientes: string
  filterStatusReembolso: string
  statusReembolso: string[]
  filterIdMotivoBloqueio: string
  filterNomeClientes: string
  statusReembolsos = environment.StatusReembolso

  produtos: Produto[]
  motivosBloqueio: MotivoBloqueio[]

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }

  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  constructor(
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private spinnerService: Ng4LoadingSpinnerService,
    private clienteService: ClienteService,
    private globalService: GlobalService,
    private produtoService: ProdutoService,
    private motivoBloqueioService: MotivoBloqueioService,
  ) {

  }

  ngOnInit() {
    this.carregarProdutos()
    this.carregarMotivosBloqueio()
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = "true"
    this.mostraDetalheAnimacao = "false"
    this.globalService.changeRoute.subscribe(data => {
      this.ocultarDetalhe()
    })
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }
  }

  carregarMotivosBloqueio() {
    this
      .motivoBloqueioService
      .obterMotivosBloqueio()
      .subscribe(
        (data: MotivoBloqueio[]) => {
          this.motivosBloqueio = data
        }
      ),
      error => {
        this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
      }

  }

  ocultarDetalhe() {
    this.mostraDetalhe = false
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()
  }

  mostrarDetalhe() {
    this.mostraDetalhe = true
    this.mostraCabecalhoAnimacao = (!this.mostraDetalhe).toString()
    this.mostraDetalheAnimacao = (this.mostraDetalhe).toString()

  }

  carregarComponents(cliente: Cliente) {
    this.mostrarDetalhe()
    this.dadosBancariosComponent.consultaDadosBancarios = ConsultaDadosBancarios.preencheDadosBancarios(cliente)
    this.dadosBancariosComponent.fieldsLock = true

    this.enderecoComponent.cliente = cliente
    this.enderecoComponent.fieldsLock = true

    let transferenciaDireito = new TransferenciaDireito()
    transferenciaDireito.cliente = cliente
    this.transferenciaDireitoComponent.transferenciaDireito = transferenciaDireito
    this.transferenciaDireitoComponent.mostraDetalhe = false
    this.transferenciaDireitoComponent.carregarTransferenciasDeDireito()
  }

  limparFiltros() {
    this.filterCpfClientes = ""
    this.filterNomeClientes = ""
    this.txtNome.value = ""
  }

  montarStatusReembolso() {
    let retorno = this.statusReembolsos.find(item => item.entrada === this.filterStatusReembolso)
    return retorno.saida.split(",")
  }

  validarCampos() {
    this.filterNomeClientes = this.txtNome.value
    let mensagemRetorno: string = "";

    if (
      (this.filterCpfClientes == undefined || this.filterCpfClientes.trim() == "") &&
      (this.filterNomeClientes == undefined || this.filterNomeClientes.trim() == "") &&
      (this.filterIdLote == undefined || this.filterIdLote.trim() == "") &&
      (this.filterIdReembolso == undefined || this.filterIdReembolso.trim() == "") &&
      (this.filterIdProduto == undefined || this.filterIdProduto.trim() == "") &&
      (this.filterDtInicial == undefined) &&
      (this.filterStatusReembolso == undefined || this.filterStatusReembolso.trim() == "") &&
      (this.filterIdMotivoBloqueio == undefined || this.filterIdMotivoBloqueio.trim() == "") 
    ) {
      mensagemRetorno = mensagemRetorno + "- Favor preencher ao menos 1 campo para pesquisa.<br>";
    }

    if (this.filterCpfClientes == undefined || this.filterCpfClientes.trim() == "") this.filterCpfClientes = ""
    if (this.filterNomeClientes == undefined || this.filterNomeClientes.trim() == "") this.filterNomeClientes = ""

    if (this.filterNomeClientes != "" && this.filterNomeClientes.length < 3) {
      mensagemRetorno = mensagemRetorno + "- Campo nome deve ter ao menos 3 caracteres.<br>";
    }

    if (this.filterStatusReembolso == undefined || this.filterStatusReembolso == null) {
      this.statusReembolso = []
    }
    else {
      this.statusReembolso = this.montarStatusReembolso()
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null
      this.filterDtFinal = null
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>"
      }
    }

    if (this.txtDataInicial.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Inicial inválida.<br>"
    }

    if (this.txtDataFinal.invalidDate == true) {
      mensagemRetorno = mensagemRetorno + "- Data Final inválida.<br>"
    }

    if(this.filterIdProduto == undefined || this.filterIdProduto.trim() == ""){
      this.filterIdProduto = ""
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  carregarClientes() {
    if (this.validarCampos()) {
      this.spinnerService.show();
      this
        .clienteService
        .obterClientes(
          this.filterCpfClientes,
          this.filterNomeClientes,
          this.filterIdLote,
          this.filterIdProduto,
          FuncoesApoio.formatarDataInicial(this.filterDtInicial),
          FuncoesApoio.formatarDataFinal(this.filterDtFinal),
          this.statusReembolso,
          this.filterIdReembolso,
          this.filterIdMotivoBloqueio
        )
        .subscribe(
          (data: Cliente[]) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse = data;
              this.spinnerService.hide();
              if (retorno.status == 502) {
                this.clientes = [];
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText);
              }

            }
            else {
              this.spinnerService.hide();
              if (data == null || data.length == 0) {
                this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro");
                this.clientes = [];
              }
              else {
                this.clientes = data

              }
            }
          }
        ),
        error => {
          this.spinnerService.hide();
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error)
        }
        ;
    }
  }
}
