﻿using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IServiceCnpj" in both code and config file together.
    [ServiceContract]
    public interface IServiceCnpj
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inserir")]
        Cnpj Inserir(Cnpj model);


        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Listar?nrCnpj={nrCnpj}&nmEmpresa={nmEmpresa}&dtVigenciaInicio={dtVigenciaInicio}&dtVigenciaFim={dtVigenciaFim}")]
        List<Cnpj> Listar(string nrCnpj, string nmEmpresa, string dtVigenciaInicio, string dtVigenciaFim);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inativar")]
        bool Inativar(Cnpj Cnpj);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Alterar")]
        Cnpj Alterar(Cnpj model);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Importar")]
        List<Cnpj> Importar(Arquivo item);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "ListarLog?idCnpj={idCnpj}")]
        List<Cnpj> ListarLog(int idCnpj);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Validar")]
        bool Validar(Cnpj item);

    }
}
