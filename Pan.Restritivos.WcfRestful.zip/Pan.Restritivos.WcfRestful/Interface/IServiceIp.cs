﻿using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IServiceIp" in both code and config file together.
    [ServiceContract]
    public interface IServiceIp
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inserir")]
        Ip Inserir(Ip model);


        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Listar?nrIp={nrIp}&nrPorta={nrPorta}&dtVigenciaInicio={dtVigenciaInicio}&dtVigenciaFim={dtVigenciaFim}")]
        List<Ip> Listar(string nrIp,int nrPorta, string dtVigenciaInicio, string dtVigenciaFim);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inativar")]
        bool Inativar(Ip Ip);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Alterar")]
        Ip Alterar(Ip model);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Importar")]
        List<Ip> Importar(Arquivo item);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "ListarLog?idIP={idIP}")]
        List<Ip> ListarLog(int idIP);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Validar")]
        bool Validar(Ip item);

    }
}
