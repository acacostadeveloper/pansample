﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using Pan.Restritivos.Model;

namespace Pan.Restritivos.WcfRestful.Interface
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceContract]
    public interface IRestToken
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "token")]
        CustomToken token(CustomToken token);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "refreshtoken")]
        String refreshToken(CustomToken token);
    }
}
