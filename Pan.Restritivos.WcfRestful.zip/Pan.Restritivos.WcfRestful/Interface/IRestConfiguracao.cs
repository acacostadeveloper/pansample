﻿using ModelPanPaDp.Alcadas;
using ModelPanPaDp.Configuracao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfRestfulPanPaDp
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRestConfiguracao" in both code and config file together.
    [ServiceContract]
    public interface IRestConfiguracao
    {
        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "getmenu?idPerfil={idPerfil}")]
        List<Menu> getmenu(string idPerfil);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "addperfil")]
        bool addperfil(PerfilAcesso model);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "pesquisar?flagstatus={flagstatus}")]
        List<PerfilAcesso> pesquisar(string flagstatus);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "deletar?idPerfil={idPerfil}")]
        PerfilAcesso deletar(string idPerfil);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "getperfil?idPerfil={idPerfil}")]
        PerfilAcesso getperfil(string idperfil);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "editarperfil")]
        bool editarperfil(PerfilAcesso model);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "getconfigalcadas")]
        Alcada getconfigalcadas();

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "getEstadosCidades")]
        EstatoCidade getEstadosCidades();

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "acessos?idperfil={idperfil}")]
        List<Menu> acessos(string idperfil);

    }
}
