﻿using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IServiceLinhaDigitavel" in both code and config file together.
    [ServiceContract]
    public interface IServiceLinhaDigitavel
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inserir")]
        LinhaDigitavel Inserir(LinhaDigitavel model);


        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Listar?nrLinhaDigitavel={nrLinhaDigitavel}&dtVigenciaInicio={dtVigenciaInicio}&dtVigenciaFim={dtVigenciaFim}")]
        List<LinhaDigitavel> Listar(string nrLinhaDigitavel,  string dtVigenciaInicio, string dtVigenciaFim);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inativar")]
        bool Inativar(LinhaDigitavel LinhaDigitavel);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Alterar")]
        LinhaDigitavel Alterar(LinhaDigitavel model);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Importar")]
        List<LinhaDigitavel> Importar(Arquivo item);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "ListarLog?idLinhaDigitavel={idLinhaDigitavel}")]
        List<LinhaDigitavel> ListarLog(int idLinhaDigitavel);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Validar")]
        bool Validar(LinhaDigitavel item);

    }
}
