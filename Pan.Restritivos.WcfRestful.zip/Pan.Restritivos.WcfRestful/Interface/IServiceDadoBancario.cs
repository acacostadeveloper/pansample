﻿using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IServiceDadoBancario" in both code and config file together.
    [ServiceContract]
    public interface IServiceDadoBancario
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inserir")]
        DadoBancario Inserir(DadoBancario model);


        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Listar?nrBanco={nrBanco}&nrAgencia={nrAgencia}&nrAgenciaDigito={nrAgenciaDigito}&nrConta={nrConta}&nrContaDigito={nrContaDigito}&nmCliente={nmCliente}&nrCPFCNPJ={nrCPFCNPJ}&dtVigenciaInicio={dtVigenciaInicio}&dtVigenciaFim={dtVigenciaFim}")]
        List<DadoBancario> Listar(int nrBanco, int nrAgencia, string nrAgenciaDigito, int nrConta, string nrContaDigito, string nmCliente, string nrCPFCNPJ, string dtVigenciaInicio, string dtVigenciaFim);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inativar")]
        bool Inativar(DadoBancario DadoBancario);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Alterar")]
        DadoBancario Alterar(DadoBancario model);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Importar")]
        List<DadoBancario> Importar(Arquivo item);

        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "ListarLog?idDadoBancario={idDadoBancario}")]
        List<DadoBancario> ListarLog(int idDadoBancario);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Validar")]
        bool Validar(DadoBancario item);

    }
}
