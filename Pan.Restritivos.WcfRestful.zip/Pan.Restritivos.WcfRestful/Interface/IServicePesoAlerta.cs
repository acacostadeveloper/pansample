﻿using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRestPesoAlerta" in both code and config file together.
    [ServiceContract]
    public interface IServicePesoAlerta
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inserir")]
        Peso Inserir(Peso model);


        [OperationContract]
        [WebInvoke(Method = "GET",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Listar?codPeso={codPeso}&txPeso={txPeso}")]
        List<Peso> Listar(string codPeso, string txPeso);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Inativar")]
        bool Inativar(Peso model);

        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         BodyStyle = WebMessageBodyStyle.Bare,
         UriTemplate = "Alterar")]
        Peso Alterar(Peso model);

    }
}
