﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using Pan.Restritivos.WcfRestful.ErrorHandling;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using Restritivos.WcfRestful.NullableBehavior;
using Pan.Restritivos.Model;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Service;

namespace Pan.Restritivos.WcfRestful
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RouteTable.Routes.Add(new ServiceRoute("api/endereco/",       new NullableWebServiceHostFactory(), typeof(ServiceEndereco)));
            RouteTable.Routes.Add(new ServiceRoute("api/linhadigitavel/", new NullableWebServiceHostFactory(), typeof(ServiceLinhaDigitavel)));
            RouteTable.Routes.Add(new ServiceRoute("api/dadosbancarios/", new NullableWebServiceHostFactory(), typeof(ServiceDadoBancario)));
            RouteTable.Routes.Add(new ServiceRoute("api/ip/",             new NullableWebServiceHostFactory(), typeof(ServiceIp)));
            RouteTable.Routes.Add(new ServiceRoute("api/codigobarra/",    new NullableWebServiceHostFactory(), typeof(ServiceCodigoBarra)));
            RouteTable.Routes.Add(new ServiceRoute("api/telefone/",       new NullableWebServiceHostFactory(), typeof(ServiceTelefone)));
            RouteTable.Routes.Add(new ServiceRoute("api/cnpj/",           new NullableWebServiceHostFactory(), typeof(ServiceCnpj)));
            RouteTable.Routes.Add(new ServiceRoute("api/motivoalerta/",   new NullableWebServiceHostFactory(), typeof(ServiceMotivoAlerta)));
            RouteTable.Routes.Add(new ServiceRoute("api/cpf/",            new NullableWebServiceHostFactory(), typeof(ServiceCpf)));
            RouteTable.Routes.Add(new ServiceRoute("api/pesoalerta/",     new NullableWebServiceHostFactory(), typeof(ServicePesoAlerta)));
            RouteTable.Routes.Add(new ServiceRoute("api/usuario/",        new NullableWebServiceHostFactory(), typeof(RestUsuario)));
            RouteTable.Routes.Add(new ServiceRoute("api/",                new NullableWebServiceHostFactory(), typeof(RestToken)));

       }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Methods", "POST,GET,PUT,OPTIONS");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "*");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Access-Control-Allow-Methods, Authorization, X-Requested-With, Access-Control-Allow-Origin, Access-Control-Expose-Headers, Skip-Authorization, X-SessionId");
                HttpContext.Current.Response.AddHeader("Access-Control-Expose-Headers", "Content-Type, Authorization");
                HttpContext.Current.Response.AddHeader("Access-Control-Max-Age", "1728000");
                HttpContext.Current.Response.End();
            }
            else
            {
                if (HttpContext.Current.Request.Headers["Skip-Authorization"] == "true")
                {
                    if (!permittedSkipAuthorization(HttpContext.Current.Request.FilePath))
                    {
                        Exception ex = new Exception("Acesso Negado: Esta requisição não pode utilizar Skip Authorization!");
                        Log.salvar(ex);
                        string desc_erro = ex.Message;
                        GenericError desc = new GenericError(desc_erro);
                        HttpContext.Current.Response.Clear();
                        HttpContext.Current.Response.ContentType = "application/json";
                        HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                        HttpContext.Current.Response.StatusDescription = desc_erro;
                        HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                        HttpContext.Current.Response.End();
                    }
                }
                else
                {
                    CustomToken objToken = new CustomToken();
                    String _keyCrypto = String.Empty;

                    // Obtém o token do Header da requisição
                    var token = HttpContext.Current.Request.Headers["Authorization"];

                    // Se possui token...
                    if (token != null)
                    {
                        // Obtem a chave de criptografia
                        _keyCrypto = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");

                        // Prepara o token para decodificação
                        token = token.Replace("Bearer ", "");

                        try
                        {
                            // Decodifica o token transformado-o em objeto
                            objToken = JsonWebToken.DecodeToObject<CustomToken>(token, _keyCrypto, true);

                            // Pega o User Agent da requisição
                            objToken.UserAgent = HttpContext.Current.Request.Headers["User-Agent"];

                            // Pega o Session ID da requisição
                            objToken.SessionId = Convert.ToInt32(HttpContext.Current.Request.Headers["X-SessionId"]);

                            // Pega o Client Address da requisição
                            objToken.ClientAddress = HttpContext.Current.Request.UserHostAddress;

                            // Valida usuário
                            ValidaToken _ValidaToken = new ValidaToken();
                            _ValidaToken.validateToken(objToken);

                        }
                        catch (ArgumentException ex)
                        {
                            Log.salvar(ex);
                            string desc_erro = "Acesso Negado: Token inválido.";
                            GenericError desc = new GenericError(desc_erro);
                            HttpContext.Current.Response.Clear();
                            HttpContext.Current.Response.ContentType = "application/json";
                            HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                            HttpContext.Current.Response.StatusDescription = desc_erro;
                            HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                            HttpContext.Current.Response.End();
                        }
                        catch (SignatureVerificationException ex)
                        {
                            Log.salvar(ex);
                            string desc_erro = "Acesso Negado: Problema na assinatura do Token.";
                            GenericError desc = new GenericError(desc_erro);
                            HttpContext.Current.Response.Clear();
                            HttpContext.Current.Response.ContentType = "application/json";
                            HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                            HttpContext.Current.Response.StatusDescription = desc_erro;
                            HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                            HttpContext.Current.Response.End();

                        }
                        catch (FaultException<ServiceFault> fault)
                        {
                            Exception ex = new Exception(fault.Detail.Message);
                            Log.salvar(ex);

                            int statusCode = HttpStatusCode.BadRequest.GetHashCode();

                            if (fault.Detail.Data["StatusCode"] != null)
                            {
                                statusCode = (int)fault.Detail.Data["StatusCode"];
                            }

                            string desc_erro = fault.Detail.Message;
                            GenericError desc = new GenericError(desc_erro);

                            HttpContext.Current.Response.Clear();
                            HttpContext.Current.Response.ContentType = "application/json";
                            HttpContext.Current.Response.StatusCode = statusCode;
                            HttpContext.Current.Response.StatusDescription = desc_erro;
                            HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                            HttpContext.Current.Response.End();
                        }
                        catch (Exception ex)
                        {
                            Log.salvar(ex);
                            string desc_erro = ex.Message;
                            GenericError desc = new GenericError(desc_erro);
                            HttpContext.Current.Response.Clear();
                            HttpContext.Current.Response.ContentType = "application/json";
                            HttpContext.Current.Response.StatusCode = HttpStatusCode.BadRequest.GetHashCode();
                            HttpContext.Current.Response.StatusDescription = desc_erro;
                            HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                            HttpContext.Current.Response.End();
                        }
                    }
                    else
                    {
                        Exception ex = new Exception("Acesso Negado: Não foi encontrado o token desta requisição!");
                        Log.salvar(ex);
                        string desc_erro = ex.Message;
                        GenericError desc = new GenericError(desc_erro);
                        HttpContext.Current.Response.Clear();
                        HttpContext.Current.Response.ContentType = "application/json";
                        HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                        HttpContext.Current.Response.StatusDescription = desc_erro;
                        HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                        HttpContext.Current.Response.End();
                    }
                } 
            }
        }


        private bool permittedSkipAuthorization(string url)
        {

            List<string> requisicoesAbertas = new List<string>();

            requisicoesAbertas.Add("/");
            requisicoesAbertas.Add("/api/token");
            requisicoesAbertas.Add("/api/usuario/limparSessao");
            requisicoesAbertas.Add("api/token");
            requisicoesAbertas.Add("api/usuario/limparSessao");
            requisicoesAbertas.Add("token");
            requisicoesAbertas.Add("usuario/limparSessao");

            if (String.IsNullOrEmpty(requisicoesAbertas.Find(x => x == url)))
                return false;
            else
                return true;
        }

    }

}