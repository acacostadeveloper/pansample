﻿using Pan.Restritivos.WcfRestful.NullableBehavior;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;

namespace Restritivos.WcfRestful.NullableBehavior
{
    /// <summary>
    /// Service host do restful
    /// </summary>
    public sealed class NullableWebServiceHost : ServiceHost
    {
        public NullableWebServiceHost()
        {
        }

        public NullableWebServiceHost(object singletonInstance, params Uri[] baseAddresses)
            : base(singletonInstance, baseAddresses)
        {
        }

        public NullableWebServiceHost(Type serviceType, params Uri[] baseAddresses)
            : base(serviceType, baseAddresses)
        {
        }

        protected override void OnOpening()
        {
            if (this.Description != null)
            {
                foreach (var endpoint in this.Description.Endpoints)
                {
                    if (endpoint.Binding != null)
                    {
                        var webHttpBinding = endpoint.Binding as WebHttpBinding;

                        if (webHttpBinding != null)
                        {
                            webHttpBinding.ContentTypeMapper = new NewtonsoftJsonContentTypeMapper();
                            endpoint.Behaviors.Add(new NullableWebHttpBehavior());
                            endpoint.Behaviors.Add(new NewtonsoftJsonBehavior());
                        }
                    }
                }
            }

            base.OnOpening();
        }
    }
}