﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web;

namespace Restritivos.WcfRestful.NullableBehavior
{
    /// <summary>
    /// construtor do service host restful
    /// </summary>
    public sealed class NullableWebServiceHostFactory : ServiceHostFactory
    {
        protected override ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
        {
            return new NullableWebServiceHost(serviceType, baseAddresses);
        }
    }
}