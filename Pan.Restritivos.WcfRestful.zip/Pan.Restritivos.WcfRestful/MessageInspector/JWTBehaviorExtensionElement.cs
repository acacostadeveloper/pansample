﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceModel.Configuration;
using System.Web;

namespace Pan.Restritivos.WcfRestful.MessageInspector
{
    /// <summary>
    /// Calsse para extensão de elemento 
    /// </summary>
    public class JWTBehaviorExtensionElement : BehaviorExtensionElement
    {
        public override Type BehaviorType
        {
            get
            {
                return typeof(JWTEndpointBehavior);
            }
        }

        protected override object CreateBehavior()
        {
            return new JWTEndpointBehavior();
        }
    }
}