﻿
using Pan.Restritivos.Model;
using Pan.Restritivos.WcfRestful.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Web;


namespace Pan.Restritivos.WcfRestful.MessageInspector
{
    /// <summary>
    /// Classe para caputar mensagem do request
    /// </summary>
    public class JWTMessageInspector : IDispatchMessageInspector
    {
        
        public JWTMessageInspector()
        {
        }

        #region IDispatchMessageInspector Members
        public object AfterReceiveRequest(ref Message request, System.ServiceModel.IClientChannel channel, System.ServiceModel.InstanceContext instanceContext)
        {
            return null;
        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
            // Refresh do TOKEN
            //## Utilizado para atualizar a data da última requisição para que o token continue válido
            String newToken = null;
            HttpResponseMessageProperty httpResponseMessage;
            object httpResponseMessageObject;

            var token = HttpContext.Current.Request.Headers["Authorization"];
            int sessionId = Convert.ToInt32(HttpContext.Current.Request.Headers["X-SessionId"]);
            if (token != null && sessionId != null)
            {
                RestToken objRestToken = new RestToken();
                CustomToken objToken = new CustomToken();
                objToken.token = token.Replace("Bearer ", "");

                // Atualiza o token
                newToken = objRestToken.refreshToken(objToken);
            }

            if (!String.IsNullOrEmpty(newToken))
            {
                if (reply.Properties.TryGetValue(HttpResponseMessageProperty.Name, out httpResponseMessageObject))
                {
                    httpResponseMessage = httpResponseMessageObject as HttpResponseMessageProperty;
                    if (string.IsNullOrEmpty(httpResponseMessage.Headers["Authorization"]))
                    {
                        httpResponseMessage.Headers["Authorization"] = "Bearer " + newToken;
                    }
                    if (string.IsNullOrEmpty(httpResponseMessage.Headers["X-SessionId"]))
                    {
                        httpResponseMessage.Headers["X-SessionId"] = sessionId.ToString();
                    }

                }
                else
                {
                    httpResponseMessage = new HttpResponseMessageProperty();
                    httpResponseMessage.Headers.Add("Authorization", "Bearer " + newToken);
                    reply.Properties.Add(HttpRequestMessageProperty.Name, httpResponseMessage);
                }
            }
        }

        #endregion


    }
}