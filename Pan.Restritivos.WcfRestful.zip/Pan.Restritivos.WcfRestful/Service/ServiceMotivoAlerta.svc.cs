﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Motivos de alerta do sistema restrivos
    /// </summary>
   [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceMotivoAlerta : IServiceMotivoAlerta
    {
        BllMotivoAlerta ibllmotivoalerta;

        public ServiceMotivoAlerta()
        {
            ibllmotivoalerta = new BllMotivoAlerta();
        }

        public Model.Sistema.Motivo Inserir(Model.Sistema.Motivo model)
        {
            try
            {
                int idusuario;
                idusuario = JsonWebToken.obterIdUsuarioLogado();
                model.idUsuarioManutencao = idusuario;
                ibllmotivoalerta.Inserir(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao adicionar usuário: " + ex.Message));
            }
            return model;
        }


        public List<Motivo> Listar(string codMotivo, string txMotivo)
        {
            List<Motivo> temp = null;
            try
            {
                Motivo filter = new Motivo();
                filter.codMotivo = codMotivo;
                filter.txMotivo = txMotivo;

                temp = ibllmotivoalerta.Listar(filter);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao obter motivo do alerta"));
            }
            return temp;
        }




        public Motivo Alterar(Motivo model)
        {
            Motivo temp = null;
            try
            {
                int idusuario;
                idusuario = JsonWebToken.obterIdUsuarioLogado();
                model.idUsuarioManutencao = idusuario;
                temp = ibllmotivoalerta.Alterar(model);
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao editar motivo do alerta"));
            }
            return temp;
        }


        public bool Inativar(int idMotivo)
        {
            
            try
            {
                int idusuario;
                bool temp;
                idusuario = JsonWebToken.obterIdUsuarioLogado();          

                temp = ibllmotivoalerta.Inativar(new Motivo() { idMotivo = idMotivo, idUsuarioManutencao = idusuario});

                return temp;
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao editar motivo do alerta"));
            }
         
        }
    }
}
