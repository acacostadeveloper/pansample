﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.User;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using Pan.Restritivos.Model;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using Pan.Restritivos.Business.Concrete;
using System.DirectoryServices.AccountManagement;
using System.Data.Entity.Validation;



namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de usuários do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class RestUsuario : IRestUsuario
    {
        BllUsuario ibllusuario;

        public RestUsuario()
        {
            ibllusuario = new BllUsuario();
        }
        
        public List<Usuario> Listar(string login,string nmUsuario)
        {
            List<Usuario> temp = null;
            try
            {
                Usuario filter   = new Usuario();
                filter.login     = login;
                filter.nmUsuario = nmUsuario;
                temp = ibllusuario.Listar(filter);
            }
            /*
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao obter as funcionalidades"));
            }  
            */
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
    
                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);
    
                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);
    
                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
            return temp;
        }

        public List<Acessos> ListaFuncionalidades()
        {
            List<Acessos> temp = null;
            try
            {
                temp = ibllusuario.ListaFuncionalidades();
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao obter as funcionalidades"));
            }
            return temp;
        }


        public Usuario Inserir(Usuario model)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                model.idUsuarioInclusao = JsonWebToken.obterIdUsuarioLogado();
                model.DtUsuarioInclusao = DateTime.Now;
                model.blnAtivo          = true;
                ibllusuario.Inserir(model);
            }
          /*catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao adicionar usuário: " + ex.Message));
            }*/
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
            return model;
        }



        public Usuario Alterar(Usuario model)
        {
            Usuario temp = null;
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                model.DtUsuarioManutencao = DateTime.Now;
                temp = ibllusuario.Alterar(model);
            }
          /*catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao editar usuário: " + ex.Message));
            }*/
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }

            return temp;
        }


        public bool Inativar(int iduser)
        {
            bool temp = false;
            try
            {
                int idusuario;
                idusuario = JsonWebToken.obterIdUsuarioLogado();
                temp = ibllusuario.Inativar(new Usuario() { idUsuario = iduser });
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao deletar usuário: " + ex.Message));
            }
            return temp;
        }


        public bool validaUsuarioExistenteAD(String login)
        {
            bool isValid = false;
            try
            {
                String domain = System.Configuration.ConfigurationManager.AppSettings.Get("domain");

                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, domain))
                {
                    UserPrincipal insUserPrincipal = new UserPrincipal(pc);
                    PrincipalSearcher insPrincipalSearcher = new PrincipalSearcher();

                    insUserPrincipal.SamAccountName = login;
                    insPrincipalSearcher.QueryFilter = insUserPrincipal;

                    List<Principal> results = insPrincipalSearcher.FindAll().ToList<Principal>();

                    if (results.Count > 0)
                        isValid = true;
                    else
                        isValid = false;
                }

                return isValid;
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool limparSessao(string login, int sessionID) 
        {
            bool temp = true;
            try
            {   
                ibllusuario.limparSessao(sessionID, login);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao editar usuário"));
            }
            return temp;
        }

    }
}
