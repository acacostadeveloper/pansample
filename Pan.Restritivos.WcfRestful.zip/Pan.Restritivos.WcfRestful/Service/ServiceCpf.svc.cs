﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;



namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de CPF do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceCpf : IServiceCpf
    {

        public Cpf Inserir(Cpf model)
        {
            try
            {
                BllCpf bll = new BllCpf();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }

            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Cpf> Listar(string nrCpf, string nmTitular, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllCpf bll = new BllCpf();

                Cpf _obj = new Cpf();

                _obj.nrCpf = nrCpf;
                _obj.nmTitular = nmTitular;

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(Cpf cpf)
        {
            try
            {
                BllCpf bll = new BllCpf();
                cpf.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(cpf);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public Cpf Alterar(Cpf model)
        {
            try
            {
                BllCpf bll = new BllCpf();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Cpf> Importar(Arquivo item)
        {
            try
            {
                if (item.arq != null)
                {
                    BllCpf bll = new BllCpf();
                    item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                    item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();
                    List<Cpf> lst = bll.Importar(item);

                    Log.salvar("lista count " + lst.Count.ToString());

                       return lst;
                }
                else
                    throw new customException("Arquivo invalido");

            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Cpf> ListarLog(int idCpf)
        {
            try
            {
                BllCpf bll = new BllCpf();
                return bll.ListarLog(idCpf);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(Cpf item)
        {
            try
            {
                BllCpf bll = new BllCpf();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
