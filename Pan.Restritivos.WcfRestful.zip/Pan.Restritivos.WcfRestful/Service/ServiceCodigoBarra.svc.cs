﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Codigo de Barras do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceCodigoBarra : IServiceCodigoBarra
    {

        public CodigoBarra Inserir(CodigoBarra model)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<CodigoBarra> Listar(string codBarra, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();

                CodigoBarra _obj = new CodigoBarra();

                _obj.codBarra = codBarra;                

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(CodigoBarra CodigoBarra)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();
                CodigoBarra.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(CodigoBarra);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public CodigoBarra Alterar(CodigoBarra model)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<CodigoBarra> Importar(Arquivo item)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();
                
                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<CodigoBarra> ListarLog(int idCodigoBarra)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();
                return bll.ListarLog(idCodigoBarra);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(CodigoBarra item)
        {
            try
            {
                BllCodigoBarra bll = new BllCodigoBarra();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
