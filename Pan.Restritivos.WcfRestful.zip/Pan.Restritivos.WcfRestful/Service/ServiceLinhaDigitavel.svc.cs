﻿
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Linha Digitavel do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceLinhaDigitavel : IServiceLinhaDigitavel
    {

        public LinhaDigitavel Inserir(LinhaDigitavel model)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<LinhaDigitavel> Listar(string nrLinhaDigitavel, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();

                LinhaDigitavel _obj = new LinhaDigitavel();

                _obj.nrLinhaDigitavel = nrLinhaDigitavel;                

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(LinhaDigitavel LinhaDigitavel)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();
                LinhaDigitavel.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(LinhaDigitavel);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public LinhaDigitavel Alterar(LinhaDigitavel model)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<LinhaDigitavel> Importar(Arquivo item)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();
                
                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<LinhaDigitavel> ListarLog(int idLinhaDigitavel)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();
                return bll.ListarLog(idLinhaDigitavel);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(LinhaDigitavel item)
        {
            try
            {
                BllLinhaDigitavel bll = new BllLinhaDigitavel();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
