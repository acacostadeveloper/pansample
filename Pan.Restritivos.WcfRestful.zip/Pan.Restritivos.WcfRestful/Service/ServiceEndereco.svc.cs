﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Endereço do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceEndereco : IServiceEndereco
    {

        public Endereco Inserir(Endereco model)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Endereco> Listar(string nmLogradouro, string nmBairro, string nmCidade, string nmUF, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                Endereco _obj = new Endereco();

                _obj.nmLogradouro = nmLogradouro;
                _obj.nmBairro = nmBairro;
                _obj.nmCidade = nmCidade;
                _obj.nmUF = nmUF;

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                var temp = bll.Listar(_obj);
                return temp;
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(Endereco Endereco)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                Endereco.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(Endereco);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public Endereco Alterar(Endereco model)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Endereco> Importar(Arquivo item)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();

                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Endereco> ListarLog(int idEndereco)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                return bll.ListarLog(idEndereco);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(Endereco item)
        {
            try
            {
                BllEndereco bll = new BllEndereco();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
