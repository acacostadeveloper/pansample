﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ModelPanPaDp.Configuracao;
using WcfRestfulPanPaDp.Utils;
using System.ServiceModel.Activation;
using ModelPanPaDp.Alcadas;
using ModelPanPaDp;
using WcfRestfulPanPaDp.Utils.JWT;

namespace WcfRestfulPanPaDp
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "RestConfiguracao" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select RestConfiguracao.svc or RestConfiguracao.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class RestConfiguracao : IRestConfiguracao
    {
        ServiceConfiguracao.ServiceConfiguracaoClient client = new ServiceConfiguracao.ServiceConfiguracaoClient();
       
        public List<Menu> getmenu(string idPerfil)
        {
            List<Menu> temp = null;
            try
            {
                temp = client.getmenu(idPerfil);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao listar os menus"));

            }
            return temp;            
        }

        public bool addperfil(PerfilAcesso model)
        {
            bool temp = false;
            try
            {
                string idusuario = String.Empty;
                idusuario = JsonWebToken.obterIdUsuarioLogado();
                model.idlogusuariooperacao = idusuario;
                temp = client.addperfil(model);
            }
            catch (FaultException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.Message));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao adicionar o perfil"));
            }
            return temp;
        }

        public List<PerfilAcesso> pesquisar(string flagstatus)
        {
            List<PerfilAcesso> temp = null;
            try
            {
                temp = client.pesquisar(flagstatus);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao listar os Perfis"));
            }
            return temp;   
        }

        public PerfilAcesso deletar(string idPerfil)
        {
            PerfilAcesso temp = null;
            try
            {
                string idusuario = String.Empty;
                idusuario = JsonWebToken.obterIdUsuarioLogado();
                temp = client.deletar(idPerfil, idusuario);
            }
            catch (FaultException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.Message));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao excluir este perfil"));
            }
            return temp;              
        }

        public PerfilAcesso getperfil(string idperfil)
        {
            PerfilAcesso temp = null;
            try
            {
                temp = client.getperfil(idperfil);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao listar o(s) perfil(is)"));
            }
            return temp;   
        }

        public bool editarperfil(PerfilAcesso model)
        {
            bool temp = false;
            try
            {
                string idusuario = String.Empty;
                idusuario = JsonWebToken.obterIdUsuarioLogado();
                model.idlogusuariooperacao = idusuario;
                temp = client.editarperfil(model);
            }
            catch (FaultException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.Message));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao editar este perfil"));
            }
            return temp;  
        }

        public Alcada getconfigalcadas()
        {
            Alcada temp = null;
            try
            {
                temp = client.getconfigalcadas();
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao listar as configurações de alçadas"));
            }
            return temp;   
        }

        public EstatoCidade getEstadosCidades()
        {
            EstatoCidade temp = null;
            try
            {
                temp = client.getEstadosCidades();
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao listar os Estados e Cidades"));
            }
            return temp;   
        }

        public List<Menu> acessos(string idperfil)
        {
            List<Menu> temp = null;
            try
            {
                temp = client.acessos(idperfil);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason("Foi encontrada uma exceção ao listar os acessos"));
            }
            return temp;   
        }
    }
}
