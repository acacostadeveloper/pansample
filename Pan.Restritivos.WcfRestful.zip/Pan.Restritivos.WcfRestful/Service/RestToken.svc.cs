﻿using System;
using System.Web;
using System.Net;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Security.Claims;
using System.ServiceModel.Activation;
using System.Security.Authentication;
using System.ServiceModel.Channels;
using System.Web.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

using Pan.Restritivos.Model;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using Pan.Restritivos.WcfRestful.Interface;


namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para geração de token, utilizado para login do sistema restritivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class RestToken : IRestToken
    {
        BllUsuario ibllusuario;
        private String _keyCrypto;
        private static readonly DateTime UnixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);

        public RestToken()
        {
            ibllusuario = new BllUsuario();
            _keyCrypto = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");
        }

        public String refreshToken(CustomToken objToken)
        {
            try
            {
                CustomToken newToken = new CustomToken();

                //## Descriptografa o token
                newToken = JsonWebToken.DecodeToObject<CustomToken>(objToken.token, _keyCrypto, true);
                newToken.DtUltimaRequisicao = DateTime.Now;
                // newToken.succeed = true;

                //## Cria novamente o token com a data de ultima requisição atualizada
                newToken.token = JsonWebToken.Encode(newToken, _keyCrypto, JwtHashAlgorithm.HS512);
                return newToken.token;
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public CustomToken token(CustomToken objToken)
        {            
            try
            {
                objToken.UserAgent = HttpContext.Current.Request.Headers["User-Agent"];

                OperationContext context = OperationContext.Current;
                MessageProperties prop = context.IncomingMessageProperties;
                RemoteEndpointMessageProperty endpoint = prop[RemoteEndpointMessageProperty.Name] as RemoteEndpointMessageProperty;
                objToken.ClientAddress = endpoint.Address;

                if (ValidaToken.isAuthenticatedUser(objToken))
                {
                    int idusuario              = ibllusuario.getIdUserbyLogin(objToken.Login);
                    Usuario usuario            = ibllusuario.getuser(idusuario);

                    //EGS 30.04.2018 Se não fosse informado SessionId na chamada do Token, estava zerando a sessão
                    objToken.IDUsuario          = idusuario;
                    objToken.DtCriacao          = DateTime.Now;
                    objToken.DtUltimaRequisicao = objToken.DtCriacao;
                    objToken.exp                = Convert.ToInt32(Math.Round((DateTime.UtcNow.AddMinutes(objToken.tempoExpiracao) - UnixEpoch).TotalSeconds));


                    //EGS 30.04.2018 Se não fosse informado SessionId na chamada do Token, estava zerando a sessão
                    if (objToken.SessionId == 0)
                    {
                        CustomToken newToken = new CustomToken();
                        newToken             = ibllusuario.obterSessao(objToken.SessionId, objToken.Login);
                        objToken.SessionId   = newToken.SessionId;
                    }


                    // TODO: ajustar para token carregar permisoes 
                    //objToken.succeed = true;
                    objToken.Roles   = ibllusuario.getaccesspage(idusuario);

                    //EGS 30.06.2018 - Carrega os grupos de permissão do AD do login
                    objToken.RolesAD = GetPoliticaPermissaoAD(objToken.Login);

                    // new JavaScriptSerializer();

                    objToken.NomeUsuario = usuario.nmUsuario;
                    objToken.token = JsonWebToken.Encode(objToken, _keyCrypto, JwtHashAlgorithm.HS512);
                    CustomToken objSessaoAtiva = ibllusuario.obterSessao(0, objToken.Login);
                    if (objSessaoAtiva.SessionId != 0)
                    {
                        //## Verifica se a sessão anterior foi expirada
                        if (objSessaoAtiva.DtUltimaRequisicao.AddMinutes(objSessaoAtiva.tempoExpiracao) < DateTime.Now)
                        {
                            //## Se a sessão foi expirada, limpar a sessão
                            ibllusuario.limparSessao(0, objToken.Login);
                        }
                        else
                        {
                            //## Se não está expirada, derrubar a sessão e comunicar usuário
                            ibllusuario.limparSessao(0, objToken.Login);
                            objToken.deslogouSessaoAnterior = true;
                        }
                    }

                    //## Salvar a sessão no BD
                    ibllusuario.iniciarSessao(objToken.SessionId, objToken.Login, objToken.token, objToken.DtUltimaRequisicao);
                }
                return objToken;


            }
            catch (FaultException<ServiceFault> fault)
            {
                Log.salvar(fault.Message);
                var a = fault;
                throw fault;
                // fault.Detail.Message contains "Unauthorized Access"
            }
        }






        /*===========================================================================================================
        // Programa...:  GetPoliticaPermissaoAD - Gera lista de grupos de permissao na politica do AD
        // Autor......:  Edinaldo Silva (IT Singular)
        // Data.......:  30.06.2018
        ===========================================================================================================*/
        private static List<String> GetPoliticaPermissaoAD(string pNomeUsuario)
        {
            //-------------------------------- validação de Politica no AD - EGS 30.06.2018 -------------------------------------
            List<String> lstRole = new List<string>();
            string path    = WebConfigurationManager.AppSettings["ActiveDirectoryPath"];
            
            using (DirectoryEntry de = new DirectoryEntry(path))
            {
                using (DirectorySearcher adSearch = new DirectorySearcher(de))
                {
                    adSearch.Filter = "(sAMAccountName=" + pNomeUsuario + ")";
                    SearchResult adSearchResult = adSearch.FindOne();

                    int propertyCount = adSearchResult.Properties["memberOf"].Count;
                    String dn;
                    int equalsIndex, commaIndex;

                    for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                    {
                        dn = (String)adSearchResult.Properties["memberOf"][propertyCounter];

                        equalsIndex = dn.IndexOf("=", 1);
                        commaIndex  = dn.IndexOf(",", 1);
                        if (-1 == equalsIndex)
                        {
                            break;
                        }
                        string role = dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1);
                        lstRole.Add(role);
                    }
                }
                //EGS ================================= REMOVER ============================================================
                //EGS ================================= REMOVER ============================================================
                if ((pNomeUsuario.ToUpper().Trim() == "14873816890") || (pNomeUsuario.ToUpper().Trim() == "800041317") || (pNomeUsuario.ToUpper().Trim() == "10579190803")) 
                { 
                    lstRole.Add("SMTEnvioTED_Dev"); lstRole.Add("SMTEnvioTED_Hml"); lstRole.Add("SMTEnvioTED_Prod"); 
                }
                //EGS ================================= REMOVER ============================================================
                //EGS ================================= REMOVER ============================================================
            }
            return lstRole;
        }

    }
}
