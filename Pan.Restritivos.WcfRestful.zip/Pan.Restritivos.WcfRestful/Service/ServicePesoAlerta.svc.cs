﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Peso de alerta do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServicePesoAlerta : IServicePesoAlerta
    {

        public Peso Inserir(Peso peso)
        {
            try
            {
                BllPesoAlerta bll = new BllPesoAlerta();                
                peso.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(peso);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Peso> Listar(string codPeso, string txPeso)
        {
            try
            {
                BllPesoAlerta bll = new BllPesoAlerta();
                return bll.Listar(new Peso() { codPeso = codPeso, txPeso = txPeso });
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(Peso peso)
        {
            try
            {
                BllPesoAlerta bll = new BllPesoAlerta();
                peso.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(new Peso() { idPeso = peso.idPeso });
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public Peso Alterar(Peso peso)
        {
            try
            {
                BllPesoAlerta bll = new BllPesoAlerta();
                peso.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(peso);
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
