﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Telefone do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceTelefone : IServiceTelefone
    {

        public List<Model.Sistema.Telefone> Listar(int nrDDD, int nrTelefone, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllTelefone bll = new BllTelefone();

                Telefone _obj = new Telefone();

                _obj.nrDDD = nrDDD;
                _obj.nrTelefone = nrTelefone;

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }


        public Telefone Inserir(Telefone model)
        {
            try
            {
                BllTelefone bll = new BllTelefone();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw new FaultException<ServiceFault>(new ServiceFault(ex), new FaultReason(ex.msg));
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }


        public Telefone Alterar(Telefone model)
        {
            try
            {
                BllTelefone bll = new BllTelefone();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }           
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Telefone> Importar(Arquivo item)
        {
            try
            {
                BllTelefone bll = new BllTelefone();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();
                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Telefone> ListarLog(int idTelefone)
        {
            try
            {
                BllTelefone bll = new BllTelefone();
                return bll.ListarLog(idTelefone);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(Telefone item)
        {
            throw new NotImplementedException();
        }


        public bool Inativar(Telefone item)
        {
            try
            {
                BllTelefone bll = new BllTelefone();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
    

