﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de cnpj do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceCnpj : IServiceCnpj
    {

        public Cnpj Inserir(Cnpj model)
        {
            try
            {
                BllCnpj bll = new BllCnpj();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Cnpj> Listar(string nrCnpj, string nmEmpresa, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllCnpj bll = new BllCnpj();

                Cnpj _obj = new Cnpj();

                _obj.nrCnpj = nrCnpj;
                _obj.nmEmpresa = nmEmpresa;

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(Cnpj Cnpj)
        {
            try
            {
                BllCnpj bll = new BllCnpj();
                Cnpj.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(Cnpj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public Cnpj Alterar(Cnpj model)
        {
            try
            {
                BllCnpj bll = new BllCnpj();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Cnpj> Importar(Arquivo item)
        {
            try
            {
                BllCnpj bll = new BllCnpj();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();
                
                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Cnpj> ListarLog(int idCnpj)
        {
            try
            {
                BllCnpj bll = new BllCnpj();
                return bll.ListarLog(idCnpj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(Cnpj item)
        {
            try
            {
                BllCnpj bll = new BllCnpj();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
