﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Endereço do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceIp : IServiceIp
    {
       
        public Ip Inserir(Ip model)
        {
            try
            {
                BllIp bll = new BllIp();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Ip> Listar(string nrIP, int nrPorta, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllIp bll = new BllIp();

                Ip _obj = new Ip();

                _obj.nrIP = nrIP;
                _obj.nrPorta = nrPorta;

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(Ip Ip)
        {
            try
            {
                BllIp bll = new BllIp();
                Ip.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(Ip);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public Ip Alterar(Ip model)
        {
            try
            {
                BllIp bll = new BllIp();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Ip> Importar(Arquivo item)
        {
            try
            {
                BllIp bll = new BllIp();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();

                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<Ip> ListarLog(int idIP)
        {
            try
            {
                BllIp bll = new BllIp();
                return bll.ListarLog(idIP);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(Ip item)
        {
            try
            {
                BllIp bll = new BllIp();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
