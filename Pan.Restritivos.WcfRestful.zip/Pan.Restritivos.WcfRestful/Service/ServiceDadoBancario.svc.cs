﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using Pan.Restritivos.WcfRestful.Interface;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.WcfRestful.Utils.JWT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace Pan.Restritivos.WcfRestful.Service
{
    /// <summary>
    /// Serviço Restful para gerenciamento de dados de Dados bancarios do sistema restrivos
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ServiceDadoBancario : IServiceDadoBancario
    {

        public DadoBancario Inserir(DadoBancario model)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inserir(model);
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw ex;
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }


        public List<DadoBancario> Listar(int nrBanco, int nrAgencia, string nrAgenciaDigito, int nrConta, string nrContaDigito, string nmCliente, string nrCPFCNPJ, string dtVigenciaInicio, string dtVigenciaFim)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();

                DadoBancario _obj = new DadoBancario();

                _obj.nrBanco = nrBanco;
                _obj.nrAgencia = nrAgencia;
                _obj.nrConta = nrConta;
                _obj.nmCliente = nmCliente;
                _obj.nrCPFCNPJ = nrCPFCNPJ;

                if (!string.IsNullOrEmpty(nrAgenciaDigito))
                    _obj.nrAgenciaDigito = nrAgenciaDigito;

                if (!string.IsNullOrEmpty(nrContaDigito))
                    _obj.nrContaDigito = nrContaDigito;

                if (!string.IsNullOrEmpty(dtVigenciaInicio))
                    _obj.dtVigenciaInicio = Convert.ToDateTime(dtVigenciaInicio);

                if (!string.IsNullOrEmpty(dtVigenciaFim))
                    _obj.dtVigenciaFim = Convert.ToDateTime(dtVigenciaFim);

                return bll.Listar(_obj);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Inativar(DadoBancario DadoBancario)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();
                DadoBancario.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Inativar(DadoBancario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DadoBancario Alterar(DadoBancario model)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();
                model.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                return bll.Alterar(model);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<DadoBancario> Importar(Arquivo item)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();
                item.idUsuarioManutencao = JsonWebToken.obterIdUsuarioLogado();
                item.NomeUsuario = JsonWebToken.obterNomeUsuarioLogado();

                return bll.Importar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public List<DadoBancario> ListarLog(int idDadoBancario)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();
                return bll.ListarLog(idDadoBancario);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }

        public bool Validar(DadoBancario item)
        {
            try
            {
                BllDadoBancario bll = new BllDadoBancario();
                return bll.Validar(item);
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
        }
    }
}
