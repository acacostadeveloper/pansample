﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Web;
using System.Web;

namespace Pan.Restritivos.WcfRestful.ErrorHandling
{
    /// <summary>
    /// Classe de tratemento de erro
    /// </summary>
    public class JsonErrorHandler : IEndpointBehavior, IErrorHandler
    {
        public bool HandleError(Exception error)
        {
            return true;
        }

        public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
        {
            GenericError desc = new GenericError(error.Message.ToString());

            fault = Message.CreateMessage(version, "", desc,
                new DataContractJsonSerializer(typeof(GenericError)));

            fault.Properties.Add(WebBodyFormatMessageProperty.Name,
                new WebBodyFormatMessageProperty(WebContentFormat.Json));

            var msgp = new HttpResponseMessageProperty();
            msgp.Headers[HttpResponseHeader.ContentType] = "application/json";
            msgp.StatusCode = HttpStatusCode.InternalServerError;
            msgp.StatusDescription = error.Message;

            fault.Properties.Add(HttpResponseMessageProperty.Name, msgp);
        }

        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bp) { }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime cr) { }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher ed)
        {
            ed.ChannelDispatcher.ErrorHandlers.Clear();
            ed.ChannelDispatcher.ErrorHandlers.Add(this);
        }

        public void Validate(ServiceEndpoint endpoint) { }
    }
}