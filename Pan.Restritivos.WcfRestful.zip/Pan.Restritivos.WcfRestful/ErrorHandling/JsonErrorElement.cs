﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Configuration;
using System.Web;

namespace Pan.Restritivos.WcfRestful.ErrorHandling
{
    /// <summary>
    /// Classe para elemento de erro 
    /// </summary>
    public class JsonErrorElement : BehaviorExtensionElement
    {
        public override Type BehaviorType
        {
            get
            {
                return typeof(JsonErrorHandler);
            }
        }

        protected override object CreateBehavior()
        {
            return new JsonErrorHandler();
        }
    }
}