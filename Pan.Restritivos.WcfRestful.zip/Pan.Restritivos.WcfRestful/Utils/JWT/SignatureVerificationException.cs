﻿using System;

namespace Pan.Restritivos.WcfRestful.Utils.JWT
{
    /// <summary>
    /// Classe para verificar assinatura do token
    /// </summary>
	public class SignatureVerificationException : Exception
	{
		public SignatureVerificationException(string message)
			: base(message)
		{
		}
	}
}