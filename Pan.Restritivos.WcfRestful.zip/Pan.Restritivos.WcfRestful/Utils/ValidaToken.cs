﻿using System;
using System.Web;
using System.Linq;
using System.Net;
using System.Web.Configuration;
using System.ServiceModel;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using Pan.Restritivos.WcfRestful.Utils;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model;
using Pan.Restritivos.WcfRestful.Utils.JWT;



namespace Pan.Restritivos.WcfRestful.Utils
{
    /// <summary>
    /// Classe para validação do token de autenticação
    /// </summary>
    public class ValidaToken
    {
        BllUsuario ibllusuario;
        private static String _keyCrypto;

        public ValidaToken()
        {
            ibllusuario = new BllUsuario();
            _keyCrypto = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");
        }
        public static bool isAuthenticatedUser(CustomToken objToken)
        {
            try
            {
                BllUsuario ibllusuario = new BllUsuario();
                String _domain         = System.Configuration.ConfigurationManager.AppSettings.Get("domain");
                String _path           = System.Configuration.ConfigurationManager.AppSettings.Get("pathAd");
                _keyCrypto             = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");

                string senhaDescriptografada = String.Empty;
                string retornoAD             = String.Empty;

                // Decriptografar senha
                Encryption en = new Encryption(_keyCrypto);
                senhaDescriptografada = en.Decrypt(objToken.Senha);

                // Validar usuário no AD
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, _domain))
                {
                    // Obtem informações do usuário
                    UserPrincipal objUser = UserPrincipal.FindByIdentity(pc, objToken.Login);

                    // Verifica se o usuário existe
                    if (objUser == null)
                    {
                        retornoAD = "invalid_grant";
                    }
                    // Verifica se o usuário está expirado ou se a conta está bloqueada
                    else if (objUser.IsAccountLockedOut())
                    {
                        retornoAD = "user_block";
                    }
                    // Verifica se o usuário é valido
                    else if (!pc.ValidateCredentials(objToken.Login, senhaDescriptografada))
                    {
                        retornoAD = "invalid_grant";
                    }
                    // Verifica se o usuário existe no sistema e está ativo
                    else if (!ibllusuario.verificaUsuarioAtivo(objToken.Login))
                    {
                        retornoAD = "user_inactive";
                    }
                }

                // Tratar retorno da validação do usuário
                if (string.IsNullOrEmpty(retornoAD))
                {
                    return true;
                }
                else
                {
                    Exception erro = null;
                    switch (retornoAD)
                    {
                        case "invalid_grant":
                            erro = new Exception("Usuário e/ou Senha Incorretos");
                            erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                            break;
                        case "user_block":
                            erro = new Exception("Usuário expirado ou bloqueado");
                            erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                            break;
                        case "user_inactive":
                            erro = new Exception("Usuário não existe ou está inativo no sistema");
                            erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                            break;
                    }
                    throw new FaultException<ServiceFault>(new ServiceFault(erro), new FaultReason(erro.Message));
                }
            }
            catch (FaultException<ServiceFault> fault)
            {
                throw fault;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private bool isSessionValid           (CustomToken objTokenAtual)
        {
            CustomToken tokenAutenticacao;
            Exception erro = null;
            try
            {
                tokenAutenticacao = ibllusuario.obterSessao(objTokenAtual.SessionId, objTokenAtual.Login);

                //## Verifica se a sessão atual existe no BD
                if (tokenAutenticacao.SessionId == 0)
                {
                    erro = new Exception("Sessão inexistente ou finalizada.");
                    erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                    throw new FaultException<ServiceFault>(new ServiceFault(erro), new FaultReason(erro.Message));
                }

                if (objTokenAtual.SessionId != tokenAutenticacao.SessionId)
                { //## Verifica se a sessão atual é a mesma que o usuário autenticou no sistema
                    erro = new Exception("Sessão inválida.");
                    erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                    throw new FaultException<ServiceFault>(new ServiceFault(erro), new FaultReason(erro.Message));
                }

                //## Verifica se o token está expirado
                if (objTokenAtual.DtUltimaRequisicao.AddMinutes(objTokenAtual.tempoExpiracao) < DateTime.Now)
                {
                    erro = new Exception("O Token está expirado!");
                    erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                    throw new FaultException<ServiceFault>(new ServiceFault(erro), new FaultReason(erro.Message));
                }


                //## Descodifica as informações do token para utilizar na validação
                tokenAutenticacao = JsonWebToken.DecodeToObject<CustomToken>(tokenAutenticacao.token, _keyCrypto, true);

                //## Verifica se o UserAgent é o mesmo do login
                if (objTokenAtual.UserAgent != tokenAutenticacao.UserAgent)
                {
                    //## Verifica se a sessão atual é a mesma que o usuário autenticou no sistema
                    erro = new Exception("O User Agent é diferente do utilizado na autenticação do sistema!");
                    erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                    throw new FaultException<ServiceFault>(new ServiceFault(erro), new FaultReason(erro.Message));
                }

                //## Verifica se o ClientAddress é o mesmo do login
                if (objTokenAtual.ClientAddress != tokenAutenticacao.ClientAddress)
                {
                    //## Verifica se a sessão atual é a mesma que o usuário autenticou no sistema
                    erro = new Exception("O Client Address é diferente do utilizado na autenticação do sistema!");
                    erro.Data.Add("StatusCode", HttpStatusCode.Unauthorized.GetHashCode());
                    throw new FaultException<ServiceFault>(new ServiceFault(erro), new FaultReason(erro.Message));
                }

                return true;
            }
            catch (FaultException<ServiceFault> fault)
            {
                throw fault;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public  bool validateToken            (CustomToken objToken)
        {
            try
            {
                bool validationResult = true;

                // 1. Validar sessionID, UserAgend, ClientAddress
                validationResult = isSessionValid(objToken);

                // 2. Validar usuário
                validationResult = isAuthenticatedUser(objToken);

                return validationResult;
            }
            catch (FaultException<ServiceFault> fault)
            {
                throw fault;
            }

        }

    }
}