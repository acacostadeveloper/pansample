﻿using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Robo.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Robo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Iniciando processamento.");
                BllRobo _bl = new BllRobo();                
                int count = _bl.UpdateVigencia();
                Console.WriteLine("Total de registros alterados: " + count.ToString());
                Console.WriteLine("Fim do processamento.");
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
            }
        }
    }
}
