﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.SRT.Entidades;


namespace Pan.SRT.Helpers
{
    public class TratamentoEnvioEmail
    {

        public void _EnviarEmail(String pEmailDestino, String pAssunto, String pMensagemHtml)
        {

            using (System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient())
            {
                try
                {
                    string sEmailConta         = "ednaldo.silva.ext@grupopan.com";
                    string sEmailComCopia      = "edinaldo.zamboni@gmail.com";
                    smtp.Host                  = "192.168.2.233";
                    smtp.Port                  = 25;
                    smtp.EnableSsl             = false;
                    smtp.UseDefaultCredentials = false;

                    using (System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage())
                    {
                        mail.From = new System.Net.Mail.MailAddress(sEmailConta);
                        mail.Subject = pAssunto;
                        mail.Body = pMensagemHtml;
                        mail.To.Add(new System.Net.Mail.MailAddress(pEmailDestino));
                        mail.CC.Add(new System.Net.Mail.MailAddress(sEmailComCopia));
                        object userState = mail;
                        smtp.SendAsync(mail, userState);
                    }
                }
                catch (Exception ex)
                {
                    string desc_erro = "Erro ao enviar o email: " + ex.Message;
                }
            }

        }




        public string _EnviarEmail_Historico(MensagemTransferenciaStatus pStatusAlterado)
        {
            string bHistoricoRetorno = "";
            string bTextoStatus = "";
            string bTextoStatusNew = "";
            //------ Status Atual Descricao ------------------------------------------------
            if (pStatusAlterado.nrStatusOld == 0) { bTextoStatus = "LIBERADO"; }
            if (pStatusAlterado.nrStatusOld == 1) { bTextoStatus = "DESBLOQUEADA"; }
            if (pStatusAlterado.nrStatusOld == 2) { bTextoStatus = "BLOQUEADA"; }
            if (pStatusAlterado.nrStatusOld == 3) { bTextoStatus = "RECUSADA"; }
            if (pStatusAlterado.nrStatusOld >= 4) { bTextoStatus = "DESCONHECIDO"; }
            //------ Novo Status Descricao -------------------------------------------------
            if (pStatusAlterado.nrStatus == 0) { bTextoStatusNew = "LIBERADO"; }
            if (pStatusAlterado.nrStatus == 1) { bTextoStatusNew = "DESBLOQUEADA"; }
            if (pStatusAlterado.nrStatus == 2) { bTextoStatusNew = "BLOQUEADA"; }
            if (pStatusAlterado.nrStatus == 3) { bTextoStatusNew = "RECUSADA"; }
            if (pStatusAlterado.nrStatus >= 4) { bTextoStatusNew = "DESCONHECIDO"; }
            //------------------------------------------------------------------------------

            bHistoricoRetorno = "MONITORAMENTO [" + pStatusAlterado.idMensagemTransferencia.ToString() + "] ALTERADADO DE STATUS [" + pStatusAlterado.nrStatusOld + "] " + bTextoStatus + " PARA [" + pStatusAlterado.nrStatus + "] **" + bTextoStatusNew + "**";

            return bHistoricoRetorno;
        }

        public string _EnviarEmail_Assunto(MensagemTransferenciaStatus pStatusAlterado)
        {
            string bAssuntoRetorno = "";
            string bTextoStatus = "";
            string bTextoStatusNew = "";
            //------ Status Atual Descricao ------------------------------------------------
            if (pStatusAlterado.nrStatusOld == 0) { bTextoStatus = "LIBERADO"; }
            if (pStatusAlterado.nrStatusOld == 1) { bTextoStatus = "DESBLOQUEADA"; }
            if (pStatusAlterado.nrStatusOld == 2) { bTextoStatus = "BLOQUEADA"; }
            if (pStatusAlterado.nrStatusOld == 3) { bTextoStatus = "RECUSADA"; }
            if (pStatusAlterado.nrStatusOld >= 4) { bTextoStatus = "DESCONHECIDO"; }
            //------ Novo Status Descricao -------------------------------------------------
            if (pStatusAlterado.nrStatus == 0) { bTextoStatusNew = "LIBERADO"; }
            if (pStatusAlterado.nrStatus == 1) { bTextoStatusNew = "DESBLOQUEADA"; }
            if (pStatusAlterado.nrStatus == 2) { bTextoStatusNew = "BLOQUEADA"; }
            if (pStatusAlterado.nrStatus == 3) { bTextoStatusNew = "RECUSADA"; }
            if (pStatusAlterado.nrStatus >= 4) { bTextoStatusNew = "DESCONHECIDO"; }
            //------------------------------------------------------------------------------

            bAssuntoRetorno = "Pan.SMT - Alterado Status do Monitoramento [" + pStatusAlterado.idMensagemTransferencia.ToString() + "] de " + bTextoStatus + " para " + bTextoStatusNew + "";

            return bAssuntoRetorno;
        }

        public string _EnviarEmail_Conteudo(MensagemTransferenciaStatus pStatusAlterado)
        {
            string bHTMLRetorno = "";
            string bTextoStatus = "";
            string bTextoStatusNew = "";
            //------ Status Atual Descricao ------------------------------------------------
            if (pStatusAlterado.nrStatusOld == 0) { bTextoStatus = "LIBERADO"; }
            if (pStatusAlterado.nrStatusOld == 1) { bTextoStatus = "DESBLOQUEADA"; }
            if (pStatusAlterado.nrStatusOld == 2) { bTextoStatus = "BLOQUEADA"; }
            if (pStatusAlterado.nrStatusOld == 3) { bTextoStatus = "RECUSADA"; }
            if (pStatusAlterado.nrStatusOld >= 4) { bTextoStatus = "DESCONHECIDO"; }
            //------ Novo Status Descricao -------------------------------------------------
            if (pStatusAlterado.nrStatus == 0) { bTextoStatusNew = "LIBERADO"; }
            if (pStatusAlterado.nrStatus == 1) { bTextoStatusNew = "DESBLOQUEADA"; }
            if (pStatusAlterado.nrStatus == 2) { bTextoStatusNew = "BLOQUEADA"; }
            if (pStatusAlterado.nrStatus == 3) { bTextoStatusNew = "RECUSADA"; }
            if (pStatusAlterado.nrStatus >= 4) { bTextoStatusNew = "DESCONHECIDO"; }
            //------------------------------------------------------------------------------

            bHTMLRetorno = "";
            bHTMLRetorno = bHTMLRetorno + "<!DOCTYPE html>";
            bHTMLRetorno = bHTMLRetorno + "<html>";
            bHTMLRetorno = bHTMLRetorno + "<head>";
            bHTMLRetorno = bHTMLRetorno + "    <meta charset='UTF-8'/>";
            bHTMLRetorno = bHTMLRetorno + "    <title>Pan.SMT - Mudança de Status de Monitoramento</title>";
            bHTMLRetorno = bHTMLRetorno + "</head>";
            bHTMLRetorno = bHTMLRetorno + "<body>";
            bHTMLRetorno = bHTMLRetorno + "	   <h2>Pan.SMT - Mudança de Status de Monitoramento</h2>";
            bHTMLRetorno = bHTMLRetorno + "	                                                        ";
            bHTMLRetorno = bHTMLRetorno + "	   <p>Em <i>" + DateTime.Now.ToString() + "</i> o monitoramento [<b>" + pStatusAlterado.idMensagemTransferencia.ToString() + "</b>]";
            bHTMLRetorno = bHTMLRetorno + "	   mudou seu status de <b>" + bTextoStatus + "</b>";
            bHTMLRetorno = bHTMLRetorno + "	   para <span style='background: #1abc9c; border-radius:5px; padding:5px'>" + bTextoStatusNew + "</span>.</p>";
            bHTMLRetorno = bHTMLRetorno + "</body>";
            bHTMLRetorno = bHTMLRetorno + "</html>";

            return bHTMLRetorno;
        }
    }
}
