﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{
    //EGS 22.03.2018 - Model da tabela da Mensagem Recebida TED
    [Table("tbMensagemTransferencia")]
    [DataContract]
    public class MensagemTransferencia
    {
        //-------------------------------------------------------------------- Identificacao
        [Key]
        [DataMember]
        public int idMensagemTransferencia      { get; set; }
        [DataMember]                            
        public int idTipoMensagem               { get; set; }
        [DataMember]                            
        public int idMensagemCredito            { get; set; }
        [DataMember]                            
        public int idMensagemDebito             { get; set; }
        [DataMember]                            
        public string   CanalEntrada            { get; set; }
        [DataMember]                            
        public string   ComplementoHistorico    { get; set; }
        [DataMember]                            
        public string   DataAgendPag            { get; set; }
        [DataMember]                            
        public string   DataVencto              { get; set; }
        [DataMember]                            
        public string   HoraVencto              { get; set; }
        [DataMember]                            
        public string   Historico               { get; set; }
        [DataMember]                            
        public bool     Tarifado                { get; set; }
        [DataMember]                            
        public string   Finalidade              { get; set; }
        [DataMember]                            
        public string   Prioridade              { get; set; }
        [DataMember]                            
        public string   NroBoleto               { get; set; }
        [DataMember]                            
        public string   NumOrigem               { get; set; }
        [DataMember]                            
        public decimal  Valor                   { get; set; }
        [DataMember]                            
        public string   EventoCodigo            { get; set; }
        [NotMapped]                             
        public string   EventoDescricao         { get; set; }
        [DataMember]                            
        public bool     SensibilizaConta        { get; set; }
        [DataMember]                            
        public int?     IdClausulaValidada      { get; set; }
        //-------------------------------------------------------------------- Tipo Origem
        [NotMapped]
        public TipoMensagem     TipoMensagem    { get; set; }
        [NotMapped]
        public MensagemCredito  MensagemCredito { get; set; }
        [NotMapped]
        public MensagemDebito   MensagemDebito  { get; set; }
        //-------------------------------------------------------------------- 
        [DataMember]
        public int nrStatus                  { get; set; }              //0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada  9=Processando
        [DataMember]
        public int IdUsuarioInclusao         { get; set; }
        [DataMember]
        public DateTime DtUsuarioInclusao    { get; set; }
        [DataMember]
        public int? IdUsuarioManutencao      { get; set; }
        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }
        [DataMember]
        public bool blnAtivo                 { get; set; }

        public MensagemTransferencia()
        {
            TipoMensagem    = new TipoMensagem();
            MensagemCredito = new MensagemCredito();
            MensagemDebito  = new MensagemDebito();
        }
    }












    [DataContract]
    public class MensagemTransferenciaLista
    {
        //-------------------------------------------------------------------- Mensagem
        [DataMember]
        public int idMensagemTransferencia      { get; set; }
        [DataMember]
        public string   DataAgendPag            { get; set; }
        [DataMember]
        public string   DataVencto              { get; set; }
        [DataMember]
        public string   HoraVencto              { get; set; }
        [DataMember]
        public string   Finalidade              { get; set; }
        [DataMember]
        public string   Prioridade              { get; set; }
        [DataMember]
        public bool     SensibilizaConta        { get; set; }
        [DataMember]
        public bool     Tarifado                { get; set; }
        [DataMember]
        public string   NroBoleto               { get; set; }
        [DataMember]
        public string   NumOrigem               { get; set; }
        [DataMember]
        public string   Historico               { get; set; }
        [DataMember]
        public string   EventoCodigo            { get; set; }
        [DataMember]
        public string   EventoDescricao         { get; set; }
        [DataMember]
        public decimal  Valor                   { get; set; }
        [DataMember]
        public string   ValorString             { get; set; }
        //-------------------------------------------------------------------- Cliente
        [DataMember]
        public string   ClienteTipo             { get; set; }
        [DataMember]
        public string   ClienteCodigo           { get; set; }
        [DataMember]
        public string   ClienteNome             { get; set; }
        [DataMember]
        public string   ClienteCNPJ             { get; set; }
        [DataMember]
        public string   ClienteDesde            { get; set; }
        [DataMember]
        public string   ClienteTelefone         { get; set; }
        [DataMember]
        public string   ClienteCelular          { get; set; }
        [DataMember]
        public bool     ClienteExpostoPublic    { get; set; }

        //-------------------------------------------------------------------- Debito
        [DataMember]
        public string CodigoOrigem              { get; set; }
        [DataMember]
        public string SistemaOrigem             { get; set; }
        [DataMember]
        public string Deb_Origem                { get; set; }
        [DataMember]
        public string Deb_NumBanco              { get; set; }
        [DataMember]
        public string Deb_NumAgencia            { get; set; }
        [DataMember]
        public string Deb_NumConta              { get; set; }
        [DataMember]
        public bool   Deb_ContaDigital          { get; set; }
        [DataMember]
        public string Deb_TipoConta             { get; set; }
        [DataMember]
        public string Deb_TipoPessoa            { get; set; }
        //-------------------------------------------------------------------- Credito
        [DataMember]
        public string Cre_NumBanco              { get; set; }
        [DataMember]
        public string Cre_NumAgencia            { get; set; }
        [DataMember]
        public string Cre_NumConta              { get; set; }
        [DataMember]
        public string Cre_Cnpj                  { get; set; }
        [DataMember]
        public bool   Cre_ContaDigital          { get; set; }
        [DataMember]
        public string Cre_TipoConta             { get; set; }
        [DataMember]
        public string Cre_TipoPessoa            { get; set; }
        //-------------------------------------------------------------------- 
        [DataMember]
        public int?  IdClausulaValidada         { get; set; }              //EGS 30.05.2018 Se parou em alguma regra, grava o ID na Mensagem
        [DataMember]  
        public int   nrStatus                   { get; set; }              //0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada  9=Processando
        [DataMember]
        public int IdUsuarioInclusao            { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome       { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao       { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao         { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome     { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao    { get; set; }

        [DataMember]
        public bool  blnAtivo                   { get; set; }

    }










    [DataContract]
    public class MensagemTransferenciaFiltro
    {
        //-------------------------------------------------------------------- Campos para Filtro 30.06.2018
        [DataMember]
        public int       idMensagemTransferencia  { get; set; }
        [DataMember]                             
        public string    NroBoleto                { get; set; }
        [DataMember]                              
        public string    EventoCodigo             { get; set; }
        [DataMember]                              
        public decimal   nrValInicio              { get; set; }
        [DataMember]                              
        public decimal   nrValFinal               { get; set; }
        [DataMember]  
        public int       nrStatus                 { get; set; }              //0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada  9=Processando
        [DataMember]
        public DateTime? DtInclusaoInicio         { get; set; }
        [DataMember]
        public DateTime? DtInclusaoFinal          { get; set; }
    }



    [Table("tbMensagemTransHistorico")]
    [DataContract]
    public class MensagemTransHistorico
    {
        [Key]
        [DataMember]
        public int      idMensagemTransHistorico { get; set; }
        [DataMember]
        public int      idMensagemTransferencia  { get; set; }
        [DataMember]
        public DateTime dtDataInclusao           { get; set; }
        [DataMember]
        public int      ErroCodigo               { get; set; }
        [DataMember]
        public string   ErroDescricao            { get; set; }
    }


    //EGS 28.03.2018 - Model da tabela de MensagemTransferencia ao alterar Status
    [Table("tbMensagemTransferencia")]
    [DataContract]
    public class MensagemTransferenciaStatus
    {
        //-------------------------------------------------------------------- Identificacao
        [Key]
        [DataMember]
        public int idMensagemTransferencia { get; set; }
        [DataMember]
        public int nrStatus { get; set; }              //0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada
        [DataMember]
        public int nrStatusOld { get; set; }
        [DataMember]
        public string nmDescricaoStatus { get; set; }
    }
}


