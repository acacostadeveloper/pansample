﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.SRT.Entidades
{
    //EGS 30.05.2018 - Model da tabela IMPORTACAO
    [DataContract]
    public class Importacao
    {
        [DataMember]
        public string  Tabela     { get; set; }
        [DataMember]
        public string  ArquivoCSV { get; set; }
    }
}
