﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{

    //EGS 15.12.2017 - Model da tabela Alcada
    [Table("tbGravaLog")]
    [DataContract]
    public class GravaLog
    {
        [Key]
        [DataMember]
        public int idLog             { get; set; }

        [DataMember]
        public DateTime DataInclusao { get; set; }

        [DataMember]
        public string   Mensagem     { get; set; }
    }
}
