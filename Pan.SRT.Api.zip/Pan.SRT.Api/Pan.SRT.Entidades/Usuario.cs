﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;



namespace Pan.SRT.Entidades
{
    /// <summary>
    /// Entidade utilizada pelo entity USUARIO para definição e persistencia da base de dados.
    /// Pública á todas as camadas 15.03.2018
    /// </summary> 
    [Table("tbUsuario")]
    [Serializable]
    public class Usuario
    {
        [Key]
        public int idUsuario { get; set; }

        [Required]
        public string login { get; set; }

        [Required]
        public string nmUsuario { get; set; }

    }
}
