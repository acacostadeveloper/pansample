﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{

    //EGS 18.01.2018 - Model da tabela Tipo de Mensagem
    [Table("tbTipoMensagem")]
    [DataContract]
    public class TipoMensagem
    {
        [Key]
        [DataMember]
        public int idTipoMensagem { get; set; }

        [DataMember]
        [MaxLength(20)]
        public string nrCodigo { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmDescricao { get; set; }

        [DataMember]
        public bool blnSensibConta { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }












    //EGS 30.03.2018 - Model da tabela de Lista
    //EGS 18.01.2018 - Model da tabela Tipo de Mensagem
    [Table("tbTipoMensagem")]
    [DataContract]
    public class TipoMensagemLista
    {
        [Key]
        [DataMember]
        public int idTipoMensagem { get; set; }

        [DataMember]
        [MaxLength(20)]
        public string nrCodigo { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmDescricao { get; set; }

        [DataMember]
        public bool blnSensibConta { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }

}
