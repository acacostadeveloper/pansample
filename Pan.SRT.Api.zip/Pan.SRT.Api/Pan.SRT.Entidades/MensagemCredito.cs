﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.SRT.Entidades
{
    //EGS 22.03.2018 - Model da tabela da Mensagem Recebida TED
    [Table("tbMensagemCredito")]
    [DataContract]
    public class MensagemCredito
    {
        [Key]
        [DataMember]
        public int idMensagemCredito         { get; set; }
        [DataMember]                         
        public int idContaCredito            { get; set; }
        [DataMember]                         
        public int idTipoDestino             { get; set; }
        [NotMapped]                          
        public TipoDestino TipoDestino       { get; set; }
        [NotMapped]                          
        public Conta ContaCredito            { get; set; }
        [DataMember]
        public int IdUsuarioInclusao         { get; set; }
        [DataMember]
        public DateTime DtUsuarioInclusao    { get; set; }
        [DataMember]
        public int? IdUsuarioManutencao      { get; set; }
        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        public MensagemCredito() 
        { 
            TipoDestino = new TipoDestino();
            ContaCredito = new Conta();
        }
    }
}
