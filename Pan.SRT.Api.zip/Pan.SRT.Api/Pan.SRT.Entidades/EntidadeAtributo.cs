﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{

    //EGS 15.01.2018 - Model da tabela
    [Table("tbEntidadeAtributo")]
    [DataContract]
    public class EntidadeAtributo
    {
        [Key]
        [DataMember]
        public int idEntidadeAtributo { get; set; }

        [DataMember]
        public int idEntidade { get; set; }

        [DataMember]
        [MaxLength(150)]
        public string cdAtributo { get; set; }

        [DataMember]
        [MaxLength(1)]
        public string cdAtributoTipo { get; set; }

        [DataMember]
        [MaxLength(150)]
        public string nmAtributo { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }





    //EGS 25.01.2018 - Model da tabela 
    [Table("tbEntidadeAtributo")]
    [DataContract]
    public class EntidadeAtributoLista
    {
        [Key]
        [DataMember]
        public int idEntidadeAtributo { get; set; }

        [DataMember]
        public int idEntidade { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmEntidade { get; set; }

        [DataMember]
        [MaxLength(200)]
        public string cdEntidade { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string cdAtributo { get; set; }

        [DataMember]
        [MaxLength(1)]
        public string cdAtributoTipo { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmAtributo { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }


        [DataMember]
        public bool blnAtivo { get; set; }
    }
}
