﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;



namespace Pan.SRT.Entidades
{
    //EGS 22.03.2018 - Model da tabela da Mensagem Recebida TED
    [DataContract]
    public class MensagemResponse
    {
        [DataMember]
        public int    codErro        { get; set; }
        [DataMember]
        public string descricaoErro { get; set; }
        [DataMember]
        public string nsuSpb { get; set; }
        [DataMember]
        public int severidadeErro { get; set; }
    }
}
