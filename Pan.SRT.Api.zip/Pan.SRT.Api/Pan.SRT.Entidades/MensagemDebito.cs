﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;



namespace Pan.SRT.Entidades
{
    //EGS 22.03.2018 - Model da tabela da Mensagem Debito Recebida TED
    [Table("tbMensagemDebito")]
    [DataContract]
    public class MensagemDebito
    {
        [Key]
        [DataMember]
        public int idMensagemDebito          { get; set; }
        [DataMember]                         
        public int idContaDebito             { get; set; }
        [DataMember]                         
        public int idTipoOrigem              { get; set; }
        [DataMember]                         
        public string CodigoOrigem           { get; set; }
        [DataMember]
        public string IndicadoDebAutorizado  { get; set; }
        [DataMember]
        public string SistemaOrigem          { get; set; }
        [DataMember]
        public string SubSistemaOrigem       { get; set; }
        [DataMember]
        public int IdUsuarioInclusao         { get; set; }
        [DataMember]
        public DateTime DtUsuarioInclusao    { get; set; }
        [DataMember]
        public int? IdUsuarioManutencao      { get; set; }
        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [NotMapped]
        public TipoOrigem TipoOrigem         { get; set; }
        [NotMapped]
        public Conta ContaDebito             { get; set; }

        public MensagemDebito() 
        { 
            TipoOrigem  = new TipoOrigem();
            ContaDebito = new Conta();
        }
    }
}
