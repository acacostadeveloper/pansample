﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{
    //EGS 17.01.2018 - Model da tabela Email de Alerta
    [Table("tbEmailAlerta")]
    [DataContract]
    public class EmailAlerta
    {
        [Key]
        [DataMember]
        public int idEmailAlerta              { get; set; }

        [DataMember]
        [MaxLength(150)]
        public string nmEmailAlerta           { get; set; }

        [DataMember]
        public int IdSistemaOrigem            { get; set; }

        [DataMember]
        public int IdUsuarioInclusao          { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao     { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao       { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao  { get; set; }

        [DataMember]
        public bool blnAtivo                  { get; set; }
    }










    //EGS 30.03.2018 - Model da tabela de Lista
    [Table("tbEmailAlerta")]
    [DataContract]
    public class EmailAlertaLista
    {
        [Key]
        [DataMember]
        public int idEmailAlerta              { get; set; }

        [DataMember]
        [MaxLength(150)]
        public string nmEmailAlerta           { get; set; }

        [DataMember]
        public int IdSistemaOrigem            { get; set; }

        [DataMember]
        public string SistemaOrigem           { get; set; }

        [DataMember]
        public int IdUsuarioInclusao          { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome     { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao     { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao       { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome   { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao  { get; set; }

        [DataMember]
        public bool blnAtivo                  { get; set; }
    }
}
