﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.SRT.Entidades
{
    public class ParametrosTed
    {
        public string Agencia {get; set;}
        public string CodEvento { get; set; }
        public string HoraVencto { get; set; }
        public decimal Valor { get; set; }
        public string AgenciaDeb { get; set; }
        public string ContaDeb { get; set; }
        public string BancoCredito { get; set; }
        public string AgenciaCred { get; set; }
        public string ContaCred { get; set; }
        public string TipoContaCred { get; set; }
        public string CnpjCpfCliCred { get; set; }
        public string NomeCliCred { get; set; }
        public string Finalidade { get; set; }
        public string Historico { get; set; }
        public string Tarifado { get; set; }
        public string ValidaPtoCorteSpb { get; set; }
        public string CodUsuario { get; set; }
        public string CnpjCpfCliRem { get; set; }
        public string NomeCliRem { get; set; }
        public string CnpjCpfCliCred2 { get; set; }
        public string NomeCliCred2 { get; set; }
        public string CodIdentdTransf { get; set; }
        public string Origem { get; set; }
        public string SisOrigem { get; set; }
        public string DataVencto { get; set; }
        public string TipoPessoaCred { get; set; }
        public string Prioridade { get; set; }
        public string DataAgendPag { get; set; }
        public string DebAutorizado { get; set; }
        public string SensibilizaCC { get; set; }
        public string NroBoleto { get; set; }
        public string CodCliente { get; set; }
        public string TipoPessoaInvest { get; set; }
        public string CnpjCpfInvest { get; set; }
        public string NomeRzSocialInvest { get; set; }
        public string ComplementoHistorico { get; set; }
        public string NumOrigem { get; set; }
        public string SubSistemaO { get; set; }
        public string CanalEntrada { get; set; }
        public string IspbCred { get; set; }
    }
}
