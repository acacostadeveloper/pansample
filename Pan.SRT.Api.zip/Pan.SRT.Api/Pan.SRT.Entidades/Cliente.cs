﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.SRT.Entidades
{
    //EGS 25.03.2018 - Model da tabela Cliente
    [Table("tbCliente")]
    [DataContract]
    public class Cliente
    {
        [Key]
        [DataMember]
        public int idCliente                { get; set; }
        [DataMember]
        public string CodigoCliente         { get; set; }
        [DataMember]
        public DateTime DataInicioRelaciona { get; set; }
        [DataMember]
        public DateTime dtDataInclusao      { get; set; }
    }
}
