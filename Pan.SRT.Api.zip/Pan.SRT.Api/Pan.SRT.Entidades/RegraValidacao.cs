﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{

    //EGS 05.01.2018 - Model da tabela 
    [Table("tbRegraValidacao")]
    [DataContract]
    public class RegraValidacao
    {

        [Key]
        [DataMember]
        public int idRegraValidacao { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmDescricao { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmConsequencia { get; set; }    //'Alertar', 'Recusar', 'Bloquear' ou 'Deletar'

        [DataMember]
        public int nrCriticidade { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [NotMapped]
        public List<RegraValidaClausula> RegraClausulas { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }









    //EGS 30.04.2018 - Model da tabela de Lista
    [Table("tbRegraValidacao")]
    [DataContract]
    public class RegraValidacaoLista
    {

        [Key]
        [DataMember]
        public int idRegraValidacao { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmDescricao { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmConsequencia { get; set; }    //'Alertar', 'Recusar', 'Bloquear' ou 'Deletar'

        [DataMember]
        public int nrCriticidade { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [NotMapped]
        public List<RegraValidaClausulaLista> RegraClausulas { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }

}
