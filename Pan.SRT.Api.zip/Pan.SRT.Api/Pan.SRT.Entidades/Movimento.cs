﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.SRT.Entidades
{
    //EGS 15.01.2018 - Model da tabela
    [Table("tbMovimento")]
    [DataContract]
    public class Movimento
    {
        [Key]
        [DataMember]
        public int idMovimento              { get; set; }
        [DataMember]
        public int idConta                  { get; set; }
        [DataMember]
        public DateTime dtDataMovimento     { get; set; }
        [DataMember]
        public string dsDescricao           { get; set; }
        [DataMember]
        public decimal Valor                { get; set; }
    }
}
