﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;



namespace Pan.SRT.Entidades
{
    /// <summary>
    /// Entidade utilizada pelo token para login do sistema
    /// Pública á todas as camadas
    /// </summary> 
    public class CustomToken
    {
        private const int defaultTempoExpiracao = 60;
        private int _tempoExpiracao;
        public int IDUsuario { get; set; }
        public string Login { get; set; }
        public string Senha { get; set; }
        public string NomeUsuario { get; set; }
        public string UserAgent { get; set; }
        public string ClientAddress { get; set; }
        public int SessionId { get; set; }
        public DateTime DtCriacao { get; set; }
        public string token { get; set; }
        public DateTime DtUltimaRequisicao { get; set; }
        public int exp;                                    //EGS 30.04.2018 Tempo de Expiração padrão JWT

        public int tempoExpiracao
        {
            get { return defaultTempoExpiracao; }
            set { _tempoExpiracao = value; }
        }

        public bool deslogouSessaoAnterior { get; set; }
    }
}
