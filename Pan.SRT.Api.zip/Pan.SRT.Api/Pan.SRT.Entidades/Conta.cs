﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{
    //EGS 25.03.2018 - Model da tabela Conta
    [Table("tbConta")]
    [DataContract]
    public class Conta
    {
        [Key]
        [DataMember]
        public int idConta                   { get; set; }
        [DataMember]                         
        public string idChavePessoa          { get; set; }
        [DataMember]                         
        public int idInstituicaoFinanceira   { get; set; }
        [DataMember]                         
        public string NumeroBanco            { get; set; }
        [DataMember]                         
        public string NumeroAgencia          { get; set; }
        [DataMember]                         
        public string NumeroConta            { get; set; }
        [DataMember]                         
        public DateTime DataAbertura         { get; set; }
        [DataMember]
        public int IdUsuarioInclusao         { get; set; }
        [DataMember]
        public DateTime DtUsuarioInclusao    { get; set; }
        [DataMember]
        public int? IdUsuarioManutencao      { get; set; }
        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [NotMapped]
        public InstituicaoFinanceira InstituicaoFinanceira { get; set; }
        [NotMapped]
        public Movimento Movimento           { get; set; }
        [NotMapped]
        public Pessoa Pessoa                 { get; set; }


        public Conta() 
        {
            InstituicaoFinanceira = new InstituicaoFinanceira();
            Movimento             = new Movimento();
            Pessoa                = new Pessoa();
        }
    }
}
