﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{

    //EGS 15.12.2017 - Model da tabela Alcada
    [Table("tbAlcada")]
    [DataContract]
    public class Alcada
    {

        [Key]
        [DataMember]
        public int idAlcada                   { get; set; }

        [DataMember]
        public int idUsuario                  { get; set; }

        [DataMember]
        public int IdSistemaOrigem            { get; set; }

        [DataMember]
        [MaxLength(10)]
        public string cdAlcada                { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmDescricao             { get; set; }

        [DataMember]
        public int nrNivel                    { get; set; }

        [DataMember]
        public int IdUsuarioInclusao          { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao     { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao       { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao  { get; set; }

        [DataMember]
        public bool blnAtivo                  { get; set; }

    }

























    //EGS 30.03.2018 - Model da tabela Alcada de Lista
    [Table("tbAlcada")]
    [DataContract]
    public class AlcadaLista
    {
        [DataMember]
        public int idAlcada                   { get; set; }

        [DataMember]
        public int idUsuario                  { get; set; }

        [DataMember]
        public string UsuarioNome             { get; set; }

        [DataMember]
        public int IdSistemaOrigem            { get; set; }

        [DataMember]
        public string SistemaOrigem           { get; set; }

        [DataMember]
        [MaxLength(10)]
        public string cdAlcada                { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmDescricao             { get; set; }

        [DataMember]
        public int nrNivel                    { get; set; }

        [DataMember]
        public int IdUsuarioInclusao          { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome     { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao     { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao       { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome   { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao  { get; set; }

        [DataMember]
        public bool blnAtivo                  { get; set; }

    }
}
