﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Pan.SRT.Entidades
{

    //EGS 12.12.2017 - Numerador do campo SEGMENTO da tabela Instituição Financeira
    public enum Segmento { Multiplo, Comercial, CaixaEconomica, Cooperativa, Insvestimento }


    //EGS 15.12.2017 - Model da tabela Instituição Financeira
    [Table("tbInstituicaoFinanceira")]
    public class InstituicaoFinanceira
    {

        [Key]
        [DataMember]
        public int idInstituicaoFinanceira { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmInstituicaoFinanceira { get; set; }

        [DataMember]
        [MaxLength(20)]
        public string nrCnpj { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nrCodigoCompensacao { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string dsSegmento { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string dsGrupoEconomico { get; set; }

        [DataMember]
        public bool blnPossuiContaDigital { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }









    //EGS 30.03.2018 - Model da tabela de Lista
    [Table("tbInstituicaoFinanceira")]
    public class InstituicaoFinanceiraLista
    {
        [DataMember]
        public int idInstituicaoFinanceira { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nmInstituicaoFinanceira { get; set; }

        [DataMember]
        [MaxLength(20)]
        public string nrCnpj { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string nrCodigoCompensacao { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string dsSegmento { get; set; }

        [DataMember]
        [MaxLength(50)]
        public string dsGrupoEconomico { get; set; }

        [DataMember]
        public bool blnPossuiContaDigital { get; set; }

        [DataMember]
        public int IdUsuarioInclusao { get; set; }

        [DataMember]
        public string UsuarioInclusaoNome { get; set; }

        [DataMember]
        public DateTime DtUsuarioInclusao { get; set; }

        [DataMember]
        public int? IdUsuarioManutencao { get; set; }

        [DataMember]
        public string UsuarioManutencaoNome { get; set; }

        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        [DataMember]
        public bool blnAtivo { get; set; }
    }
}
