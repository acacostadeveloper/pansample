﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.SRT.Entidades
{
    //EGS 25.03.2018 - Model da tabela Pessoa
    [Table("tbPessoa")]
    [DataContract]
    public class Pessoa
    {
        [Key]
        [DataMember]
        public int idPessoa                  { get; set; }
        [DataMember]                         
        public int idCliente                 { get; set; }
        [DataMember]                         
        public string CNPFCNPJ               { get; set; }
        [DataMember]                         
        public string Nome                   { get; set; }
        [DataMember]                         
        public string TelefoneCelular        { get; set; }
        [DataMember]                         
        public string TelefoneFixo           { get; set; }
        [DataMember]                         
        public string TipoPessoa             { get; set; }
        [DataMember]
        public bool blnExpostaPublicamente   { get; set; }
        [DataMember]
        public Cliente Cliente               { get; set; }
        [DataMember]
        public int IdUsuarioInclusao         { get; set; }
        [DataMember]
        public DateTime DtUsuarioInclusao    { get; set; }
        [DataMember]
        public int? IdUsuarioManutencao      { get; set; }
        [DataMember]
        public DateTime? DtUsuarioManutencao { get; set; }

        public Pessoa() 
        { 
            Cliente  = new Cliente();
        }
    }
}
