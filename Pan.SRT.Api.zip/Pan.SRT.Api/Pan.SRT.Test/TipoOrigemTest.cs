﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serializers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pan.SRT.Business;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;


namespace Pan.SRT.Test
{
    [TestClass]
    public class TipoOrigemTest
    {
        //EGS 30.05.2018 Inicia as variaveis usados nos testes
        TokenPegar _TokenPegar = new TokenPegar();
        string StringToken = "";
        IEnumerable<TipoOrigemLista> tabTeste = null;    //Tabela completa com Numerable
        TipoOrigemLista tabTstRegLista = null;           //Tabela completa
        TipoOrigem      tabTstRegistro = null;           //Registro unico da tabela
        TipoOrigem      tabTstRegAlter = null;           //Registro unico da tabela
        string      pTxtNomePesq       = "CC";
        string      pTxtNomeIncl       = "CX_INC";
        string      pTxtNomeAlter      = "CX_INC_ALT";

        [TestInitialize]
        public void Inicializar()
        {
            //EGS 30.05.2018 - Pega a string do Token em restritivos/api/token
            StringToken = _TokenPegar.StringTokenPegar();
        }



        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo todos os registros                          Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaTipoOrigem()
        {
            var client         = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem");
            var request        = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<TipoOrigemLista>>(response.Content);
                //Valida se existem +2 registros na tabela
                Assert.IsTrue(tabTeste.Count() >= 2, "Quantidade de registros incorreta [{0}]", DateTime.Now);
                //Valida se existe ID 1 na tabela
                tabTstRegLista = tabTeste.Select(x => x).Where(x => x.idTipoOrigem == 1).FirstOrDefault();
                Assert.IsNotNull(tabTstRegLista);
            }
            Assert.IsNotNull(tabTeste);
            Assert.IsNotNull(response, "Sem conexão ao API GET TipoOrigem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por ID                  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaTipoOrigemsID()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?id=2");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoOrigem>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsNotNull(tabTstRegistro.idTipoOrigem = 2);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET ID TipoOrigem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por Descricao           Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaTipoOrigemsDescricao()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?Nome=" + pTxtNomePesq);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoOrigem>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsTrue(tabTstRegistro.nmOrigem == pTxtNomePesq, "Registro não encontrado [{0}]", DateTime.Now);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET Descricao TipoOrigem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar POST - Inserindo registro e depois pesquisando a inclusao  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void InclusaoTipoOrigem()
        {
            TipoOrigem pTipoOrigem            = new TipoOrigem();
            pTipoOrigem.nmOrigem              = pTxtNomeIncl;
            pTipoOrigem.nmTipoConta           = "C.Corrente TST";
            pTipoOrigem.nmTipoPessoa          = "Juridica";
            pTipoOrigem.blnPossuiContaDigital = true;

            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem");
            var request = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddBody(pTipoOrigem);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
            var lTamResposta = response.ContentLength;
            if (lTamResposta >= 50)
            {
                var clientPesq = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?Nome=" + pTipoOrigem.nmOrigem);
                var requestPesq = new RestRequest(Method.GET);
                requestPesq.AddHeader("Authorization", StringToken);
                IRestResponse responsePesq = clientPesq.Execute(requestPesq);
                if (responsePesq.ContentLength >= 50)
                {
                    tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoOrigem>(responsePesq.Content);
                    Assert.IsNotNull(tabTstRegistro);
                    Assert.IsTrue(tabTstRegistro.nmOrigem == pTipoOrigem.nmOrigem, "Registro não encontrado [{0}]", DateTime.Now);
                }
            }
            Assert.IsNotNull(response, "Sem conexão ao API POST TipoOrigem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar PUT - Alterando um registro e depois pesquisando a alteração  Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void AlteracaoTipoOrigem()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?Nome=" + pTxtNomeIncl);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0 , "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<TipoOrigem>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nmOrigem == pTxtNomeIncl, "Registro incluido não encontrado [{0}]", DateTime.Now);
                tabTstRegAlter.nmOrigem = pTxtNomeAlter;

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem");
                var request = new RestRequest(Method.PUT);
                request.RequestFormat = DataFormat.Json;
                request.AddBody(tabTstRegAlter);
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                if (response != null)
                {
                    var clientPesq2 = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    Assert.IsTrue(responsePesq2.ContentLength >= 50, "Registro não foi alterado [{0}]", DateTime.Now);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoOrigem>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.nmOrigem == tabTstRegAlter.nmOrigem, "Registro não encontrado [{0}]", DateTime.Now);
                    }
                }
                Assert.IsNotNull(response, "Sem conexão ao API PUT TipoOrigem [{0}]", DateTime.Now);
            }
        }


        /*===========================================================================================================
        // Programa...:  Testar DEL - Inativando um registro e depois pesquisando             Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ExclusaoTipoOrigem()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?Nome=" + pTxtNomeAlter);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0 , "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
            Assert.IsTrue(responsePesq.ContentLength >= 50, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<TipoOrigem>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nmOrigem == pTxtNomeAlter, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?id=" + tabTstRegAlter.idTipoOrigem.ToString());
                var request = new RestRequest(Method.DELETE);
                request.RequestFormat = DataFormat.Json;
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoOrigem' não esta disponivel [{0}]", DateTime.Now);
                var lTamResposta = response.ContentLength;
                if (lTamResposta >= 50)
                {
                    var clientPesq2  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipoorigem?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoOrigem>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.blnAtivo == false, "Registro não foi excluido corretamente [{0}]", DateTime.Now);
                    }
                }
            }
            Assert.IsNotNull(responsePesq, "Sem conexão ao API DEL InstituicaoFinanceira [{0}]", DateTime.Now);
        }
    }
}
