﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serializers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pan.SRT.Business;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.Test
{
    [TestClass]
    public class InstituicaoFinanceiraTest
    {
        //EGS 30.05.2018 Inicia as variaveis usados nos testes
        TokenPegar _TokenPegar = new TokenPegar();
        string StringToken = "";
        IEnumerable<InstituicaoFinanceiraLista> tabTeste = null;    //Tabela completa com Numerable
        InstituicaoFinanceiraLista tabTstRegLista = null;           //Tabela completa
        InstituicaoFinanceira tabTstRegistro = null;           //Registro unico da tabela
        InstituicaoFinanceira tabTstRegAlter = null;           //Registro unico da tabela
        string pTxtNomePesq  = "NOME_INSTITUICAO_002";
        string pTxtNomeIncl  = "NOME_INSTITUICAO_TST_INCLUIDO";
        string pTxtNomeAlter = "NOME_INSTITUICAO_TST_INCLUIDO_ALTERADO";

        [TestInitialize]
        public void Inicializar()
        {
            //EGS 30.05.2018 - Pega a string do Token em restritivos/api/token
            StringToken = _TokenPegar.StringTokenPegar();
        }



        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo todos os registros                          Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaInstituicaoFinanceira()
        {
            var client = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'InstituicaoFinanceira' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<InstituicaoFinanceiraLista>>(response.Content);
                //Valida se existem +2 registros na tabela
                Assert.IsTrue(tabTeste.Count() >= 2, "Quantidade de registros incorreta [{0}]", DateTime.Now);
                //Valida se existe ID 1 na tabela
                tabTstRegLista = tabTeste.Select(x => x).Where(x => x.idInstituicaoFinanceira == 1).FirstOrDefault();
                Assert.IsNotNull(tabTstRegLista);
            }
            Assert.IsNotNull(tabTeste);
            Assert.IsNotNull(response, "Sem conexão ao API GET InstituicaoFinanceira [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por ID                  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaInstituicaoFinanceirasID()
        {
            var client = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?id=2");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'InstituicaoFinanceira' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsNotNull(tabTstRegistro.idInstituicaoFinanceira = 2);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET ID InstituicaoFinanceira [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por Descricao           Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaInstituicaoFinanceirasDescricao()
        {
            var client = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?Nome=" + pTxtNomePesq);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'InstituicaoFinanceira' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsTrue(tabTstRegistro.nmInstituicaoFinanceira == pTxtNomePesq, "Registro não encontrado[{0}]", DateTime.Now);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET Descricao InstituicaoFinanceira [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar POST - Inserindo registro e depois pesquisando a inclusao  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void InclusaoInstituicaoFinanceira()
        {
            InstituicaoFinanceira pInstituicaoFinanceira = new InstituicaoFinanceira();
            pInstituicaoFinanceira.nrCnpj                  = "05.095.120/0005-05";
            pInstituicaoFinanceira.nmInstituicaoFinanceira = pTxtNomeIncl;
            pInstituicaoFinanceira.nrCodigoCompensacao     = "TST.TST";
            pInstituicaoFinanceira.dsSegmento              = "TST-TST";
            pInstituicaoFinanceira.dsGrupoEconomico        = "TSTS";

            var client = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira");
            var request = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddBody(pInstituicaoFinanceira);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'InstituicaoFinanceira' não esta disponivel [{0}]", DateTime.Now);
            var lTamResposta = response.ContentLength;
            if (lTamResposta >= 50)
            {
                var clientPesq = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?Nome=" + pInstituicaoFinanceira.nmInstituicaoFinanceira);
                var requestPesq = new RestRequest(Method.GET);
                requestPesq.AddHeader("Authorization", StringToken);
                IRestResponse responsePesq = clientPesq.Execute(requestPesq);
                if (responsePesq.ContentLength >= 50)
                {
                    tabTstRegistro = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(responsePesq.Content);
                    Assert.IsNotNull(tabTstRegistro);
                    Assert.IsTrue(tabTstRegistro.nmInstituicaoFinanceira == pInstituicaoFinanceira.nmInstituicaoFinanceira, "Registro não encontrado[{0}]", DateTime.Now);
                }
            }
            Assert.IsNotNull(response, "Sem conexão ao API POST InstituicaoFinanceira [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar PUT - Alterando um registro e depois pesquisando a alteração  Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void AlteracaoInstituicaoFinanceira()
        {
            var clientPesq = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?Nome=" + pTxtNomeIncl);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0, "Web.Api 'InstituicaoFinanceira' não esta disponivel [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nmInstituicaoFinanceira == pTxtNomeIncl, "Registro incluido não encontrado[{0}]", DateTime.Now);
                tabTstRegAlter.nmInstituicaoFinanceira = pTxtNomeAlter;

                var client = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira");
                var request = new RestRequest(Method.PUT);
                request.RequestFormat = DataFormat.Json;
                request.AddBody(tabTstRegAlter);
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                if (response != null)
                {
                    var clientPesq2 = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    Assert.IsTrue(responsePesq2.ContentLength >= 50, "Registro não foi alterado [{0}]", DateTime.Now);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.nmInstituicaoFinanceira == tabTstRegAlter.nmInstituicaoFinanceira, "Registro não encontrado[{0}]", DateTime.Now);
                    }
                }
                Assert.IsNotNull(response, "Sem conexão ao API PUT InstituicaoFinanceira [{0}]", DateTime.Now);
            }
        }


        /*===========================================================================================================
        // Programa...:  Testar DEL - Inativando um registro e depois pesquisando             Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ExclusaoInstituicaoFinanceira()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?Nome=" + pTxtNomeAlter);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0, "Web.Api 'instituicaofinanceira' não esta disponivel [{0}]", DateTime.Now);
            Assert.IsTrue(responsePesq.ContentLength >= 50, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nmInstituicaoFinanceira == pTxtNomeAlter, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?id=" + tabTstRegAlter.idInstituicaoFinanceira.ToString());
                var request = new RestRequest(Method.DELETE);
                request.RequestFormat = DataFormat.Json;
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                Assert.IsTrue(response.ContentLength != 0, "Web.Api 'instituicaofinanceira' não esta disponivel [{0}]", DateTime.Now);
                var lTamResposta = response.ContentLength;
                if (lTamResposta >= 50)
                {
                    var clientPesq2  = new RestClient(Constants.GlobalApiServiceSRT + "/api/instituicaofinanceira?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<InstituicaoFinanceira>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.blnAtivo == false, "Registro não foi excluido corretamente [{0}]", DateTime.Now);
                    }
                }
            }
            Assert.IsNotNull(responsePesq, "Sem conexão ao API DEL InstituicaoFinanceira [{0}]", DateTime.Now);
        }
    }
}
