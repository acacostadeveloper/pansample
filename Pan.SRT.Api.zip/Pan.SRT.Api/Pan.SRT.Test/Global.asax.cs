﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
//--
using Pan.SRT.Business;
using Pan.SRT.Infra;



namespace Pan.SRT.Test
{
    /*===========================================================================================================
    // Programa...:  Define as constantes de URL de DEVP, HOML ou PROD para chamar
    // Autor......:  Edinaldo Silva (IT Singular)
    // Data.......:  30.05.2017
    ===========================================================================================================*/
    static class Constants
    {
      //public const string GlobalApiServiceSRT = "http://restritivosdes.grupopan.com:35021";
        public const string GlobalApiServiceSRT = "http://localhost:35021";
    }
}