﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serializers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pan.SRT.Business;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.Test
{
    [TestClass]
    public class SistemaOrigemTest
    {
        //EGS 30.05.2018 Inicia as variaveis usados nos testes
        TokenPegar _TokenPegar = new TokenPegar();
        string StringToken = "";
        IEnumerable<SistemaOrigemLista> tabTeste = null;    //Tabela completa com Numerable
        SistemaOrigemLista tabTstRegLista = null;           //Tabela completa
        SistemaOrigem      tabTstRegistro = null;           //Registro unico da tabela
        string      pTxtNomePesq   = "SISTEMA ORIGEM B";

        [TestInitialize]
        public void Inicializar()
        {
            //EGS 30.05.2018 - Pega a string do Token em restritivos/api/token
            StringToken = _TokenPegar.StringTokenPegar();
        }



        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo todos os registros                          Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaSistemaOrigem()
        {
            var client         = new RestClient(Constants.GlobalApiServiceSRT + "/api/sistemaorigem");
            var request        = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'SistemaOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<SistemaOrigemLista>>(response.Content);
                //Valida se existem +2 registros na tabela
                Assert.IsTrue(tabTeste.Count() >= 2, "Quantidade de registros incorreta [{0}]", DateTime.Now);
                //Valida se existe ID 1 na tabela
                tabTstRegLista = tabTeste.Select(x => x).Where(x => x.IdSistemaOrigem == 1).FirstOrDefault();
                Assert.IsNotNull(tabTstRegLista);
            }
            Assert.IsNotNull(tabTeste);
            Assert.IsNotNull(response, "Sem conexão ao API GET SistemaOrigem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por ID                  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaSistemaOrigemsID()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/sistemaorigem?id=2");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'SistemaOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<SistemaOrigem>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsNotNull(tabTstRegistro.IdSistemaOrigem = 2);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET ID SistemaOrigem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por Descricao           Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaSistemaOrigemsDescricao()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/sistemaorigem?Nome=" + pTxtNomePesq);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'SistemaOrigem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<SistemaOrigem>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsTrue(tabTstRegistro.nmDescricao == pTxtNomePesq, "Registro não encontrado [{0}]", DateTime.Now);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET Descricao SistemaOrigem [{0}]", DateTime.Now);
        }

    }
}
