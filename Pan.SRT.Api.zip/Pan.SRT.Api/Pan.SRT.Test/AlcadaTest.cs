﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serializers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;


namespace Pan.SRT.Test
{
    [TestClass]
    public class AlcadaTest
    {
        //EGS 30.05.2018 Inicia as variaveis usados nos testes
        TokenPegar _TokenPegar = new TokenPegar();
        string StringToken = "";
        IEnumerable<AlcadaLista> tabTeste = null;    //Tabela completa com Numerable
        AlcadaLista tabTstRegLista = null;           //Tabela completa
        Alcada      tabTstRegistro = null;           //Registro unico da tabela
        Alcada      tabTstRegAlter = null;           //Registro unico da tabela
        string      pTxtNomePesq   = "ALCADA NIVEL GERENTE";
        string      pTxtNomeIncl   = "ALCADA NIVEL TST_INCLUIDO";
        string      pTxtNomeAlter  = "ALCADA NIVEL TST_INCLUIDO_ALTERADO";

        [TestInitialize]
        public void Inicializar()
        {
            //EGS 30.05.2018 - Pega a string do Token em restritivos/api/token
            StringToken = _TokenPegar.StringTokenPegar();
        }



        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo todos os registros                          Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaAlcada()
        {
            var client         = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada");
            var request        = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<AlcadaLista>>(response.Content);
                //Valida se existem +2 registros na tabela
                Assert.IsTrue(tabTeste.Count() >= 2, "Quantidade de registros incorreta [{0}]", DateTime.Now);
                //Valida se existe ID 1 na tabela
                tabTstRegLista = tabTeste.Select(x => x).Where(x => x.idAlcada == 1).FirstOrDefault();
                Assert.IsNotNull(tabTstRegLista);
            }
            Assert.IsNotNull(tabTeste);
            Assert.IsNotNull(response, "Sem conexão ao API GET Alcada [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por ID                  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaAlcadasID()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?id=2");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<Alcada>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsNotNull(tabTstRegistro.idAlcada = 2);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET ID Alcada [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por Descricao           Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaAlcadasDescricao()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?Nome=" + pTxtNomePesq);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<Alcada>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsTrue(tabTstRegistro.nmDescricao == pTxtNomePesq, "Registro não encontrado [{0}]", DateTime.Now);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET Descricao Alcada [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar POST - Inserindo registro e depois pesquisando a inclusao  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void InclusaoAlcada()
        {
            Alcada pAlcada = new Alcada();
            pAlcada.cdAlcada        = "TST001";
            pAlcada.nmDescricao     = pTxtNomeIncl;
            pAlcada.idUsuario       = 12;
            pAlcada.IdSistemaOrigem = 1;
            pAlcada.nrNivel         = 1;

            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada");
            var request = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddBody(pAlcada);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
            var lTamResposta = response.ContentLength;
            if (lTamResposta >= 50)
            {
                var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?Nome=" + pAlcada.nmDescricao);
                var requestPesq = new RestRequest(Method.GET);
                requestPesq.AddHeader("Authorization", StringToken);
                IRestResponse responsePesq = clientPesq.Execute(requestPesq);
                if (responsePesq.ContentLength >= 50)
                {
                    tabTstRegistro = new JavaScriptSerializer().Deserialize<Alcada>(responsePesq.Content);
                    Assert.IsNotNull(tabTstRegistro);
                    Assert.IsTrue(tabTstRegistro.nmDescricao == pAlcada.nmDescricao, "Registro não encontrado [{0}]", DateTime.Now);
                }
            }
            Assert.IsNotNull(response, "Sem conexão ao API POST Alcada [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar PUT - Alterando um registro e depois pesquisando a alteração  Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void AlteracaoAlcada()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?Nome=" + pTxtNomeIncl);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0 , "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<Alcada>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nmDescricao == pTxtNomeIncl, "Registro incluido não encontrado [{0}]", DateTime.Now);
                tabTstRegAlter.nmDescricao = pTxtNomeAlter;

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada");
                var request = new RestRequest(Method.PUT);
                request.RequestFormat = DataFormat.Json;
                request.AddBody(tabTstRegAlter);
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                if (response != null)
                {
                    var clientPesq2 = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    Assert.IsTrue(responsePesq2.ContentLength >= 50, "Registro não foi alterado [{0}]", DateTime.Now);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<Alcada>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.nmDescricao == tabTstRegAlter.nmDescricao, "Registro não encontrado [{0}]", DateTime.Now);
                    }
                }
                Assert.IsNotNull(response, "Sem conexão ao API PUT Alcada [{0}]", DateTime.Now);
            }
        }


        /*===========================================================================================================
        // Programa...:  Testar DEL - Inativando um registro e depois pesquisando             Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ExclusaoAlcada()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?Nome=" + pTxtNomeAlter);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0 , "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
            Assert.IsTrue(responsePesq.ContentLength >= 50, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<Alcada>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nmDescricao == pTxtNomeAlter, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?id=" + tabTstRegAlter.idAlcada.ToString());
                var request = new RestRequest(Method.DELETE);
                request.RequestFormat = DataFormat.Json;
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                Assert.IsTrue(response.ContentLength != 0, "Web.Api 'Alcada' não esta disponivel [{0}]", DateTime.Now);
                var lTamResposta = response.ContentLength;
                if (lTamResposta >= 50)
                {
                    var clientPesq2  = new RestClient(Constants.GlobalApiServiceSRT + "/api/alcada?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<Alcada>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.blnAtivo == false, "Registro não foi excluido corretamente [{0}]", DateTime.Now);
                    }
                }
            }
            Assert.IsNotNull(responsePesq, "Sem conexão ao API DEL InstituicaoFinanceira [{0}]", DateTime.Now);
        }
    }
}
