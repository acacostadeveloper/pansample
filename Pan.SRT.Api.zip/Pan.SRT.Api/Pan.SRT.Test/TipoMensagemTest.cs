﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serializers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pan.SRT.Business;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;


namespace Pan.SRT.Test
{
    [TestClass]
    public class TipoMensagemTest
    {
        //EGS 30.05.2018 Inicia as variaveis usados nos testes
        TokenPegar _TokenPegar = new TokenPegar();
        string StringToken = "";
        IEnumerable<TipoMensagemLista> tabTeste = null;    //Tabela completa com Numerable
        TipoMensagemLista tabTstRegLista = null;           //Tabela completa
        TipoMensagem      tabTstRegistro = null;           //Registro unico da tabela
        TipoMensagem      tabTstRegAlter = null;           //Registro unico da tabela
        string      pTxtNomePesq   = "CODIGO_001";
        string      pTxtNomeIncl   = "COD_TST_INCL";
        string      pTxtNomeAlter  = "COD_TST_INCL_ALT";

        [TestInitialize]
        public void Inicializar()
        {
            //EGS 30.05.2018 - Pega a string do Token em restritivos/api/token
            StringToken = _TokenPegar.StringTokenPegar();
        }



        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo todos os registros                          Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaTipoMensagem()
        {
            var client         = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem");
            var request        = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<TipoMensagemLista>>(response.Content);
                //Valida se existem +2 registros na tabela
                Assert.IsTrue(tabTeste.Count() >= 2, "Quantidade de registros incorreta [{0}]", DateTime.Now);
                //Valida se existe ID 1 na tabela
                tabTstRegLista = tabTeste.Select(x => x).Where(x => x.idTipoMensagem == 1).FirstOrDefault();
                Assert.IsNotNull(tabTstRegLista);
            }
            Assert.IsNotNull(tabTeste);
            Assert.IsNotNull(response, "Sem conexão ao API GET TipoMensagem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por ID                  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaTipoMensagemsID()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?id=2");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoMensagem>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsNotNull(tabTstRegistro.idTipoMensagem = 2);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET ID TipoMensagem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo apenas um registros por Descricao           Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaTipoMensagemsDescricao()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?Nome=" + pTxtNomePesq);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoMensagem>(response.Content);
                Assert.IsNotNull(tabTstRegistro);
                Assert.IsTrue(tabTstRegistro.nrCodigo == pTxtNomePesq, "Registro não encontrado [{0}]", DateTime.Now);
            }
            Assert.IsNotNull(response, "Sem conexão ao API GET Descricao TipoMensagem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar POST - Inserindo registro e depois pesquisando a inclusao  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void InclusaoTipoMensagem()
        {
            TipoMensagem pTipoMensagem   = new TipoMensagem();
            pTipoMensagem.nrCodigo       = pTxtNomeIncl;
            pTipoMensagem.nmDescricao    = "DESCRICAO_EVENTO_TST";

            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem");
            var request = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddBody(pTipoMensagem);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
            var lTamResposta = response.ContentLength;
            if (lTamResposta >= 50)
            {
                var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?Nome=" + pTipoMensagem.nrCodigo);
                var requestPesq = new RestRequest(Method.GET);
                requestPesq.AddHeader("Authorization", StringToken);
                IRestResponse responsePesq = clientPesq.Execute(requestPesq);
                if (responsePesq.ContentLength >= 50)
                {
                    tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoMensagem>(responsePesq.Content);
                    Assert.IsNotNull(tabTstRegistro);
                    Assert.IsTrue(tabTstRegistro.nrCodigo == pTipoMensagem.nrCodigo, "Registro não encontrado [{0}]", DateTime.Now);
                }
            }
            Assert.IsNotNull(response, "Sem conexão ao API POST TipoMensagem [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar PUT - Alterando um registro e depois pesquisando a alteração  Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void AlteracaoTipoMensagem()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?Nome=" + pTxtNomeIncl);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0 , "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<TipoMensagem>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nrCodigo == pTxtNomeIncl, "Registro incluido não encontrado [{0}]", DateTime.Now);
                tabTstRegAlter.nrCodigo = pTxtNomeAlter;

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem");
                var request = new RestRequest(Method.PUT);
                request.RequestFormat = DataFormat.Json;
                request.AddBody(tabTstRegAlter);
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                if (response != null)
                {
                    var clientPesq2 = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    Assert.IsTrue(responsePesq2.ContentLength >= 50, "Registro não foi alterado [{0}]", DateTime.Now);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoMensagem>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.nrCodigo == tabTstRegAlter.nrCodigo, "Registro não encontrado [{0}]", DateTime.Now);
                    }
                }
                Assert.IsNotNull(response, "Sem conexão ao API PUT TipoMensagem [{0}]", DateTime.Now);
            }
        }


        /*===========================================================================================================
        // Programa...:  Testar DEL - Inativando um registro e depois pesquisando             Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ExclusaoTipoMensagem()
        {
            var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?Nome=" + pTxtNomeAlter);
            var requestPesq = new RestRequest(Method.GET);
            requestPesq.AddHeader("Authorization", StringToken);
            IRestResponse responsePesq = clientPesq.Execute(requestPesq);
            Assert.IsTrue(responsePesq.ContentLength != 0 , "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
            Assert.IsTrue(responsePesq.ContentLength >= 50, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);
            if (responsePesq.ContentLength >= 50)
            {
                tabTstRegAlter = new JavaScriptSerializer().Deserialize<TipoMensagem>(responsePesq.Content);
                Assert.IsTrue(tabTstRegAlter.nrCodigo == pTxtNomeAlter, "Registro que foi alterado não encontrado [{0}]", DateTime.Now);

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?id=" + tabTstRegAlter.idTipoMensagem.ToString());
                var request = new RestRequest(Method.DELETE);
                request.RequestFormat = DataFormat.Json;
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                Assert.IsTrue(response.ContentLength != 0, "Web.Api 'TipoMensagem' não esta disponivel [{0}]", DateTime.Now);
                var lTamResposta = response.ContentLength;
                if (lTamResposta >= 50)
                {
                    var clientPesq2  = new RestClient(Constants.GlobalApiServiceSRT + "/api/tipomensagem?Nome=" + pTxtNomeAlter);
                    var requestPesq2 = new RestRequest(Method.GET);
                    requestPesq2.AddHeader("Authorization", StringToken);
                    IRestResponse responsePesq2 = clientPesq2.Execute(requestPesq2);
                    if (responsePesq2.ContentLength >= 50)
                    {
                        tabTstRegistro = new JavaScriptSerializer().Deserialize<TipoMensagem>(responsePesq2.Content);
                        Assert.IsNotNull(tabTstRegistro);
                        Assert.IsTrue(tabTstRegistro.blnAtivo == false, "Registro não foi excluido corretamente [{0}]", DateTime.Now);
                    }
                }
            }
            Assert.IsNotNull(responsePesq, "Sem conexão ao API DEL InstituicaoFinanceira [{0}]", DateTime.Now);
        }
    }
}
