﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serializers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pan.SRT.Business;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.Test
{
    [TestClass]
    public class RegraValidaClausulaTest
    {
        //EGS 30.05.2018 Inicia as variaveis usados nos testes
        TokenPegar _TokenPegar = new TokenPegar();
        string StringToken = "";
        IEnumerable<RegraValidaClausulaLista> tabTeste = null;    //Tabela completa com Numerable
        RegraValidaClausulaLista tabTstRegLista = null;           //Tabela completa
        RegraValidaClausula      tabTstRegistro = null;           //Registro unico da tabela
        int         pIDRegClausPesq  = 1  ;   //Por ID ao inves de descricao
        int         pIDRegraClausula = 4  ;   //Por ID ao inves de descricao

        [TestInitialize]
        public void Inicializar()
        {
            //EGS 30.05.2018 - Pega a string do Token em restritivos/api/token
            StringToken = _TokenPegar.StringTokenPegar();
        }



        /*===========================================================================================================
        // Programa...:  Testar GET - Trazendo todos os registros                          Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ConsultaRegraValidaClausula()
        {
            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula?idRegraValidacao=" + pIDRegClausPesq);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'RegraValidaClausula' não esta disponivel [{0}]", DateTime.Now);
            if (response.ContentLength >= 50)
            {
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<RegraValidaClausulaLista>>(response.Content);
                //Valida se existem +2 registros na tabela
                Assert.IsTrue(tabTeste.Count() >= 1, "Quantidade de registros incorreta [{0}]", DateTime.Now);
                //Valida se existe ID 1 na tabela
                tabTstRegLista = tabTeste.Select(x => x).Where(x => x.idRegraValidaClausula == 1).FirstOrDefault();
                Assert.IsNotNull(tabTstRegLista);
            }
            Assert.IsNotNull(tabTeste);
            Assert.IsNotNull(response, "Sem conexão ao API GET RegraValidaClausula [{0}]", DateTime.Now);
        }



        /*===========================================================================================================
        // Programa...:  Testar POST - Inserindo registro e depois pesquisando a inclusao  Data.......:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void InclusaoRegraValidaClausula()
        {
            RegraValidaClausula pRegraValidaClausula = new RegraValidaClausula();
            pRegraValidaClausula.idRegraValidacao     = pIDRegClausPesq;
            pRegraValidaClausula.idEntidade           = 1;
            pRegraValidaClausula.idEntidadeAtributo   = 1;
            pRegraValidaClausula.idTipoOperador       = 6;
            pRegraValidaClausula.idPeriodoAgrupamento = 1;
            pRegraValidaClausula.idTipoAgrupamento    = 1;
            pRegraValidaClausula.nrValor              = "199999.99";
            pRegraValidaClausula.blnAtivo             = true;

            var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula");
            var request = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddBody(pRegraValidaClausula);
            request.AddHeader("Authorization", StringToken);
            IRestResponse response = client.Execute(request);
            Assert.IsTrue(response.ContentLength != 0, "Web.Api 'RegraValidaClausula' não esta disponivel [{0}]", DateTime.Now);
            var lTamResposta = response.ContentLength;
            if (lTamResposta >= 50)
            {
                tabTstRegistro   = new JavaScriptSerializer().Deserialize<RegraValidaClausula>(response.Content);
                pIDRegraClausula = tabTstRegistro.idRegraValidaClausula;

                var clientPesq  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula?id=" + pIDRegraClausula.ToString());
                var requestPesq = new RestRequest(Method.HEAD);
                requestPesq.AddHeader("Authorization", StringToken);
                IRestResponse responsePesq = clientPesq.Execute(requestPesq);
                if (responsePesq.ContentLength >= 50)
                {
                    Assert.IsNotNull(tabTstRegistro);
                }
            }
            Assert.IsNotNull(response, "Sem conexão ao API POST RegraValidaClausula [{0}]", DateTime.Now);
        }


        /*===========================================================================================================
        // Programa...:  Testar PUT - Alterando um registro e depois pesquisando a alteração  Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void AlteracaoRegraValidaClausula()
        {
            var clientTotal  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula?idRegraValidacao=" + pIDRegClausPesq);
            var requestTotal = new RestRequest(Method.GET);
            requestTotal.AddHeader("Authorization", StringToken);
            IRestResponse responseTotal = clientTotal.Execute(requestTotal);
            Assert.IsTrue(responseTotal.ContentLength != 0, "Web.Api 'RegraValidaClausula' não esta disponivel [{0}]", DateTime.Now);
            if (responseTotal.ContentLength >= 50)
            {
                //Para pegar o ULTIMO registro inserido....
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<RegraValidaClausulaLista>>(responseTotal.Content);
                foreach (var itemClau in tabTeste)
                {
                    pIDRegraClausula = itemClau.idRegraValidaClausula;
                }

                RegraValidaClausula pRegraValidaClauAlter   = new RegraValidaClausula();
                pRegraValidaClauAlter.idRegraValidaClausula = pIDRegraClausula;
                pRegraValidaClauAlter.idRegraValidacao      = pIDRegClausPesq;
                pRegraValidaClauAlter.idEntidade            = 1;
                pRegraValidaClauAlter.idEntidadeAtributo    = 1;
                pRegraValidaClauAlter.idTipoOperador        = 6;
                pRegraValidaClauAlter.idPeriodoAgrupamento  = 1;
                pRegraValidaClauAlter.idTipoAgrupamento     = 1;
                pRegraValidaClauAlter.nrValor               = "188888.88";
                pRegraValidaClauAlter.IdUsuarioInclusao     = 12;
                pRegraValidaClauAlter.DtUsuarioInclusao     = DateTime.Now;
                pRegraValidaClauAlter.blnAtivo              = true;

                var client = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula");
                var request = new RestRequest(Method.PUT);
                request.RequestFormat = DataFormat.Json;
                request.AddBody(pRegraValidaClauAlter);
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                if (response != null)
                {
                    Assert.IsTrue(response.ContentLength == -1, "Alteração não executada [{0}]", DateTime.Now);

                    var clientVolta  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula?idRegraValidacao=" + pIDRegClausPesq);
                    var requestVolta = new RestRequest(Method.GET);
                    requestVolta.AddHeader("Authorization", StringToken);
                    IRestResponse responseVolta = clientVolta.Execute(requestVolta);
                    Assert.IsTrue(responseVolta.ContentLength != 0, "Web.Api 'RegraValidaClausula' não esta disponivel [{0}]", DateTime.Now);
                    if (responseVolta.ContentLength >= 50)
                    {
                        //Para pegar o ULTIMO registro inserido....
                        tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<RegraValidaClausulaLista>>(responseVolta.Content);
                        foreach (var itemClau in tabTeste)
                        {
                            if (itemClau.idRegraValidaClausula == pIDRegraClausula)
                            {
                                Assert.IsTrue(itemClau.nrValor == pRegraValidaClauAlter.nrValor, "Registro não foi alterado corretamente [{0}]", DateTime.Now);
                            }
                        }
                    }
                }
                Assert.IsNotNull(response, "Sem conexão ao API PUT RegraValidaClausula [{0}]", DateTime.Now);
            }            
        }


        /*===========================================================================================================
        // Programa...:  Testar DEL - Inativando um registro e depois pesquisando             Data....:  30.05.2018
        ===========================================================================================================*/
        [TestMethod]
        public void ExclusaoRegraValidaClausula()
        {
            var clientTotal  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula?idRegraValidacao=" + pIDRegClausPesq);
            var requestTotal = new RestRequest(Method.GET);
            requestTotal.AddHeader("Authorization", StringToken);
            IRestResponse responseTotal = clientTotal.Execute(requestTotal);
            Assert.IsTrue(responseTotal.ContentLength != 0, "Web.Api 'RegraValidaClausula' não esta disponivel [{0}]", DateTime.Now);
            var lTamResposta = responseTotal.ContentLength;
            if (lTamResposta >= 50)
            {
                //Para pegar o ULTIMO registro inserido....
                tabTeste = new JavaScriptSerializer().Deserialize<IEnumerable<RegraValidaClausulaLista>>(responseTotal.Content);
                foreach (var itemClau in tabTeste)
                {
                    pIDRegraClausula = itemClau.idRegraValidaClausula;
                }

                var client  = new RestClient(Constants.GlobalApiServiceSRT + "/api/regravalidaclausula?id=" + pIDRegraClausula.ToString());
                var request = new RestRequest(Method.DELETE);
                request.RequestFormat = DataFormat.Json;
                request.AddHeader("Authorization", StringToken);
                IRestResponse response = client.Execute(request);
                Assert.IsTrue(response.ContentLength != 0, "Web.Api 'RegraValidaClausula' não esta disponivel [{0}]", DateTime.Now);
                var lTamResposta2 = response.ContentLength;
                if (lTamResposta2 >= 50)
                {
                    Assert.IsTrue(response.ContentLength == -1, "Exclusão executada [{0}]", DateTime.Now);
                }
            }
            Assert.IsNotNull(responseTotal, "Sem conexão ao API DEL RegraValidaClausula [{0}]", DateTime.Now);
        }
    }
}
