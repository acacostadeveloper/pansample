﻿using System;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Pan.SRT.Helpers;



namespace Pan.SRT.WebApi
{
    public class WebApiApplication : HttpApplication
    {
        private GravaLogHelp _logHlp = new GravaLogHelp();

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            var _GlobalContainer = new GlobalContainer();
            _GlobalContainer._ChamaGlobalContainer();
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            //_logHlp._GravaLog("HttpContext.Current.Request.HttpMethod = " + HttpContext.Current.Request.HttpMethod);
            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Methods" , "POST,GET,PUT,DELETE,OPTIONS");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Headers" , "Content-Type, Access-Control-Allow-Headers, Access-Control-Allow-Methods, Authorization, X-Requested-With, Access-Control-Allow-Origin, Access-Control-Expose-Headers, Skip-Authorization, X-SessionId");
                HttpContext.Current.Response.AddHeader("Access-Control-Expose-Headers", "Content-Type, Authorization");
                HttpContext.Current.Response.AddHeader("Access-Control-Max-Age"       , "1728000");
                HttpContext.Current.Response.End();
            }
        }

    }
}