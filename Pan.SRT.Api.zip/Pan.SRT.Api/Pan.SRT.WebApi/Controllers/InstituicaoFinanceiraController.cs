﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class InstituicaoFinanceiraController : ApiController
    {
        private readonly IInstituicaoFinanceiraBusinessLayer _objInstituicaoFinanceiraBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public InstituicaoFinanceiraController(IInstituicaoFinanceiraBusinessLayer objInstituicaoFinanceiraBal)
        {
            var auth                     = new Auth();
            pIDUserLogin                 = auth.Authorize();
            _objInstituicaoFinanceiraBal = objInstituicaoFinanceiraBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/instituicaofinanceira
        public IEnumerable<InstituicaoFinanceiraLista> Get([FromUri] InstituicaoFinanceira item)
        {
            IEnumerable<InstituicaoFinanceiraLista> tabela = null;
            try
            {
                tabela = _objInstituicaoFinanceiraBal.ObterInstituicaoFinanceira(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "GET", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }


        //------------------------------------------------------------- Listar por ID
        // GET api/instituicaofinanceira/5
        public InstituicaoFinanceira Get(int id)
        {
            InstituicaoFinanceira tabela = null;
            try
            {
                tabela = _objInstituicaoFinanceiraBal.ObterInstituicaoFinanceira(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "GET_ID", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/instituicaofinanceira/nome
        public InstituicaoFinanceira Get(string Nome)
        {
            InstituicaoFinanceira tabela = null;
            try
            {
                tabela = _objInstituicaoFinanceiraBal.ObterInstituicaoFinanceira(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "GET_NM", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }


        //------------------------------------------------------------- Inserir
        // POST api/instituicaofinanceira
        public void Post([FromBody] InstituicaoFinanceira item)
        {
            try
            {
                _objInstituicaoFinanceiraBal.InserirInstituicaoFinanceira(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "POST", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/instituicaofinanceira
        public void Put([FromBody] InstituicaoFinanceira item)
        {
            try
            {
                _objInstituicaoFinanceiraBal.AlterarInstituicaoFinanceira(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "PUT", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/instituicaofinanceira/5
        public void Delete(int id)
        {
            try
            {
                _objInstituicaoFinanceiraBal.InativarInstituicaoFinanceira(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "DEL", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
        }
    }
}