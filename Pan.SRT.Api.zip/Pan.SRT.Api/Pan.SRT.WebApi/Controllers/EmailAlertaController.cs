﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class EmailAlertaController : ApiController
    {
        private readonly IEmailAlertaBusinessLayer _objEmailAlertaBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public EmailAlertaController(IEmailAlertaBusinessLayer objEmailAlertaBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objEmailAlertaBal = objEmailAlertaBal;
        }


        //------------------------------------------------------------- Listar Todos
        // GET api/EmailAlerta
        public IEnumerable<EmailAlertaLista> Get([FromUri] EmailAlerta item)
        {
            IEnumerable<EmailAlertaLista> tabela = null;
            try
            {
                tabela = _objEmailAlertaBal.ObterEmailAlerta(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/emailalerta", "GET", "/api/emailalerta", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }
        //------------------------------------------------------------- Listar por ID
        // GET api/EmailAlerta/5
        public EmailAlerta Get(int id)
        {
            EmailAlerta tabela = null;
            try
            {
                tabela = _objEmailAlertaBal.ObterEmailAlerta(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/emailalerta", "GET_ID", "/api/emailalerta", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Descricao
        // GET api/EmailAlerta/5
        public EmailAlerta Get(string Nome)
        {
            EmailAlerta tabela = null;
            try
            {
                tabela = _objEmailAlertaBal.ObterEmailAlerta(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/emailalerta", "GET_NM", "/api/emailalerta", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/EmailAlerta
        public void Post([FromBody] EmailAlerta item) // EmailAlerta item
        {
            try
            {
                _objEmailAlertaBal.InserirEmailAlerta(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/emailalerta", "POST", "/api/emailalerta", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/EmailAlerta/5
        public void Put([FromBody] EmailAlerta item) // EmailAlerta item
        {
            try
            {
                _objEmailAlertaBal.AlterarEmailAlerta(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/emailalerta", "PUT", "/api/emailalerta", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/EmailAlerta/5
        public void Delete(int id)
        {
            try
            {
                _objEmailAlertaBal.InativarEmailAlerta(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/emailalerta", "DEL", "/api/emailalerta", ex.Message + " " + ex.InnerException);
            }
        }
    }
}