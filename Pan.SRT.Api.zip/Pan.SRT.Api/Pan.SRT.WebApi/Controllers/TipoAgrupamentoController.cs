﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class TipoAgrupamentoController : ApiController
    {
        private readonly ITipoAgrupamentoBusinessLayer _objTipoAgrupamentoBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public TipoAgrupamentoController(ITipoAgrupamentoBusinessLayer objTipoAgrupamentoBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objTipoAgrupamentoBal = objTipoAgrupamentoBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<TipoAgrupamentoLista> Get([FromUri] TipoAgrupamento item)
        {
            IEnumerable<TipoAgrupamentoLista> tabela = null;
            try
            {
                tabela = _objTipoAgrupamentoBal.ObterTipoAgrupamento(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "GET", "/api/tipoagrupamento", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public TipoAgrupamento Get(int id)
        {
            TipoAgrupamento tabela = null;
            try
            {
                tabela = _objTipoAgrupamentoBal.ObterTipoAgrupamento(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "GET_ID", "/api/tipoagrupamento", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public TipoAgrupamento Get(string Nome)
        {
            TipoAgrupamento tabela = null;
            try
            {
                tabela = _objTipoAgrupamentoBal.ObterTipoAgrupamento(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "GET_NM", "/api/tipoagrupamento", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] TipoAgrupamento item)
        {
            try
            {
                _objTipoAgrupamentoBal.InserirTipoAgrupamento(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "POST", "/api/tipoagrupamento", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] TipoAgrupamento item)
        {
            try
            {
                _objTipoAgrupamentoBal.AlterarTipoAgrupamento(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "PUT", "/api/tipoagrupamento", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objTipoAgrupamentoBal.InativarTipoAgrupamento(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "DEL", "/api/tipoagrupamento", ex.Message + " " + ex.InnerException);
            }
        }
    }
}