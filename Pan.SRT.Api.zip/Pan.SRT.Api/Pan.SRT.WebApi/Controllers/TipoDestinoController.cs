﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class TipoDestinoController : ApiController
    {
        private readonly ITipoDestinoBusinessLayer _objTipoDestinoBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public TipoDestinoController(ITipoDestinoBusinessLayer objTipoDestinoBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objTipoDestinoBal = objTipoDestinoBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<TipoDestinoLista> Get([FromUri] TipoDestino item)
        {
            IEnumerable<TipoDestinoLista> tabela = null;
            try
            {
                tabela = _objTipoDestinoBal.ObterTipoDestino(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "GET", "/api/tipodestino", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public TipoDestino Get(int id)
        {
            TipoDestino tabela = null;
            try
            {
                tabela = _objTipoDestinoBal.ObterTipoDestino(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "GET_ID", "/api/tipodestino", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Descricao
        // GET api/values/5
        public TipoDestino Get(string Nome)
        {
            TipoDestino tabela = null;
            try
            {
                tabela = _objTipoDestinoBal.ObterTipoDestino(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "GET_NM", "/api/tipodestino", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] TipoDestino item)
        {
            try
            {
                _objTipoDestinoBal.InserirTipoDestino(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "POST", "/api/tipodestino", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] TipoDestino item)
        {
            try
            {
                _objTipoDestinoBal.AlterarTipoDestino(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "PUT", "/api/tipodestino", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objTipoDestinoBal.InativarTipoDestino(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "DEL", "/api/tipodestino", ex.Message + " " + ex.InnerException);
            }
        }
    }
}