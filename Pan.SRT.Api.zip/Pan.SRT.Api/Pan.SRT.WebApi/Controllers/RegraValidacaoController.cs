﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class RegraValidacaoController : ApiController
    {
        private readonly IRegraValidacaoBusinessLayer _objRegraValidacaoBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public RegraValidacaoController(IRegraValidacaoBusinessLayer objRegraValidacaoBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objRegraValidacaoBal = objRegraValidacaoBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<RegraValidacaoLista> Get([FromUri] RegraValidacao item)
        {
            IEnumerable<RegraValidacaoLista> tabela = null;
            try
            {
                tabela = _objRegraValidacaoBal.ObterRegraValidacao(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public RegraValidacao Get(int id)
        {
            RegraValidacao tabela = null;
            try
            {
                tabela = _objRegraValidacaoBal.ObterRegraValidacao(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET_ID", "/api/regravalidacao", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public RegraValidacao Get(string Nome)
        {
            RegraValidacao tabela = null;
            try
            {
                tabela = _objRegraValidacaoBal.ObterRegraValidacao(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET_NM", "/api/regravalidacao", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] RegraValidacao item)
        {
            try
            {
                _objRegraValidacaoBal.InserirRegraValidacao(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "POST", "/api/regravalidacao", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] RegraValidacao item)
        {
            try
            {
                _objRegraValidacaoBal.AlterarRegraValidacao(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "PUT", "/api/regravalidacao", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id, bool ativar)
        {
            try
            {
                _objRegraValidacaoBal.InativarRegraValidacao(id, ativar, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "DEL", "/api/regravalidacao", ex.Message + " " + ex.InnerException);
            }
        }
    }
}