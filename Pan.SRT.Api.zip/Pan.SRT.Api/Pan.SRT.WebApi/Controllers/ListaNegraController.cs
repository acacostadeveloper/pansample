﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class ListaNegraController : ApiController
    {
        private readonly IListaNegraBusinessLayer _objListaNegraBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public ListaNegraController(IListaNegraBusinessLayer objListaNegraBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objListaNegraBal = objListaNegraBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<ListaNegraLista> Get([FromUri] ListaNegra item)
        {
            IEnumerable<ListaNegraLista> tabela = null;
            try
            {
                tabela = _objListaNegraBal.ObterListaNegra(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "GET", "/api/listanegra", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Descricao
        // GET api/values/5
        public ListaNegra Get(int id)
        {
            ListaNegra tabela = null;
            try
            {
                tabela = _objListaNegraBal.ObterListaNegra(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "GET_ID", "/api/listanegra", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public ListaNegra Get(string Nome)
        {
            ListaNegra tabela = null;
            try
            {
                tabela = _objListaNegraBal.ObterListaNegra(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "GET_NM", "/api/listanegra", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] ListaNegra item)
        {
            try
            {
                _objListaNegraBal.InserirListaNegra(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "POST", "/api/listanegra", ex.Message + " " + ex.InnerException);
            }            
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] ListaNegra item)
        {
            try
            {
                _objListaNegraBal.AlterarListaNegra(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "PUT", "/api/listanegra", ex.Message + " " + ex.InnerException);
            }            
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objListaNegraBal.InativarListaNegra(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "DEL", "/api/listanegra", ex.Message + " " + ex.InnerException);
            }
        }
    }
}