﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class TipoOperadorController : ApiController
    {
        private readonly ITipoOperadorBusinessLayer _objTipoOperadorBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public TipoOperadorController(ITipoOperadorBusinessLayer objTipoOperadorBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objTipoOperadorBal = objTipoOperadorBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<TipoOperadorLista> Get([FromUri] TipoOperador item)
        {
            IEnumerable<TipoOperadorLista> tabela = null;
            try
            {
                tabela = _objTipoOperadorBal.ObterTipoOperador(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "GET", "/api/tipooperador", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public TipoOperador Get(int id)
        {
            TipoOperador tabela = null;
            try
            {
                tabela = _objTipoOperadorBal.ObterTipoOperadorID(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "GET_ID", "/api/tipooperador", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public TipoOperador Get(string Nome)
        {
            TipoOperador tabela = null;
            try
            {
                tabela = _objTipoOperadorBal.ObterTipoOperadorTx(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "GET_NM", "/api/tipooperador", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] TipoOperador item)
        {
            try
            {
                _objTipoOperadorBal.InserirTipoOperador(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "POST", "/api/tipooperador", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] TipoOperador item)
        {
            try
            {
                _objTipoOperadorBal.AlterarTipoOperador(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "PUT", "/api/tipooperador", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objTipoOperadorBal.InativarTipoOperador(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "DEL", "/api/tipooperador", ex.Message + " " + ex.InnerException);
            }
        }
    }
}