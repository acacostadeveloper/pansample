﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class PeriodoAgrupamentoController : ApiController
    {
        private readonly IPeriodoAgrupamentoBusinessLayer _objPeriodoAgrupamentoBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public PeriodoAgrupamentoController(IPeriodoAgrupamentoBusinessLayer objPeriodoAgrupamentoBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objPeriodoAgrupamentoBal = objPeriodoAgrupamentoBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<PeriodoAgrupamentoLista> Get([FromUri] PeriodoAgrupamento item)
        {
            IEnumerable<PeriodoAgrupamentoLista> tabela = null;
            try
            {
                tabela = _objPeriodoAgrupamentoBal.ObterPeriodoAgrupamento(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "GET", "/api/periodoagrupamento", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public PeriodoAgrupamento Get(int id)
        {
            PeriodoAgrupamento tabela = null;
            try
            {
                tabela = _objPeriodoAgrupamentoBal.ObterPeriodoAgrupamento(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "GET_ID", "/api/periodoagrupamento", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public PeriodoAgrupamento Get(string Nome)
        {
            PeriodoAgrupamento tabela = null;
            try
            {
                tabela = _objPeriodoAgrupamentoBal.ObterPeriodoAgrupamento(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "GET_NM", "/api/periodoagrupamento", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] PeriodoAgrupamento item)
        {
            try
            {
                _objPeriodoAgrupamentoBal.InserirPeriodoAgrupamento(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "POST", "/api/periodoagrupamento", ex.Message + " " + ex.InnerException);
            }            
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] PeriodoAgrupamento item)
        {
            try
            {
                _objPeriodoAgrupamentoBal.AlterarPeriodoAgrupamento(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "PUT", "/api/periodoagrupamento", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objPeriodoAgrupamentoBal.InativarPeriodoAgrupamento(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "DEL", "/api/periodoagrupamento", ex.Message + " " + ex.InnerException);
            }            
        }
    }
}