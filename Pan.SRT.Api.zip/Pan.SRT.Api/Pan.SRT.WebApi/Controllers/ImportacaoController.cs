﻿using System;
using System.IO;
using System.Text;
using System.Web;
using System.Linq;
using System.Web.Http;
using System.Collections.Generic;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class ImportacaoController : ApiController
    {
        private IListaBrancaBusinessLayer _objListaBrancaBal;
        private IListaNegraBusinessLayer  _objListaNegraBal;
        private int pIDUserLogin;
        Log _Log = new Log();


        public ImportacaoController(IListaBrancaBusinessLayer objListaBrancaBal, IListaNegraBusinessLayer objListaNegraBal)
        {
            var auth           = new Auth();
            pIDUserLogin       = auth.Authorize();
            _objListaBrancaBal = objListaBrancaBal;
            _objListaNegraBal  = objListaNegraBal;
        }

        //https://www.html5rocks.com/pt/tutorials/file/dndfiles/


        //------------------------------------------------------------- Inserir
        // POST api/values
        public string Post(Importacao pArquivo)  
        {
            var pRetorno = "";
            if ((pArquivo.ArquivoCSV == null) || (pArquivo.ArquivoCSV == ""))
            {
                return "Arquivo não informado";
            }
            if ((pArquivo.Tabela     == null) || (pArquivo.Tabela     == ""))
            {
                return "Nome da Tabela não informado";
            }

            try
            {
                var Streamm     = new MemoryStream(Encoding.UTF8.GetBytes(pArquivo.ArquivoCSV));
                var pArquivoCSV = new StreamReader(Streamm);
                string linha    = null;
                var iLin        = 1;
                while ((linha = pArquivoCSV.ReadLine()) != null)
                {
                    var sLin   = "";
                    var coluna = linha.Split(';');
                    if (coluna[0].Trim().ToUpper() != "")
                    {
                        if (coluna.Count() != 6)
                        {
                            sLin = "Linha [" + iLin + "] com colunas diferente do padrão";
                        }
                        else
                        {
                            try
                            {
                                //================================================================== RECEBIDO LISTA NEGRA ===================================================================
                                if (pArquivo.Tabela.Trim().ToUpper() == "LISTANEGRA")
                                {
                                    var NewListaNegra            = new ListaNegra();
                                    NewListaNegra.nmListaNegra   = coluna[0].Trim().ToUpper();
                                    NewListaNegra.nrCNPJ         = coluna[1].Trim().ToUpper();
                                    NewListaNegra.nrBanco        = Convert.ToInt32(coluna[2].Trim().ToUpper());
                                    NewListaNegra.nrAgencia      = Convert.ToInt32(coluna[3].Trim().ToUpper());
                                    NewListaNegra.nrConta        = Convert.ToInt32(coluna[4].Trim().ToUpper());
                                    NewListaNegra.nrContaDigito  = Convert.ToInt32(coluna[5].Trim().ToUpper());
                                    string sBcoAgConta = coluna[2].Trim().ToUpper() + "/" + coluna[3].Trim().ToUpper() + "/" + coluna[4].Trim().ToUpper();

                                    if (_objListaNegraBal.PesquisaListaNegra(NewListaNegra.nrCNPJ) == false)   //CNPJ Não existe
                                    {
                                        sLin = "Linha [" + iLin + "]: CNPJ [" + NewListaNegra.nrCNPJ + "] ja cadastrado";
                                    }
                                    else
                                    {
                                        if (_objListaNegraBal.PesqContaListaNegra(NewListaNegra.nrBanco, NewListaNegra.nrAgencia, NewListaNegra.nrConta) == false)   //Banco, Agencia e Conta Não existe
                                        {
                                            sLin = "Linha [" + iLin + "]: Banco/Ag/CConta [" + sBcoAgConta + "] ja cadastrado";
                                        }
                                        else
                                        {
                                            _objListaNegraBal.InserirListaNegra(NewListaNegra, pIDUserLogin);
                                        }
                                    }
                                }
                                //================================================================== RECEBIDO LISTA BRANCA ==================================================================
                                if (pArquivo.Tabela.Trim().ToUpper() == "LISTABRANCA")
                                {
                                    var NewListaBranca            = new ListaBranca();
                                    NewListaBranca.nmListaBranca  = coluna[0].Trim().ToUpper();
                                    NewListaBranca.nrCNPJ         = coluna[1].Trim().ToUpper();
                                    NewListaBranca.nrBanco        = Convert.ToInt32(coluna[2].Trim().ToUpper());
                                    NewListaBranca.nrAgencia      = Convert.ToInt32(coluna[3].Trim().ToUpper());
                                    NewListaBranca.nrConta        = Convert.ToInt32(coluna[4].Trim().ToUpper());
                                    NewListaBranca.nrContaDigito  = Convert.ToInt32(coluna[5].Trim().ToUpper());
                                    string sBcoAgConta = coluna[2].Trim().ToUpper() + "/" + coluna[3].Trim().ToUpper() + "/" + coluna[4].Trim().ToUpper();

                                    if (_objListaBrancaBal.PesquisaListaBranca(NewListaBranca.nrCNPJ) == false)   //CNPJ Não existe
                                    {
                                        sLin = "Linha [" + iLin + "]: CNPJ [" + NewListaBranca.nrCNPJ + "] ja cadastrado";
                                    }
                                    else
                                    {
                                        if (_objListaBrancaBal.PesqContaListaBranca(NewListaBranca.nrBanco, NewListaBranca.nrAgencia, NewListaBranca.nrConta) == false)   //Banco, Agencia e Conta Não existe
                                        {
                                            sLin = "Linha [" + iLin + "]: Banco/Ag/CConta [" + sBcoAgConta + "] ja cadastrado";
                                        }
                                        else
                                        {
                                            _objListaBrancaBal.InserirListaBranca(NewListaBranca, pIDUserLogin);
                                        }
                                    }
                                }
                                //===========================================================================================================================================================
                            }
                            catch (Exception ex)
                            {
                                sLin = "Erro na Linha [" + iLin + "]: " + ex.Message;
                            }
                        }
                        if (sLin != "") { pRetorno = pRetorno + sLin + "\n" + Environment.NewLine; }
                        iLin = iLin + 1;
                    }
                }
                if (pRetorno != "")
                {
                    pRetorno = pRetorno + "Restante das Linhas foram importadas com sucesso";
                }
                pArquivoCSV.Close();
            }
            catch (Exception ex)
            {
                pRetorno = pRetorno + "Erro: **" + ex.Message + "**" + Environment.NewLine;
                Log.LoggerErroTransacao("", "", "/api/importacao", "DEL", pRetorno, ex.Message + " " + ex.InnerException);
            }
            //
            if (pRetorno == "")
            {
                pRetorno = "Arquivo carregado com sucesso";
            }
            return pRetorno;
        }        
    }
}