﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class EntidadeController : ApiController
    {
        private readonly IEntidadeBusinessLayer _objEntidadeBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public EntidadeController(IEntidadeBusinessLayer objEntidadeBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objEntidadeBal = objEntidadeBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/entidade
        public IEnumerable<EntidadeLista> Get([FromUri] Entidade item)
        {
            IEnumerable<EntidadeLista> tabela = null;
            try
            {
                tabela = _objEntidadeBal.ObterEntidade(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidade", "GET", "/api/entidade", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/entidade/5
        public Entidade Get(int id)
        {
            Entidade tabela = null;
            try
            {
                tabela = _objEntidadeBal.ObterEntidade(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidade", "GET_ID", "/api/entidade", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/entidade/5
        public Entidade Get(string Nome)
        {
            Entidade tabela = null;
            try
            {
                tabela = _objEntidadeBal.ObterEntidade(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidade", "GET_NM", "/api/entidade", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] Entidade item)
        {
            try
            {
                _objEntidadeBal.InserirEntidade(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidade", "POST", "/api/entidade", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/entidade/5
        public void Put([FromBody] Entidade item)
        {
            try
            {
                _objEntidadeBal.AlterarEntidade(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidade", "PUT", "/api/entidade", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/entidade/5
        public void Delete(int id)
        {
            try
            {
                _objEntidadeBal.InativarEntidade(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidade", "DEL", "/api/entidade", ex.Message + " " + ex.InnerException);
            }
        }
    }
}