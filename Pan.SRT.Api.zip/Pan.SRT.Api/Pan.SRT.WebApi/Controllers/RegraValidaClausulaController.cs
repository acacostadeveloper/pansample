﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class RegraValidaClausulaController : ApiController
    {
        private readonly IRegraValidaClausulaBusinessLayer _objRegraValidaClausulaBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public RegraValidaClausulaController(IRegraValidaClausulaBusinessLayer objRegraValidaClausulaBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objRegraValidaClausulaBal = objRegraValidaClausulaBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<RegraValidaClausulaLista> Get([FromUri] RegraValidaClausula item)
        {
            IEnumerable<RegraValidaClausulaLista> tabela = null;
            try
            {
                tabela = _objRegraValidaClausulaBal.ObterRegraValidaClausula(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidaclausula", "GET", "/api/regravalidaclausula", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        public RegraValidaClausula Get(int id)
        {
            RegraValidaClausula tabela = null;
            try
            {
                tabela = _objRegraValidaClausulaBal.ObterRegraValidaClausula(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidaclausula", "GET_ID", "/api/regravalidaclausula", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public RegraValidaClausula Post([FromBody] RegraValidaClausula item)
        {
            RegraValidaClausula tabela = null;
            try
            {
                tabela = _objRegraValidaClausulaBal.InserirRegraValidaClausula(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidaclausula", "POST", "/api/regravalidaclausula", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] RegraValidaClausula item)
        {
            try
            {
                _objRegraValidaClausulaBal.AlterarRegraValidaClausula(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidaclausula", "PUT", "/api/regravalidaclausula", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objRegraValidaClausulaBal.InativarRegraValidaClausula(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidaclausula", "DEL", "/api/regravalidaclausula", ex.Message + " " + ex.InnerException);
            }
        }
    }
}