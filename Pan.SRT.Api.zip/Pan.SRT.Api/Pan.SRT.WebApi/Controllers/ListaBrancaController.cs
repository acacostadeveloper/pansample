﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class ListaBrancaController : ApiController
    {
        private readonly IListaBrancaBusinessLayer _objListaBrancaBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public ListaBrancaController(IListaBrancaBusinessLayer objListaBrancaBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objListaBrancaBal = objListaBrancaBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<ListaBrancaLista> Get([FromUri] ListaBranca item)
        {
            IEnumerable<ListaBrancaLista> tabela = null;
            try
            {
                tabela = _objListaBrancaBal.ObterListaBranca(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "GET", "/api/listabranca", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public ListaBranca Get(int id)
        {
            ListaBranca tabela = null;
            try
            {
                tabela = _objListaBrancaBal.ObterListaBranca(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "GET_ID", "/api/listabranca", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public ListaBranca Get(string Nome)
        {
            ListaBranca tabela = null;
            try
            {
                tabela = _objListaBrancaBal.ObterListaBranca(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "GET_NM", "/api/listabranca", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] ListaBranca item)
        {
            try
            {
                _objListaBrancaBal.InserirListaBranca(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "POST", "/api/listabranca", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] ListaBranca item)
        {
            try
            {
                _objListaBrancaBal.AlterarListaBranca(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "PUT", "/api/listabranca", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objListaBrancaBal.InativarListaBranca(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "DEL", "/api/listabranca", ex.Message + " " + ex.InnerException);
            }
        }
    }
}