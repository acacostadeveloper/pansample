﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class SistemaOrigemController : ApiController
    {
        private readonly ISistemaOrigemBusinessLayer _objSistemaOrigemBal;
        private int pIDUserLogin;
        Log _Log = new Log();

        public SistemaOrigemController(ISistemaOrigemBusinessLayer objSistemaOrigemBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objSistemaOrigemBal = objSistemaOrigemBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<SistemaOrigemLista> Get([FromUri] SistemaOrigem item)
        {
            IEnumerable<SistemaOrigemLista> tabela = null;
            try
            {
                tabela = _objSistemaOrigemBal.ObterSistemaOrigem(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/sistemaorigem", "GET", "/api/sistemaorigem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //--------------------------------------------------------------------------------
        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public SistemaOrigem Get(int id)
        {
            SistemaOrigem tabela = null;
            try
            {
                tabela = _objSistemaOrigemBal.ObterSistemaOrigem(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/sistemaorigem", "GET_ID", "/api/sistemaorigem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public SistemaOrigem Get(string Nome)
        {
            SistemaOrigem tabela = null;
            try
            {
                tabela = _objSistemaOrigemBal.ObterSistemaOrigem(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/sistemaorigem", "GET_NM", "/api/sistemaorigem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }
    }
}