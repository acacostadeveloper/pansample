﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class TipoMensagemController : ApiController
    {
        private readonly ITipoMensagemBusinessLayer _objTipoMensagemBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public TipoMensagemController(ITipoMensagemBusinessLayer objTipoMensagemBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objTipoMensagemBal = objTipoMensagemBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<TipoMensagemLista> Get([FromUri] TipoMensagem item)
        {
            IEnumerable<TipoMensagemLista> tabela = null;
            try
            {
                tabela = _objTipoMensagemBal.ObterTipoMensagem(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipomensagem", "GET", "/api/tipomensagem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public TipoMensagem Get(int id)
        {
            TipoMensagem tabela = null;
            try
            {
                tabela = _objTipoMensagemBal.ObterTipoMensagem(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipomensagem", "GET_ID", "/api/tipomensagem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Descricao
        // GET api/values/5
        public TipoMensagem Get(string Nome)
        {
            TipoMensagem tabela = null;
            try
            {
                tabela = _objTipoMensagemBal.ObterTipoMensagem(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipomensagem", "GET_NM", "/api/tipomensagem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] TipoMensagem item)
        {
            try
            {
                _objTipoMensagemBal.InserirTipoMensagem(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipomensagem", "POST", "/api/tipomensagem", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] TipoMensagem item)
        {
            try
            {
                _objTipoMensagemBal.AlterarTipoMensagem(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipomensagem", "PUT", "/api/tipomensagem", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objTipoMensagemBal.InativarTipoMensagem(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipomensagem", "DEL", "/api/tipomensagem", ex.Message + " " + ex.InnerException);
            }
        }
    }
}