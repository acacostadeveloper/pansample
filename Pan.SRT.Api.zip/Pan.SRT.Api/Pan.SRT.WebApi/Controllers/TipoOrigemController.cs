﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class TipoOrigemController : ApiController
    {
        private readonly ITipoOrigemBusinessLayer _objTipoOrigemBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public TipoOrigemController(ITipoOrigemBusinessLayer objTipoOrigemBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objTipoOrigemBal = objTipoOrigemBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<TipoOrigemLista> Get([FromUri] TipoOrigem item)
        {
            IEnumerable<TipoOrigemLista> tabela = null;
            try
            {
                tabela = _objTipoOrigemBal.ObterTipoOrigem(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "GET", "/api/tipoorigem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }


        //------------------------------------------------------------- Listar por ID
        // GET api/values/5
        public TipoOrigem Get(int id)
        {
            TipoOrigem tabela = null;
            try
            {
                tabela = _objTipoOrigemBal.ObterTipoOrigem(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "GET_ID", "/api/tipoorigem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/values/5
        public TipoOrigem Get(string Nome)
        {
            TipoOrigem tabela = null;
            try
            {
                tabela = _objTipoOrigemBal.ObterTipoOrigem(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "GET_NM", "/api/tipoorigem", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/values
        public void Post([FromBody] TipoOrigem item)
        {
            try
            {
                _objTipoOrigemBal.InserirTipoOrigem(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "POST", "/api/tipoorigem", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/values/5
        public void Put([FromBody] TipoOrigem item)
        {
            try
            {
                _objTipoOrigemBal.AlterarTipoOrigem(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "PUT", "/api/tipoorigem", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/values/5
        public void Delete(int id)
        {
            try
            {
                _objTipoOrigemBal.InativarTipoOrigem(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "DEL", "/api/tipoorigem", ex.Message + " " + ex.InnerException);
            }
        }
    }
}