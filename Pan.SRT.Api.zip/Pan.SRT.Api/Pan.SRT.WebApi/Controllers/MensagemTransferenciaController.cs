﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class MensagemTransferenciaController : ApiController
    {
        private readonly IMensagemTransferenciaBusinessLayer _objMensagemTransferenciaBal;
        private int pIDUserLogin;
        private Auth Autorize = new Auth();
        Log _Log = new Log();

        public MensagemTransferenciaController(IMensagemTransferenciaBusinessLayer objMensagemTransferenciaBal)
        {
            pIDUserLogin                 = 2; //USUARIO PADRÃO  --------->//Autorize.Authorize();
            _objMensagemTransferenciaBal = objMensagemTransferenciaBal;
        }

        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<MensagemTransferenciaLista> Get([FromUri] MensagemTransferenciaFiltro item)
        {
            IEnumerable<MensagemTransferenciaLista> tabela = null;
            try
            {
                tabela = _objMensagemTransferenciaBal.ObterMensagemTransferencia(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/mensagemtransferencia", "GET", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/Alcada/5
        public MensagemTransferencia Get(int id)
        {
            MensagemTransferencia tabela = null;
            try
            {
                tabela = _objMensagemTransferenciaBal.ObterMensagemTransferencia(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/mensagemtransferencia", "GET_ID", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Requista TED
        // POST api/values
        public MensagemResponse Post([FromBody] ParametrosTed item) 
        {
            MensagemResponse Resposta = new MensagemResponse();
            try
            {
                //20.06.2018 - Vanderlei pediu para comentar, para testes com Autbank
              /*if (!Autorize.AuthorizeADGroup())
                {
                    Resposta.codErro       = 401;
                    Resposta.descricaoErro = "Usuario sem permissao para envio de TED";
                }
                else
                {*/
                    var pApiServiceEBank    = System.Configuration.ConfigurationManager.AppSettings.Get("ApiServiceEBankUrl");
                    var pApiServiceInfoBank = System.Configuration.ConfigurationManager.AppSettings.Get("ApiServiceInfoBankUrl");
                    //================================================================================= Define qual EBank e Info pegar: DEVP, HML ou PRD
                    Resposta = _objMensagemTransferenciaBal.requisitaTED(item, pIDUserLogin, pApiServiceEBank, pApiServiceInfoBank);
                //}
            }
            catch (Exception ex)
            {
                Resposta.codErro       = 401;
                Resposta.descricaoErro = ex.Message + " " + ex.InnerException;
                Log.LoggerErroTransacao("", "", "/api/mensagemtransferencia", "POST", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException);
            }
            return Resposta;
        }

        //------------------------------------------------------------- Altera Status da Mensagem Transferencia
        // PUT api/values/5
        public bool Put([FromBody] MensagemTransferenciaStatus item)
        {
            bool bRet = false;
            try
            {
                bRet = _objMensagemTransferenciaBal.StatusMensagemTransferencia(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/mensagemstatus", "PUT", "/api/mensagemstatus", ex.Message + " " + ex.InnerException);
            }
            return bRet;
        }
    }
}