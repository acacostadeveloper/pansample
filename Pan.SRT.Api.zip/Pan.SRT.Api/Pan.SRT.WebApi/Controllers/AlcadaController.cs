﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class AlcadaController : ApiController
    {
        private IAlcadaBusinessLayer   _objAlcadaBal;
        private int pIDUserLogin;
        Log _Log = new Log();

        public AlcadaController(IAlcadaBusinessLayer objAlcadaBal)
        {
            var auth              = new Auth();
            pIDUserLogin          = auth.Authorize();
            _objAlcadaBal         = objAlcadaBal;
        }


        //------------------------------------------------------------- Listar Todos
        // GET api/Alcada
        public IEnumerable<AlcadaLista> Get([FromUri] Alcada item)
        {
            IEnumerable<AlcadaLista> tabela = null;
            try
            {
                tabela = _objAlcadaBal.ObterAlcada(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "GET", "/api/alcada", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por ID
        // GET api/Alcada/5
        public Alcada Get(int id)
        {
            Alcada tabela = null;
            try
            {
                tabela = _objAlcadaBal.ObterAlcada(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "GET_ID", "/api/alcada", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Listar por Nome
        // GET api/Alcada/5
        public Alcada Get(string Nome)
        {
            Alcada tabela = null;
            try
            {
                tabela = _objAlcadaBal.ObterAlcada(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "GET_NM", "/api/alcada", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

        //------------------------------------------------------------- Inserir
        // POST api/Alcada
        public void Post([FromBody]Alcada item)
        {
            try
            {
                _objAlcadaBal.InserirAlcada(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "POST", "/api/alcada", ex.Message + " " + ex.InnerException);
            }
        }
        //------------------------------------------------------------- Alterar
        // PUT api/Alcada/5
        public void Put([FromBody]Alcada item)
        {
            try
            {
                _objAlcadaBal.AlterarAlcada(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "PUT", "/api/alcada", ex.Message + " " + ex.InnerException);
            }
        }
        //------------------------------------------------------------- Inativar
        // DELETE api/Alcada/5
        public void Delete(int id)
        {
            try
            {
                _objAlcadaBal.InativarAlcada(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "DEL", "/api/alcada", ex.Message + " " + ex.InnerException);
            }
        }
        //----------------------------------------------------------------------------------        
    }
}
