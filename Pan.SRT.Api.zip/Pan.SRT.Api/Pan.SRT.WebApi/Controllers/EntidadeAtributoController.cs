﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Entidades;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Infra.Token;



namespace Pan.SRT.WebApi.Controllers
{
    public class EntidadeAtributoController : ApiController
    {
        private readonly IEntidadeAtributoBusinessLayer _objEntidadeAtributoBal;
        private readonly int pIDUserLogin;
        Log _Log = new Log();

        public EntidadeAtributoController(IEntidadeAtributoBusinessLayer objEntidadeAtributoBal)
        {
            var auth = new Auth();
            pIDUserLogin = auth.Authorize();
            _objEntidadeAtributoBal = objEntidadeAtributoBal;
        }


        //------------------------------------------------------------- Listar Todos
        // GET api/values
        public IEnumerable<EntidadeAtributoLista> Get([FromUri] EntidadeAtributo item)
        {
            IEnumerable<EntidadeAtributoLista> tabela = null;
            try
            {
                tabela = _objEntidadeAtributoBal.ObterEntidadeAtributo(item);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "GET", "/api/entidadeatributo", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }



        //------------------------------------------------------------- Listar por ID
        // GET api/Alcada/5
        public EntidadeAtributo Get(int id)
        {
            EntidadeAtributo tabela = null;
            try
            {
                tabela = _objEntidadeAtributoBal.ObterEntidadeAtributo(id);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "GET_ID", "/api/entidadeatributo", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }
        //------------------------------------------------------------- Listar por Nome
        // GET api/Alcada/5
        public EntidadeAtributo Get(string Nome)
        {
            EntidadeAtributo tabela = null;
            try
            {
                tabela = _objEntidadeAtributoBal.ObterEntidadeAtributo(Nome);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "GET_NM", "/api/entidadeatributo", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }
      
        //------------------------------------------------------------- Inserir
        // POST api/EntidadeAtributo
        public void Post([FromBody] EntidadeAtributo item)
        {
            try
            {
                _objEntidadeAtributoBal.InserirEntidadeAtributo(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "POST", "/api/entidadeatributo", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Alterar
        // PUT api/EntidadeAtributo/5
        public void Put([FromBody] EntidadeAtributo item)
        {
            try
            {
                _objEntidadeAtributoBal.AlterarEntidadeAtributo(item, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "PUT", "/api/entidadeatributo", ex.Message + " " + ex.InnerException);
            }
        }

        //------------------------------------------------------------- Inativar
        // DELETE api/EntidadeAtributo/5
        public void Delete(int id)
        {
            try
            {
                _objEntidadeAtributoBal.InativarEntidadeAtributo(id, pIDUserLogin);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "DEL", "/api/entidadeatributo", ex.Message + " " + ex.InnerException);
            }
        }
    }
}