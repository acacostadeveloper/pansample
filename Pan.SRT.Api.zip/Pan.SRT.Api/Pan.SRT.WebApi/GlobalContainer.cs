﻿using System.Web.Http;
using System.Web.Mvc;
using Pan.SRT.Business;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.WebApi.Handlers;
using SimpleInjector;

namespace Pan.SRT.WebApi
{
    public class GlobalContainer
    {
        public void _ChamaGlobalContainer()
        {
            GlobalConfiguration.Configuration.MessageHandlers.Add(new LogHandler());

            //EGS 30.04.2018 - Gravação de LOG
            var container = new Container();
            //------------------------------------------------------------------------------------------------------------------------ Alcada
            container.Register<IAlcadaDataAccessLayer                  , AlcadaDataAccessLayer>();
            container.Register<IAlcadaBusinessLayer                    , AlcadaBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Sistema Origem
            container.Register<ISistemaOrigemDataAccessLayer           , SistemaOrigemDataAccessLayer>();
            container.Register<ISistemaOrigemBusinessLayer             , SistemaOrigemBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Instituicao Financeira
            container.Register<IInstituicaoFinanceiraDataAccessLayer   , InstituicaoFinanceiraDataAccessLayer>();
            container.Register<IInstituicaoFinanceiraBusinessLayer     , InstituicaoFinanceiraBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Tipo Origem
            container.Register<ITipoOrigemDataAccessLayer              , TipoOrigemDataAccessLayer>();
            container.Register<ITipoOrigemBusinessLayer                , TipoOrigemBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Tipo Destino
            container.Register<ITipoDestinoDataAccessLayer             , TipoDestinoDataAccessLayer>();
            container.Register<ITipoDestinoBusinessLayer               , TipoDestinoBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Validacao de regras
            container.Register<IRegraValidacaoDataAccessLayer          , RegraValidacaoDataAccessLayer>();
            container.Register<IRegraValidacaoBusinessLayer            , RegraValidacaoBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Validacao de Regra Clausulas
            container.Register<IRegraValidaClausulaDataAccessLayer     , RegraValidaClausulaDataAccessLayer>();
            container.Register<IRegraValidaClausulaBusinessLayer       , RegraValidaClausulaBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Tipo Operador
            container.Register<ITipoOperadorDataAccessLayer            , TipoOperadorDataAccessLayer>();
            container.Register<ITipoOperadorBusinessLayer              , TipoOperadorBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Tipo Agrupamento
            container.Register<ITipoAgrupamentoDataAccessLayer         , TipoAgrupamentoDataAccessLayer>();
            container.Register<ITipoAgrupamentoBusinessLayer           , TipoAgrupamentoBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Periodo Agrupamento
            container.Register<IPeriodoAgrupamentoDataAccessLayer      , PeriodoAgrupamentoDataAccessLayer>();
            container.Register<IPeriodoAgrupamentoBusinessLayer        , PeriodoAgrupamentoBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Entidade Externa
            container.Register<IEntidadeDataAccessLayer                , EntidadeDataAccessLayer>();
            container.Register<IEntidadeBusinessLayer                  , EntidadeBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Entidade Atributo
            container.Register<IEntidadeAtributoDataAccessLayer        , EntidadeAtributoDataAccessLayer>();
            container.Register<IEntidadeAtributoBusinessLayer          , EntidadeAtributoBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Email de Alerta
            container.Register<IEmailAlertaDataAccessLayer             , EmailAlertaDataAccessLayer>();
            container.Register<IEmailAlertaBusinessLayer               , EmailAlertaBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Lista Branca
            container.Register<IListaBrancaDataAccessLayer             , ListaBrancaDataAccessLayer>();
            container.Register<IListaBrancaBusinessLayer               , ListaBrancaBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Lista Negra
            container.Register<IListaNegraDataAccessLayer              , ListaNegraDataAccessLayer>();
            container.Register<IListaNegraBusinessLayer                , ListaNegraBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Clausula - Tipo de Mensagem
            container.Register<ITipoMensagemDataAccessLayer            , TipoMensagemDataAccessLayer>();
            container.Register<ITipoMensagemBusinessLayer              , TipoMensagemBusinessLayer>();
            //------------------------------------------------------------------------------------------------------------------------ Mensagem Transferencia webservice AutBank, para receber, validar, e enviar ao AutBank 05.02.2018
            container.Register<IMensagemTransferenciaDataAccessLayer   , MensagemTransferenciaDataAccessLayer>();
            container.Register<IMensagemTransferenciaBusinessLayer     , MensagemTransferenciaBusinessLayer>();
            //--------------------------------------------------------------------------------------------------------------------------------------------------------
            //--------------------------------------------------------------------------------------------------------------------------------------------------------
            //--------------------------------------------------------------------------------------------------------------------------------------------------------
            container.Verify();
            DependencyResolver.SetResolver(new SimpleInjectorDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new SimpleInjectorDependencyResolver(container);
        }
    }
}