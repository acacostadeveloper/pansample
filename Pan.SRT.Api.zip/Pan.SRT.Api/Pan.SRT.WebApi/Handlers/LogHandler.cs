﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using Pan.SRT.Entidades;
using Pan.SRT.Infra;

namespace Pan.SRT.WebApi.Handlers
{
    public class LogHandler : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var logModel = CreateLog(request);
            if (request.Content != null)
            {
                await request.Content.ReadAsStringAsync()
                    .ContinueWith(task =>
                    {
                        try
                        {
                            logModel.RequestBody = JsonConvert.DeserializeObject(task.Result);
                        }
                        catch (Exception)
                        {
                            logModel.RequestBody = "";
                        }
                    }, cancellationToken);
            }

            return await base.SendAsync(request, cancellationToken)
                .ContinueWith(task =>
                {
                    var response = task.Result;

                    logModel.ResponseStatusCode = (int)response.StatusCode;
                    if (logModel.ResponseStatusCode >= 500)
                    {
                        logModel.HttpError = logModel.ResponseStatusCode == 501 ? null : response.Content.ReadAsAsync<HttpError>().Result;
                    }
                    logModel.ResponseTimestamp = DateTime.Now;

                    if (response.Content != null)
                    {
                        try
                        {
                        logModel.ResponseContentBody = logModel.ResponseStatusCode >= 400 ? JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result) : null;
                        }
                        catch
                        { };
                        logModel.ResponseHeaders = GetHeaders(response.Content.Headers);
                    }
                    LogRepository.AddLog(logModel);

                    return response;
                }, cancellationToken);
        }

        private Logguer CreateLog(HttpRequestMessage request)
        {
            var context = ((HttpContextBase)request.Properties["MS_HttpContext"]);

            return new Logguer
            {
                Application       = "RESTRITIVO.SRT-API",
                CorrelationId     = request.GetCorrelationId(),
                User              = context.User.Identity.Name,
                Machine           = Environment.MachineName,
                IpAddress         = context.Request.UserHostAddress,
                RequestMethod     = request.Method.Method,
                RequestHeaders    = GetHeaders(request.Headers),
                RequestTimestamp  = DateTime.Now,
                RequestUri        = request.RequestUri.ToString(),
                MessageError      = ""
            };
        }

        private static IDictionary<string, string> GetHeaders(HttpHeaders headers)
        {
            var retorno = new Dictionary<string, string>();

            foreach (var item in headers.ToList())
            {
                if (item.Value == null) continue;
                var header = item.Value.Aggregate(string.Empty, (current, value) => current + (value + " "));

                header = header.TrimEnd(" ".ToCharArray());
                retorno.Add(item.Key, header);
            }
            return retorno;
        }
    }
}