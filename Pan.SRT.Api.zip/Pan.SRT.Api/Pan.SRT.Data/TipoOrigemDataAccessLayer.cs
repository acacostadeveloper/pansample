﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class TipoOrigemDataAccessLayer : ITipoOrigemDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public TipoOrigemDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<TipoOrigemLista> ObterTipoOrigem(TipoOrigem item)
        {
            TipoOrigem itemTab = new TipoOrigem();
            if (item != null) { itemTab = item; }
            IEnumerable<TipoOrigemLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (from ifs in _contexto.TipoOrigem
                          join _UsuaInc in _contexto.Usuario on ifs.IdUsuarioInclusao   equals _UsuaInc.idUsuario
                          join _UsuaAlt in _contexto.Usuario on ifs.IdUsuarioManutencao equals _UsuaAlt.idUsuario into tm
                          from subUser  in tm.DefaultIfEmpty()
                          let UsuarioManutencao = subUser.nmUsuario
                          //where ifs.blnAtivo.Equals(true)      //True
                          where ((string.IsNullOrEmpty(itemTab.nmOrigem)) || (ifs.nmOrigem.Contains(itemTab.nmOrigem)))
                          && ((string.IsNullOrEmpty(itemTab.nmTipoConta)) || (ifs.nmTipoConta.Contains(itemTab.nmTipoConta)))
                          && ((string.IsNullOrEmpty(itemTab.nmTipoPessoa)) || (ifs.nmTipoPessoa.Contains(itemTab.nmTipoPessoa)))

                    select new
                    {
                        idTipoOrigem            = ifs.idTipoOrigem,
                        nmOrigem                = ifs.nmOrigem,
                        nmTipoConta             = ifs.nmTipoConta,
                        nmTipoPessoa            = ifs.nmTipoPessoa,
                        blnPossuiContaDigital   = ifs.blnPossuiContaDigital,
                        IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                        blnAtivo                = ifs.blnAtivo
                    }).ToList().Select(x => new TipoOrigemLista()
                    {
                        idTipoOrigem            = x.idTipoOrigem,
                        nmOrigem                = x.nmOrigem,
                        nmTipoConta             = x.nmTipoConta,
                        nmTipoPessoa            = x.nmTipoPessoa,
                        blnPossuiContaDigital   = x.blnPossuiContaDigital,
                        IdUsuarioInclusao       = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao       = x.DtUsuarioInclusao,
                        IdUsuarioManutencao     = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao     = x.DtUsuarioManutencao,
                        blnAtivo                = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "GET", "/api/tipoorigem", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por ID
        public TipoOrigem ObterTipoOrigem(int pID)
        {
            TipoOrigem tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoOrigem.Select(x => x).Where(x => x.idTipoOrigem == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "GET", "/api/tipoorigem", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public TipoOrigem ObterTipoOrigem(string pTexto)
        {
            TipoOrigem tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoOrigem.Select(x => x).Where(x => x.nmOrigem == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoorigem", "GET", "/api/tipoorigem", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public TipoOrigem InserirTipoOrigem(TipoOrigem item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<TipoOrigem>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirTipoOrigem", "POST", "/api/tipoorigem", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public TipoOrigem AlterarTipoOrigem(TipoOrigem item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarTipoOrigem", "PUT", "/api/tipoorigem", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public TipoOrigem InativarTipoOrigem(int idTipoOrigem, int pIDUserLogin)
        {
            TipoOrigem tabela = null;
            try
            {
                TipoOrigem user          = _contexto.Set<TipoOrigem>().Single(x => x.idTipoOrigem == idTipoOrigem);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<TipoOrigem>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarTipoOrigem", "DEL", "/api/tipoorigem", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}