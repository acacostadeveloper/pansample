﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class ListaNegraMap : EntityTypeConfiguration<ListaNegra>
    {
        public ListaNegraMap() 
        {
            this.HasKey(t   => t.idListaNegra);
            this.Property(t => t.idListaNegra).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmListaNegra).HasMaxLength(20);

            this.ToTable("tbListaNegra");
            this.Property(t => t.idListaNegra           ).HasColumnName("idListaNegra");
            this.Property(t => t.nmListaNegra           ).HasColumnName("nmListaNegra");
            this.Property(t => t.nrCNPJ                 ).HasColumnName("nrCNPJ");
            this.Property(t => t.nrBanco                ).HasColumnName("nrBanco");
            this.Property(t => t.nrAgencia              ).HasColumnName("nrAgencia");
            this.Property(t => t.nrConta                ).HasColumnName("nrConta");
            this.Property(t => t.nrContaDigito          ).HasColumnName("nrContaDigito");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
