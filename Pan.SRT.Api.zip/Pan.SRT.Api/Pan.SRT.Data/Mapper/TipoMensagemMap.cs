﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class TipoMensagemMap : EntityTypeConfiguration<TipoMensagem>
    {
        public TipoMensagemMap() 
        {
            this.HasKey(t   => t.idTipoMensagem);
            this.Property(t => t.idTipoMensagem).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nrCodigo      ).HasMaxLength(20);
            this.Property(t => t.nmDescricao   ).HasMaxLength(50);

            this.ToTable("tbTipoMensagem");
            this.Property(t => t.idTipoMensagem         ).HasColumnName("idTipoMensagem");
            this.Property(t => t.nrCodigo               ).HasColumnName("nrCodigo");
            this.Property(t => t.nmDescricao            ).HasColumnName("nmDescricao");
            this.Property(t => t.blnSensibConta         ).HasColumnName("blnSensibConta");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
