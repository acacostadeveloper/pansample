﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class TipoOrigemMap : EntityTypeConfiguration<TipoOrigem>
    {
        public TipoOrigemMap() 
        {
            this.HasKey(t   => t.idTipoOrigem);
            this.Property(t => t.idTipoOrigem).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmOrigem).HasMaxLength(50);

            this.ToTable("tbTipoOrigem");
            this.Property(t => t.idTipoOrigem           ).HasColumnName("idTipoOrigem");
            this.Property(t => t.nmOrigem               ).HasColumnName("nmOrigem");
            this.Property(t => t.nmTipoConta            ).HasColumnName("nmTipoConta");
            this.Property(t => t.nmTipoPessoa           ).HasColumnName("nmTipoPessoa");
            this.Property(t => t.blnPossuiContaDigital  ).HasColumnName("blnPossuiContaDigital");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
