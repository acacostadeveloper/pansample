﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class TipoAgrupamentoMap : EntityTypeConfiguration<TipoAgrupamento>
    {
        public TipoAgrupamentoMap() 
        {
            this.HasKey(t   => t.idTipoAgrupamento);
            this.Property(t => t.idTipoAgrupamento).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmDescricao).HasMaxLength(50);

            this.ToTable("tbTipoAgrupamento");
            this.Property(t => t.idTipoAgrupamento      ).HasColumnName("idTipoAgrupamento");
            this.Property(t => t.cdTipoAgrupamento      ).HasColumnName("cdTipoAgrupamento");
            this.Property(t => t.nmDescricao            ).HasColumnName("nmDescricao");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
