﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class EntidadeMap : EntityTypeConfiguration<Entidade>
    {
        public EntidadeMap() 
        {
            this.HasKey(t   => t.idEntidade);
            this.Property(t => t.idEntidade).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmEntidade).HasMaxLength(50);

            this.ToTable("tbEntidade");
            this.Property(t => t.idEntidade             ).HasColumnName("idEntidade");
            this.Property(t => t.cdEntidade             ).HasColumnName("cdEntidade");
            this.Property(t => t.nmEntidade             ).HasColumnName("nmEntidade");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
