﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class InstituicaoFinanceiraMap : EntityTypeConfiguration<InstituicaoFinanceira>
    {
        public InstituicaoFinanceiraMap() 
        {
            this.HasKey(t   => t.idInstituicaoFinanceira);
            this.Property(t => t.idInstituicaoFinanceira).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmInstituicaoFinanceira).HasMaxLength(50);

            this.ToTable("tbInstituicaoFinanceira");
            this.Property(t => t.idInstituicaoFinanceira).HasColumnName("idInstituicaoFinanceira");
            this.Property(t => t.nmInstituicaoFinanceira).HasColumnName("nmInstituicaoFinanceira");
            this.Property(t => t.nrCnpj                 ).HasColumnName("nrCnpj");
            this.Property(t => t.nrCodigoCompensacao    ).HasColumnName("nrCodigoCompensacao");
            this.Property(t => t.dsSegmento             ).HasColumnName("dsSegmento");
            this.Property(t => t.dsGrupoEconomico       ).HasColumnName("dsGrupoEconomico");
            this.Property(t => t.blnPossuiContaDigital  ).HasColumnName("blnPossuiContaDigital");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
