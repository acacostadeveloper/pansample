﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class RegraValidaClausulaMap : EntityTypeConfiguration<RegraValidaClausula>
    {
        public RegraValidaClausulaMap() 
        {
            this.HasKey  (t => t.idRegraValidaClausula);
            this.Property(t => t.idRegraValidaClausula).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("tbRegraValidaClausula");
            this.Property(t => t.idRegraValidaClausula  ).HasColumnName("idRegraValidaClausula");
            this.Property(t => t.idRegraValidacao       ).HasColumnName("idRegraValidacao");
            this.Property(t => t.idEntidade             ).HasColumnName("idEntidade");
            this.Property(t => t.idEntidadeAtributo     ).HasColumnName("idEntidadeAtributo");
            this.Property(t => t.idTipoOperador         ).HasColumnName("idTipoOperador");
            this.Property(t => t.idPeriodoAgrupamento   ).HasColumnName("idPeriodoAgrupamento");
            this.Property(t => t.idTipoAgrupamento      ).HasColumnName("idTipoAgrupamento");
            this.Property(t => t.nrValor                ).HasColumnName("nrValor");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
