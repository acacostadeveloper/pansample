﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class ListaBrancaMap : EntityTypeConfiguration<ListaBranca>
    {
        public ListaBrancaMap() 
        {
            this.HasKey(t   => t.idListaBranca);
            this.Property(t => t.idListaBranca).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmListaBranca).HasMaxLength(20);

            this.ToTable("tbListaBranca");
            this.Property(t => t.idListaBranca          ).HasColumnName("idListaBranca");
            this.Property(t => t.nmListaBranca          ).HasColumnName("nmListaBranca");
            this.Property(t => t.nrCNPJ                 ).HasColumnName("nrCNPJ");
            this.Property(t => t.nrBanco                ).HasColumnName("nrBanco");
            this.Property(t => t.nrAgencia              ).HasColumnName("nrAgencia");
            this.Property(t => t.nrConta                ).HasColumnName("nrConta");
            this.Property(t => t.nrContaDigito          ).HasColumnName("nrContaDigito");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
