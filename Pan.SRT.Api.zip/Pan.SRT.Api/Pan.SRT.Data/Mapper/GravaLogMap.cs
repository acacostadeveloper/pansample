﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class GravaLogMap : EntityTypeConfiguration<GravaLog>
    {
        public GravaLogMap() 
        {
            this.HasKey  (t => t.idLog);
            this.Property(t => t.idLog).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("tbLog");
            this.Property(t => t.idLog                  ).HasColumnName("idLog");
            this.Property(t => t.DataInclusao           ).HasColumnName("DataInclusao");
            this.Property(t => t.Mensagem               ).HasColumnName("Mensagem");
        }
    }
}
