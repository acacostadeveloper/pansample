﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class MensagemTransferenciaMap : EntityTypeConfiguration<MensagemTransferencia>
    {
        public MensagemTransferenciaMap() 
        {
            this.HasKey(t   => t.idMensagemTransferencia);
            this.Property(t => t.idMensagemTransferencia).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("tbMensagemTransferencia");
            this.Property(t => t.idMensagemTransferencia    ).HasColumnName("idMensagemTransferencia");
            this.Property(t => t.CanalEntrada               ).HasColumnName("CanalEntrada");
            this.Property(t => t.ComplementoHistorico       ).HasColumnName("ComplementoHistorico");
            this.Property(t => t.DataAgendPag               ).HasColumnName("DataAgendPag");
            this.Property(t => t.DataVencto                 ).HasColumnName("DataVencto");
            this.Property(t => t.HoraVencto                 ).HasColumnName("HoraVencto");
            this.Property(t => t.Historico                  ).HasColumnName("Historico");
            this.Property(t => t.Tarifado                   ).HasColumnName("Tarifado");
            this.Property(t => t.Finalidade                 ).HasColumnName("Finalidade");
            this.Property(t => t.Prioridade                 ).HasColumnName("Prioridade");
            this.Property(t => t.NroBoleto                  ).HasColumnName("NroBoleto");
            this.Property(t => t.NumOrigem                  ).HasColumnName("NumOrigem");
            this.Property(t => t.Valor                      ).HasColumnName("Valor");
            this.Property(t => t.EventoCodigo               ).HasColumnName("EventoCodigo");
            this.Property(t => t.SensibilizaConta           ).HasColumnName("SensibilizaConta");
            this.Property(t => t.nrStatus                   ).HasColumnName("nrStatus");
            this.Property(t => t.IdUsuarioInclusao          ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao          ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao        ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao        ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo                   ).HasColumnName("blnAtivo");
        }
    }
}
