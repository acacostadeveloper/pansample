﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class TipoDestinoMap : EntityTypeConfiguration<TipoDestino>
    {
        public TipoDestinoMap() 
        {
            this.HasKey(t => t.idTipoDestino);
            this.Property(t => t.idTipoDestino).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmDestino).HasMaxLength(50);

            this.ToTable("tbTipoDestino");
            this.Property(t => t.idTipoDestino          ).HasColumnName("idTipoDestino");
            this.Property(t => t.nmDestino              ).HasColumnName("nmDestino");
            this.Property(t => t.nmTipoConta            ).HasColumnName("nmTipoConta");
            this.Property(t => t.nmTipoPessoa           ).HasColumnName("nmTipoPessoa");
            this.Property(t => t.blnPossuiContaDigital  ).HasColumnName("blnPossuiContaDigital");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
