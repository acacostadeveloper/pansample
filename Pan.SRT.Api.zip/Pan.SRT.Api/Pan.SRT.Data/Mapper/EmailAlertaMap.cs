﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class EmailAlertaMap : EntityTypeConfiguration<EmailAlerta>
    {
        public EmailAlertaMap() 
        {
            this.HasKey(t   => t.idEmailAlerta);
            this.Property(t => t.idEmailAlerta).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmEmailAlerta).HasMaxLength(150);

            this.ToTable("tbEmailAlerta");
            this.Property(t => t.idEmailAlerta          ).HasColumnName("idEmailAlerta");
            this.Property(t => t.nmEmailAlerta          ).HasColumnName("nmEmailAlerta");
            this.Property(t => t.IdSistemaOrigem        ).HasColumnName("IdSistemaOrigem");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
