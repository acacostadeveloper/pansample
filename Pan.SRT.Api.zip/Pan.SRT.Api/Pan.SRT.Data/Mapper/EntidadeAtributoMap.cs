﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class EntidadeAtributoMap : EntityTypeConfiguration<EntidadeAtributo>
    {
        public EntidadeAtributoMap() 
        {
            this.HasKey(t   => t.idEntidadeAtributo);
            this.Property(t => t.idEntidadeAtributo).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.cdAtributo        ).HasMaxLength(150);
            this.Property(t => t.nmAtributo        ).HasMaxLength(150);

            this.ToTable("tbEntidadeAtributo");
            this.Property(t => t.idEntidadeAtributo     ).HasColumnName("idEntidadeAtributo");
            this.Property(t => t.idEntidade             ).HasColumnName("idEntidade");
            this.Property(t => t.cdAtributo             ).HasColumnName("cdAtributo");
            this.Property(t => t.cdAtributoTipo         ).HasColumnName("cdAtributoTipo");
            this.Property(t => t.nmAtributo             ).HasColumnName("nmAtributo");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
