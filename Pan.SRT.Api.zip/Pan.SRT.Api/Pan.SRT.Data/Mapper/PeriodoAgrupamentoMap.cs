﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class PeriodoAgrupamentoMap : EntityTypeConfiguration<PeriodoAgrupamento>
    {
        public PeriodoAgrupamentoMap() 
        {
            this.HasKey(t   => t.idPeriodoAgrupamento);
            this.Property(t => t.idPeriodoAgrupamento).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmDescricao).HasMaxLength(50);

            this.ToTable("tbPeriodoAgrupamento");
            this.Property(t => t.idPeriodoAgrupamento   ).HasColumnName("idPeriodoAgrupamento");
            this.Property(t => t.cdPeriodoAgrupamento   ).HasColumnName("cdPeriodoAgrupamento");
            this.Property(t => t.nmDescricao            ).HasColumnName("nmDescricao");
            this.Property(t => t.nrTempoMinuto          ).HasColumnName("nrTempoMinuto");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
