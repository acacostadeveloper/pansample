﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class TipoOperadorMap : EntityTypeConfiguration<TipoOperador>
    {
        public TipoOperadorMap() 
        {
            this.HasKey(t   => t.idTipoOperador);
            this.Property(t => t.idTipoOperador).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmDescricao   ).HasMaxLength(50);

            this.ToTable("tbTipoOperador");
            this.Property(t => t.idTipoOperador         ).HasColumnName("idTipoOperador");
            this.Property(t => t.cdTipoOperador         ).HasColumnName("cdTipoOperador");
            this.Property(t => t.nmDescricao            ).HasColumnName("nmDescricao");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");
        }
    }
}
