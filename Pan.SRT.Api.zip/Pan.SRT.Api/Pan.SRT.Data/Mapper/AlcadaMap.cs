﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class AlcadaMap : EntityTypeConfiguration<Alcada>
    {
        public AlcadaMap() 
        {
            this.HasKey(t   => t.idAlcada   );
            this.Property(t => t.idAlcada   ).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.cdAlcada   ).HasMaxLength(10);
            this.Property(t => t.nmDescricao).HasMaxLength(50);

            this.ToTable("tbAlcada");
            this.Property(t => t.idAlcada               ).HasColumnName("idAlcada");
            this.Property(t => t.cdAlcada               ).HasColumnName("cdAlcada");
            this.Property(t => t.nmDescricao            ).HasColumnName("nmDescricao");
            this.Property(t => t.IdUsuarioInclusao      ).HasColumnName("IdUsuarioInclusao");
            this.Property(t => t.DtUsuarioInclusao      ).HasColumnName("DtUsuarioInclusao");
            this.Property(t => t.IdUsuarioManutencao    ).HasColumnName("IdUsuarioManutencao");
            this.Property(t => t.DtUsuarioManutencao    ).HasColumnName("DtUsuarioManutencao");
            this.Property(t => t.nrNivel                ).HasColumnName("nrNivel");
            this.Property(t => t.blnAtivo               ).HasColumnName("blnAtivo");

        }
    }
}
