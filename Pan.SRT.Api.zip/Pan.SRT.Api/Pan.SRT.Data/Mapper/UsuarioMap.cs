﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class UsuarioMap : EntityTypeConfiguration<Usuario>
    {
        public UsuarioMap() 
        {
            this.HasKey  (t => t.idUsuario);
            this.Property(t => t.idUsuario).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.login).HasMaxLength(50);

            this.ToTable("tbUsuario");
            this.Property(t => t.idUsuario              ).HasColumnName("idUsuario");
            this.Property(t => t.login                  ).HasColumnName("login");
            this.Property(t => t.nmUsuario              ).HasColumnName("nmUsuario");
        }
    }
}
