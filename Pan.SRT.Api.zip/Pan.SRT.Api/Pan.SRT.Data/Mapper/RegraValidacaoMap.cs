﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.Mapper
{
    public class RegraValidacaoMap : EntityTypeConfiguration<RegraValidacao>
    {
        public RegraValidacaoMap() 
        {
            this.HasKey(t   => t.idRegraValidacao   );
            this.Property(t => t.idRegraValidacao   ).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            this.Property(t => t.nmDescricao        ).HasMaxLength(50);
            this.Property(t => t.nmConsequencia     ).HasMaxLength(50);

            this.ToTable("tbRegraValidacao");
            this.Property(t => t.idRegraValidacao   ).HasColumnName("idRegraValidacao");
            this.Property(t => t.nmDescricao        ).HasColumnName("nmDescricao");
            this.Property(t => t.nmConsequencia     ).HasColumnName("nmConsequencia");
            this.Property(t => t.nrCriticidade      ).HasColumnName("nrCriticidade");
            this.Property(t => t.blnAtivo           ).HasColumnName("blnAtivo");
        }
    }
}
