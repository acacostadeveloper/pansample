﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Helpers;




namespace Pan.SRT.Data
{
    public class InstituicaoFinanceiraDataAccessLayer : IInstituicaoFinanceiraDataAccessLayer
    {

        private PanRestritivosContext   _contexto;
        private GravaLogDataAccessLayer _ObjGravaLogDataAccessLayer;
        private GravaLogHelp _LogHlp = new GravaLogHelp();

        public InstituicaoFinanceiraDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
            _ObjGravaLogDataAccessLayer = new GravaLogDataAccessLayer();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<InstituicaoFinanceiraLista> ObterInstituicaoFinanceira(InstituicaoFinanceira item)
        {
            InstituicaoFinanceira itemTab = new InstituicaoFinanceira();
            if (item != null) { itemTab = item; }

            IEnumerable<InstituicaoFinanceiraLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (
                    from ifs in _contexto.InstituicaoFinanceira
                    join _UsuaInc in _contexto.Usuario on ifs.IdUsuarioInclusao equals _UsuaInc.idUsuario
                    join _UsuaAlt in _contexto.Usuario on ifs.IdUsuarioManutencao equals _UsuaAlt.idUsuario into tm
                    from subUser  in tm.DefaultIfEmpty()
                    let UsuarioManutencao = subUser.nmUsuario
                    //where ifs.blnAtivo.Equals(true)      //True
                    where ((string.IsNullOrEmpty(itemTab.nmInstituicaoFinanceira)) || (ifs.nmInstituicaoFinanceira.Contains(itemTab.nmInstituicaoFinanceira)))
                    && ((string.IsNullOrEmpty(itemTab.nrCnpj)) || (ifs.nrCnpj.Contains(itemTab.nrCnpj)))

                    select new
                    {
                        idInstituicaoFinanceira      = ifs.idInstituicaoFinanceira,
                        nmInstituicaoFinanceira      = ifs.nmInstituicaoFinanceira,
                        nrCnpj                       = ifs.nrCnpj,
                        nrCodigoCompensacao          = ifs.nrCodigoCompensacao,
                        dsSegmento                   = ifs.dsSegmento,
                        dsGrupoEconomico             = ifs.dsGrupoEconomico,
                        blnPossuiContaDigital        = ifs.blnPossuiContaDigital,
                        IdUsuarioInclusao            = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome          = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao            = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao          = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome        = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao          = ifs.DtUsuarioManutencao,
                        blnAtivo = ifs.blnAtivo
                    }).ToList().Select(x => new InstituicaoFinanceiraLista()
                    {
                        idInstituicaoFinanceira      = x.idInstituicaoFinanceira,
                        nmInstituicaoFinanceira      = x.nmInstituicaoFinanceira,
                        nrCnpj                       = x.nrCnpj,
                        nrCodigoCompensacao          = x.nrCodigoCompensacao,
                        dsSegmento                   = x.dsSegmento,
                        dsGrupoEconomico             = x.dsGrupoEconomico,
                        blnPossuiContaDigital        = x.blnPossuiContaDigital,
                        IdUsuarioInclusao            = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome          = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao            = x.DtUsuarioInclusao,
                        IdUsuarioManutencao          = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome        = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao          = x.DtUsuarioManutencao,
                        blnAtivo                     = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Inst.Financ DATA GET - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "GET", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }



        //------------------------------------------------------------------ LISTAR por ID
        public InstituicaoFinanceira ObterInstituicaoFinanceira(int pID)
        {
            InstituicaoFinanceira tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.InstituicaoFinanceira.Select(x => x).Where(x => x.idInstituicaoFinanceira == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "GET", "/api/instituicaofinanceira", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public InstituicaoFinanceira ObterInstituicaoFinanceira(string pTexto)
        {
            InstituicaoFinanceira tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.InstituicaoFinanceira.Select(x => x).Where(x => x.nmInstituicaoFinanceira == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/instituicaofinanceira", "GET", "/api/instituicaofinanceira", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR por CNPJ
        public InstituicaoFinanceira ObterInstituicaoFinancCNPJ(string pCNPJ)
        {
            InstituicaoFinanceira tabela = null; 
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.InstituicaoFinanceira.Select(x => x).Where(x => x.nrCnpj == pCNPJ).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Inst.Financ DATA GET - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "/api/ObterInstituicaoFinancCNPJ", "GET", "/api/ObterInstituicaoFinancCNPJ", ex.Message + " " + ex.InnerException);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public InstituicaoFinanceira InserirInstituicaoFinanceira(InstituicaoFinanceira item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<InstituicaoFinanceira>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Inst.Financ DATA GET - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "InserirInstituicaoFinanceira", "POST", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public InstituicaoFinanceira AlterarInstituicaoFinanceira(InstituicaoFinanceira item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Inst.Financ DATA GET - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "AlterarInstituicaoFinanceira", "PUT", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public InstituicaoFinanceira InativarInstituicaoFinanceira(int idInstituicaoFinanceira, int pIDUserLogin)
        {
            InstituicaoFinanceira tabela = null;

            try
            {
                InstituicaoFinanceira user = _contexto.Set<InstituicaoFinanceira>().Single(x => x.idInstituicaoFinanceira == idInstituicaoFinanceira);
                user.IdUsuarioManutencao   = pIDUserLogin;
                user.DtUsuarioManutencao   = DateTime.Now;
                user.blnAtivo              = false;
                _contexto.Entry<InstituicaoFinanceira>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Inst.Financ DATA GET - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "InativarInstituicaoFinanceira", "DEL", "/api/instituicaofinanceira", ex.Message + " " + ex.InnerException);
            }
            return tabela;
        }

    }
}