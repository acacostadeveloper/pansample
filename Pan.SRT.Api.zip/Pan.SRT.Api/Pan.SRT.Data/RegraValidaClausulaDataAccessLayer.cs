﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Data;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class RegraValidaClausulaDataAccessLayer : IRegraValidaClausulaDataAccessLayer
    {

        private PanRestritivosContext _contexto;

        public RegraValidaClausulaDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<RegraValidaClausulaLista> ObterRegraValidaClausula(RegraValidaClausula item)
        {
            RegraValidaClausula itemTab = new RegraValidaClausula();
            if (item != null) { itemTab = item; }

            IEnumerable<RegraValidaClausulaLista> tabela = null;
            try
            {
                tabela = (from _Clausula in _contexto.RegraValidaClausula
                            join _Exta    in _contexto.EntidadeAtributo   on _Clausula.idEntidadeAtributo   equals _Exta.idEntidadeAtributo
                            join _Ente    in _contexto.Entidade           on _Clausula.idEntidade           equals _Ente.idEntidade
                            join _Peri    in _contexto.PeriodoAgrupamento on _Clausula.idPeriodoAgrupamento equals _Peri.idPeriodoAgrupamento
                            join _Tipo    in _contexto.TipoAgrupamento    on _Clausula.idTipoAgrupamento    equals _Tipo.idTipoAgrupamento
                            join _Oper    in _contexto.TipoOperador       on _Clausula.idTipoOperador       equals _Oper.idTipoOperador
                            join _UsuaInc in _contexto.Usuario            on _Clausula.IdUsuarioInclusao    equals _UsuaInc.idUsuario
                            join _UsuaAlt in _contexto.Usuario            on _Clausula.IdUsuarioManutencao  equals _UsuaAlt.idUsuario into tm
                            from subUser  in tm.DefaultIfEmpty()
                            let UsuarioManutencao = subUser.nmUsuario
                          //where _Clausula.blnAtivo.Equals(true)      //True
                          where ((itemTab.idRegraValidacao == 0) || (_Clausula.idRegraValidacao.Equals(itemTab.idRegraValidacao)))
                          && ((itemTab.idRegraValidaClausula == 0) || (_Clausula.idRegraValidaClausula.Equals(itemTab.idRegraValidaClausula)))
                          orderby _Clausula.DtUsuarioManutencao descending

                            select new
                            {
                                idRegraValidaClausula       = _Clausula.idRegraValidaClausula,
                                idRegraValidacao            = _Clausula.idRegraValidacao,
                                idEntidade                  = _Clausula.idEntidade,
                                EntidadeDescricao           = _Ente.nmEntidade,
                                idEntidadeAtributo          = _Clausula.idEntidadeAtributo,
                                EntidadeNomeTecnico         = _Ente.cdEntidade,
                                EntidadeAtributoDescricao   = _Exta.cdAtributo,
                                idTipoOperador              = _Clausula.idTipoOperador,
                                TipoOperadorCodigo          = _Oper.cdTipoOperador,
                                TipoOperadorDescricao       = _Oper.nmDescricao,
                                idPeriodoAgrupamento        = _Clausula.idPeriodoAgrupamento,
                                PeriodoAgrupamentoDescricao = _Peri.nmDescricao,
                                idTipoAgrupamento           = _Clausula.idTipoAgrupamento,
                                TipoAgrupamentoDescricao    = _Tipo.nmDescricao,
                                nrValor                     = _Clausula.nrValor,
                                IdUsuarioInclusao           = _Clausula.IdUsuarioInclusao,
                                UsuarioInclusaoNome         = _UsuaInc.nmUsuario.Substring(0,16),
                                DtUsuarioInclusao           = _Clausula.DtUsuarioInclusao,
                                IdUsuarioManutencao         = _Clausula.IdUsuarioManutencao,
                                UsuarioManutencaoNome       = UsuarioManutencao.Substring(0,16),
                                DtUsuarioManutencao         = _Clausula.DtUsuarioManutencao,
                                blnAtivo                    = _Clausula.blnAtivo

                            }).ToList().Select(x => new RegraValidaClausulaLista()
                            {
                                idRegraValidaClausula       = x.idRegraValidaClausula,
                                idRegraValidacao            = x.idRegraValidacao,
                                idEntidade                  = x.idEntidade,
                                EntidadeDescricao           = x.EntidadeDescricao,
                                idEntidadeAtributo          = x.idEntidadeAtributo,
                                EntidadeAtributoDescricao   = x.EntidadeAtributoDescricao,
                                EntidadeNomeTecnico         = x.EntidadeNomeTecnico,
                                idTipoOperador              = x.idTipoOperador,
                                TipoOperadorCodigo          = x.TipoOperadorCodigo,
                                TipoOperadorDescricao       = x.TipoOperadorDescricao,
                                idPeriodoAgrupamento        = x.idPeriodoAgrupamento,
                                PeriodoAgrupamentoDescricao = x.PeriodoAgrupamentoDescricao,
                                idTipoAgrupamento           = x.idTipoAgrupamento,
                                TipoAgrupamentoDescricao    = x.TipoAgrupamentoDescricao,
                                nrValor                     = x.nrValor,
                                IdUsuarioInclusao           = x.IdUsuarioInclusao,
                                UsuarioInclusaoNome         = x.UsuarioInclusaoNome,
                                DtUsuarioInclusao           = x.DtUsuarioInclusao,
                                IdUsuarioManutencao         = x.IdUsuarioManutencao,
                                UsuarioManutencaoNome       = x.UsuarioManutencaoNome,
                                DtUsuarioManutencao         = x.DtUsuarioManutencao,
                                blnAtivo                    = x.blnAtivo
                            }).ToList();
            
                
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por ID
        public RegraValidaClausula ObterRegraValidaClausula(int pID)
        {
            RegraValidaClausula tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.RegraValidaClausula.Select(x => x).Where(x => x.idRegraValidaClausula == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public RegraValidaClausula InserirRegraValidaClausula(RegraValidaClausula item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<RegraValidaClausula>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public RegraValidaClausula AlterarRegraValidaClausula(RegraValidaClausula item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarRegraValidaClausula", "PUT", "/api/RegraValidaClausula", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public RegraValidaClausula InativarRegraValidaClausula(int idRegraValidaClausula, int pIDUserLogin)
        {
            RegraValidaClausula tabela = null;
            try
            {
                RegraValidaClausula user = _contexto.Set<RegraValidaClausula>().Single(x => x.idRegraValidaClausula == idRegraValidaClausula);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<RegraValidaClausula>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarRegraValidaClausula", "DEL", "/api/RegraValidaClausula", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}