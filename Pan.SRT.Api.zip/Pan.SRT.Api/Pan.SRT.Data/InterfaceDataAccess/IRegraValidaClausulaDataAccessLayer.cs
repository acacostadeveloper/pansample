﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IRegraValidaClausulaDataAccessLayer
    {
        IEnumerable<RegraValidaClausulaLista> ObterRegraValidaClausula   (RegraValidaClausula item);
        RegraValidaClausula                   ObterRegraValidaClausula   (int pID);
        RegraValidaClausula                   InserirRegraValidaClausula (RegraValidaClausula item , int pIDUserLogin);
        RegraValidaClausula                   AlterarRegraValidaClausula (RegraValidaClausula item , int pIDUserLogin);
        RegraValidaClausula                   InativarRegraValidaClausula(int idRegraValidaClausula, int pIDUserLogin);
    }
}
