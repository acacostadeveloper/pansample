﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IPeriodoAgrupamentoDataAccessLayer
    {
        IEnumerable<PeriodoAgrupamentoLista> ObterPeriodoAgrupamento   (PeriodoAgrupamento item);
        PeriodoAgrupamento                   ObterPeriodoAgrupamento   (int pID);
        PeriodoAgrupamento                   ObterPeriodoAgrupamento   (string pTexto);
        PeriodoAgrupamento                   InserirPeriodoAgrupamento (PeriodoAgrupamento item , int pIDUserLogin);
        PeriodoAgrupamento                   AlterarPeriodoAgrupamento (PeriodoAgrupamento item , int pIDUserLogin);
        PeriodoAgrupamento                   InativarPeriodoAgrupamento(int idPeriodoAgrupamento, int pIDUserLogin);
    }
}
