﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IEntidadeDataAccessLayer
    {
        IEnumerable<EntidadeLista> ObterEntidade   (Entidade item);
        Entidade                   ObterEntidade   (int pID);
        Entidade                   ObterEntidade   (string pTexto);
        Entidade                   InserirEntidade (Entidade item , int pIDUserLogin);
        Entidade                   AlterarEntidade (Entidade item , int pIDUserLogin);
        Entidade                   InativarEntidade(int idEntidade, int pIDUserLogin);
    }
}
