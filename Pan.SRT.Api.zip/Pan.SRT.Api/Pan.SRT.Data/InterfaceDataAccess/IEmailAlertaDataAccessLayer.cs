﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IEmailAlertaDataAccessLayer
    {
        IEnumerable<EmailAlertaLista> ObterEmailAlerta   (EmailAlerta item);
        EmailAlerta                   ObterEmailAlerta   (int pID);
        EmailAlerta                   ObterEmailAlerta   (string pTexto);
        EmailAlerta                   InserirEmailAlerta (EmailAlerta item , int pIDUserLogin);
        EmailAlerta                   AlterarEmailAlerta (EmailAlerta item , int pIDUserLogin);
        EmailAlerta                   InativarEmailAlerta(int idEmailAlerta, int pIDUserLogin);
    }
}
