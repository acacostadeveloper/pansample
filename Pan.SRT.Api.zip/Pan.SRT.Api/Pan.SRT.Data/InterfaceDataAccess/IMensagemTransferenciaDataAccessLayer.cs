﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IMensagemTransferenciaDataAccessLayer
    {
        IEnumerable<MensagemTransferenciaLista> ObterMensagemTransferencia    (MensagemTransferenciaFiltro item);
        MensagemTransferencia                   ObterMensagemTransferencia    (int idMensagemTransferencia);
        bool                                    StatusMensagemTransferencia   (MensagemTransferenciaStatus item, int pIDUserLogin);
        bool                                    AlertaMensagemTransferencia   (MensagemTransferenciaStatus item);


        MensagemTransferencia                   InserirMensagemTransferencia  (MensagemTransferencia       item, int pIDUserLogin);
        MensagemTransferencia                   AlterarMensagemTransferencia  (MensagemTransferencia       item, int pIDUserLogin);
        void                                    InserirMensagemDebito         (MensagemDebito              item, int pIDUserLogin);
        MensagemCredito                         InserirMensagemCredito        (MensagemCredito             item, int pIDUserLogin);
        Conta                                   InserirConta                  (Conta                       item, int pIDUserLogin);
        MensagemTransHistorico                  InserirMensagemTransfHistorico(MensagemTransHistorico      item);
    }
}
