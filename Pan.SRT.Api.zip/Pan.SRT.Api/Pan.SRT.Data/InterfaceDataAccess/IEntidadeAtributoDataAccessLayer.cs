﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IEntidadeAtributoDataAccessLayer
    {
        IEnumerable<EntidadeAtributoLista> ObterEntidadeAtributo   (EntidadeAtributo item);
        EntidadeAtributo                   ObterEntidadeAtributo   (int pID);
        EntidadeAtributo                   ObterEntidadeAtributo   (string pTexto);
        EntidadeAtributo                   InserirEntidadeAtributo (EntidadeAtributo item , int pIDUserLogin);
        EntidadeAtributo                   AlterarEntidadeAtributo (EntidadeAtributo item , int pIDUserLogin);
        EntidadeAtributo                   InativarEntidadeAtributo(int idEntidadeAtributo, int pIDUserLogin);
    }
}
