﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface ITipoMensagemDataAccessLayer
    {
        IEnumerable<TipoMensagemLista> ObterTipoMensagem   (TipoMensagem item);
        TipoMensagem                   ObterTipoMensagem   (int pID);
        TipoMensagem                   ObterTipoMensagem   (string pTexto);
        TipoMensagem                   InserirTipoMensagem (TipoMensagem item , int pIDUserLogin);
        TipoMensagem                   AlterarTipoMensagem (TipoMensagem item , int pIDUserLogin);
        TipoMensagem                   InativarTipoMensagem(int idTipoMensagem, int pIDUserLogin);
    }
}
