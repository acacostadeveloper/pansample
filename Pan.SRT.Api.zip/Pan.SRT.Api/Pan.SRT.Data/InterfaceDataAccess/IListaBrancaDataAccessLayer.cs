﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IListaBrancaDataAccessLayer
    {
        IEnumerable<ListaBrancaLista> ObterListaBranca    (ListaBranca item);
        ListaBranca                   ObterListaBranca    (int pID);
        ListaBranca                   ObterListaBranca    (string pTexto);
        ListaBranca                   InserirListaBranca  (ListaBranca item , int pIDUserLogin);
        ListaBranca                   AlterarListaBranca  (ListaBranca item , int pIDUserLogin);
        ListaBranca                   InativarListaBranca (int idListaBranca, int pIDUserLogin);
        bool                          PesquisaListaBranca (string pCNPJ);
        bool                          PesqContaListaBranca(int pBanco, int pConta, int pAgencia);
    }
}
