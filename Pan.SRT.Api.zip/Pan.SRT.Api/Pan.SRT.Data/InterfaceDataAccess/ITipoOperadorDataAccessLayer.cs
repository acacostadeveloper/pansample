﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface ITipoOperadorDataAccessLayer
    {
        IEnumerable<TipoOperadorLista> ObterTipoOperador   (TipoOperador item);
        TipoOperador                   ObterTipoOperadorID (int pID);
        TipoOperador                   ObterTipoOperadorTx (string pTexto);
        TipoOperador                   InserirTipoOperador (TipoOperador item , int pIDUserLogin);
        TipoOperador                   AlterarTipoOperador (TipoOperador item , int pIDUserLogin);
        TipoOperador                   InativarTipoOperador(int idTipoOperador, int pIDUserLogin);
    }
}
