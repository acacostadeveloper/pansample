﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IInstituicaoFinanceiraDataAccessLayer
    {
        IEnumerable<InstituicaoFinanceiraLista> ObterInstituicaoFinanceira   (InstituicaoFinanceira item);
        InstituicaoFinanceira                   ObterInstituicaoFinanceira   (int pID);
        InstituicaoFinanceira                   ObterInstituicaoFinanceira   (string pTexto);
        InstituicaoFinanceira                   ObterInstituicaoFinancCNPJ   (string pCNPJ);
        InstituicaoFinanceira                   InserirInstituicaoFinanceira (InstituicaoFinanceira item , int pIDUserLogin);
        InstituicaoFinanceira                   AlterarInstituicaoFinanceira (InstituicaoFinanceira item , int pIDUserLogin);
        InstituicaoFinanceira                   InativarInstituicaoFinanceira(int idInstituicaoFinanceira, int pIDUserLogin);
    }
}
