﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface ITipoAgrupamentoDataAccessLayer
    {
        IEnumerable<TipoAgrupamentoLista> ObterTipoAgrupamento    (TipoAgrupamento item);
        TipoAgrupamento                   ObterTipoAgrupamento    (int pID);
        TipoAgrupamento                   ObterTipoAgrupamento    (string pTexto);
        TipoAgrupamento                   InserirTipoAgrupamento  (TipoAgrupamento item , int pIDUserLogin);
        TipoAgrupamento                   AlterarTipoAgrupamento  (TipoAgrupamento item , int pIDUserLogin);
        TipoAgrupamento                   InativarTipoAgrupamento (int idTipoAgrupamento, int pIDUserLogin);
    }
}
