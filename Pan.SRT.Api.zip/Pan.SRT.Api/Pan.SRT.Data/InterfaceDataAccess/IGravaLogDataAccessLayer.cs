﻿namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface IGravaLogDataAccessLayer
    {
        void InserirGravaLog(string pMensagem);
    }
}
