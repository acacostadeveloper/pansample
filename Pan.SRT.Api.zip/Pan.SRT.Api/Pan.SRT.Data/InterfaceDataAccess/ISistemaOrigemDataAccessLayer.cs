﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Data.InterfaceDataAccess
{
    public interface ISistemaOrigemDataAccessLayer
    {
        IEnumerable<SistemaOrigemLista> ObterSistemaOrigem(SistemaOrigem item);
        SistemaOrigem                   ObterSistemaOrigem(int pID);
        SistemaOrigem                   ObterSistemaOrigem(string pTexto);
    }
}
