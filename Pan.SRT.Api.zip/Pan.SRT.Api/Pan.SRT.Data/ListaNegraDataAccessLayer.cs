﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Helpers;


namespace Pan.SRT.Data
{
    public class ListaNegraDataAccessLayer : IListaNegraDataAccessLayer
    {
        private PanRestritivosContext _contexto;
        private GravaLogHelp _LogHlp = new GravaLogHelp();

        public ListaNegraDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<ListaNegraLista> ObterListaNegra(ListaNegra item)
        {
            ListaNegra itemTab = new ListaNegra();
            if (item != null) { itemTab = item; }

            IEnumerable<ListaNegraLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (
                    from ifs in _contexto.ListaNegra
                    join _UsuaInc in _contexto.Usuario       on ifs.IdUsuarioInclusao    equals _UsuaInc.idUsuario
                    join _UsuaAlt in _contexto.Usuario       on ifs.IdUsuarioManutencao  equals _UsuaAlt.idUsuario into tm
                    from subUser  in tm.DefaultIfEmpty()
                    let UsuarioManutencao = subUser.nmUsuario
                    //where ifs.blnAtivo.Equals(true)      //True
                    where ((string.IsNullOrEmpty(itemTab.nrCNPJ)) || (ifs.nrCNPJ.Contains(itemTab.nrCNPJ)))
                    && ((string.IsNullOrEmpty(itemTab.nmListaNegra)) || (ifs.nmListaNegra.Contains(itemTab.nmListaNegra)))
                    && ((itemTab.nrBanco == 0) || (ifs.nrBanco.Equals(itemTab.nrBanco)))
                    && ((itemTab.nrAgencia == 0) || (ifs.nrAgencia.Equals(itemTab.nrAgencia)))
                    && ((itemTab.nrConta == 0) || (ifs.nrConta.ToString().Contains(itemTab.nrConta.ToString())))
                    select new
                    {
                        idListaNegra            = ifs.idListaNegra,
                        nmListaNegra            = ifs.nmListaNegra,
                        nrAgencia               = ifs.nrAgencia,
                        nrBanco                 = ifs.nrBanco,
                        nrConta                 = ifs.nrConta,
                        nrContaDigito           = ifs.nrContaDigito,
                        nrCNPJ                  = ifs.nrCNPJ,
                        IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                        blnAtivo                = ifs.blnAtivo
                    }).ToList().Select(x => new ListaNegraLista()
                    {
                        idListaNegra            = x.idListaNegra,
                        nmListaNegra            = x.nmListaNegra,
                        nrAgencia               = x.nrAgencia,
                        nrBanco                 = x.nrBanco,
                        nrConta                 = x.nrConta,
                        nrContaDigito           = x.nrContaDigito,
                        nrCNPJ                  = x.nrCNPJ,
                        IdUsuarioInclusao       = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao       = x.DtUsuarioInclusao,
                        IdUsuarioManutencao     = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao     = x.DtUsuarioManutencao,
                        blnAtivo                = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "GET", "/api/listanegra", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR POR ID
        public ListaNegra ObterListaNegra(int pID)
        {
            ListaNegra tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.ListaNegra.Select(x => x).Where(x => x.idListaNegra == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "GET", "/api/listanegra", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR POR NOME
        public ListaNegra ObterListaNegra(string pTexto)
        {
            ListaNegra tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.ListaNegra.Select(x => x).Where(x => x.nmListaNegra == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listanegra", "GET", "/api/listanegra", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ INSERT
        public ListaNegra InserirListaNegra(ListaNegra item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<ListaNegra>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirListaNegra", "POST", "/api/listanegra", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public ListaNegra AlterarListaNegra(ListaNegra item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarListaNegra", "PUT", "/api/listanegra", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public ListaNegra InativarListaNegra(int idListaNegra, int pIDUserLogin)
        {
            ListaNegra tabela = null;

            try
            {
                ListaNegra user = _contexto.Set<ListaNegra>().Single(x => x.idListaNegra == idListaNegra);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<ListaNegra>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarListaNegra", "DEL", "/api/listanegra", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ PESQUISA por CNPJ
        public bool PesquisaListaNegra(string pCNPJ)
        {
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                if (_contexto.ListaNegra.Select(x => x).Where(x => x.nrCNPJ == pCNPJ).FirstOrDefault() == null)
                {
                    return true;
                };
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/PesquisaListaNegra", "GET", "/api/PesquisaListaNegra", ex.Message);
                throw ex;
            }
            return false;
        }


        //------------------------------------------------------------------ PESQUISA por CONTA  30.06.2018
        public bool PesqContaListaNegra(int pBanco, int pConta, int pAgencia)
        {
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                if (_contexto.ListaNegra.Select(x => x).Where(x => x.nrBanco == pBanco && x.nrAgencia == pAgencia && x.nrConta == pConta).FirstOrDefault() == null)
                {
                    return true;
                };
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/PesqContaListaNegra", "GET", "/api/PesqContaListaNegra", ex.Message);
                throw ex;
            }
            return false;
        }


    }
}