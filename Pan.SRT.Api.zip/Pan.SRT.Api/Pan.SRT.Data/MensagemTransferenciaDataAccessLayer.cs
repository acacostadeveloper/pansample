﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Agent.EBankWebServ;
using Pan.SRT.Agent.InfoBankWebServ;
using Pan.SRT.Helpers;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class MensagemTransferenciaDataAccessLayer : IMensagemTransferenciaDataAccessLayer
    {
        private PanRestritivosContext _contexto;
        private GravaLogHelp _LogHlp = new GravaLogHelp();

        public MensagemTransferenciaDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }




        //------------------------------------------------------------------ LISTAR
        public IEnumerable<MensagemTransferenciaLista> ObterMensagemTransferencia(MensagemTransferenciaFiltro item)
        {

            DateTime dDtIncInicio = DateTime.MinValue;
            DateTime dDtIncFinal  = DateTime.MinValue;
            if (item.DtInclusaoInicio != null) { dDtIncInicio = Convert.ToDateTime(item.DtInclusaoInicio);}
            if (item.DtInclusaoFinal  != null) { dDtIncFinal  = Convert.ToDateTime(item.DtInclusaoFinal );}

            IEnumerable<MensagemTransferenciaLista> tabela = null;
            try
            {

                //EGS Traz todos os registros, com campo ATIVO=1, e agora com usuario inclusao e manutencao 16.03.2018
                var temp = (from _Msg            in _contexto.MensagemTransferencia
                                 join _Deb       in _contexto.MensagemDebito        on _Msg.idMensagemDebito            equals _Deb.idMensagemDebito
                                 join _ContDeb   in _contexto.Conta                 on _Deb.idContaDebito               equals _ContDeb.idConta
                                 join _TipOrig   in _contexto.TipoOrigem            on _Deb.idTipoOrigem                equals _TipOrig.idTipoOrigem
                                 join _Inst      in _contexto.InstituicaoFinanceira on _ContDeb.idInstituicaoFinanceira equals _Inst.idInstituicaoFinanceira
                                 join _Cre       in _contexto.MensagemCredito       on _Msg.idMensagemCredito           equals _Cre.idMensagemCredito
                                 join _ContCre   in _contexto.Conta                 on _Cre.idContaCredito              equals _ContCre.idConta
                                 join _TipDest   in _contexto.TipoDestino           on _Cre.idTipoDestino               equals _TipDest.idTipoDestino
                                 join _InsCre    in _contexto.InstituicaoFinanceira on _ContCre.idInstituicaoFinanceira equals _InsCre.idInstituicaoFinanceira
                                 join _TipMens   in _contexto.TipoMensagem          on _Msg.idTipoMensagem              equals _TipMens.idTipoMensagem
                            //where _Msg.blnAtivo.Equals(true)      //True

                            where ((item.idMensagemTransferencia == 0) || (_Msg.idMensagemTransferencia.Equals(item.idMensagemTransferencia)))
                            && ((string.IsNullOrEmpty(item.NroBoleto)) || (_Msg.NroBoleto.Contains(item.NroBoleto)))
                            && ((item.nrStatus == -1) || (_Msg.nrStatus.Equals(item.nrStatus)))
                            && ((item.nrValInicio == 0) || (_Msg.Valor >= item.nrValInicio))
                            && ((item.nrValFinal == 0) || (_Msg.Valor <= item.nrValFinal))
                            && ((dDtIncInicio == DateTime.MinValue) || (_Msg.DtUsuarioInclusao >= dDtIncInicio))
                            && ((dDtIncFinal == DateTime.MinValue) || (_Msg.DtUsuarioInclusao <= dDtIncFinal))

                            select new
                            {
                                idMensagemTransferencia = _Msg.idMensagemTransferencia,                                
                                DtUsuarioInclusao       = _Msg.DtUsuarioInclusao,
                                Finalidade              = _Msg.Finalidade,
                                Prioridade              = _Msg.Prioridade,
                                NroBoleto               = _Msg.NroBoleto,
                                NumOrigem               = _Msg.NumOrigem,
                                Tarifado                = _Msg.Tarifado,
                                Historico               = _Msg.Historico,
                                SensibilizaConta        = _Msg.SensibilizaConta,
	                            DataAgendPag            = _Msg.DataAgendPag,
	                            DataVencto              = _Msg.DataVencto,
	                            HoraVencto              = _Msg.HoraVencto,
                                EventoCodigo            = _Msg.EventoCodigo,
                                EventoDescricao         = _TipMens.nmDescricao,
                                CodigoOrigem            = _Deb.CodigoOrigem,                                
                                SistemaOrigem           = _Deb.SistemaOrigem,
                                ClienteTipo             = "ClienteTipo",
                                ClienteCodigo           = "ClienteCodigo",
                                ClienteNome             = "ClienteNome",
                                ClienteCNPJ             = "ClienteCNPJ",
                                ClienteDesde            = "ClienteDesde",
                                ClienteTelefone         = "ClienteTelefone",
                                ClienteCelular          = "ClienteCelular",
                                ClienteExpostoPublic    = true,
                                Deb_Origem              = _TipOrig.nmOrigem,
                                Deb_NumBanco            = _ContDeb.NumeroBanco,
                                Deb_NumAgencia          = _ContDeb.NumeroAgencia,
                                Deb_NumConta            = _ContDeb.NumeroConta,
                                Deb_ContaDigital        = _Inst.blnPossuiContaDigital,
                                Deb_TipoConta           = _TipOrig.nmTipoConta,
                                Deb_TipoPessoa          = _TipOrig.nmTipoPessoa,
                                Cre_NumBanco            = _ContCre.NumeroBanco,
                                Cre_NumAgencia          = _ContCre.NumeroAgencia,
                                Cre_NumConta            = _ContCre.NumeroConta,
                                Cre_Cnpj                = _InsCre.nrCnpj,
                                Cre_ContaDigital        = _InsCre.blnPossuiContaDigital,
                                Cre_TipoConta           = _TipDest.nmTipoConta,
                                Cre_TipoPessoa          = _TipDest.nmTipoPessoa,
                                Valor                   = _Msg.Valor,
                                ValorString             = _Msg.Valor,
                                nrStatus                = _Msg.nrStatus,
                                blnAtivo                = _Msg.blnAtivo

                            }).ToList().Select(x => new MensagemTransferenciaLista()
                            {

                                idMensagemTransferencia = x.idMensagemTransferencia,
                                DtUsuarioInclusao       = x.DtUsuarioInclusao      ,
                                Finalidade              = x.Finalidade             ,
                                Prioridade              = x.Prioridade             ,
                                NroBoleto               = x.NroBoleto              ,
                                NumOrigem               = x.NumOrigem              ,
                                Tarifado                = x.Tarifado               ,
                                SensibilizaConta        = x.SensibilizaConta       ,
                                Historico               = x.Historico              ,
	                            DataAgendPag            = x.DataAgendPag           ,
	                            DataVencto              = x.DataVencto             ,
	                            HoraVencto              = x.HoraVencto             ,
                                EventoCodigo            = x.EventoCodigo           ,
                                EventoDescricao         = x.EventoDescricao        ,
                                CodigoOrigem            = x.CodigoOrigem           ,
                                SistemaOrigem           = x.SistemaOrigem          ,
                                ClienteTipo             = x.ClienteTipo            ,
                                ClienteCodigo           = x.ClienteCodigo          ,
                                ClienteNome             = x.ClienteNome            ,
                                ClienteCNPJ             = x.ClienteCNPJ            ,
                                ClienteDesde            = x.ClienteDesde           ,
                                ClienteTelefone         = x.ClienteTelefone        ,
                                ClienteCelular          = x.ClienteCelular         ,
                                ClienteExpostoPublic    = x.ClienteExpostoPublic   ,
                                Deb_Origem              = x.Deb_Origem             ,
                                Deb_NumBanco            = x.Deb_NumBanco           ,
                                Deb_NumAgencia          = x.Deb_NumAgencia         ,
                                Deb_NumConta            = x.Deb_NumConta           ,
                                Deb_ContaDigital        = x.Deb_ContaDigital       ,
                                Deb_TipoConta           = x.Deb_TipoConta          ,
                                Deb_TipoPessoa          = x.Deb_TipoPessoa         ,
                                Cre_NumBanco            = x.Cre_NumBanco           ,
                                Cre_NumAgencia          = x.Cre_NumAgencia         ,
                                Cre_NumConta            = x.Cre_NumConta           ,
                                Cre_Cnpj                = x.Cre_Cnpj               ,
                                Cre_TipoConta           = x.Cre_TipoConta          ,
                                Cre_TipoPessoa          = x.Cre_TipoPessoa         ,
                                Valor                   = x.Valor                  ,
                                ValorString             = string.Format("{0:N}", x.ValorString),
                                nrStatus                = x.nrStatus               ,
                                blnAtivo                = x.blnAtivo});

                tabela = temp.ToList().OrderByDescending(x => x.DtUsuarioManutencao);

            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/mensagemtransferencia", "GET", "/api/mensagemtransferencia", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public MensagemTransferencia ObterMensagemTransferencia(int idMensagemTransferencia)
        {
            MensagemTransferencia tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.MensagemTransferencia.Select(x => x).Where(x => x.idMensagemTransferencia == idMensagemTransferencia).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/mensagemtransferencia", "GET", "/api/mensagemtransferencia", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ ALTERA O STATUS DA MENSAGEM
        public bool StatusMensagemTransferencia(MensagemTransferenciaStatus item, int pIDUserLogin)
        {
            bool bRetorno = false;
            try
            {
                MensagemTransferencia tabMsg = new MensagemTransferencia();
                //EGS Localiza o Status atual --------------------------------------------------------------------------------
                tabMsg = _contexto.Set<MensagemTransferencia>().Find(item.idMensagemTransferencia);

                //EGS Prepara Envio do Email mudança de Status ---------------------------------------------------------------
                TratamentoEnvioEmail _EnviarEmail = new TratamentoEnvioEmail();
                item.nrStatusOld = tabMsg.nrStatus;

                //EGS Grava a solicitacao em tabela para consultas futuras ---------------------------------------------------                
                MensagemTransHistorico tabelaHist = new MensagemTransHistorico();
                tabelaHist = new MensagemTransHistorico();
                tabelaHist.idMensagemTransferencia = item.idMensagemTransferencia;
                tabelaHist.ErroCodigo              = 888888;
                tabelaHist.ErroDescricao           = _EnviarEmail._EnviarEmail_Historico(item);
                InserirMensagemTransfHistorico(tabelaHist);

                //EGS Atualiza o Status do Monitoramento ---------------------------------------------------------------------
                tabMsg.nrStatus               = item.nrStatus;
                if (pIDUserLogin != 999999)  //Se for alteração do sistema, não grava usuario
                {
                tabMsg.IdUsuarioManutencao    = pIDUserLogin;
                tabMsg.DtUsuarioManutencao    = DateTime.Now;
                }
                _contexto.Entry(tabMsg).State = EntityState.Modified;
                _contexto.SaveChanges();

                //----------------------------------------------------------------------- CHAMA 
                if (item.nrStatus == 1)    //indo para DESBLOQUEADO
                {
                    EnviarWebServiceAutBankDesbloqueio(tabMsg);
                }

                //EGS Prepara Envio do Email mudança de Status ---------------------------------------------------------------
                string sEmailDestino, sEmailAssunto, sEmailConteudo = "";
                List<EmailAlerta> tabelaEmail = null;
                try
                {
                    //EGS Pega assunto e conteudo no envio de email
                    sEmailAssunto  = _EnviarEmail._EnviarEmail_Assunto(item);
                    sEmailConteudo = _EnviarEmail._EnviarEmail_Conteudo(item);

                    //EGS Traz todos os registros, com campo ATIVO=1
                    tabelaEmail = (from ifs in _contexto.EmailAlerta where (ifs.blnAtivo.Equals(true)) && (ifs.IdSistemaOrigem.Equals(5)) select ifs).ToList();
                    foreach (var ItemEmail in tabelaEmail)
                    {
                        sEmailDestino = ItemEmail.nmEmailAlerta.ToLower();
                        _EnviarEmail._EnviarEmail(sEmailDestino, sEmailAssunto, sEmailConteudo);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                //EGS Envio do Email -----------------------------------------------------------------------------------------
                //------------------------------------------------------------------------------------------------------------
                //------------------------------------------------------------------------------------------------------------
                bRetorno = true;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "StatusMensagemTransferencia", "POST", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("StatusMensagemTransferencia Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return bRetorno;

        }



        //------------------------------------------------------------------ EMAIL de ALERTA DA MENSAGEM
        public bool AlertaMensagemTransferencia(MensagemTransferenciaStatus item)
        {
            bool bRetorno = false;
            try
            {
                MensagemTransferencia tabMsg = new MensagemTransferencia();
                //EGS Localiza o Status atual --------------------------------------------------------------------------------
                tabMsg = _contexto.Set<MensagemTransferencia>().Find(item.idMensagemTransferencia);

                //EGS Prepara Envio do Email mudança de Status ---------------------------------------------------------------
                TratamentoEnvioEmail _EnviarEmail = new TratamentoEnvioEmail();
                item.nrStatusOld = tabMsg.nrStatus;

                //EGS Grava a solicitacao em tabela para consultas futuras ---------------------------------------------------                
                MensagemTransHistorico tabelaHist   = new MensagemTransHistorico();
                tabelaHist                          = new MensagemTransHistorico();
                tabelaHist.idMensagemTransferencia  = item.idMensagemTransferencia;
                tabelaHist.ErroCodigo               = 777777;
                tabelaHist.ErroDescricao            = "TED recebido e pela regra deve ser alertado";
                InserirMensagemTransfHistorico(tabelaHist);

                //EGS Prepara Envio do Email mudança de Status ---------------------------------------------------------------
                string sEmailDestino, sEmailAssunto, sEmailConteudo = "";
                List<EmailAlerta> tabelaEmail = null;
                try
                {
                    //EGS Pega assunto e conteudo no envio de email
                    sEmailAssunto  = _EnviarEmail._EnviarEmail_Assunto(item);
                    sEmailConteudo = _EnviarEmail._EnviarEmail_Conteudo(item);

                    //EGS Traz todos os registros, com campo ATIVO=1
                    tabelaEmail = (from ifs in _contexto.EmailAlerta where (ifs.blnAtivo.Equals(true)) && (ifs.IdSistemaOrigem.Equals(5)) select ifs).ToList();
                    foreach (var ItemEmail in tabelaEmail)
                    {
                        sEmailDestino = ItemEmail.nmEmailAlerta.ToLower();
                        _EnviarEmail._EnviarEmail(sEmailDestino, sEmailAssunto, sEmailConteudo);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                //EGS Envio do Email -----------------------------------------------------------------------------------------
                //------------------------------------------------------------------------------------------------------------
                //------------------------------------------------------------------------------------------------------------
                bRetorno = true;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlertaMensagemTransferencia", "POST", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("AlertaMensagemTransferencia Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return bRetorno;

        }



        //------------------------------------------------------------------ INSERT
        public MensagemTransferencia InserirMensagemTransferencia(MensagemTransferencia item, int pIDUserLogin)
        {
            try
            {
                //--------------------------------------------------------------------------------------- Grava dados do Debito
                InserirMensagemDebito(item.MensagemDebito, pIDUserLogin);
                //--------------------------------------------------------------------------------------- Grava dados do Debito
                InserirMensagemCredito(item.MensagemCredito, pIDUserLogin);


                //--------------------------------------------------------------------------------------- Grava dados da Mensagem Transferencia
                //--------------------------------------------------------------------------------------- Grava dados da Mensagem Transferencia
                item.idTipoMensagem     = item.TipoMensagem.idTipoMensagem;
                item.idMensagemDebito   = item.MensagemDebito.idMensagemDebito;
                item.idMensagemCredito  = item.MensagemCredito.idMensagemCredito;
                item.IdUsuarioInclusao  = pIDUserLogin;
                item.DtUsuarioInclusao  = DateTime.Now;
                item.nrStatus           = 9;                                 //0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada  9=Processando
                item.blnAtivo           = true;
                _contexto.Set<MensagemTransferencia>().Add(item);
                _contexto.SaveChanges();
                //-----------------------------------------------------------------------------------------------------------------------------
                    
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirMensagemTransferencia", "POST", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("InserirMensagemTransferencia Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ UPDATE
        public MensagemTransferencia AlterarMensagemTransferencia(MensagemTransferencia item, int pIDUserLogin)
        {
            try
            {
                if (pIDUserLogin != 999999)  //Se for alteração do sistema, não grava usuario
                {
                    item.IdUsuarioManutencao = pIDUserLogin;
                    item.DtUsuarioManutencao = DateTime.Now;                
                }
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarMensagemTransferencia", "PUT", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("AlterarMensagemTransferencia Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ INSERIR MENSAGEM DEBITO
        public void InserirMensagemDebito(MensagemDebito item, int pIDUserLogin)
        {
            try
            {
                InserirConta(item.ContaDebito, pIDUserLogin);
                item.idTipoOrigem              = item.TipoOrigem.idTipoOrigem;
                item.idContaDebito             = item.ContaDebito.idConta;
                item.ContaDebito.idChavePessoa = item.ContaDebito.Pessoa.CNPFCNPJ + "001";
                item.IdUsuarioInclusao         = pIDUserLogin;
                item.DtUsuarioInclusao         = DateTime.Now;
                _contexto.Set<MensagemDebito>().Add(item);
                _contexto.SaveChanges();                
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirMensagemDebito", "PUT", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("InserirMensagemDebito Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            //return item;
        }

        //------------------------------------------------------------------ INSERIR MENSAGEM CREDITO
        public MensagemCredito InserirMensagemCredito(MensagemCredito item, int pIDUserLogin)
        {
            try
            {
                InserirConta(item.ContaCredito, pIDUserLogin);
                item.idTipoDestino     = item.TipoDestino.idTipoDestino;
                item.idContaCredito    = item.ContaCredito.idConta;
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                _contexto.Set<MensagemCredito>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirMensagemCredito", "PUT", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("InserirMensagemCredito Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ INSERIR CONTA
        public Conta InserirConta(Conta item, int pIDUserLogin)
        {
            try
            {
                item.idInstituicaoFinanceira = item.InstituicaoFinanceira.idInstituicaoFinanceira;
                item.IdUsuarioInclusao       = pIDUserLogin;
                item.DtUsuarioInclusao       = DateTime.Now;
                _contexto.Set<Conta>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirConta", "PUT", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("InserirConta Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ INSERT de Historico da Mensagem
        public MensagemTransHistorico InserirMensagemTransfHistorico(MensagemTransHistorico item)
        {
            try
            {
                item.dtDataInclusao = DateTime.Now;
                _contexto.Set<MensagemTransHistorico>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirMensagemTransfHistorico", "PUT", "/api/mensagemtransferencia", ex.Message + " " + ex.InnerException.InnerException);
                _LogHlp._GravaLog("InserirMensagemTransfHistorico Erro: " + ex.Message + " " + ex.InnerException.InnerException);
                throw ex;
            }
            return item;
        }




        /*===========================================================================================================
        // Programa...:  EnviarWebServiceAutBank - Envia dados para webservice AutBank
        // Autor......:  Afonso Celso - Edinaldo Silva (IT Singular)
        // Data.......:  30.04.2018
        ===========================================================================================================*/
        private void EnviarWebServiceAutBankDesbloqueio(MensagemTransferencia pMsg)
        {
            MensagemTransHistorico tabelaHist   = new MensagemTransHistorico();
            tabelaHist                          = new MensagemTransHistorico();
            tabelaHist.idMensagemTransferencia  = pMsg.idMensagemTransferencia;
            TOIntegracaoRetornoTED requistaResp = new TOIntegracaoRetornoTED();
            try
            {
                EB_PadraoServicesLTService wsEBankDataService = new EB_PadraoServicesLTService();
                requistaResp         = new TOIntegracaoRetornoTED();
                requistaResp.codErro = 0;

                requistaResp = wsEBankDataService.requisitaTED("", pMsg.EventoCodigo, pMsg.HoraVencto, pMsg.Valor,
                                                           pMsg.MensagemDebito.ContaDebito.NumeroAgencia, pMsg.MensagemDebito.ContaDebito.NumeroConta,
                                                           pMsg.MensagemCredito.ContaCredito.NumeroBanco, pMsg.MensagemCredito.ContaCredito.NumeroAgencia,
                                                           pMsg.MensagemCredito.ContaCredito.NumeroConta, pMsg.MensagemCredito.TipoDestino.nmTipoConta,
                                                           "", "", "", "", pMsg.Finalidade, pMsg.Historico, "false",
                                                           "", "", "", "", "", "", "", "", "", pMsg.DataVencto, "", pMsg.Prioridade, "", "", "", pMsg.NroBoleto,
                                                           "", "", "", "", pMsg.ComplementoHistorico, pMsg.NumOrigem, "");

                //EGS Grava a solicitacao em tabela para consultas futuras ---------------------------------------------------                
                tabelaHist.ErroCodigo    = requistaResp.codErro;
                tabelaHist.ErroDescricao = "Mensagem [" + Convert.ToString(pMsg.idMensagemTransferencia) + "] do AutBank:: " + requistaResp.descricaoErro;
            }
            catch (Exception Ex)
            {
                Log.LoggerErroTransacao("", "", "EnviarWebServiceAutBankDesbloqueio", "PUT", "/api/mensagemtransferencia", Ex.Message + " " + Ex.InnerException.InnerException);
                _LogHlp._GravaLog("EnviarWebServiceAutBankDesbloqueio Erro: " + Ex.Message + " " + Ex.InnerException.InnerException);
                tabelaHist.ErroCodigo = 400;
                tabelaHist.ErroDescricao = "Erro ao Gravar Desbloqueio WS [" + Convert.ToString(pMsg.idMensagemTransferencia) + "] ao AutBank:: " + Ex.Message;
            }
            //------------------------------------------ Final do Webservice AutBank -----------------------------------------------------\\
            //------------------------------------------ Final do Webservice AutBank -----------------------------------------------------\\
            InserirMensagemTransfHistorico(tabelaHist);
        }
        

    }
}