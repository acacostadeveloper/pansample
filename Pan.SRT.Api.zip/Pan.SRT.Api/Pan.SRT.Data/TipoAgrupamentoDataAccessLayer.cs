﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class TipoAgrupamentoDataAccessLayer : ITipoAgrupamentoDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public TipoAgrupamentoDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<TipoAgrupamentoLista> ObterTipoAgrupamento(TipoAgrupamento item)
        {
            TipoAgrupamento itemTab = new TipoAgrupamento();
            if (item != null) { itemTab = item; }

            IEnumerable<TipoAgrupamentoLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1, e agora com usuario inclusao e manutencao 15.03.2018
                tabela = (from ifs           in _contexto.TipoAgrupamento
                          join _UsuaInc      in _contexto.Usuario on ifs.IdUsuarioInclusao   equals _UsuaInc.idUsuario
                          join _UsuaAlt      in _contexto.Usuario on ifs.IdUsuarioManutencao equals _UsuaAlt.idUsuario into tm
                                from subUser in tm.DefaultIfEmpty()
                                let UsuarioManutencao = subUser.nmUsuario
                          //where ifs.blnAtivo.Equals(true)      //True
                          where ((string.IsNullOrEmpty(itemTab.cdTipoAgrupamento)) || (ifs.cdTipoAgrupamento.Contains(itemTab.cdTipoAgrupamento)))
                          && ((string.IsNullOrEmpty(itemTab.nmDescricao)) || (ifs.nmDescricao.Contains(itemTab.nmDescricao)))

                          select new
                          {
                              idTipoAgrupamento       = ifs.idTipoAgrupamento,
                              cdTipoAgrupamento       = ifs.cdTipoAgrupamento,
                              nmDescricao             = ifs.nmDescricao,
                              IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                              UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0,16),
                              DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                              IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                              UsuarioManutencaoNome   = UsuarioManutencao.Substring(0,16),
                              DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                              blnAtivo                = ifs.blnAtivo
                          }).ToList().Select(x => new TipoAgrupamentoLista()
                          {
                              idTipoAgrupamento       = x.idTipoAgrupamento,
                              cdTipoAgrupamento       = x.cdTipoAgrupamento,
                              nmDescricao             = x.nmDescricao,
                              IdUsuarioInclusao       = x.IdUsuarioInclusao,
                              UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                              DtUsuarioInclusao       = x.DtUsuarioInclusao,
                              IdUsuarioManutencao     = x.IdUsuarioManutencao,
                              UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                              DtUsuarioManutencao     = x.DtUsuarioManutencao,
                              blnAtivo                = x.blnAtivo
                          }).ToList().OrderByDescending(x=> x.DtUsuarioManutencao);

            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "GET", "/api/tipoagrupamento", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por ID
        public TipoAgrupamento ObterTipoAgrupamento(int pID)
        {
            TipoAgrupamento tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoAgrupamento.Select(x => x).Where(x => x.idTipoAgrupamento == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "GET", "/api/tipoagrupamento", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public TipoAgrupamento ObterTipoAgrupamento(string pTexto)
        {
            TipoAgrupamento tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoAgrupamento.Select(x => x).Where(x => x.nmDescricao == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipoagrupamento", "GET", "/api/tipoagrupamento", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public TipoAgrupamento InserirTipoAgrupamento(TipoAgrupamento item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<TipoAgrupamento>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirTipoAgrupamento", "POST", "/api/tipoagrupamento", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public TipoAgrupamento AlterarTipoAgrupamento(TipoAgrupamento item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarTipoAgrupamento", "PUT", "/api/tipoagrupamento", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public TipoAgrupamento InativarTipoAgrupamento(int idTipoAgrupamento, int pIDUserLogin)
        {
            TipoAgrupamento tabela = null;
            try
            {
                TipoAgrupamento user     = _contexto.Set<TipoAgrupamento>().Single(x => x.idTipoAgrupamento == idTipoAgrupamento);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<TipoAgrupamento>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarTipoAgrupamento", "DEL", "/api/tipoagrupamento", ex.Message);
                throw ex;
            }

            return tabela;
        }

    }
}