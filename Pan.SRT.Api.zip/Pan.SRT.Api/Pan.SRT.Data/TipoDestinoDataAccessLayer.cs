﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class TipoDestinoDataAccessLayer : ITipoDestinoDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public TipoDestinoDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<TipoDestinoLista> ObterTipoDestino(TipoDestino item)
        {
            TipoDestino itemTab = new TipoDestino();
            if (item != null) { itemTab = item; }
            IEnumerable<TipoDestinoLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (
                    from ifs in _contexto.TipoDestino
                    join _UsuaInc in _contexto.Usuario       on ifs.IdUsuarioInclusao    equals _UsuaInc.idUsuario
                    join _UsuaAlt in _contexto.Usuario       on ifs.IdUsuarioManutencao  equals _UsuaAlt.idUsuario into tm
                    from subUser  in tm.DefaultIfEmpty()
                    let UsuarioManutencao = subUser.nmUsuario
                    //where ifs.blnAtivo.Equals(true)
                    where ((string.IsNullOrEmpty(itemTab.nmDestino)) || (ifs.nmDestino.Contains(itemTab.nmDestino)))
                    && ((string.IsNullOrEmpty(itemTab.nmTipoConta)) || (ifs.nmTipoConta.Contains(itemTab.nmTipoConta)))
                    && ((string.IsNullOrEmpty(itemTab.nmTipoPessoa)) || (ifs.nmTipoPessoa.Contains(itemTab.nmTipoPessoa)))

                    select new
                    {
                        idTipoDestino           = ifs.idTipoDestino,
                        nmDestino               = ifs.nmDestino,
                        nmTipoConta             = ifs.nmTipoConta,
                        nmTipoPessoa            = ifs.nmTipoPessoa,
                        blnPossuiContaDigital   = ifs.blnPossuiContaDigital,
                        IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                        blnAtivo                = ifs.blnAtivo
                    }).ToList().Select(x => new TipoDestinoLista()
                    {
                        idTipoDestino           = x.idTipoDestino,
                        nmDestino               = x.nmDestino,
                        nmTipoConta             = x.nmTipoConta,
                        nmTipoPessoa            = x.nmTipoPessoa,
                        blnPossuiContaDigital   = x.blnPossuiContaDigital,
                        IdUsuarioInclusao       = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao       = x.DtUsuarioInclusao,
                        IdUsuarioManutencao     = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao     = x.DtUsuarioManutencao,
                        blnAtivo                = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);



            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "GET", "/api/tipodestino", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por ID
        public TipoDestino ObterTipoDestino(int pID)
        {
            TipoDestino tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoDestino.Select(x => x).Where(x => x.idTipoDestino == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "GET", "/api/tipodestino", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public TipoDestino ObterTipoDestino(string pTexto)
        {
            TipoDestino tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoDestino.Select(x => x).Where(x => x.nmDestino == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipodestino", "GET", "/api/tipodestino", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public TipoDestino InserirTipoDestino(TipoDestino item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<TipoDestino>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirTipoDestino", "POST", "/api/tipodestino", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public TipoDestino AlterarTipoDestino(TipoDestino item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarTipoDestino", "PUT", "/api/tipodestino", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public TipoDestino InativarTipoDestino(int idTipoDestino, int pIDUserLogin)
        {
            TipoDestino tabela = null;

            try
            {
                TipoDestino user         = _contexto.Set<TipoDestino>().Single(x => x.idTipoDestino == idTipoDestino);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<TipoDestino>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarTipoDestino", "DEL", "/api/tipodestino", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}