﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class TipoOperadorDataAccessLayer : ITipoOperadorDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public TipoOperadorDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<TipoOperadorLista> ObterTipoOperador(TipoOperador item)
        {
            TipoOperador itemTab = new TipoOperador();
            if (item != null) { itemTab = item; }

            IEnumerable<TipoOperadorLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (
                    from ifs       in _contexto.TipoOperador
                    join _UsuaInc  in _contexto.Usuario       on ifs.IdUsuarioInclusao    equals _UsuaInc.idUsuario
                    join _UsuaAlt  in _contexto.Usuario       on ifs.IdUsuarioManutencao  equals _UsuaAlt.idUsuario into tm
                    from subUser   in tm.DefaultIfEmpty()
                    let UsuarioManutencao = subUser.nmUsuario
                    //where ifs.blnAtivo.Equals(true)      //True
                    where ((string.IsNullOrEmpty(itemTab.cdTipoOperador)) || (ifs.cdTipoOperador.Contains(itemTab.cdTipoOperador)))
                    && ((string.IsNullOrEmpty(itemTab.nmDescricao)) || (ifs.nmDescricao.Contains(itemTab.nmDescricao)))

                    select new
                    {
                        idTipoOperador          = ifs.idTipoOperador,
                        cdTipoOperador          = ifs.cdTipoOperador,
                        nmDescricao             = ifs.nmDescricao,
                        IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                        blnAtivo                = ifs.blnAtivo
                    }).ToList().Select(x => new TipoOperadorLista()
                    {
                        idTipoOperador          = x.idTipoOperador,
                        cdTipoOperador          = x.cdTipoOperador,
                        nmDescricao             = x.nmDescricao,
                        IdUsuarioInclusao       = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao       = x.DtUsuarioInclusao,
                        IdUsuarioManutencao     = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao     = x.DtUsuarioManutencao,
                        blnAtivo                = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "GET", "/api/tipooperador", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por ID
        public TipoOperador ObterTipoOperadorID(int pID)
        {
            TipoOperador tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoOperador.Select(x => x).Where(x => x.idTipoOperador == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "GET", "/api/tipooperador", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public TipoOperador ObterTipoOperadorTx(string pTexto)
        {
            TipoOperador tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.TipoOperador.Select(x => x).Where(x => x.cdTipoOperador == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/tipooperador", "GET", "/api/tipooperador", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ INSERT
        public TipoOperador InserirTipoOperador(TipoOperador item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<TipoOperador>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirTipoOperador", "POST", "/api/tipooperador", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public TipoOperador AlterarTipoOperador(TipoOperador item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarTipoOperador", "PUT", "/api/tipooperador", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public TipoOperador InativarTipoOperador(int idTipoOperador, int pIDUserLogin)
        {
            TipoOperador tabela = null;

            try
            {
                TipoOperador user        = _contexto.Set<TipoOperador>().Single(x => x.idTipoOperador == idTipoOperador);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<TipoOperador>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarTipoOperador", "DEL", "/api/tipooperador", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}