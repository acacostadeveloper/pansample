﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class RegraValidacaoDataAccessLayer : IRegraValidacaoDataAccessLayer
    {

        private PanRestritivosContext _contexto;

        public RegraValidacaoDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<RegraValidacaoLista> ObterRegraValidacao(RegraValidacao item)
        {
            RegraValidacao itemTab = new RegraValidacao();
            if (item != null) { itemTab = item; }

            IEnumerable<RegraValidacaoLista> tabela = null;
            try
            {

                //EGS Traz todos os registros, com campo ATIVO=1, e agora com usuario inclusao e manutencao 16.03.2018
                var temp = (from _Regras         in _contexto.RegraValidacao
                                 join _UsuaInc   in _contexto.Usuario on _Regras.IdUsuarioInclusao   equals _UsuaInc.idUsuario
                                 join _UsuaAlt   in _contexto.Usuario on _Regras.IdUsuarioManutencao equals _UsuaAlt.idUsuario into tm
                                 from subUser    in tm.DefaultIfEmpty()
                                 let UsuarioManutencao = subUser.nmUsuario
                            where     ((itemTab.blnAtivo      == false               ) || (_Regras.blnAtivo == true))
                            && ((string.IsNullOrEmpty(itemTab.nmDescricao)) || (_Regras.nmDescricao.Contains(itemTab.nmDescricao)))
                            && ((itemTab.nrCriticidade == 0) || (_Regras.nrCriticidade.Equals(itemTab.nrCriticidade)))
                            && ((string.IsNullOrEmpty(itemTab.nmConsequencia)) || (_Regras.nmConsequencia.Contains(itemTab.nmConsequencia)))
                                 orderby _Regras.nrCriticidade descending    //EGS 30.04.2018 Pegar primeiro as regras com maior criticidade ao validar
                            select new
                            {
                                idRegraValidacao      = _Regras.idRegraValidacao,
                                nmDescricao           = _Regras.nmDescricao,
                                nmConsequencia        = _Regras.nmConsequencia,
                                nrCriticidade         = _Regras.nrCriticidade,
                                IdUsuarioInclusao     = _Regras.IdUsuarioInclusao,
                                UsuarioInclusaoNome   = _UsuaInc.nmUsuario,
                                DtUsuarioInclusao     = _Regras.DtUsuarioInclusao,
                                IdUsuarioManutencao   = _Regras.IdUsuarioManutencao,
                                UsuarioManutencaoNome = UsuarioManutencao,
                                DtUsuarioManutencao   = _Regras.DtUsuarioManutencao,
                                blnAtivo              = _Regras.blnAtivo

                            }).ToList().Select(x => new RegraValidacaoLista()
                            {

                                idRegraValidacao        = x.idRegraValidacao,
                                nmDescricao             = x.nmDescricao,
                                nmConsequencia          = x.nmConsequencia,
                                nrCriticidade           = x.nrCriticidade,
                                IdUsuarioInclusao       = x.IdUsuarioInclusao,
                                UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                                DtUsuarioInclusao       = x.DtUsuarioInclusao,
                                IdUsuarioManutencao     = x.IdUsuarioManutencao,
                                UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                                DtUsuarioManutencao     = x.DtUsuarioManutencao,
                                blnAtivo                = x.blnAtivo,


                                RegraClausulas = (from _Clausula      in _contexto.RegraValidaClausula
                                                  join _Exta          in _contexto.EntidadeAtributo    on _Clausula.idEntidadeAtributo    equals _Exta.idEntidadeAtributo
                                                  join _Ente          in _contexto.Entidade            on _Clausula.idEntidade            equals _Ente.idEntidade
                                                  join _Peri          in _contexto.PeriodoAgrupamento  on _Clausula.idPeriodoAgrupamento  equals _Peri.idPeriodoAgrupamento
                                                  join _Tipo          in _contexto.TipoAgrupamento     on _Clausula.idTipoAgrupamento     equals _Tipo.idTipoAgrupamento
                                                  join _Oper          in _contexto.TipoOperador        on _Clausula.idTipoOperador        equals _Oper.idTipoOperador
                                                  //where _Clausula.blnAtivo.Equals(true) 
                                                  where _Clausula.idRegraValidacao.Equals(x.idRegraValidacao)
                                                  select new
                                                   {
                                                       idRegraValidaClausula       = _Clausula.idRegraValidaClausula,
                                                       idRegraValidacao            = _Clausula.idRegraValidacao,
                                                       idEntidade                  = _Clausula.idEntidade,
                                                       EntidadeDescricao           = _Ente.cdEntidade,
                                                       idEntidadeAtributo          = _Clausula.idEntidadeAtributo,
                                                       EntidadeAtributoDescricao   = _Exta.cdAtributo,
                                                       EntidadeAtributoTipo        = _Exta.cdAtributoTipo,
                                                       idTipoOperador              = _Clausula.idTipoOperador,
                                                       TipoOperadorCodigo          = _Oper.cdTipoOperador,
                                                       idPeriodoAgrupamento        = _Clausula.idPeriodoAgrupamento,
                                                       PeriodoAgrupamentoDescricao = _Peri.nmDescricao,
                                                       idTipoAgrupamento           = _Clausula.idTipoAgrupamento,
                                                       TipoAgrupamentoDescricao    = _Tipo.nmDescricao,
                                                       nrValor                     = _Clausula.nrValor,
                                                       IdUsuarioInclusao           = _Clausula.IdUsuarioInclusao,
                                                       DtUsuarioInclusao           = _Clausula.DtUsuarioInclusao,
                                                       IdUsuarioManutencao         = _Clausula.IdUsuarioManutencao,
                                                       DtUsuarioManutencao         = _Clausula.DtUsuarioManutencao, 
                                                       blnAtivo                    = _Clausula.blnAtivo,

                                                   }).ToList().Select(y => new RegraValidaClausulaLista()
                                                   {
                                                       idRegraValidaClausula       = y.idRegraValidaClausula,
                                                       idRegraValidacao            = y.idRegraValidacao,
                                                       idEntidade                  = y.idEntidade,
                                                       EntidadeDescricao           = y.EntidadeDescricao,
                                                       idEntidadeAtributo          = y.idEntidadeAtributo,
                                                       EntidadeAtributoDescricao   = y.EntidadeAtributoDescricao,
                                                       EntidadeAtributoTipo        = y.EntidadeAtributoTipo,
                                                       idTipoOperador              = y.idTipoOperador,
                                                       TipoOperadorCodigo          = y.TipoOperadorCodigo,
                                                       idPeriodoAgrupamento        = y.idPeriodoAgrupamento,
                                                       PeriodoAgrupamentoDescricao = y.PeriodoAgrupamentoDescricao,
                                                       idTipoAgrupamento           = y.idTipoAgrupamento,
                                                       TipoAgrupamentoDescricao    = y.TipoAgrupamentoDescricao,
                                                       nrValor                     = y.nrValor,
                                                       IdUsuarioInclusao           = y.IdUsuarioInclusao,
                                                       DtUsuarioInclusao           = y.DtUsuarioInclusao,
                                                       IdUsuarioManutencao         = y.IdUsuarioManutencao,
                                                       DtUsuarioManutencao         = y.DtUsuarioManutencao,
                                                       blnAtivo                    = y.blnAtivo
                                                   }).ToList()
                            });

                tabela = temp.ToList();

            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return tabela;
        }



        //------------------------------------------------------------------ LISTAR por ID
        public RegraValidacao ObterRegraValidacao(int pID)
        {
            RegraValidacao tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.RegraValidacao.Select(x => x).Where(x => x.idRegraValidacao == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public RegraValidacao ObterRegraValidacao(string pTexto)
        {
            RegraValidacao tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.RegraValidacao.Select(x => x).Where(x => x.nmDescricao == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/regravalidacao", "GET", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return tabela;
        }



        //------------------------------------------------------------------ INSERT
        public RegraValidacao InserirRegraValidacao(RegraValidacao item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<RegraValidacao>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirRegraValidacao", "POST", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public RegraValidacao AlterarRegraValidacao(RegraValidacao item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarRegraValidacao", "PUT", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public RegraValidacao InativarRegraValidacao(int idRegraValidacao, bool pAtivar, int pIDUserLogin)
        {
            RegraValidacao tabela = null;
            try
            {
                RegraValidacao user      = _contexto.Set<RegraValidacao>().Single(x => x.idRegraValidacao == idRegraValidacao);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                //EGS 22.01.2018 - IT Singular, mesmo metodo de ATIVAR/DESATIVAR, se tiver ativado, desativa, e versa e vice
                if (user.blnAtivo == true)
                {
                    //EGS 30.06.2018 - Se estiver ativo e pedir para inativar, então faz, caso contrário não faz nada
                    if (pAtivar == false)
                    {
                        user.blnAtivo = false;
                    }
                }
                else
                {
                    //EGS 30.06.2018 - Se estiver inativo e pedir para ativar, então faz, caso contrário não faz nada
                    if (pAtivar == true)
                    {
                        user.blnAtivo = true;
                    }
                }
                var temp = _contexto.Entry<RegraValidacao>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarRegraValidacao", "DEL", "/api/regravalidacao", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}