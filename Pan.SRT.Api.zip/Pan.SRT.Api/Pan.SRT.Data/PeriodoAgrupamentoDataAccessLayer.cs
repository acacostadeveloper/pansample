﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class PeriodoAgrupamentoDataAccessLayer : IPeriodoAgrupamentoDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public PeriodoAgrupamentoDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<PeriodoAgrupamentoLista> ObterPeriodoAgrupamento(PeriodoAgrupamento item)
        {
            PeriodoAgrupamento itemTab = new PeriodoAgrupamento();
            if (item != null) { itemTab = item; }

            IEnumerable<PeriodoAgrupamentoLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (from ifs in _contexto.PeriodoAgrupamento
                          join _UsuaInc in _contexto.Usuario on ifs.IdUsuarioInclusao   equals _UsuaInc.idUsuario
                          join _UsuaAlt in _contexto.Usuario on ifs.IdUsuarioManutencao equals _UsuaAlt.idUsuario into tm
                          from subUser in tm.DefaultIfEmpty()
                          let UsuarioManutencao = subUser.nmUsuario
                          //where ifs.blnAtivo.Equals(true)      //True
                          where ((string.IsNullOrEmpty(itemTab.cdPeriodoAgrupamento)) || (ifs.cdPeriodoAgrupamento.Contains(itemTab.cdPeriodoAgrupamento)))
                          && ((string.IsNullOrEmpty(itemTab.nmDescricao)) || (ifs.nmDescricao.Contains(itemTab.nmDescricao)))
                          select new
                          {
                              idPeriodoAgrupamento     = ifs.idPeriodoAgrupamento,
                              cdPeriodoAgrupamento     = ifs.cdPeriodoAgrupamento,
                              nmDescricao              = ifs.nmDescricao,
                              nrTempoMinuto            = ifs.nrTempoMinuto,
                              IdUsuarioInclusao        = ifs.IdUsuarioInclusao,
                              UsuarioInclusaoNome      = _UsuaInc.nmUsuario.Substring(0, 16),
                              DtUsuarioInclusao        = ifs.DtUsuarioInclusao,
                              IdUsuarioManutencao      = ifs.IdUsuarioManutencao,
                              UsuarioManutencaoNome    = UsuarioManutencao.Substring(0, 16),
                              DtUsuarioManutencao      = ifs.DtUsuarioManutencao,
                              blnAtivo                 = ifs.blnAtivo
                          }).ToList().Select(x => new PeriodoAgrupamentoLista()
                          {
                              idPeriodoAgrupamento     = x.idPeriodoAgrupamento,
                              cdPeriodoAgrupamento     = x.cdPeriodoAgrupamento,
                              nmDescricao              = x.nmDescricao,
                              nrTempoMinuto            = x.nrTempoMinuto,
                              IdUsuarioInclusao        = x.IdUsuarioInclusao,
                              UsuarioInclusaoNome      = x.UsuarioInclusaoNome,
                              DtUsuarioInclusao        = x.DtUsuarioInclusao,
                              IdUsuarioManutencao      = x.IdUsuarioManutencao,
                              UsuarioManutencaoNome    = x.UsuarioManutencaoNome,
                              DtUsuarioManutencao      = x.DtUsuarioManutencao,
                              blnAtivo                 = x.blnAtivo
                          }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "GET", "/api/periodoagrupamento", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR por ID
        public PeriodoAgrupamento ObterPeriodoAgrupamento(int pID)
        {
            PeriodoAgrupamento tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.PeriodoAgrupamento.Select(x => x).Where(x => x.idPeriodoAgrupamento == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "GET", "/api/periodoagrupamento", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public PeriodoAgrupamento ObterPeriodoAgrupamento(string pTexto)
        {
            PeriodoAgrupamento tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.PeriodoAgrupamento.Select(x => x).Where(x => x.nmDescricao == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/periodoagrupamento", "GET", "/api/periodoagrupamento", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ INSERT
        public PeriodoAgrupamento InserirPeriodoAgrupamento(PeriodoAgrupamento item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<PeriodoAgrupamento>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirPeriodoAgrupamento", "POST", "/api/periodoagrupamento", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public PeriodoAgrupamento AlterarPeriodoAgrupamento(PeriodoAgrupamento item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarPeriodoAgrupamento", "PUT", "/api/periodoagrupamento", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public PeriodoAgrupamento InativarPeriodoAgrupamento(int idPeriodoAgrupamento, int pIDUserLogin)
        {
            PeriodoAgrupamento tabela = null;
            try
            {
                PeriodoAgrupamento user  = _contexto.Set<PeriodoAgrupamento>().Single(x => x.idPeriodoAgrupamento == idPeriodoAgrupamento);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<PeriodoAgrupamento>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarPeriodoAgrupamento", "DEL", "/api/periodoagrupamento", ex.Message);
                throw ex;
            }

            return tabela;
        }

    }
}