﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Helpers;


namespace Pan.SRT.Data
{
    public class AlcadaDataAccessLayer : IAlcadaDataAccessLayer
    {
        private PanRestritivosContext _contexto;
        private GravaLogHelp _LogHlp = new GravaLogHelp();

        public AlcadaDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<AlcadaLista> ObterAlcada(Alcada item)
        {
            Alcada itemTab = new Alcada();
            if (item != null) { itemTab = item; }

            IEnumerable<AlcadaLista> tabela = null;
            try
            {
                tabela = (
                    from ifs      in _contexto.Alcada
                    join _Usua    in _contexto.Usuario       on ifs.idUsuario            equals _Usua.idUsuario
                    join _Sist    in _contexto.SistemaOrigem on ifs.IdSistemaOrigem      equals _Sist.IdSistemaOrigem
                    join _UsuaInc in _contexto.Usuario       on ifs.IdUsuarioInclusao    equals _UsuaInc.idUsuario
                    join _UsuaAlt in _contexto.Usuario       on ifs.IdUsuarioManutencao  equals _UsuaAlt.idUsuario into tm
                    from subUser  in tm.DefaultIfEmpty()
                    let UsuarioManutencao = subUser.nmUsuario
                    //where ifs.blnAtivo.Equals(true)      //True
                    where ((string.IsNullOrEmpty(itemTab.cdAlcada)) || (ifs.cdAlcada.Contains(itemTab.cdAlcada)))
                    && ((string.IsNullOrEmpty(itemTab.nmDescricao)) || (ifs.nmDescricao.Contains(itemTab.nmDescricao)))

                    select new
                    {
                        idAlcada                = ifs.idAlcada,
                        cdAlcada                = ifs.cdAlcada,
                        nmDescricao             = ifs.nmDescricao,
                        idUsuario               = ifs.idUsuario,
                        UsuarioNome             = _Usua.nmUsuario.Substring(0, 16),
                        IdSistemaOrigem         = ifs.IdSistemaOrigem,
                        SistemaOrigem           = _Sist.cdSistemaOrigem,
                        nrNivel                 = ifs.nrNivel,
                        IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                        blnAtivo                = ifs.blnAtivo
                    }).ToList().Select(x => new AlcadaLista()
                    {
                        idAlcada                = x.idAlcada,
                        cdAlcada                = x.cdAlcada,
                        nmDescricao             = x.nmDescricao,
                        idUsuario               = x.idUsuario,
                        UsuarioNome             = x.UsuarioNome,
                        IdSistemaOrigem         = x.IdSistemaOrigem,
                        SistemaOrigem           = x.SistemaOrigem,
                        nrNivel                 = x.nrNivel,
                        IdUsuarioInclusao       = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao       = x.DtUsuarioInclusao,
                        IdUsuarioManutencao     = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao     = x.DtUsuarioManutencao,
                        blnAtivo                = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Alcada DATA GET - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "/api/alcada", "GET", "/api/alcada", ex.Message + " " + ex.InnerException);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR POR ID
        public Alcada ObterAlcada(int pID)
        {
            Alcada tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.Alcada.Select(x => x).Where(x => x.idAlcada == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "GET_ID", "/api/alcada", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ LISTAR POR NOME
        public Alcada ObterAlcada(string pTexto)
        {
            Alcada tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.Alcada.Select(x => x).Where(x => x.nmDescricao == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/alcada", "GET)TX", "/api/alcada", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public Alcada InserirAlcada(Alcada item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<Alcada>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Alcada DATA Incluir - Erro: " + ex.Message + " " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "InserirAlcada", "POST", "/api/alcada", ex.Message + " " + ex.InnerException);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public Alcada AlterarAlcada(Alcada item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Alcada DATA Alterar - Erro: " + ex.Message);
                _LogHlp._GravaLog("Alcada DATA Alterar - Erro: " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "AlterarAlcada", "PUT", "/api/alcada", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public Alcada InativarAlcada(int idAlcada, int pIDUserLogin)
        {
            Alcada tabela = null;
            try
            {
                Alcada user = _contexto.Set<Alcada>().Single(x => x.idAlcada == idAlcada);
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<Alcada>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Alcada DATA Excluir - Erro: " + ex.Message);
                _LogHlp._GravaLog("Alcada DATA Excluir - Erro: " + ex.InnerException);
                Log.LoggerErroTransacao("", "", "InativarAlcada", "DEL", "/api/alcada", ex.Message);
                throw ex;
            }
            return tabela;
        }
    }
}