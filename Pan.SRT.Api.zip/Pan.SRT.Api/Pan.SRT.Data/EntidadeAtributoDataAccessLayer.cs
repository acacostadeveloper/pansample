﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class EntidadeAtributoDataAccessLayer : IEntidadeAtributoDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public EntidadeAtributoDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<EntidadeAtributoLista> ObterEntidadeAtributo(EntidadeAtributo item)
        {
            EntidadeAtributo itemTab = new EntidadeAtributo();
            if (item != null) { itemTab = item; }

            IEnumerable<EntidadeAtributoLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (from ifs       in _contexto.EntidadeAtributo
                          join _Externa  in _contexto.Entidade on ifs.idEntidade          equals _Externa.idEntidade
                          join _UsuaInc  in _contexto.Usuario  on ifs.IdUsuarioInclusao   equals _UsuaInc.idUsuario
                          join _UsuaAlt  in _contexto.Usuario  on ifs.IdUsuarioManutencao equals _UsuaAlt.idUsuario into tm
                          from subUser   in tm.DefaultIfEmpty()
                          let UsuarioManutencao = subUser.nmUsuario
                          //where ifs.blnAtivo.Equals(true)      //True
                          where ((itemTab.idEntidade == 0) || (ifs.idEntidade.Equals(itemTab.idEntidade)))
                          && ((string.IsNullOrEmpty(itemTab.cdAtributo)) || (ifs.cdAtributo.Contains(itemTab.cdAtributo)))
                          && ((string.IsNullOrEmpty(itemTab.nmAtributo)) || (ifs.nmAtributo.Contains(itemTab.nmAtributo)))

                          select new
                          {
                              idEntidadeAtributo      = ifs.idEntidadeAtributo,
                              idEntidade              = ifs.idEntidade,
                              nmEntidade              = _Externa.nmEntidade,
                              nmAtributo              = ifs.nmAtributo,
                              cdAtributo              = ifs.cdAtributo,
                              cdAtributoTipo          = ifs.cdAtributoTipo,
                              IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                              UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                              DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                              IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                              UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                              DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                              blnAtivo                = ifs.blnAtivo
                          }).ToList().Select(x => new EntidadeAtributoLista()
                          {
                              idEntidadeAtributo      = x.idEntidadeAtributo,
                              idEntidade              = x.idEntidade,
                              nmEntidade              = x.nmEntidade,
                              cdAtributo              = x.cdAtributo,
                              cdAtributoTipo          = x.cdAtributoTipo,
                              nmAtributo              = x.nmAtributo,
                              IdUsuarioInclusao       = x.IdUsuarioInclusao,
                              UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                              DtUsuarioInclusao       = x.DtUsuarioInclusao,
                              IdUsuarioManutencao     = x.IdUsuarioManutencao,
                              UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                              DtUsuarioManutencao     = x.DtUsuarioManutencao,
                              blnAtivo                = x.blnAtivo
                          }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);

            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "GET", "/api/entidadeatributo", ex.Message);
                throw ex;
            }
            return tabela;
        }



        //------------------------------------------------------------------ LISTAR POR ID
        public EntidadeAtributo ObterEntidadeAtributo(int pID)
        {
            EntidadeAtributo tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.EntidadeAtributo.Select(x => x).Where(x => x.idEntidadeAtributo == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "GET_ID", "/api/entidadeatributo", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR POR ID
        public EntidadeAtributo ObterEntidadeAtributo(string pTexto)
        {
            EntidadeAtributo tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.EntidadeAtributo.Select(x => x).Where(x => x.nmAtributo == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/entidadeatributo", "GET_tx", "/api/entidadeatributo", ex.Message);
                throw ex;
            }
            return tabela;
        }

        //------------------------------------------------------------------ INSERT
        public EntidadeAtributo InserirEntidadeAtributo(EntidadeAtributo item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<EntidadeAtributo>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirEntidadeAtributo", "POST", "/api/entidadeatributo", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public EntidadeAtributo AlterarEntidadeAtributo(EntidadeAtributo item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao = pIDUserLogin;
                item.DtUsuarioManutencao = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarEntidadeAtributo", "PUT", "/api/entidadeatributo", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public EntidadeAtributo InativarEntidadeAtributo(int idEntidadeAtributo, int pIDUserLogin)
        {
            EntidadeAtributo tabela = null;
            try
            {
                EntidadeAtributo user    = _contexto.Set<EntidadeAtributo>().Single(x => x.idEntidadeAtributo == idEntidadeAtributo);
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<EntidadeAtributo>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarEntidadeAtributo", "DEL", "/api/entidadeatributo", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}