﻿namespace Pan.SRT.Data.Interface
{
    public interface IPanRestritivosRepositorio
    {
    }
}
