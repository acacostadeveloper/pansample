﻿using Pan.SRT.Data.Context;
using Pan.SRT.Data.Interface;

namespace Pan.SRT.Data
{
    public class PanRestritivosRepositorio : IPanRestritivosRepositorio 
    {
        private PanRestritivosContext   _contexto;

        public PanRestritivosRepositorio()
        {
            _contexto    = new PanRestritivosContext  ();
        }
    }
}
