﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class ListaBrancaDataAccessLayer : IListaBrancaDataAccessLayer
    {
        private PanRestritivosContext _contexto;

        public ListaBrancaDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }

        //------------------------------------------------------------------ LISTAR
        public IEnumerable<ListaBrancaLista> ObterListaBranca(ListaBranca item)
        {
            ListaBranca itemTab = new ListaBranca();
            if (item != null) { itemTab = item; }

            IEnumerable<ListaBrancaLista> tabela = null;
            try
            {
                //EGS Traz todos os registros, com campo ATIVO=1
                tabela = (
                    from ifs in _contexto.ListaBranca
                    join _UsuaInc in _contexto.Usuario       on ifs.IdUsuarioInclusao    equals _UsuaInc.idUsuario
                    join _UsuaAlt in _contexto.Usuario       on ifs.IdUsuarioManutencao  equals _UsuaAlt.idUsuario into tm
                    from subUser  in tm.DefaultIfEmpty()
                    let UsuarioManutencao = subUser.nmUsuario
                    //where ifs.blnAtivo.Equals(true)      //True
                    where ((string.IsNullOrEmpty(itemTab.nrCNPJ)) || (ifs.nrCNPJ.Contains(itemTab.nrCNPJ)))
                    && ((string.IsNullOrEmpty(itemTab.nmListaBranca)) || (ifs.nmListaBranca.Contains(itemTab.nmListaBranca)))
                    && ((itemTab.nrBanco == 0) || (ifs.nrBanco.Equals(itemTab.nrBanco)))
                    && ((itemTab.nrAgencia == 0) || (ifs.nrAgencia.Equals(itemTab.nrAgencia)))
                    && ((itemTab.nrConta == 0) || (ifs.nrConta.ToString().Contains(itemTab.nrConta.ToString())))
                    select new
                    {
                        idListaBranca           = ifs.idListaBranca,
                        nmListaBranca           = ifs.nmListaBranca,
                        nrAgencia               = ifs.nrAgencia,
                        nrBanco                 = ifs.nrBanco,
                        nrConta                 = ifs.nrConta,
                        nrContaDigito           = ifs.nrContaDigito,
                        nrCNPJ                  = ifs.nrCNPJ,
                        IdUsuarioInclusao       = ifs.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = _UsuaInc.nmUsuario.Substring(0, 16),
                        DtUsuarioInclusao       = ifs.DtUsuarioInclusao,
                        IdUsuarioManutencao     = ifs.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = UsuarioManutencao.Substring(0, 16),
                        DtUsuarioManutencao     = ifs.DtUsuarioManutencao,
                        blnAtivo                = ifs.blnAtivo
                    }).ToList().Select(x => new ListaBrancaLista()
                    {
                        idListaBranca           = x.idListaBranca,
                        nmListaBranca           = x.nmListaBranca,
                        nrAgencia               = x.nrAgencia,
                        nrBanco                 = x.nrBanco,
                        nrConta                 = x.nrConta,
                        nrContaDigito           = x.nrContaDigito,
                        nrCNPJ                  = x.nrCNPJ,
                        IdUsuarioInclusao       = x.IdUsuarioInclusao,
                        UsuarioInclusaoNome     = x.UsuarioInclusaoNome,
                        DtUsuarioInclusao       = x.DtUsuarioInclusao,
                        IdUsuarioManutencao     = x.IdUsuarioManutencao,
                        UsuarioManutencaoNome   = x.UsuarioManutencaoNome,
                        DtUsuarioManutencao     = x.DtUsuarioManutencao,
                        blnAtivo                = x.blnAtivo
                    }).ToList().OrderByDescending(x => x.DtUsuarioManutencao);
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "GET", "/api/listabranca", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR por ID
        public ListaBranca ObterListaBranca(int pID)
        {
            ListaBranca tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.ListaBranca.Select(x => x).Where(x => x.idListaBranca == pID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "GET", "/api/listabranca", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ LISTAR por DESCRICAO
        public ListaBranca ObterListaBranca(string pTexto)
        {
            ListaBranca tabela = null;
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                tabela = _contexto.ListaBranca.Select(x => x).Where(x => x.nmListaBranca == pTexto).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/listabranca", "GET", "/api/listabranca", ex.Message);
                throw ex;
            }
            return tabela;
        }


        //------------------------------------------------------------------ PESQUISA por CNPJ
        public bool PesquisaListaBranca(string pCNPJ)
        {
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                if (_contexto.ListaBranca.Select(x => x).Where(x => x.nrCNPJ == pCNPJ).FirstOrDefault() == null)
                {
                    return true;
                };
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/PesquisaListaBranca", "GET", "/api/PesquisaListaBranca", ex.Message);
                throw ex;
            }
            return false;
        }


        //------------------------------------------------------------------ PESQUISA por CONTA  30.06.2018
        public bool PesqContaListaBranca(int pBanco, int pConta, int pAgencia)
        {
            try
            {
                //EGS Traz somente um registro, com campo ATIVO=1, mas não lista, somente um registro
                if (_contexto.ListaBranca.Select(x => x).Where(x => x.nrBanco == pBanco && x.nrAgencia == pAgencia && x.nrConta == pConta).FirstOrDefault() == null)
                {
                    return true;
                };
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "/api/PesqContaListaBranca", "GET", "/api/PesqContaListaBranca", ex.Message);
                throw ex;
            }
            return false;
        }


        //------------------------------------------------------------------ INSERT
        public ListaBranca InserirListaBranca(ListaBranca item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioInclusao = pIDUserLogin;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _contexto.Set<ListaBranca>().Add(item);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirListaBranca", "POST", "/api/listabranca", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ ALTERAR
        public ListaBranca AlterarListaBranca(ListaBranca item, int pIDUserLogin)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.IdUsuarioManutencao    = pIDUserLogin;
                item.DtUsuarioManutencao    = DateTime.Now;
                _contexto.Entry(item).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "AlterarListaBranca", "POST", "/api/listabranca", ex.Message);
                throw ex;
            }
            return item;
        }

        //------------------------------------------------------------------ EXCLUIR
        public ListaBranca InativarListaBranca(int idListaBranca, int pIDUserLogin)
        {
            ListaBranca tabela = null;

            try
            {
                ListaBranca user = _contexto.Set<ListaBranca>().Single(x => x.idListaBranca == idListaBranca);
                user.IdUsuarioManutencao = pIDUserLogin;
                user.DtUsuarioManutencao = DateTime.Now;
                user.blnAtivo            = false;
                _contexto.Entry<ListaBranca>(user).State = EntityState.Modified;
                _contexto.SaveChanges();
                tabela = user;
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InativarListaBranca", "DEL", "/api/listabranca", ex.Message);
                throw ex;
            }
            return tabela;
        }

    }
}