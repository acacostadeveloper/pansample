﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using Pan.SRT.Data.Mapper;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;


namespace Pan.SRT.Data.Context
{
    public class PanRestritivosContext : DbContext
    {
        public PanRestritivosContext() : base("name=PanRestritivosContext")
        {
            //---------
        }

        public DbSet<Alcada> Alcada { get; set; }
        public DbSet<InstituicaoFinanceira> InstituicaoFinanceira { get; set; }
        public DbSet<TipoOrigem> TipoOrigem { get; set; }
        public DbSet<TipoDestino> TipoDestino { get; set; }
        public DbSet<EntidadeAtributo> EntidadeAtributo { get; set; }
        public DbSet<Entidade> Entidade { get; set; }
        public DbSet<PeriodoAgrupamento> PeriodoAgrupamento { get; set; }
        public DbSet<TipoAgrupamento> TipoAgrupamento { get; set; }
        public DbSet<TipoOperador> TipoOperador { get; set; }
        public DbSet<EmailAlerta> EmailAlerta { get; set; }
        public DbSet<ListaBranca> ListaBranca { get; set; }
        public DbSet<ListaNegra> ListaNegra { get; set; }
        public DbSet<MensagemTransferencia> MensagemTransferencia { get; set; }
        public DbSet<TipoMensagem> TipoMensagem { get; set; }
        public DbSet<RegraValidacao> RegraValidacao { get; set; }
        public DbSet<RegraValidaClausula> RegraValidaClausula { get; set; }
        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<SistemaOrigem> SistemaOrigem { get; set; }
        public DbSet<Cliente> Cliente { get; set; }
        public DbSet<Pessoa> Pessoa { get; set; }
        public DbSet<Conta> Conta { get; set; }
        public DbSet<MensagemCredito> MensagemCredito { get; set; }
        public DbSet<MensagemDebito> MensagemDebito { get; set; }
        public DbSet<Movimento> Movimento { get; set; }
        public DbSet<MensagemTransHistorico> MensagemTransHistorico { get; set; }
        public DbSet<GravaLog> GravaLog { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new AlcadaMap());
            modelBuilder.Configurations.Add(new InstituicaoFinanceiraMap());
            modelBuilder.Configurations.Add(new TipoOrigemMap());
            modelBuilder.Configurations.Add(new TipoDestinoMap());
            modelBuilder.Configurations.Add(new RegraValidacaoMap());
            modelBuilder.Configurations.Add(new RegraValidaClausulaMap());
            modelBuilder.Configurations.Add(new EntidadeAtributoMap());
            modelBuilder.Configurations.Add(new EntidadeMap());
            modelBuilder.Configurations.Add(new PeriodoAgrupamentoMap());
            modelBuilder.Configurations.Add(new TipoAgrupamentoMap());
            modelBuilder.Configurations.Add(new TipoOperadorMap());
            modelBuilder.Configurations.Add(new EmailAlertaMap());
            modelBuilder.Configurations.Add(new ListaBrancaMap());
            modelBuilder.Configurations.Add(new MensagemTransferenciaMap());
            modelBuilder.Configurations.Add(new TipoMensagemMap());
            modelBuilder.Configurations.Add(new UsuarioMap());
            modelBuilder.Configurations.Add(new SistemaOrigemMap());
            modelBuilder.Configurations.Add(new GravaLogMap());
        }
    }
    

}
