﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Pan.SRT.Infra;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Data
{
    public class GravaLogDataAccessLayer : IGravaLogDataAccessLayer
    {

        private PanRestritivosContext _contexto;

        public GravaLogDataAccessLayer()
        {
            _contexto = new PanRestritivosContext();
        }



        //------------------------------------------------------------------ INSERT
        public void InserirGravaLog(string pMensagem)
        {
            try
            {
                GravaLog DbLog     = new GravaLog();
                DbLog.DataInclusao = DateTime.Now;
                DbLog.Mensagem     = pMensagem;
                _contexto.Set<GravaLog>().Add(DbLog);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.LoggerErroTransacao("", "", "InserirGravaLog", "POST", "InserirGravaLog", ex.Message);
                throw ex;
            }                        
        }

    }
}