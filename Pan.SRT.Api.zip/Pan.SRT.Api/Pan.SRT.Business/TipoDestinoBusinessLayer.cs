﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class TipoDestinoBusinessLayer : ITipoDestinoBusinessLayer
    {
        private ITipoDestinoDataAccessLayer _objTipoDestinoDal;
        public TipoDestinoBusinessLayer(ITipoDestinoDataAccessLayer objTipoDestinoDal)
        {
            _objTipoDestinoDal = objTipoDestinoDal;
        }
        public IEnumerable<TipoDestinoLista> ObterTipoDestino(TipoDestino item)
        {
            return _objTipoDestinoDal.ObterTipoDestino(item);
        }
        //---------------------------------------------------------------------- LISTA com ID
        public TipoDestino ObterTipoDestino(int pID)
        {
            return _objTipoDestinoDal.ObterTipoDestino(pID);
        }
        //---------------------------------------------------------------------- LISTA com DESCRICAO
        public TipoDestino ObterTipoDestino(string pTexto)
        {
            return _objTipoDestinoDal.ObterTipoDestino(pTexto);
        }
        //---------------------------------------------------------------------- LISTA com FILTRO
        public TipoDestino InserirTipoDestino(TipoDestino item, int pIDUserLogin)
        {
            return _objTipoDestinoDal.InserirTipoDestino(item, pIDUserLogin);
        }
        public TipoDestino AlterarTipoDestino(TipoDestino item, int pIDUserLogin)
        {
            return _objTipoDestinoDal.AlterarTipoDestino(item, pIDUserLogin);
        }
        public TipoDestino InativarTipoDestino(int idTipoDestino, int pIDUserLogin)
        {
            return _objTipoDestinoDal.InativarTipoDestino(idTipoDestino, pIDUserLogin);
        }
    }
}