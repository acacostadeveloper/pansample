﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class EntidadeAtributoBusinessLayer : IEntidadeAtributoBusinessLayer
    {
        private IEntidadeAtributoDataAccessLayer _objEntidadeAtributoDal;
        public EntidadeAtributoBusinessLayer(IEntidadeAtributoDataAccessLayer objEntidadeAtributoDal)
        {
            _objEntidadeAtributoDal = objEntidadeAtributoDal;
        }
        public IEnumerable<EntidadeAtributoLista> ObterEntidadeAtributo(EntidadeAtributo item)
        {
            return _objEntidadeAtributoDal.ObterEntidadeAtributo(item);
        }
        public EntidadeAtributo ObterEntidadeAtributo(int pID)
        {
            return _objEntidadeAtributoDal.ObterEntidadeAtributo(pID);
        }
        public EntidadeAtributo ObterEntidadeAtributo(string pTexto)
        {
            return _objEntidadeAtributoDal.ObterEntidadeAtributo(pTexto);
        }
        public EntidadeAtributo InserirEntidadeAtributo(EntidadeAtributo item, int pIDUserLogin)
        {
            return _objEntidadeAtributoDal.InserirEntidadeAtributo(item, pIDUserLogin);
        }
        public EntidadeAtributo AlterarEntidadeAtributo(EntidadeAtributo item, int pIDUserLogin)
        {
            return _objEntidadeAtributoDal.AlterarEntidadeAtributo(item, pIDUserLogin);
        }
        public EntidadeAtributo InativarEntidadeAtributo(int idEntidadeAtributo, int pIDUserLogin)
        {
            return _objEntidadeAtributoDal.InativarEntidadeAtributo(idEntidadeAtributo, pIDUserLogin);
        }
    }
}