﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class TipoOperadorBusinessLayer : ITipoOperadorBusinessLayer
    {
        private ITipoOperadorDataAccessLayer _objTipoOperadorDal;
        public TipoOperadorBusinessLayer(ITipoOperadorDataAccessLayer objTipoOperadorDal)
        {
            _objTipoOperadorDal = objTipoOperadorDal;
        }
        public IEnumerable<TipoOperadorLista> ObterTipoOperador(TipoOperador item)
        {
            return _objTipoOperadorDal.ObterTipoOperador(item);
        }
        public TipoOperador ObterTipoOperadorID(int pID)
        {
            return _objTipoOperadorDal.ObterTipoOperadorID(pID);
        }
        public TipoOperador ObterTipoOperadorTx(string pTexto)
        {
            return _objTipoOperadorDal.ObterTipoOperadorTx(pTexto);
        }
        public TipoOperador InserirTipoOperador(TipoOperador item, int pIDUserLogin)
        {
            return _objTipoOperadorDal.InserirTipoOperador(item, pIDUserLogin);
        }
        public TipoOperador AlterarTipoOperador(TipoOperador item, int pIDUserLogin)
        {
            return _objTipoOperadorDal.AlterarTipoOperador(item, pIDUserLogin);
        }
        public TipoOperador InativarTipoOperador(int idTipoOperador, int pIDUserLogin)
        {
            return _objTipoOperadorDal.InativarTipoOperador(idTipoOperador, pIDUserLogin);
        }
    }
}