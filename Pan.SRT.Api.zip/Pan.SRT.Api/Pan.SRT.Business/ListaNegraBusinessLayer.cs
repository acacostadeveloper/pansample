﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class ListaNegraBusinessLayer : IListaNegraBusinessLayer
    {
        private IListaNegraDataAccessLayer _objListaNegraDal;
        public ListaNegraBusinessLayer(IListaNegraDataAccessLayer objListaNegraDal)
        {
            _objListaNegraDal = objListaNegraDal;
        }
        public IEnumerable<ListaNegraLista> ObterListaNegra(ListaNegra item)
        {
            return _objListaNegraDal.ObterListaNegra(item);
        }
        //---------------------------------------------------------------------- LISTA com ID
        public ListaNegra ObterListaNegra(int pID)
        {
            return _objListaNegraDal.ObterListaNegra(pID);
        }
        //---------------------------------------------------------------------- LISTA com FILTRO
        public ListaNegra ObterListaNegra(string pTexto)
        {
            return _objListaNegraDal.ObterListaNegra(pTexto);
        }
        //---------------------------------------------------------------------- PESQUISA por CNPJ  30.06.2018
        public bool PesquisaListaNegra(string pCNPJ)
        {
            return _objListaNegraDal.PesquisaListaNegra(pCNPJ);
        }
        //---------------------------------------------------------------------- PESQUISA por CONTA  30.06.2018
        public bool PesqContaListaNegra(int pBanco, int pConta, int pAgencia)
        {
            return _objListaNegraDal.PesqContaListaNegra(pBanco, pConta, pAgencia);
        }    
        //---------------------------------------------------------------------- CRUD
        public ListaNegra InserirListaNegra(ListaNegra item, int pIDUserLogin)
        {
            return _objListaNegraDal.InserirListaNegra(item, pIDUserLogin);
        }
        public ListaNegra AlterarListaNegra(ListaNegra item, int pIDUserLogin)
        {
            return _objListaNegraDal.AlterarListaNegra(item, pIDUserLogin);
        }
        public ListaNegra InativarListaNegra(int idListaNegra, int pIDUserLogin)
        {
            return _objListaNegraDal.InativarListaNegra(idListaNegra, pIDUserLogin);
        }
    }
}