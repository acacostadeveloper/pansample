﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class TipoAgrupamentoBusinessLayer : ITipoAgrupamentoBusinessLayer
    {
        private ITipoAgrupamentoDataAccessLayer _objTipoAgrupamentoDal;
        public TipoAgrupamentoBusinessLayer(ITipoAgrupamentoDataAccessLayer objTipoAgrupamentoDal)
        {
            _objTipoAgrupamentoDal = objTipoAgrupamentoDal;
        }
        public IEnumerable<TipoAgrupamentoLista> ObterTipoAgrupamento(TipoAgrupamento item)
        {
            return _objTipoAgrupamentoDal.ObterTipoAgrupamento(item);
        }
        public TipoAgrupamento ObterTipoAgrupamento(int pID)
        {
            return _objTipoAgrupamentoDal.ObterTipoAgrupamento(pID);
        }
        public TipoAgrupamento ObterTipoAgrupamento(string pTexto)
        {
            return _objTipoAgrupamentoDal.ObterTipoAgrupamento(pTexto);
        }
        public TipoAgrupamento InserirTipoAgrupamento(TipoAgrupamento item, int pIDUserLogin)
        {
            return _objTipoAgrupamentoDal.InserirTipoAgrupamento(item, pIDUserLogin);
        }
        public TipoAgrupamento AlterarTipoAgrupamento(TipoAgrupamento item, int pIDUserLogin)
        {
            return _objTipoAgrupamentoDal.AlterarTipoAgrupamento(item, pIDUserLogin);
        }
        public TipoAgrupamento InativarTipoAgrupamento(int idTipoAgrupamento, int pIDUserLogin)
        {
            return _objTipoAgrupamentoDal.InativarTipoAgrupamento(idTipoAgrupamento, pIDUserLogin);
        }
    }
}