﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class SistemaOrigemBusinessLayer : ISistemaOrigemBusinessLayer
    {
        private ISistemaOrigemDataAccessLayer _objSistemaOrigemDal;
        public SistemaOrigemBusinessLayer(ISistemaOrigemDataAccessLayer objSistemaOrigemDal)
        {
            _objSistemaOrigemDal = objSistemaOrigemDal;
        }
        public IEnumerable<SistemaOrigemLista> ObterSistemaOrigem(SistemaOrigem item)
        {
            return _objSistemaOrigemDal.ObterSistemaOrigem(item);
        }
        public SistemaOrigem ObterSistemaOrigem(int pID)
        {
            return _objSistemaOrigemDal.ObterSistemaOrigem(pID);
        }
        public SistemaOrigem ObterSistemaOrigem(string pTexto)
        {
            return _objSistemaOrigemDal.ObterSistemaOrigem(pTexto);
        }

    }
}