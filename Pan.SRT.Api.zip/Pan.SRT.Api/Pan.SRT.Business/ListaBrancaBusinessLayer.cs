﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class ListaBrancaBusinessLayer : IListaBrancaBusinessLayer
    {
        private IListaBrancaDataAccessLayer _objListaBrancaDal;
        public ListaBrancaBusinessLayer(IListaBrancaDataAccessLayer objListaBrancaDal)
        {
            _objListaBrancaDal = objListaBrancaDal;
        }
        public IEnumerable<ListaBrancaLista> ObterListaBranca(ListaBranca item)
        {
            return _objListaBrancaDal.ObterListaBranca(item);
        }
        //---------------------------------------------------------------------- LISTA com ID
        public ListaBranca ObterListaBranca(int pID)
        {
            return _objListaBrancaDal.ObterListaBranca(pID);
        }
        //---------------------------------------------------------------------- LISTA com FILTRO
        public ListaBranca ObterListaBranca(string pTexto)
        {
            return _objListaBrancaDal.ObterListaBranca(pTexto);
        }
        //---------------------------------------------------------------------- PESQUISA por CNPJ  30.06.2018
        public bool PesquisaListaBranca(string pCNPJ)
        {
            return _objListaBrancaDal.PesquisaListaBranca(pCNPJ);
        }
        //---------------------------------------------------------------------- PESQUISA por CONTA  30.06.2018
        public bool PesqContaListaBranca(int pBanco, int pConta, int pAgencia)
        {
            return _objListaBrancaDal.PesqContaListaBranca(pBanco, pConta, pAgencia);
        }    
        //---------------------------------------------------------------------- INSERIR
        public ListaBranca InserirListaBranca(ListaBranca item, int pIDUserLogin)
        {
            return _objListaBrancaDal.InserirListaBranca(item, pIDUserLogin);
        }
        public ListaBranca AlterarListaBranca(ListaBranca item, int pIDUserLogin)
        {
            return _objListaBrancaDal.AlterarListaBranca(item, pIDUserLogin);
        }
        public ListaBranca InativarListaBranca(int idListaBranca, int pIDUserLogin)
        {
            return _objListaBrancaDal.InativarListaBranca(idListaBranca, pIDUserLogin);
        }
    }
}