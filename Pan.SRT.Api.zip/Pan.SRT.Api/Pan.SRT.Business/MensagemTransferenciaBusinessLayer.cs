﻿using System.Text;
using System.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Data;
using Pan.SRT.Entidades;
using Pan.SRT.Data.Context;
using System.Threading.Tasks;
using System.Net.Http;
using System.Threading;
using System.Reflection;
using Pan.SRT.Helpers;
using System.Web.Services;
using Pan.SRT.Agent.EBankWebServ;
using Pan.SRT.Agent.InfoBankWebServ;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data.InterfaceDataAccess;


namespace Pan.SRT.Business
{
    public class MensagemTransferenciaBusinessLayer : IMensagemTransferenciaBusinessLayer
    {
        private IMensagemTransferenciaDataAccessLayer _objMensagemTransferenciaDal;
        private ITipoMensagemDataAccessLayer          _objDataAccessTipoMensagem;
        private ITipoOrigemDataAccessLayer            _objDataAccessTipoOrigem;
        private ITipoDestinoDataAccessLayer           _objDataAccessTipoDestino;
        private IInstituicaoFinanceiraDataAccessLayer _objDataAccessInstituicao;
        private IRegraValidacaoDataAccessLayer        _objDataAccessRegraValidacao;
        private IMensagemTransferenciaDataAccessLayer _objDataAccessMensagemTransf;
        private EB_PadraoServicesLTService wsEBankService = new EB_PadraoServicesLTService();
        private IB_ServicesLTService    wsInfoBankService = new IB_ServicesLTService();
        private GravaLogHelp                      _LogHlp = new GravaLogHelp();

        public MensagemTransferenciaBusinessLayer(  IMensagemTransferenciaDataAccessLayer objMensagemTransferenciaDal , 
                                                    ITipoMensagemDataAccessLayer          objDataAccessTipoMensagem   ,
                                                    ITipoOrigemDataAccessLayer            objDataAccessTipoOrigem     ,
                                                    ITipoDestinoDataAccessLayer           objDataAccessTipoDestino    ,
                                                    IInstituicaoFinanceiraDataAccessLayer objDataAccessInstituicao    ,
                                                    IRegraValidacaoDataAccessLayer        objDataAccessRegraValidacao ,
                                                    IMensagemTransferenciaDataAccessLayer objDataAccessMensagemTransf )
        {
            _objMensagemTransferenciaDal = objMensagemTransferenciaDal;
            _objDataAccessTipoMensagem   = objDataAccessTipoMensagem  ;
            _objDataAccessTipoOrigem     = objDataAccessTipoOrigem    ;
            _objDataAccessTipoDestino    = objDataAccessTipoDestino   ;
            _objDataAccessInstituicao    = objDataAccessInstituicao   ;
            _objDataAccessRegraValidacao = objDataAccessRegraValidacao;
            _objDataAccessMensagemTransf = objDataAccessMensagemTransf;
        }


        public IEnumerable<MensagemTransferenciaLista> ObterMensagemTransferencia(MensagemTransferenciaFiltro item)
        {
            return _objMensagemTransferenciaDal.ObterMensagemTransferencia(item);
        }
        public MensagemTransferencia ObterMensagemTransferencia(int pID)
        {
            return _objMensagemTransferenciaDal.ObterMensagemTransferencia(pID);
        }
        public bool StatusMensagemTransferencia(MensagemTransferenciaStatus item, int pIDUserLogin)
        {
            return _objMensagemTransferenciaDal.StatusMensagemTransferencia(item, pIDUserLogin);
        }




        /*===========================================================================================================
        // Programa...:  RequisitaTED - Emulando mesmo método do AutBank, para validar regras do TED
        // Autor......:  Afonso Celso - Edinaldo Silva (IT Singular)
        // Data.......:  20.03.2017
        ===========================================================================================================*/
        public MensagemResponse requisitaTED(ParametrosTed pParametroTED, int pIDUserLogin, string pApiServiceEBank, string pApiServiceInfoBank)
        {
            MensagemTransferencia objTransferencia = new MensagemTransferencia();
            MensagemResponse objResponse           = new MensagemResponse();
            DateTime dataAgora                     = DateTime.Now;   //Usado nos campos de data, não remover !!

            try
            {
                // todo: atribuir valores Mensagem
                wsEBankService.Url    = pApiServiceEBank;
                wsInfoBankService.Url = pApiServiceInfoBank;

                //EGS 30.04.2018 Se nenhum parametro informado, aborta !
                if (pParametroTED == null)
                {
                    objResponse.codErro = 400;   //400  Nenhum conteúdo
                    objResponse.descricaoErro = "Nenhum parametro informado, processo abortado";
                    _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
                    return objResponse;
                }

                // todo: Buscar o tipo mensagem ----------------------------------------------------------------------------------------
                TipoMensagem objTipoMensagem = new TipoMensagem();
                objTipoMensagem = _objDataAccessTipoMensagem.ObterTipoMensagem(pParametroTED.CodEvento);
                if (objTipoMensagem == null)
                {
                    objResponse.codErro = 204;   //204  Nenhum conteúdo
                    objResponse.descricaoErro = "Tipo da Mensagem não encontrado atraves do evento [" + pParametroTED.CodEvento + "], processo abortado";
                    _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
                    return objResponse;
                }
                objTransferencia.TipoMensagem     = objTipoMensagem;
                objTransferencia.EventoDescricao  = objTipoMensagem.nmDescricao;
                objTransferencia.SensibilizaConta = objTipoMensagem.blnSensibConta;

                // todo: Buscar o tipo origem ------------------------------------------------------------------------------------------
                TipoOrigem objTipoOrigem = new TipoOrigem();
                objTipoOrigem = _objDataAccessTipoOrigem.ObterTipoOrigem(pParametroTED.Origem);
                if (objTipoOrigem == null)
                {
                    objResponse.codErro = 204;   //204  Nenhum conteúdo
                    objResponse.descricaoErro = "Tipo da Origem não encontrado atraves do codigo [" + pParametroTED.Origem + "], processo abortado";
                    _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
                    return objResponse;
                }
                objTransferencia.MensagemDebito.TipoOrigem = objTipoOrigem;


                // todo: Buscar o tipo destino ------------------------------------------------------------------------------------------
                TipoDestino objTipoDestino = new TipoDestino();
                objTipoDestino = _objDataAccessTipoDestino.ObterTipoDestino(pParametroTED.TipoContaCred);
                if (objTipoDestino == null)
                {
                    objResponse.codErro = 204;   //204  Nenhum conteúdo
                    objResponse.descricaoErro = "Tipo de Destino não encontrado atraves do codigo [" + pParametroTED.TipoContaCred + "], processo abortado";
                    _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
                    return objResponse;
                }
                objTransferencia.MensagemCredito.TipoDestino = objTipoDestino;

                //----------------------------------------------------------------------------------------------------------------------

                // todo: Buscar Instituicao Financeira ---------------------------------------------------------------------------------
                InstituicaoFinanceira objInstituicaoDebito = new InstituicaoFinanceira();
                objInstituicaoDebito = _objDataAccessInstituicao.ObterInstituicaoFinancCNPJ(pParametroTED.CnpjCpfCliCred);
                if (objInstituicaoDebito == null)
                {
                    objResponse.codErro = 204;   //204  Nenhum conteúdo
                    objResponse.descricaoErro = "Instituicao Financeira Debito não encontrada atraves do CNPJ [" + pParametroTED.CnpjCpfCliRem + "], processo abortado";
                    _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
                    return objResponse;
                }
                InstituicaoFinanceira objInstituicaoCredito = new InstituicaoFinanceira();
                objInstituicaoCredito = _objDataAccessInstituicao.ObterInstituicaoFinancCNPJ(pParametroTED.CnpjCpfCliCred);
                if (objInstituicaoCredito == null)
                {
                    objResponse.codErro = 204;   //204  Nenhum conteúdo
                    objResponse.descricaoErro = "Instituicao Financeira Credito não encontrada atraves do CNPJ [" + pParametroTED.CnpjCpfCliCred + "], processo abortado";
                    _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
                    return objResponse;
                }
                objTransferencia.MensagemDebito.ContaDebito.InstituicaoFinanceira = objInstituicaoDebito;
                objTransferencia.MensagemCredito.ContaCredito.InstituicaoFinanceira = objInstituicaoCredito;
                //----------------------------------------------------------------------------------------------------------------------



                // todo: atualiza dados de Debito --------------------------------------------------------------------------------------
                objTransferencia.MensagemDebito.ContaDebito.DataAbertura        = dataAgora;
                objTransferencia.MensagemDebito.ContaDebito.NumeroBanco         = pParametroTED.BancoCredito;
                objTransferencia.MensagemDebito.ContaDebito.NumeroAgencia       = pParametroTED.AgenciaDeb;
                objTransferencia.MensagemDebito.ContaDebito.NumeroConta         = pParametroTED.ContaDeb;
                objTransferencia.MensagemDebito.ContaDebito.Pessoa.CNPFCNPJ     = pParametroTED.CnpjCpfCliRem;
                objTransferencia.MensagemDebito.ContaDebito.Pessoa.Nome         = pParametroTED.NomeCliRem;
                objTransferencia.MensagemDebito.IndicadoDebAutorizado           = pParametroTED.DebAutorizado;
                objTransferencia.MensagemDebito.CodigoOrigem                    = pParametroTED.Origem;
                objTransferencia.MensagemDebito.SistemaOrigem                   = pParametroTED.SisOrigem;
                objTransferencia.MensagemDebito.SubSistemaOrigem                = pParametroTED.SubSistemaO;


                // todo: atualiza dados de Credito -------------------------------------------------------------------------------------
                objTransferencia.MensagemCredito.ContaCredito.DataAbertura      = dataAgora;
                objTransferencia.MensagemCredito.ContaCredito.NumeroBanco       = pParametroTED.BancoCredito;
                objTransferencia.MensagemCredito.ContaCredito.NumeroAgencia     = pParametroTED.AgenciaCred;
                objTransferencia.MensagemCredito.ContaCredito.NumeroConta       = pParametroTED.ContaCred;
                objTransferencia.MensagemCredito.ContaCredito.Pessoa.CNPFCNPJ   = pParametroTED.CnpjCpfCliCred;
                objTransferencia.MensagemCredito.ContaCredito.Pessoa.Nome       = pParametroTED.NomeCliCred;
                objTransferencia.MensagemCredito.ContaCredito.Pessoa.TipoPessoa = pParametroTED.TipoPessoaCred;


                // todo: gravar todos os demais campos do autbank recebidos ------------------------------------------------------------
                objTransferencia.EventoCodigo                                   = pParametroTED.CodEvento;
                objTransferencia.NroBoleto                                      = pParametroTED.NroBoleto;
                objTransferencia.HoraVencto                                     = pParametroTED.HoraVencto;
                objTransferencia.Valor                                          = pParametroTED.Valor;
                objTransferencia.Finalidade                                     = pParametroTED.Finalidade;
                objTransferencia.Tarifado                                       = false;     //pParametroTED.Tarifado;
                objTransferencia.Historico                                      = pParametroTED.Historico;
                objTransferencia.DataVencto                                     = pParametroTED.DataVencto;
                objTransferencia.DataAgendPag                                   = pParametroTED.DataAgendPag;
                objTransferencia.Prioridade                                     = pParametroTED.Prioridade;     //Prioridade (“B”, “C”, “D”)
                objTransferencia.NroBoleto                                      = pParametroTED.NroBoleto;
                objTransferencia.ComplementoHistorico                           = pParametroTED.ComplementoHistorico;
                objTransferencia.NumOrigem                                      = pParametroTED.NumOrigem;
                objTransferencia.CanalEntrada                                   = pParametroTED.CanalEntrada;   //Canal de Entrada do Lançamento P - Pessoal/Presencial E - Eletrônico I  -  Internet Obs.: Se não informado, o e-Bank assumirá como default “P” – Pessoal/Presencial
                // ---------------------------------------------------------------------------------------------------------------------

                // todo: pesquisar em Lista Branca e Lista Negra
                //------------------------------------------------------------------------------------------------------------------

                // todo: gravar dados da Alcada
                //------------------------------------------------------------------------------------------------------------------


                // todo: obter dados de pessoa (infobank)
                objTransferencia.MensagemDebito.ContaDebito.Pessoa.Cliente.CodigoCliente         = pParametroTED.CodCliente;
                objTransferencia.MensagemDebito.ContaDebito.Pessoa.Cliente.DataInicioRelaciona   = Convert.ToDateTime(dataAgora.AddMonths(-17));
                objTransferencia.MensagemCredito.ContaCredito.Pessoa.Cliente.CodigoCliente       = pParametroTED.CodCliente;
                objTransferencia.MensagemCredito.ContaCredito.Pessoa.Cliente.DataInicioRelaciona = Convert.ToDateTime(dataAgora.AddMonths(-11));

                try
                {
                    TOIntegracaoRetornoConsContasTitular[] retornoContas;
                    retornoContas = wsEBankService.consultaContasTitular(pParametroTED.CodCliente, pParametroTED.CnpjCpfCliCred, "001", pParametroTED.AgenciaDeb, pParametroTED.ContaDeb, "", "");
                    if (retornoContas != null)
                    {
                        foreach (var itemCont in retornoContas)
                        {
                            objTransferencia.MensagemDebito.ContaDebito.Pessoa.Cliente.DataInicioRelaciona = Convert.ToDateTime(itemCont.dataAbertura);
                        }
                    }
                }
                catch (Exception)
                {
                }


                try
                {                
                    TOIntegracaoRetornoConsultaConta retornoConta = new TOIntegracaoRetornoConsultaConta();
                    retornoConta = wsEBankService.consultaConta("001", pParametroTED.AgenciaDeb, pParametroTED.ContaDeb);
                    if (retornoConta != null)
                    {
                        objTransferencia.MensagemDebito.ContaDebito.Pessoa.TelefoneCelular             = Convert.ToString(retornoConta.telefoneAgencia);
                        objTransferencia.MensagemDebito.ContaDebito.Pessoa.TelefoneFixo                = Convert.ToString(retornoConta.telefoneAgencia);
                        objTransferencia.MensagemDebito.ContaDebito.Pessoa.Nome                        = Convert.ToString(retornoConta.nome);
                        objTransferencia.MensagemDebito.ContaDebito.Pessoa.TipoPessoa                  = Convert.ToString(retornoConta.tipoPessoa);
                    }
                }
                catch (Exception)
                {
                }
                


                try
                {
                    string dDtHistoInicio = dataAgora.AddMonths(-3).ToString("dd-MM-yyyy");
                    string dDtHistoFinal  = dataAgora.ToString("dd-MM-yyyy");

                    // todo: obter dados de historico da conta ()
                    TOIntegracaoRetornoMovimentos[] retornoMovtoCred;
                    retornoMovtoCred = wsEBankService.consultaMovimentos("001", pParametroTED.AgenciaDeb, pParametroTED.ContaDeb, dDtHistoInicio, dDtHistoFinal, "", "");
                    if (retornoMovtoCred != null)
                    {
                        foreach (var itemMovt in retornoMovtoCred)
                        {
                            objTransferencia.MensagemCredito.ContaCredito.Movimento                 = new Movimento();
                            objTransferencia.MensagemCredito.ContaCredito.Movimento.dtDataMovimento = Convert.ToDateTime(itemMovt.dataLancto);
                            objTransferencia.MensagemCredito.ContaCredito.Movimento.dsDescricao     = Convert.ToString(itemMovt.descHistorico);
                            objTransferencia.MensagemCredito.ContaCredito.Movimento.Valor           = Convert.ToDecimal(itemMovt.valorLcto);
                        }
                    }
                }
                catch (Exception)
                {
                }


                try
                { 
                    // todo: obter dados de historico da conta ()
                    string dDtMovtoInicio = dataAgora.AddMonths(-1).AddDays(-19).ToString("dd-MM-yyyy");
                    string dDtMovtoFinal  = dataAgora.ToString("dd-MM-yyyy");
                    TOIntegracaoRetornoMovimentos[] retornoMovtoDeb;
                    retornoMovtoDeb = wsEBankService.consultaMovimentos("001", pParametroTED.AgenciaDeb, pParametroTED.ContaDeb, dDtMovtoInicio, dDtMovtoFinal, "", "");
                    if (retornoMovtoDeb != null)
                    {
                        foreach (var itemMovt in retornoMovtoDeb)
                        {
                            objTransferencia.MensagemDebito.ContaDebito.Movimento                 = new Movimento();
                            objTransferencia.MensagemDebito.ContaDebito.Movimento.dtDataMovimento = Convert.ToDateTime(itemMovt.dataLancto);
                            objTransferencia.MensagemDebito.ContaDebito.Movimento.dsDescricao     = Convert.ToString(itemMovt.descHistorico);
                            objTransferencia.MensagemDebito.ContaDebito.Movimento.Valor           = Convert.ToDecimal(itemMovt.valorLcto);
                        }
                    }
                }
                catch (Exception)
                {
                }


                // TODO PENDENTE ===========================================================================================>>>>>>>>
                // TODO PENDENTE ===========================================================================================>>>>>>>>
                // todo: Persistir mensagem 
                var taskValidRegra = Task.Run(() => ProcessarMensagemTransferencia(objTransferencia, pIDUserLogin));


                // todo: criar response 200 OK
                objResponse.codErro       = 200;   //200  OK
                objResponse.descricaoErro = "Mensagem gravada com sucesso";
                _LogHlp._GravaLog("Msg.Trans - " + objResponse.descricaoErro);
            }
            catch (Exception ex)
            {
                objResponse.codErro = 400;   //200  OK
                objResponse.descricaoErro = "Erro ao receber mensagem: " + ex.Message + " " + ex.InnerException;
                _LogHlp._GravaLog("Msg.Trans - requisitaTED Erro: " + ex.Message + " " + ex.InnerException);
                throw ex;
            }
            return objResponse;
        }



        /*===========================================================================================================
        // Programa...:  ProcessarMensagemTransferencia - Valida as regras, envia ou não para AutBank
        // Autor......:  Afonso Celso - Edinaldo Silva (IT Singular)
        // Data.......:  25.03.2017
        ===========================================================================================================*/
        public async Task<int> ProcessarMensagemTransferencia(MensagemTransferencia pMsg, int pIDUserLogin)
        {
            int bRetono = 0;
            try
            {
                
                MensagemTransferencia objMensagem = new MensagemTransferencia();
                objMensagem = _objDataAccessMensagemTransf.InserirMensagemTransferencia(pMsg, pIDUserLogin);

                _LogHlp._GravaLog("Msg.Trans - IDMensTransferencia [" + objMensagem.idMensagemTransferencia.ToString() + "] inserida com sucesso...");

                if (objMensagem.idMensagemTransferencia != 0)   //Mensagem Gravada no Banco
                {
                    var taskEnvioAutBankPrimeira = Task.Run(() => EnviarWebServiceAutBank(pMsg, 1));

                    bool bRetornoRegra = this.ValidaMensagemTransferencia(pMsg);
                    _LogHlp._GravaLog("Msg.Trans - ProcessarMensagemTransferencia - Regras verificadas");

                    // todo: integrar EBank 
                    if (bRetornoRegra == true)  //Passou pelas regras
                    {
                        _LogHlp._GravaLog("Msg.Trans - ProcessarMensagemTransferencia - Regra Validada - Pode chamar EBank autorizando");

                        var taskEnvioAutBankSegunda = Task.Run(() => EnviarWebServiceAutBank(pMsg, 2));
                    }
                    _objDataAccessMensagemTransf.AlterarMensagemTransferencia(pMsg, 999999);
                    _LogHlp._GravaLog("Msg.Trans - ProcessarMensagemTransferencia - Status da Msg atualizado");
                }
            }
            catch (Exception ex)
            {
                bRetono = 400;
                _LogHlp._GravaLog("Msg.Trans - ProcessarMensagemTransferencia Erro: " + ex.Message + " " + ex.InnerException);
                throw ex;
            }
            return bRetono;
        }



        /*===========================================================================================================
        // Programa...:  ProcessarMensagemTransferencia - Valida as regras e clausulas para aceitar ou bloquear o TED
        // Autor......:  Afonso Celso - Edinaldo Silva (IT Singular)
        // Data.......:  25.03.2017
        ===========================================================================================================*/
        private bool ValidaMensagemTransferencia(MensagemTransferencia pMsg)
        {
            bool bRetornoRegra = true;     //Por padrão retorna como false
            int bStatus        = 9;
            // todo: carregar dados das Regras e Clausulas
            //------------------------------------------------------------------------------------------------------------------
            RegraValidacao itemRegra = new RegraValidacao();
            itemRegra.blnAtivo = true;  //Pegar somente as regras ativas
            IEnumerable<RegraValidacaoLista> objRegras = _objDataAccessRegraValidacao.ObterRegraValidacao(itemRegra);
            try
            {
                // todo: validação da mensagem
                foreach (RegraValidacaoLista rule in objRegras)
                {
                    #region Clausulas
                    foreach (RegraValidaClausulaLista clause in rule.RegraClausulas)
                    {
                        var iIDRegraClausula = clause.idRegraValidaClausula;
                        var sEntidadeDescr   = clause.EntidadeDescricao;
                        var sAtributoDescr   = clause.EntidadeAtributoDescricao;
                        var sAtributoTipo    = clause.EntidadeAtributoTipo;
                        string sValorRegra   = "";
                        string sValueArray   = "";
                        decimal iValorRegra  = 0;
                        decimal iValueArray  = 0;

                        if (sAtributoTipo == "C")     //Caracter
                        {
                            sValorRegra  = Convert.ToString(clause.nrValor);
                            sValueArray  = Convert.ToString(pMsg.GetType().GetProperty(sAtributoDescr).GetValue(pMsg, null));
                        }
                        else                          //Numerico
                        {
                            iValorRegra  = Convert.ToDecimal(clause.nrValor);
                            iValueArray  = Convert.ToDecimal(pMsg.GetType().GetProperty(sAtributoDescr).GetValue(pMsg, null));
                        }

                        switch (clause.TipoOperadorCodigo)
                        {
                            case "==":    //Igual
                                if (sAtributoTipo == "C") { bRetornoRegra = (sValueArray == sValorRegra);}
                                if (sAtributoTipo == "N") { bRetornoRegra = (iValueArray == iValorRegra);}
                                break;
                            case "<>":    //Diferente
                                if (sAtributoTipo == "C") { bRetornoRegra = (sValueArray != sValorRegra);}
                                if (sAtributoTipo == "N") { bRetornoRegra = (iValueArray != iValorRegra);}
                                break;
                            case ">>":    //Maior que
                                if (sAtributoTipo == "N") { bRetornoRegra = (iValorRegra >  iValueArray); }
                                break;
                            case "<<":    //Menor que
                                if (sAtributoTipo == "N") { bRetornoRegra = (iValorRegra <  iValueArray);}
                                break;
                            case "<=":    //Menor ou igual
                                if (sAtributoTipo == "N") { bRetornoRegra = (iValorRegra <= iValueArray);}
                                break;
                            case ">=":    //Maior ou igual
                                if (sAtributoTipo == "N") { bRetornoRegra = (iValorRegra >= iValueArray);}
                                break;
                            case "IN":    //Contém
                                bRetornoRegra = false;
                                break;
                            case "NOT":   //Não contém
                                bRetornoRegra = false;
                                break;
                            case "END":   //Termina com
                                bRetornoRegra = false;
                                break;
                            case "INI":   //Começa com
                                bRetornoRegra = false;
                                break;

                            default:
                                bRetornoRegra = false;
                                Console.WriteLine("Default case");
                                break;
                        }
                        if (bRetornoRegra == false)                         
                        { 
                            //EGS 30.05.2018 Se parou em alguma regra, grava o ID na Mensagem
                            pMsg.IdClausulaValidada = iIDRegraClausula;
                            break; 
                        }
                    }
                    #endregion

                    // todo: executar ação da regra 
                    //EGS Se ao validar a regra retorna FALSE, então nem precisa processar mais nada
                    #region RegraConsequencia
                    if (bRetornoRegra==false)
                    {
                        //---------------------------------------------------- Valida Consequencia
                        //0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada  9=Processando
                        switch (rule.nmConsequencia)
                        {
                            case "Alertar":
                                bStatus = 0;
                                //_EnviaEmailAlerta(pMsg);
                                break;
                            case "Recusar":
                                bStatus = 3;
                                break;
                            case "Bloquear":
                                bStatus = 2;
                                break;
                            case "Deletar":
                                bStatus = 2;                                
                                break;
                            default:
                                Console.WriteLine("Consequencia da Regra não declarada");
                                bStatus = 1;
                                break;
                        }
                        //------------------------------------------------------------------------
                        break;
                    }
                    #endregion
                }
                //EGS Se ao validar a regra retorna FALSE, então nem precisa processar mais nada
                if (bRetornoRegra == true)
                {
                    bStatus = 0;
                }
                MensagemTransferenciaStatus Status = new MensagemTransferenciaStatus();
                Status.idMensagemTransferencia     = pMsg.idMensagemTransferencia;
                Status.nrStatusOld                 = pMsg.nrStatus;
                Status.nrStatus                    = bStatus;
                _objDataAccessMensagemTransf.StatusMensagemTransferencia(Status, 999999);

            }
            catch (Exception ex)
            {
                bRetornoRegra = false;
                _LogHlp._GravaLog("Msg.Trans - ValidaMensagemTransferencia Erro: " + ex.Message + " " + ex.InnerException);
            }
            return bRetornoRegra;             
        }



        /*===========================================================================================================
        // Programa...:  EnviarWebServiceAutBank - Envia dados para webservice AutBank
        // Autor......:  Afonso Celso - Edinaldo Silva (IT Singular)
        // Data.......:  25.03.2018
        ===========================================================================================================*/
        public async Task<bool> EnviarWebServiceAutBank(MensagemTransferencia pMsg, int pStatus)
        {
            bool bRetornoWS = false;     //Por padrão retorna como false
            // todo: integrar EBank 
            //------------------------------------------ Envia para Webservice AutBank ---------------------------------------------------\\
            //------------------------------------------ Envia para Webservice AutBank ---------------------------------------------------\\
            MensagemTransHistorico tabelaHist   = new MensagemTransHistorico();
            tabelaHist                          = new MensagemTransHistorico();
            tabelaHist.idMensagemTransferencia  = pMsg.idMensagemTransferencia;
            try
            {
                TOIntegracaoRetornoTED requistaResp = new TOIntegracaoRetornoTED();
                requistaResp                        = new TOIntegracaoRetornoTED();
                requistaResp.codErro                = pStatus;
                
                requistaResp = wsEBankService.requisitaTED("", pMsg.EventoCodigo, pMsg.HoraVencto, pMsg.Valor,
                                                           pMsg.MensagemDebito.ContaDebito.NumeroAgencia, pMsg.MensagemDebito.ContaDebito.NumeroConta,
                                                           pMsg.MensagemCredito.ContaCredito.NumeroBanco, pMsg.MensagemCredito.ContaCredito.NumeroAgencia,
                                                           pMsg.MensagemCredito.ContaCredito.NumeroConta, pMsg.MensagemCredito.TipoDestino.nmTipoConta,
                                                           "", "", "", "", pMsg.Finalidade, pMsg.Historico, "false",
                                                           "", "", "", "", "", "", "", "", "", pMsg.DataVencto, "", pMsg.Prioridade, "", "", "", pMsg.NroBoleto,
                                                           "", "", "", "", pMsg.ComplementoHistorico, pMsg.NumOrigem, "");

                if (pStatus == 1) 
                { _LogHlp._GravaLog("Msg.Trans - EnviarWebServiceAutBank - Primeira Chamada do EBank concluida"); } else 
                { _LogHlp._GravaLog("Msg.Trans - EnviarWebServiceAutBank - Segunda  Chamada do EBank concluida"); }
             

                bRetornoWS = true;
                //EGS Grava a solicitacao em tabela para consultas futuras ---------------------------------------------------                
                if (requistaResp == null)
                {
                    tabelaHist.ErroCodigo    = 400;
                    tabelaHist.ErroDescricao = "Mensagem [" + Convert.ToString(pMsg.idMensagemTransferencia) + "] Não foi possivel conectar no AutBank";
                }
                else
                {
                    tabelaHist.ErroCodigo = requistaResp.codErro;
                    tabelaHist.ErroDescricao = "Mensagem [" + Convert.ToString(pMsg.idMensagemTransferencia) + "] do AutBank:: " + requistaResp.descricaoErro;
                }
                _LogHlp._GravaLog("Msg.Trans - EnviarWebServiceAutBank - " + tabelaHist.ErroDescricao);
            }
            catch (Exception ex)
            {
                tabelaHist.ErroCodigo    = 400;
                tabelaHist.ErroDescricao = "Erro ao Gravar Mensagem WS ["      + Convert.ToString(pMsg.idMensagemTransferencia) + "] enviada ao AutBank - Err: " + ex.Message + " " + ex.InnerException;
                _LogHlp._GravaLog("Msg.Trans - EnviarWebServiceAutBank URL : " + wsEBankService.Url);
                _LogHlp._GravaLog("Msg.Trans - EnviarWebServiceAutBank Erro: " + ex.Message + " " + ex.InnerException);
            } 
            //------------------------------------------ Final do Webservice AutBank -----------------------------------------------------\\
            //------------------------------------------ Final do Webservice AutBank -----------------------------------------------------\\
            _objDataAccessMensagemTransf.InserirMensagemTransfHistorico(tabelaHist);
            return bRetornoWS;
        }










        /*===========================================================================================================
        // Programa...:  _EnviaEmailAlerta - Envia email de ALERTA com os dados da mensagem recebida
        // Autor......:  Afonso Celso - Edinaldo Silva (IT Singular)
        // Data.......:  30.05.2018
        ===========================================================================================================*/
        public async Task<bool> _EnviaEmailAlerta(MensagemTransferencia pMsg)
        {
            bool bRetornoWS = false;     //Por padrão retorna como false
 
            //EGS Prepara Envio do Email mudança de Status ---------------------------------------------------------------
            TratamentoEnvioEmail _EnviarEmail = new TratamentoEnvioEmail();
            MensagemTransferenciaStatus item = new MensagemTransferenciaStatus();
            item.idMensagemTransferencia = pMsg.idMensagemTransferencia;
            item.nrStatus                = pMsg.nrStatus;
            item.nrStatusOld             = pMsg.nrStatus;
            item.nmDescricaoStatus       = "TED recebido e pela regra deve ser alertado";

            try
            {
                _objDataAccessMensagemTransf.AlertaMensagemTransferencia(item);
            }
            catch (Exception ex)
            {
                _LogHlp._GravaLog("Msg.Trans - _EnviaEmailAlerta Erro: " + ex.Message + " " + ex.InnerException);
                throw ex;
            }
            //EGS Envio do Email -----------------------------------------------------------------------------------------
            //------------------------------------------------------------------------------------------------------------
            //------------------------------------------------------------------------------------------------------------
            return bRetornoWS;

        }
    }
}
