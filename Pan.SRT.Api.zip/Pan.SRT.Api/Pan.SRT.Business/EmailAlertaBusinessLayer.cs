﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class EmailAlertaBusinessLayer : IEmailAlertaBusinessLayer
    {
        private IEmailAlertaDataAccessLayer _objEmailAlertaDal;
        public EmailAlertaBusinessLayer(IEmailAlertaDataAccessLayer objEmailAlertaDal)
        {
            _objEmailAlertaDal = objEmailAlertaDal;
        }
        public IEnumerable<EmailAlertaLista> ObterEmailAlerta(EmailAlerta item)
        {
            return _objEmailAlertaDal.ObterEmailAlerta(item);
        }
        //---------------------------------------------------------------------- LISTA com ID
        public EmailAlerta ObterEmailAlerta(int pID)
        {
            return _objEmailAlertaDal.ObterEmailAlerta(pID);
        }
        //---------------------------------------------------------------------- LISTA com DESCRICAO
        public EmailAlerta ObterEmailAlerta(string pTexto)
        {
            return _objEmailAlertaDal.ObterEmailAlerta(pTexto);
        }
        //---------------------------------------------------------------------- CRUD
        public EmailAlerta InserirEmailAlerta(EmailAlerta item, int pIDUserLogin)
        {
            return _objEmailAlertaDal.InserirEmailAlerta(item, pIDUserLogin);
        }
        public EmailAlerta AlterarEmailAlerta(EmailAlerta item, int pIDUserLogin)
        {
            return _objEmailAlertaDal.AlterarEmailAlerta(item, pIDUserLogin);
        }
        public EmailAlerta InativarEmailAlerta(int idEmailAlerta, int pIDUserLogin)
        {
            return _objEmailAlertaDal.InativarEmailAlerta(idEmailAlerta, pIDUserLogin);
        }
    }
}