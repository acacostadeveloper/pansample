﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class InstituicaoFinanceiraBusinessLayer : IInstituicaoFinanceiraBusinessLayer
    {
        private IInstituicaoFinanceiraDataAccessLayer _objInstituicaoFinanceiraDal;
        public InstituicaoFinanceiraBusinessLayer(IInstituicaoFinanceiraDataAccessLayer objInstituicaoFinanceiraDal)
        {
            _objInstituicaoFinanceiraDal = objInstituicaoFinanceiraDal;
        }
        public IEnumerable<InstituicaoFinanceiraLista> ObterInstituicaoFinanceira(InstituicaoFinanceira item)
        {
            return _objInstituicaoFinanceiraDal.ObterInstituicaoFinanceira(item);
        }
        public InstituicaoFinanceira ObterInstituicaoFinanceira(int pID)
        {
            return _objInstituicaoFinanceiraDal.ObterInstituicaoFinanceira(pID);
        }
        public InstituicaoFinanceira ObterInstituicaoFinanceira(string pTexto)
        {
            return _objInstituicaoFinanceiraDal.ObterInstituicaoFinanceira(pTexto);
        }
        public InstituicaoFinanceira ObterInstituicaoFinancCNPJ(string pCNPJ)
        {
            return _objInstituicaoFinanceiraDal.ObterInstituicaoFinancCNPJ(pCNPJ);
        }
        public InstituicaoFinanceira InserirInstituicaoFinanceira(InstituicaoFinanceira item, int pIDUserLogin)
        {
            return _objInstituicaoFinanceiraDal.InserirInstituicaoFinanceira(item, pIDUserLogin);
        }
        public InstituicaoFinanceira AlterarInstituicaoFinanceira(InstituicaoFinanceira item, int pIDUserLogin)
        {
            return _objInstituicaoFinanceiraDal.AlterarInstituicaoFinanceira(item, pIDUserLogin);
        }
        public InstituicaoFinanceira InativarInstituicaoFinanceira(int idInstituicaoFinanceira, int pIDUserLogin)
        {
            return _objInstituicaoFinanceiraDal.InativarInstituicaoFinanceira(idInstituicaoFinanceira, pIDUserLogin);
        }
    }
}