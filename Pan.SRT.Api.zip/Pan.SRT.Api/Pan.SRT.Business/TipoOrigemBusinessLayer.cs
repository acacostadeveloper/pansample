﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class TipoOrigemBusinessLayer : ITipoOrigemBusinessLayer
    {
        private ITipoOrigemDataAccessLayer _objTipoOrigemDal;
        public TipoOrigemBusinessLayer(ITipoOrigemDataAccessLayer objTipoOrigemDal)
        {
            _objTipoOrigemDal = objTipoOrigemDal;
        }
        public IEnumerable<TipoOrigemLista> ObterTipoOrigem(TipoOrigem item)
        {
            return _objTipoOrigemDal.ObterTipoOrigem(item);
        }
        public TipoOrigem ObterTipoOrigem(int pID)
        {
            return _objTipoOrigemDal.ObterTipoOrigem(pID);
        }
        public TipoOrigem ObterTipoOrigem(string pTexto)
        {
            return _objTipoOrigemDal.ObterTipoOrigem(pTexto);
        }
        public TipoOrigem InserirTipoOrigem(TipoOrigem item, int pIDUserLogin)
        {
            return _objTipoOrigemDal.InserirTipoOrigem(item, pIDUserLogin);
        }
        public TipoOrigem AlterarTipoOrigem(TipoOrigem item, int pIDUserLogin)
        {
            return _objTipoOrigemDal.AlterarTipoOrigem(item, pIDUserLogin);
        }
        public TipoOrigem InativarTipoOrigem(int idTipoOrigem, int pIDUserLogin)
        {
            return _objTipoOrigemDal.InativarTipoOrigem(idTipoOrigem, pIDUserLogin);
        }
    }
}