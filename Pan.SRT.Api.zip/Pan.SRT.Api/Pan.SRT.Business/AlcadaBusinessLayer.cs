﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class AlcadaBusinessLayer : IAlcadaBusinessLayer
    {
        private IAlcadaDataAccessLayer _objAlcadaDal;
        public AlcadaBusinessLayer(IAlcadaDataAccessLayer objAlcadaDal)
        {
            _objAlcadaDal = objAlcadaDal;
        }
        public IEnumerable<AlcadaLista> ObterAlcada(Alcada item)
        {
            return _objAlcadaDal.ObterAlcada(item);
        }
        public Alcada ObterAlcada(int pID)
        {
            return _objAlcadaDal.ObterAlcada(pID);
        }
        public Alcada ObterAlcada(string pTexto)
        {
            return _objAlcadaDal.ObterAlcada(pTexto);
        }
        public Alcada InserirAlcada(Alcada item, int pIDUserLogin)
        {
            return _objAlcadaDal.InserirAlcada(item, pIDUserLogin);
        }
        public Alcada AlterarAlcada(Alcada item, int pIDUserLogin)
        {
            return _objAlcadaDal.AlterarAlcada(item, pIDUserLogin);
        }
        public Alcada InativarAlcada(int idAlcada, int pIDUserLogin)
        {
            return _objAlcadaDal.InativarAlcada(idAlcada, pIDUserLogin);
        }
    }
}