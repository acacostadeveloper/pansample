﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class PeriodoAgrupamentoBusinessLayer : IPeriodoAgrupamentoBusinessLayer
    {
        private IPeriodoAgrupamentoDataAccessLayer _objPeriodoAgrupamentoDal;
        public PeriodoAgrupamentoBusinessLayer(IPeriodoAgrupamentoDataAccessLayer objPeriodoAgrupamentoDal)
        {
            _objPeriodoAgrupamentoDal = objPeriodoAgrupamentoDal;
        }
        public IEnumerable<PeriodoAgrupamentoLista> ObterPeriodoAgrupamento(PeriodoAgrupamento item)
        {
            return _objPeriodoAgrupamentoDal.ObterPeriodoAgrupamento(item);
        }
        public PeriodoAgrupamento ObterPeriodoAgrupamento(int pID)
        {
            return _objPeriodoAgrupamentoDal.ObterPeriodoAgrupamento(pID);
        }
        public PeriodoAgrupamento ObterPeriodoAgrupamento(string pTexto)
        {
            return _objPeriodoAgrupamentoDal.ObterPeriodoAgrupamento(pTexto);
        }
        public PeriodoAgrupamento InserirPeriodoAgrupamento(PeriodoAgrupamento item, int pIDUserLogin)
        {
            return _objPeriodoAgrupamentoDal.InserirPeriodoAgrupamento(item, pIDUserLogin);
        }
        public PeriodoAgrupamento AlterarPeriodoAgrupamento(PeriodoAgrupamento item, int pIDUserLogin)
        {
            return _objPeriodoAgrupamentoDal.AlterarPeriodoAgrupamento(item, pIDUserLogin);
        }
        public PeriodoAgrupamento InativarPeriodoAgrupamento(int idPeriodoAgrupamento, int pIDUserLogin)
        {
            return _objPeriodoAgrupamentoDal.InativarPeriodoAgrupamento(idPeriodoAgrupamento, pIDUserLogin);
        }
    }
}