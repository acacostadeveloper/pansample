﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class TipoMensagemBusinessLayer : ITipoMensagemBusinessLayer
    {
        private ITipoMensagemDataAccessLayer _objTipoMensagemDal;
        public TipoMensagemBusinessLayer(ITipoMensagemDataAccessLayer objTipoMensagemDal)
        {
            _objTipoMensagemDal = objTipoMensagemDal;
        }
        public IEnumerable<TipoMensagemLista> ObterTipoMensagem(TipoMensagem item)
        {
            return _objTipoMensagemDal.ObterTipoMensagem(item);
        }
        //---------------------------------------------------------------------- LISTA com ID
        public TipoMensagem ObterTipoMensagem(int pID)
        {
            return _objTipoMensagemDal.ObterTipoMensagem(pID);
        }
        //---------------------------------------------------------------------- LISTA com DESCRICAO
        public TipoMensagem ObterTipoMensagem(string pTexto)
        {
            return _objTipoMensagemDal.ObterTipoMensagem(pTexto);
        }
        //---------------------------------------------------------------------- LISTA com FILTRO
        public TipoMensagem InserirTipoMensagem(TipoMensagem item, int pIDUserLogin)
        {
            return _objTipoMensagemDal.InserirTipoMensagem(item, pIDUserLogin);
        }
        public TipoMensagem AlterarTipoMensagem(TipoMensagem item, int pIDUserLogin)
        {
            return _objTipoMensagemDal.AlterarTipoMensagem(item, pIDUserLogin);
        }
        public TipoMensagem InativarTipoMensagem(int idTipoMensagem, int pIDUserLogin)
        {
            return _objTipoMensagemDal.InativarTipoMensagem(idTipoMensagem, pIDUserLogin);
        }
    }
}