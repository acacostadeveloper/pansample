﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface ITipoMensagemBusinessLayer
    {
        IEnumerable<TipoMensagemLista> ObterTipoMensagem   (TipoMensagem item);
        TipoMensagem                   ObterTipoMensagem   (int pID);
        TipoMensagem                   ObterTipoMensagem   (string pTexto);
        TipoMensagem                   InserirTipoMensagem (TipoMensagem item , int pIDUserLogin);
        TipoMensagem                   AlterarTipoMensagem (TipoMensagem item , int pIDUserLogin);
        TipoMensagem                   InativarTipoMensagem(int idTipoMensagem, int pIDUserLogin);
    }
}
