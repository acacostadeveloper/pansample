﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface IInstituicaoFinanceiraBusinessLayer
    {
        IEnumerable<InstituicaoFinanceiraLista> ObterInstituicaoFinanceira   (InstituicaoFinanceira item);
        InstituicaoFinanceira                   ObterInstituicaoFinanceira   (int pID);
        InstituicaoFinanceira                   ObterInstituicaoFinanceira   (string pTexto);
        InstituicaoFinanceira                   ObterInstituicaoFinancCNPJ   (string pCNPJ);
        InstituicaoFinanceira                   InserirInstituicaoFinanceira (InstituicaoFinanceira item , int pIDUserLogin);
        InstituicaoFinanceira                   AlterarInstituicaoFinanceira (InstituicaoFinanceira item , int pIDUserLogin);
        InstituicaoFinanceira                   InativarInstituicaoFinanceira(int idInstituicaoFinanceira, int pIDUserLogin);

    }
}
