﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface IListaNegraBusinessLayer
    {
        IEnumerable<ListaNegraLista> ObterListaNegra    (ListaNegra item);
        ListaNegra                   ObterListaNegra    (int pID);
        ListaNegra                   ObterListaNegra    (string pTexto);
        ListaNegra                   InserirListaNegra  (ListaNegra item , int pIDUserLogin);
        ListaNegra                   AlterarListaNegra  (ListaNegra item , int pIDUserLogin);
        ListaNegra                   InativarListaNegra (int idListaNegra, int pIDUserLogin);
        bool                         PesquisaListaNegra (string pCNPJ);
        bool                         PesqContaListaNegra(int pBanco, int pConta, int pAgencia);
    }
}
