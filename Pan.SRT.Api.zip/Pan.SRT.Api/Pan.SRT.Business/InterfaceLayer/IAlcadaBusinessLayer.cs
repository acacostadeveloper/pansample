﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface IAlcadaBusinessLayer
    {
        IEnumerable<AlcadaLista> ObterAlcada    (Alcada item);
        Alcada                   ObterAlcada    (int pID);
        Alcada                   ObterAlcada    (string pTexto);
        Alcada                   InserirAlcada  (Alcada item , int pIDUserLogin);
        Alcada                   AlterarAlcada  (Alcada item , int pIDUserLogin);
        Alcada                   InativarAlcada (int idAlcada, int pIDUserLogin);
    }
}
