﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface IPeriodoAgrupamentoBusinessLayer
    {
        IEnumerable<PeriodoAgrupamentoLista> ObterPeriodoAgrupamento   (PeriodoAgrupamento item);
        PeriodoAgrupamento                   ObterPeriodoAgrupamento   (int pID);
        PeriodoAgrupamento                   ObterPeriodoAgrupamento   (string pTexto);
        PeriodoAgrupamento                   InserirPeriodoAgrupamento (PeriodoAgrupamento item , int pIDUserLogin);
        PeriodoAgrupamento                   AlterarPeriodoAgrupamento (PeriodoAgrupamento item , int pIDUserLogin);
        PeriodoAgrupamento                   InativarPeriodoAgrupamento(int idPeriodoAgrupamento, int pIDUserLogin);
    }
}
