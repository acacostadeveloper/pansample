﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface ITipoOrigemBusinessLayer
    {
        IEnumerable<TipoOrigemLista> ObterTipoOrigem   (TipoOrigem item);
        TipoOrigem                   ObterTipoOrigem   (int pID);
        TipoOrigem                   ObterTipoOrigem   (string pTexto);
        TipoOrigem                   InserirTipoOrigem (TipoOrigem item , int pIDUserLogin);
        TipoOrigem                   AlterarTipoOrigem (TipoOrigem item , int pIDUserLogin);
        TipoOrigem                   InativarTipoOrigem(int idTipoOrigem, int pIDUserLogin);
    }
}
