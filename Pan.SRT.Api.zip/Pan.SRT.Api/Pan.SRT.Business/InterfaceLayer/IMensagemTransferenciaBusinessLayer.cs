﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface IMensagemTransferenciaBusinessLayer
    {
        IEnumerable<MensagemTransferenciaLista> ObterMensagemTransferencia (MensagemTransferenciaFiltro item);
        MensagemTransferencia                   ObterMensagemTransferencia (int pID);
        bool                                    StatusMensagemTransferencia(MensagemTransferenciaStatus item, int pIDUserLogin);
        MensagemResponse                        requisitaTED               (ParametrosTed               item, int pIDUserLogin, string pApiServiceEBank, string pApiServiceInfoBank);
    }
}
