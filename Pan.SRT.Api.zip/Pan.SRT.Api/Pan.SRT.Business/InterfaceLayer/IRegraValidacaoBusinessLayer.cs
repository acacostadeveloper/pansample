﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface IRegraValidacaoBusinessLayer
    {
        IEnumerable<RegraValidacaoLista> ObterRegraValidacao    (RegraValidacao item);
        RegraValidacao                   ObterRegraValidacao    (int pID);
        RegraValidacao                   ObterRegraValidacao    (string pTexto);
        RegraValidacao                   InserirRegraValidacao  (RegraValidacao item , int pIDUserLogin);
        RegraValidacao                   AlterarRegraValidacao  (RegraValidacao item , int pIDUserLogin);
        RegraValidacao                   InativarRegraValidacao (int idRegraValidacao, bool pAtivar, int pIDUserLogin);
    }
}
