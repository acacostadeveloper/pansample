﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface ITipoDestinoBusinessLayer
    {
        IEnumerable<TipoDestinoLista> ObterTipoDestino   (TipoDestino item);
        TipoDestino                   ObterTipoDestino   (int pID);
        TipoDestino                   ObterTipoDestino   (string pTexto);
        TipoDestino                   InserirTipoDestino (TipoDestino item , int pIDUserLogin);
        TipoDestino                   AlterarTipoDestino (TipoDestino item , int pIDUserLogin);
        TipoDestino                   InativarTipoDestino(int idTipoDestino, int pIDUserLogin);
    }
}
