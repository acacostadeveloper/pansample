﻿using System.Collections.Generic;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business.InterfaceLayer
{
    public interface ITipoAgrupamentoBusinessLayer
    {
        IEnumerable<TipoAgrupamentoLista> ObterTipoAgrupamento    (TipoAgrupamento item);
        TipoAgrupamento                   ObterTipoAgrupamento    (int pID);
        TipoAgrupamento                   ObterTipoAgrupamento    (string pTexto);
        TipoAgrupamento                   InserirTipoAgrupamento  (TipoAgrupamento item , int pIDUserLogin);
        TipoAgrupamento                   AlterarTipoAgrupamento  (TipoAgrupamento item , int pIDUserLogin);
        TipoAgrupamento                   InativarTipoAgrupamento (int idTipoAgrupamento, int pIDUserLogin);
    }
}
