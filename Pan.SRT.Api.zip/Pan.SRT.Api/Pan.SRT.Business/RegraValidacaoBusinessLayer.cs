﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class RegraValidacaoBusinessLayer : IRegraValidacaoBusinessLayer
    {
        private IRegraValidacaoDataAccessLayer _objRegraValidacaoDal;
        public RegraValidacaoBusinessLayer(IRegraValidacaoDataAccessLayer objRegraValidacaoDal)
        {
            _objRegraValidacaoDal = objRegraValidacaoDal;
        }
        public IEnumerable<RegraValidacaoLista> ObterRegraValidacao(RegraValidacao item)
        {
            return _objRegraValidacaoDal.ObterRegraValidacao(item);
        }
        public RegraValidacao ObterRegraValidacao(int pID)
        {
            return _objRegraValidacaoDal.ObterRegraValidacao(pID);
        }
        public RegraValidacao ObterRegraValidacao(string pTexto)
        {
            return _objRegraValidacaoDal.ObterRegraValidacao(pTexto);
        }
        public RegraValidacao InserirRegraValidacao(RegraValidacao item, int pIDUserLogin)
        {
            return _objRegraValidacaoDal.InserirRegraValidacao(item, pIDUserLogin);
        }
        public RegraValidacao AlterarRegraValidacao(RegraValidacao item, int pIDUserLogin)
        {
            return _objRegraValidacaoDal.AlterarRegraValidacao(item, pIDUserLogin);
        }
        public RegraValidacao InativarRegraValidacao(int idRegraValidacao, bool pAtivar, int pIDUserLogin)
        {
            return _objRegraValidacaoDal.InativarRegraValidacao(idRegraValidacao, pAtivar, pIDUserLogin);
        }
    }
}