﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class EntidadeBusinessLayer : IEntidadeBusinessLayer
    {
        private IEntidadeDataAccessLayer _objEntidadeDal;
        public EntidadeBusinessLayer(IEntidadeDataAccessLayer objEntidadeDal)
        {
            _objEntidadeDal = objEntidadeDal;
        }
        public IEnumerable<EntidadeLista> ObterEntidade(Entidade item)
        {
            return _objEntidadeDal.ObterEntidade(item);
        }
        public Entidade ObterEntidade(int pID)
        {
            return _objEntidadeDal.ObterEntidade(pID);
        }
        public Entidade ObterEntidade(string pTexto)
        {
            return _objEntidadeDal.ObterEntidade(pTexto);
        }
        public Entidade InserirEntidade(Entidade item, int pIDUserLogin)
        {
            return _objEntidadeDal.InserirEntidade(item, pIDUserLogin);
        }
        public Entidade AlterarEntidade(Entidade item, int pIDUserLogin)
        {
            return _objEntidadeDal.AlterarEntidade(item, pIDUserLogin);
        }
        public Entidade InativarEntidade(int idEntidade, int pIDUserLogin)
        {
            return _objEntidadeDal.InativarEntidade(idEntidade, pIDUserLogin);
        }
    }
}