﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pan.SRT.Business.InterfaceLayer;
using Pan.SRT.Data;
using Pan.SRT.Data.InterfaceDataAccess;
using Pan.SRT.Entidades;

namespace Pan.SRT.Business
{
    public class RegraValidaClausulaBusinessLayer : IRegraValidaClausulaBusinessLayer
    {
        private IRegraValidaClausulaDataAccessLayer _objRegraValidaClausulaDal;
        public RegraValidaClausulaBusinessLayer(IRegraValidaClausulaDataAccessLayer objRegraValidaClausulaDal)
        {
            _objRegraValidaClausulaDal = objRegraValidaClausulaDal;
        }
        public IEnumerable<RegraValidaClausulaLista> ObterRegraValidaClausula(RegraValidaClausula item)
        {
            return _objRegraValidaClausulaDal.ObterRegraValidaClausula(item);
        }
        public RegraValidaClausula ObterRegraValidaClausula(int pID)
        {
            return _objRegraValidaClausulaDal.ObterRegraValidaClausula(pID);
        }
        public RegraValidaClausula InserirRegraValidaClausula(RegraValidaClausula item, int pIDUserLogin)
        {
            return _objRegraValidaClausulaDal.InserirRegraValidaClausula(item, pIDUserLogin);
        }
        public RegraValidaClausula AlterarRegraValidaClausula(RegraValidaClausula item, int pIDUserLogin)
        {
            return _objRegraValidaClausulaDal.AlterarRegraValidaClausula(item, pIDUserLogin);
        }
        public RegraValidaClausula InativarRegraValidaClausula(int idRegraValidaClausula, int pIDUserLogin)
        {
            return _objRegraValidaClausulaDal.InativarRegraValidaClausula(idRegraValidaClausula, pIDUserLogin);
        }
    }
}