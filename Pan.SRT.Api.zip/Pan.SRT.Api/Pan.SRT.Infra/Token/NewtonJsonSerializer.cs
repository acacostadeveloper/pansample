﻿using Newtonsoft.Json;

namespace Pan.SRT.Infra.Token
{
    /// <summary>
    /// Classe para serializar e Deserializar json
    /// </summary>
    public class NewtonJsonSerializer : IJsonSerializer
    {
        public string Serialize(object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }

        public T Deserialize<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }
    }
}