﻿using RestSharp;

namespace Pan.SRT.Infra.Token
{
    public class TokenPegar
    {
        /*===========================================================================================================
        // Programa...:  TesteRetornaToken - Retorno string de token do usuario e senha
        // Autor......:  Edinaldo Silva (IT Singular)
        // Data.......:  30.05.2018
        ===========================================================================================================*/
        public string StringTokenPegar()
        {
            string pApiServiceRestritivo = "http://restritivosdes.grupopan.com:35023";
            string pApiServiceLogin      = "14873816890";
            string pApiServiceSenha      = "YLYJED4RzkUatDN8B4MKgA==";
          //string pApiServiceLoginVand  = "800041316";
          //string pApiServiceSenhaVand  = "hTdGrbcryTImb1/jF1FMlA==";

            string pRetorna = "";                          //Apos informar usuario e senha, tem que guardar o token
            var client      = new RestClient(pApiServiceRestritivo + "/api/token");
            var request     = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddHeader   ("cache-control"     , "no-cache");
            request.AddHeader   ("content-type"      , "application/json");
            request.AddHeader   ("Skip-Authorization", "true");
            request.AddParameter("authorization"     , "{\"Login\":\"" + pApiServiceLogin + "\", \"Senha\":\"" + pApiServiceSenha + "\"}", ParameterType.RequestBody);
            request.AddParameter("application/json"  , "{\n\"grant_type\":\"client_credentials\"\n}", ParameterType.RequestBody);

            IRestResponse response = client.Execute(request);
            if (response.ContentLength >= 200)
            {
                var bRetorno = response.Content.ToString();
                var bRetLimpo = bRetorno.Replace("\"", "");
                string[] campos = bRetLimpo.Split(',');
                foreach (string value in campos)
                {
                    if (value.Substring(0, 6) == "token:")
                    {
                        pRetorna = value.Substring(6, (value.Length - 6));
                    }
                }
            }
            return pRetorna;    
        }
    }
}
