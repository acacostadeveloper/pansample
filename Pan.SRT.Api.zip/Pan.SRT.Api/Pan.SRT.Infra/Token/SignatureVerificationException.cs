﻿using System;

namespace Pan.SRT.Infra.Token
{
    /// <summary>
    /// Classe para verificar assinatura do token
    /// </summary>
    public class SignatureVerificationException : Exception
    {
        public SignatureVerificationException(string message)
            : base(message)
        {
        }
    }


    /// <summary>
    /// Edinaldo IT Singular 30.04.2018 - Token expirado
    /// Classe para verificar assinatura do token
    /// </summary>
    public class ExpiredVerificationException : Exception
    {
        public ExpiredVerificationException(string message)
            : base(message)
        {
        }
    }
}