﻿using System;
using System.Net;
using System.Web;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.ServiceModel;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Web.Configuration;



namespace Pan.SRT.Infra.Token
{
    public class Auth
    {
        public int Authorize()
        {
            int bRetUsu    = 0;
            var token      = HttpContext.Current.Request.Headers["Authorization"];
            var pHeader    = Convert.ToString(HttpContext.Current.Request.Headers);
            var pMetodo    = HttpContext.Current.Request.HttpMethod;
            var pIP        = HttpContext.Current.Request.UserHostAddress;
            var pUrl       = Convert.ToString(HttpContext.Current.Request.Url);
            if (token == null)
            {
                Exception ex = new Exception("Acesso Negado: Não foi encontrado o token desta requisição!");
                Log.LoggerErroTransacao("", pIP, "Acesso Negado: Não foi encontrado o token desta requisição!", pMetodo, pUrl, ex.ToString());
                string desc_erro = ex.Message;
                GenericError desc = new GenericError(desc_erro);
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ContentType = "application/json";
                HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                HttpContext.Current.Response.StatusDescription = desc_erro;
                HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                HttpContext.Current.Response.End();
            }
            else
            {
                try
                {
                    String _keyCrypto = String.Empty;
                    _keyCrypto = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");
                    token      = token.Replace("Bearer ", "");
                    bRetUsu    = JsonWebToken.DecodeTokenUsuario(token, _keyCrypto, true);
                    return bRetUsu;
                }
                catch (ArgumentException ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Token inválido::", pMetodo, pUrl, ex.Message);
                    string desc_erro = "Acesso Negado: Token inválido.";
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
                catch (SignatureVerificationException ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Problema na assinatura do Token::", pMetodo, pUrl, ex.ToString());
                    string desc_erro = "Acesso Negado: Problema na assinatura do Token.";
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
                catch (ExpiredVerificationException ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Token expirado::", pMetodo, pUrl, ex.Message);
                    string desc_erro = "Acesso Negado: Token expirado.";
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
                catch (Exception ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Problema na assinatura do Token::", pMetodo, pUrl, ex.Message);
                    string desc_erro = ex.Message;
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.BadRequest.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
            }
            return bRetUsu;
        }









        /*===========================================================================================================
        // Programa...:  AuthorizeADGroup - Verifica se usuario tem permissao na politica do AD
        // Autor......:  Edinaldo Silva (IT Singular)
        // Data.......:  30.06.2018
        ===========================================================================================================*/
        public bool AuthorizeADGroup()
        {
            bool bRetGroup = false;
            var  token     = HttpContext.Current.Request.Headers["Authorization"];
            if (token != null)
            {
                var keyCrypto  = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");
                var pHeader    = Convert.ToString(HttpContext.Current.Request.Headers);
                var pMetodo    = HttpContext.Current.Request.HttpMethod;
                var pIP        = HttpContext.Current.Request.UserHostAddress;
                var pUrl       = Convert.ToString(HttpContext.Current.Request.Url);
                try
                {
                    token     = token.Replace("Bearer ", "");
                    bRetGroup = JsonWebToken.DecodeTokenUsuarioADGroup(token, keyCrypto);
                }
                catch (ArgumentException ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Token inválido::", pMetodo, pUrl, ex.Message);
                    string desc_erro = "Acesso Negado: Token inválido.";
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
                catch (SignatureVerificationException ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Problema na assinatura do Token::", pMetodo, pUrl, ex.ToString());
                    string desc_erro = "Acesso Negado: Problema na assinatura do Token.";
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
                catch (ExpiredVerificationException ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Token expirado::", pMetodo, pUrl, ex.Message);
                    string desc_erro = "Acesso Negado: Token expirado.";
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
                catch (Exception ex)
                {
                    Log.LoggerErroTransacao("", pIP, "Acesso Negado: Problema na assinatura do Token::", pMetodo, pUrl, ex.Message);
                    string desc_erro = ex.Message;
                    GenericError desc = new GenericError(desc_erro);
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.Response.StatusCode = HttpStatusCode.BadRequest.GetHashCode();
                    HttpContext.Current.Response.StatusDescription = desc_erro;
                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
                    HttpContext.Current.Response.End();
                }
            }
            return bRetGroup;
        }




        // from JWT spec
        private static byte[] Base64UrlDecode(string input)
        {
            var output = input;
            output = output.Replace('-', '+'); // 62nd char of encoding
            output = output.Replace('_', '/'); // 63rd char of encoding
            switch (output.Length % 4) // Pad with trailing '='s
            {
                case 0: break; // No pad chars in this case
                case 2: output += "=="; break; // Two pad chars
                case 3: output += "="; break;  // One pad char
                default: throw new Exception("Illegal base64url string!");
            }
            var converted = Convert.FromBase64String(output); // Standard base64 decoder
            return converted;
        }
    }
}
