﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Pan.SRT.Infra
{
    /// <summary>
    /// Classe para genreciamento de erro genérico
    /// </summary>
    public class GenericError
    {

        public List<string> errors { get; set; }

        public GenericError()
        {
            errors = new List<string>();
        }

        public GenericError(string error)
        {
            errors = new List<string>();
            errors.Add(error);
        }
    }

}
