﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Pan.SRT.Entidades;



namespace Pan.SRT.Infra
{
    public class LogRepository
    {
        public static void AddLog(Logguer log)
        {
            Task.Factory.StartNew(() =>
            {
                var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["PanRestritivosLogs"].ConnectionString);
                const string query =
                    "INSERT INTO [dbo].[LogsRestritivoWebAPI] ([Application],[CorrelationId],[Machine],[IpAddress],[RequestUri],[StatusCode],[RequestTimestamp],[ResponseTimestamp],[TotalTime],[JsonLog],[MessageError]) " +
                                                     " VALUES (@Application ,@CorrelationId ,@Machine ,@IpAddress ,@RequestUri ,@StatusCode ,@RequestTimestamp ,@ResponseTimestamp ,@TotalTime ,@JsonLog ,@MessageError ) ";

                using (var commando = new SqlCommand(query, conn))
                {
                    try
                    {
                        try
                        { 
                            if (conn.State == ConnectionState.Closed) conn.Open();
                            commando.Parameters.AddWithValue("@Application"      , log.Application);
                            commando.Parameters.AddWithValue("@CorrelationId"    , log.CorrelationId);
                            commando.Parameters.AddWithValue("@Machine"          , log.Machine);
                            commando.Parameters.AddWithValue("@IpAddress"        , log.IpAddress);
                            commando.Parameters.AddWithValue("@RequestUri"       , log.RequestUri);
                            commando.Parameters.AddWithValue("@StatusCode"       , log.ResponseStatusCode);
                            commando.Parameters.AddWithValue("@RequestTimestamp" , log.RequestTimestamp);
                            commando.Parameters.AddWithValue("@ResponseTimestamp", log.ResponseTimestamp);
                            commando.Parameters.AddWithValue("@TotalTime"        , Convert.ToDateTime(log.TotalTime));
                            commando.Parameters.AddWithValue("@JsonLog"          , JsonConvert.SerializeObject(log, Formatting.Indented));
                            commando.Parameters.AddWithValue("@MessageError"     , log.MessageError);
                            commando.ExecuteNonQuery();
                        }
                        catch (Exception)
                        {
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            });
        } 
    }
}