﻿using System;
using System.Threading.Tasks;
using Pan.SRT.Helpers;
using Pan.SRT.Entidades;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Linq;


namespace Pan.SRT.Infra
{
    public class Log
    {

        public static void LoggerErroTransacao(string pUserName, string pIP, string HttpHeader, string requestMetodo, string requestURL, string MessageError)
        {
            Logguer logNew            = new Logguer();
            logNew.Application        = "RESTRITIVO.SRT-API";
            logNew.CorrelationId      = Guid.NewGuid();
            logNew.User               = pUserName;
            logNew.Machine            = Environment.MachineName;
            logNew.IpAddress          = pIP;
            logNew.RequestMethod      = requestMetodo;
            logNew.RequestHeaders     = new Dictionary<string, string>();
            logNew.RequestTimestamp   = DateTime.Now;
            logNew.RequestUri         = requestURL;
            logNew.MessageError       = MessageError;
            logNew.ResponseTimestamp  = DateTime.Now;
            logNew.RequestTimestamp   = DateTime.Now;
            logNew.ResponseStatusCode = 400;
            LogRepository.AddLog(logNew);
        }
    }
}
