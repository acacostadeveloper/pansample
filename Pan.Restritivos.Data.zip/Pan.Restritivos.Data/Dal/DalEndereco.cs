﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Endereço
    /// </summary>
    public class DalEndereco : IDalBase<Endereco>
    {
        public Endereco Alterar(Endereco item)
        {
            EnderecoRepository _Repository = new EnderecoRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

      

        public bool Inativar(Endereco item)
        {
            EnderecoRepository _Repository = new EnderecoRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Endereco Inserir(Endereco item)
        {

            EnderecoRepository _Repository = new EnderecoRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<Endereco> Listar(Endereco item)
        {
            EnderecoRepository _Repository = new EnderecoRepository();
            List<Endereco> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Endereco> ListarLog(int id)
        {
            EnderecoRepository _Repository = new EnderecoRepository();
            List<Endereco> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Endereco Obter(Endereco item)
        {
            EnderecoRepository _Repository = new EnderecoRepository();
            Endereco ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(Endereco item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Endereco item)
        {
            throw new NotImplementedException();
        }
        
        public List<Endereco> Importar(List<Endereco> item)
        {
            throw new NotImplementedException();
        }

    }
}
