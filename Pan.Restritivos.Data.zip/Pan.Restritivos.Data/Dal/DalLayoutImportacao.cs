﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Layout de importação
    /// </summary>
    public class DalLayoutImportacao 
    {
        public List<LayoutImportacao> Listar(string pbase)
        {
            LayoutImportacaoRepository _Repository = new LayoutImportacaoRepository();
            List<LayoutImportacao> ret = null;
            try
            {
                ret = _Repository.Listar(pbase);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }


    }
}
