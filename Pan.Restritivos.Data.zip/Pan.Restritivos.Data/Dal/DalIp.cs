﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de IP
    /// </summary>
    public class DalIp : IDalBase<Ip>
    {
        public Ip Alterar(Ip item)
        {
            IpRepository _Repository = new IpRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

      

        public bool Inativar(Ip item)
        {
            IpRepository _Repository = new IpRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Ip Inserir(Ip item)
        {

            IpRepository _Repository = new IpRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<Ip> Listar(Ip item)
        {
            IpRepository _Repository = new IpRepository();
            List<Ip> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Ip> ListarLog(int id)
        {
            IpRepository _Repository = new IpRepository();
            List<Ip> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Ip Obter(Ip item)
        {
            IpRepository _Repository = new IpRepository();
            Ip ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(Ip item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Ip item)
        {
            throw new NotImplementedException();
        }
        
        public List<Ip> Importar(List<Ip> item)
        {
            throw new NotImplementedException();
        }

    }
}
