﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Telefone
    /// </summary>
    public class DalTelefone : IDalBase<Telefone>
    {
        public Telefone Alterar(Telefone item)
        {
            TelefoneRepository _Repository = new TelefoneRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<Telefone> Importar(List<Telefone> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Telefone item)
        {
            TelefoneRepository _Repository = new TelefoneRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Telefone Inserir(Telefone item)
        {
            TelefoneRepository _Repository = new TelefoneRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<Telefone> Listar(Telefone item)
        {
            TelefoneRepository _Repository = new TelefoneRepository();
            List<Telefone> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Telefone> ListarLog(int id)
        {
            TelefoneRepository _Repository = new TelefoneRepository();
            List<Telefone> ret = null;
            try
            {
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Telefone Obter(Telefone item)
        {
            TelefoneRepository _Repository = new TelefoneRepository();
            Telefone ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(Telefone item)
        {
            TelefoneRepository _Repository = new TelefoneRepository();
            bool ret = false;
            try
            {
                ret = _Repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(Telefone item)
        {
            throw new NotImplementedException();
        }
    }
}
