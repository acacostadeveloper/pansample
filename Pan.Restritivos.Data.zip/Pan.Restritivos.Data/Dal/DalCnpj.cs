﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de CNPJ
    /// </summary>
    public class DalCnpj : IDalBase<Cnpj>
    {
        public Cnpj Alterar(Cnpj item)
        {
            CnpjRepository _Repository = new CnpjRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

      

        public bool Inativar(Cnpj item)
        {
            CnpjRepository _Repository = new CnpjRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Cnpj Inserir(Cnpj item)
        {

            CnpjRepository _Repository = new CnpjRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<Cnpj> Listar(Cnpj item)
        {
            CnpjRepository _Repository = new CnpjRepository();
            List<Cnpj> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Cnpj> ListarLog(int id)
        {
            CnpjRepository _Repository = new CnpjRepository();
            List<Cnpj> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Cnpj Obter(Cnpj item)
        {
            CnpjRepository _Repository = new CnpjRepository();
            Cnpj ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(Cnpj item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Cnpj item)
        {
            throw new NotImplementedException();
        }
        
        public List<Cnpj> Importar(List<Cnpj> item)
        {
            throw new NotImplementedException();
        }

    }
}
