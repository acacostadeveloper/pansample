﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Data.SqlHelper;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Dado bancário
    /// </summary>
    public class DalContaBlacklist : IDalBase<ContaBlacklist>
    {

        public ContaBlacklist Alterar(ContaBlacklist item)
        {
            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();

            try
            {
                //item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public bool Inativar(ContaBlacklist item)
        {
            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();

            try
            {
                //item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ContaBlacklist Inserir(ContaBlacklist item)
        {

            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();

            try
            {
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<ContaBlacklist> Listar(ContaBlacklist item)
        {
            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();
            List<ContaBlacklist> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<ContaBlacklist> ListarLog(int id)
        {
            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();
            List<ContaBlacklist> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public ContaBlacklist Obter(ContaBlacklist item)
        {
            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();
            ContaBlacklist ret = null;
            try
            {
                //item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(ContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(ContaBlacklist item)
        {
            throw new NotImplementedException();
        }
        
        public List<ContaBlacklist> Importar(List<ContaBlacklist> item)
        {
            ContaBlacklistRepository _Repository = new ContaBlacklistRepository();
            
            try
            {
                item = _Repository.Importar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }
    }
}
