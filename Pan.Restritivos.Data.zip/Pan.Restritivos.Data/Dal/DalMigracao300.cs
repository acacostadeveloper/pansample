﻿using Pan.Restritivos.Data.SqlHelper;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Calsse de acesso a dados que define metôdos para importação de base 300
    /// </summary>
    public class DalMigracao300
    {
        SqlCommon _sql;
        DalCpf _DalCpf;

        public DalMigracao300()
        {
            _sql = new SqlCommon();
            _DalCpf = new DalCpf();
        }

        public List<Migracao300> BuscarBase()
        {
            try
            {

                return _sql.ReadData<Migracao300>("select SC_CPF_CLIENTE,SC_DESC_ANTPEN_ALERTA,SC_DESC_ULT_ALERTA " +
                                        "from " +
                                        "	ttbteste" +
                                        "where" +
                                        "	(" +
                                    "		SC_DESC_ULT_ALERTA in ('PEDALADAS' ,'OBITO', 'BASE_PANJUR', 'REV_EX') " +
                                    "	and " +
                                            "SC_DESC_ANTPEN_ALERTA = 'FRAUDES'" +
                                            ")" +
                                        "OR" +
                                        "	(" +
                                    "		SC_DESC_ULT_ALERTA in ('FRAUDE_CONF' ,'SUS_FRAUDE', 'AUT_FRAUDE', 'CLI_IND') " +
                                            ")"
        );
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int ImportarBase(Migracao300 item)
        {
            int count = 0;
            try
            {
                Dictionary<string, string> param = new Dictionary<string, string>();

                param.Add("@nr_cpf", item.SC_CPF_CLIENTE);
                param.Add("@motivo", item.SC_DESC_ULT_ALERTA);


                _sql.Insert("sp_inserirImportacaoBase300", param);

                return count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int SalvarImportcao()
        {
            int count = 0;
            try
            {
                count = _sql.ExecNoReturn("sp_ValidarImportacao300");
                return count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void OpenTransaction()
        {
            _sql.OpenTransaction();
        }
        public void OpenConnection(string conn)
        {
            _sql.OpenConnection(conn);
        }
        public void CloseConnection()
        {
            _sql.CloseConnection();
        }

        public void CommitTransaction()
        {
            _sql.CommitTransaction();
        }

        public void RoolbackTransaction()
        {
            _sql.RoolbackTransaction();
        }

    }
}
