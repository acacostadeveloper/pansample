﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Código de barras
    /// </summary>
    public class DalCodigoBarra : IDalBase<CodigoBarra>
    {
        public CodigoBarra Alterar(CodigoBarra item)
        {
            CodigoBarraRepository _Repository = new CodigoBarraRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

      

        public bool Inativar(CodigoBarra item)
        {
            CodigoBarraRepository _Repository = new CodigoBarraRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CodigoBarra Inserir(CodigoBarra item)
        {

            CodigoBarraRepository _Repository = new CodigoBarraRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<CodigoBarra> Listar(CodigoBarra item)
        {
            CodigoBarraRepository _Repository = new CodigoBarraRepository();
            List<CodigoBarra> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<CodigoBarra> ListarLog(int id)
        {
            CodigoBarraRepository _Repository = new CodigoBarraRepository();
            List<CodigoBarra> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public CodigoBarra Obter(CodigoBarra item)
        {
            CodigoBarraRepository _Repository = new CodigoBarraRepository();
            CodigoBarra ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(CodigoBarra item)
        {
            CodigoBarraRepository _Repository = new CodigoBarraRepository();
            bool ret = false;
            try
            {
                ret = _Repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(CodigoBarra item)
        {
            throw new NotImplementedException();
        }
        
        public List<CodigoBarra> Importar(List<CodigoBarra> item)
        {
            throw new NotImplementedException();
        }

    }
}
