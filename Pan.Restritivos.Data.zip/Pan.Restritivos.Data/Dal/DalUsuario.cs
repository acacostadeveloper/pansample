﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Data;
using Pan.Restritivos.Data.Repositories.User;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Usuário
    /// </summary>
    public class DalUsuario : IDalBase<Usuario>
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();


        #region Usuario
        public Usuario Alterar(Usuario item)
        {

            UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
            UsuarioItemAcessoRepository _UsuarioItemAcessoRepository = new UsuarioItemAcessoRepository(unitOfWork);

            if (item.idUsuarioInclusao == 0)
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.idUsuarioInclusao = 3;
                item.DtUsuarioInclusao = DateTime.Now;
            }

            unitOfWork.OpenConnection();
            using (DbTransaction _transaction = unitOfWork.BeginTransaction())
            {
                try
                {
                    var update = _repository.Alterar(item);

                    _transaction.Commit();
                    unitOfWork.CloseConnection();
                    return item;
                }
                catch (Exception ex)
                {
                    _transaction.Rollback();
                    unitOfWork.CloseConnection();
                    throw ex;
                }
            }
        }
        public bool ExcluirItemAcesso(int idUsuario)
        {
            UsuarioItemAcessoRepository _UsuarioItemAcessoRepository = new UsuarioItemAcessoRepository(unitOfWork);
            bool temp = false;
         
                try
                {
                    temp = _UsuarioItemAcessoRepository.Excluir(idUsuario);
                    temp = true;
                }
                catch (Exception ex)
                {
          
                    throw ex;
                }
                return temp;
        
        }

     
        public List<Usuario> Importar(List<Usuario> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Usuario item)
        {
            UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
            bool ret = false;
            unitOfWork.OpenConnection();
            using (DbTransaction _transaction = unitOfWork.BeginTransaction())
            {
                try
                {
                    ret = _repository.Inativar(item);
                    _transaction.Commit();
                    unitOfWork.CloseConnection();
                }
                catch (Exception ex)
                {
                    _transaction.Rollback();
                    unitOfWork.CloseConnection();
                    throw ex;
                }
                return ret;
            }
        }

        public Usuario Inserir(Usuario item)
        {
            UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
            UsuarioItemAcessoRepository _UsuarioItemAcessoRepository = new UsuarioItemAcessoRepository(unitOfWork);

            item.DtUsuarioInclusao = DateTime.Now;
            item.idUsuarioInclusao = item.idUsuarioInclusao;
            item.blnAtivo          = true;

            unitOfWork.OpenConnection();
            using (DbTransaction _transaction = unitOfWork.BeginTransaction())
            {
                try
                {
                    item = _repository.Inserir(item);
                    _transaction.Commit();
                    unitOfWork.CloseConnection();
                    return item;
                }
                catch (Exception ex)
                {
                    _transaction.Rollback();
                    unitOfWork.CloseConnection();
                    throw ex;
                }
            }
        }



        public UsuarioItemAcesso InserirItemAcesso(UsuarioItemAcesso item)
        {
            UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
            UsuarioItemAcessoRepository _UsuarioItemAcessoRepository = new UsuarioItemAcessoRepository(unitOfWork);
            UsuarioItemAcesso temp = null;

            unitOfWork.OpenConnection();
            using (DbTransaction _transaction = unitOfWork.BeginTransaction())
            {
                try
                {
                    temp = _UsuarioItemAcessoRepository.Inserir(item);
                    _transaction.Commit();
                    unitOfWork.CloseConnection();

                }
                catch (Exception ex)
                {
                    _transaction.Rollback();
                    unitOfWork.CloseConnection();
                    throw ex;
                }
                return temp;
            }
        }
        public List<Usuario> Listar(Usuario item)
        {
            try
            {
                UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Usuario> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Usuario Obter(Usuario item)
        {
            try
            {
                UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
                return _repository.Obter(item);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool Validar(Usuario item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Usuario item)
        {
            throw new NotImplementedException();
        }

        public int getIdUserbyLogin(string login)
        {
            try
            {
                UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
                return _repository.getIdUserbyLogin(login);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool verificaUsuarioAtivo(string login)
        {
            try
            {
                UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
                return _repository.verificaUsuarioAtivo(login);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Usuario getuser(int iduser)
        {
            try
            {
                UsuarioRepository _repository = new UsuarioRepository(unitOfWork);
                return _repository.getuser(iduser);
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        
        #region Acesso
        public bool RemoverAcesso(UsuarioItemAcesso UsuarioItemAcesso)
        {
            bool retorno = false;
            try
            {
                UsuarioItemAcessoRepository _repository = new UsuarioItemAcessoRepository(unitOfWork);
                _repository.Inativar(UsuarioItemAcesso);
                retorno = true;
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;

        }

        public bool AddAcesso(UsuarioItemAcesso UsuarioItemAcesso)
        {
            bool retorno = false;
            try
            {
                UsuarioItemAcessoRepository _repository = new UsuarioItemAcessoRepository(unitOfWork);
                _repository.Inserir(UsuarioItemAcesso);
                retorno = true;
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;

        }

        public List<Acessos> getaccesspage(int idusuario)
        {
            List<Acessos> retorno = null;
            try
            {
                UsuarioItemAcessoRepository _repository = new UsuarioItemAcessoRepository(unitOfWork);
                retorno = _repository.getaccesspage(idusuario);
                return retorno;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Acessos> ListaFuncionalidades()
        {
            List<Acessos> retorno = null;
            try
            {
                UsuarioItemAcessoRepository _repository = new UsuarioItemAcessoRepository(unitOfWork);
                retorno = _repository.ListaFuncionalidades();
                return retorno;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion


        #region Sessão
        public void iniciarSessao(int sessionID, string login, string token, DateTime dtUltimaRequisicao)
        {
            try
            {
                SessaoUsuarioRepository _Repository = new SessaoUsuarioRepository(unitOfWork);
                _Repository.Inserir(new Sessaousuario()
                {
                    idSession = sessionID,
                    login = login,
                    token = token,
                    dtultimarequisicao = dtUltimaRequisicao
                });
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void atualizarSessao(int sessionID, string login, string token, DateTime dtUltimaRequisicao)
        {

            try
            {
                SessaoUsuarioRepository _Repository = new SessaoUsuarioRepository(unitOfWork);
                //_Repository.
                _Repository.Alterar(new Sessaousuario()
                {
                    idSession          = sessionID,
                    login              = login,
                    token              = token,
                    dtultimarequisicao = dtUltimaRequisicao
                });
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void limparSessao(string login, int sessionID)
        {
            try
            {
                SessaoUsuarioRepository _Repository = new SessaoUsuarioRepository(unitOfWork);
                Sessaousuario temp = new Sessaousuario() { login = login, idSession = sessionID };

                _Repository.limparSessao(temp);

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public CustomToken obterSessao(string login, int sessionID)
        {
            CustomToken _CustomToken = new CustomToken();
            try
            {
                SessaoUsuarioRepository _Repository = new SessaoUsuarioRepository(unitOfWork);

                Sessaousuario filter = new Sessaousuario();
                filter.idSession = sessionID;
                filter.login = login;


                Sessaousuario temp = _Repository.Listar(filter).FirstOrDefault();

                if (temp != null)
                {
                    _CustomToken.IDUsuario          = getIdUserbyLogin(temp.login);           //EGS 30.04.2018 Informar tambem o ID do usuario no Token
                    _CustomToken.SessionId          = temp.idSession;
                    _CustomToken.Login              = temp.login;
                    _CustomToken.token              = temp.token;
                    _CustomToken.DtUltimaRequisicao = temp.dtultimarequisicao;
                }
                return _CustomToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        public void Dispose()
        {

        }

    }
}
