﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de CPF
    /// </summary>
    public class DalCpf : IDalBase<Cpf>
    {
        public Cpf Alterar(Cpf item)
        {
            CpfRepository _Repository = new CpfRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

      

        public bool Inativar(Cpf item)
        {
            CpfRepository _Repository = new CpfRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {             
                throw ex;
            }
        }

        public Cpf Inserir(Cpf item)
        {

            CpfRepository _Repository = new CpfRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<Cpf> Listar(Cpf item)
        {
            CpfRepository _Repository = new CpfRepository();
            List<Cpf> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Cpf> ListarLog(int id)
        {
            CpfRepository _Repository = new CpfRepository();
            List<Cpf> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Cpf Obter(Cpf item)
        {
            CpfRepository _Repository = new CpfRepository();
            Cpf ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(Cpf item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Cpf item)
        {
            throw new NotImplementedException();
        }
        
        public List<Cpf> Importar(List<Cpf> item)
        {
            throw new NotImplementedException();
        }

    }
}
