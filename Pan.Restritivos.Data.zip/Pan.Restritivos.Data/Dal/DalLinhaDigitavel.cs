﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Linha Digitável
    /// </summary>
    public class DalLinhaDigitavel : IDalBase<LinhaDigitavel>
    {
        public LinhaDigitavel Alterar(LinhaDigitavel item)
        {
            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

      

        public bool Inativar(LinhaDigitavel item)
        {
            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
               return _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LinhaDigitavel Inserir(LinhaDigitavel item)
        {

            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        public List<LinhaDigitavel> Listar(LinhaDigitavel item)
        {
            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();
            List<LinhaDigitavel> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<LinhaDigitavel> ListarLog(int id)
        {
            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();
            List<LinhaDigitavel> ret = null;
            try
            {   
                ret = _Repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public LinhaDigitavel Obter(LinhaDigitavel item)
        {
            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();
            LinhaDigitavel ret = null;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(LinhaDigitavel item)
        {
            LinhaDigitavelRepository _Repository = new LinhaDigitavelRepository();
            bool ret = false;
            try
            {
                ret = _Repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(LinhaDigitavel item)
        {
            throw new NotImplementedException();
        }
        
        public List<LinhaDigitavel> Importar(List<LinhaDigitavel> item)
        {
            throw new NotImplementedException();
        }

    }
}
