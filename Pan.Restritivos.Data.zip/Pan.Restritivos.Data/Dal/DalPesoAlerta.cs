﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Peso de alerta
    /// </summary>
    public class DalPesoAlerta : IDalBase<Peso>
    {
        public Peso Alterar(Peso item)
        {
            PesoAlertaRepository _Repository = new PesoAlertaRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item = _Repository.Alterar(item);
            }
            catch (Exception ex)
        {
                throw ex;
        }
            return item;

        }

        public List<Peso> Importar(List<Peso> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Peso item)
        {
            PesoAlertaRepository _Repository = new PesoAlertaRepository();
            bool ret = false;
            try
            {
                item.dtManutencao = DateTime.Now;
                ret = _Repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Peso Inserir(Peso item)
        {
            PesoAlertaRepository _Repository = new PesoAlertaRepository();

            try
            {
                item.dtManutencao = DateTime.Now;
                item.blnAtivo = true;
                item = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;

        }

        public List<Peso> Listar(Peso item)
        {
            PesoAlertaRepository _Repository = new PesoAlertaRepository();
            List<Peso> ret = null;
            try
            {
                ret = _Repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Peso> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Peso Obter(Peso item)
        {
            PesoAlertaRepository _Repository = new PesoAlertaRepository();
            Peso ret = null;
            try
            {
                ret = _Repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(Peso item)
        {
            try
            {
                PesoAlertaRepository _Repository = new PesoAlertaRepository();
                return _Repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(Peso item)
        {
            throw new NotImplementedException();

        }
    }
}
