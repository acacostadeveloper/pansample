﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados da base de Motivo de alerta
    /// </summary>
    public class DalMotivoAlerta : IDalBase<Motivo>
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();

        public Motivo Alterar(Motivo item)
        {
            MotivoAlertaRepository _repository = new MotivoAlertaRepository(unitOfWork);           

            item.dtManutencao = DateTime.Now;          

            unitOfWork.OpenConnection();
            using (DbTransaction _transaction = unitOfWork.BeginTransaction())
            {
                try
                {
                    var update = _repository.Alterar(item);                                                          
                                        
                    unitOfWork.CloseConnection();
                    return update;
                }
                catch (Exception ex)
                {                 
                    unitOfWork.CloseConnection();
                    throw ex;
                }
            }
        }

        public List<Motivo> Importar(List<Motivo> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Motivo item)
        {
            MotivoAlertaRepository _repository = new MotivoAlertaRepository(unitOfWork);
            bool ret = false;
            //item.dtManutencao = DateTime.Now;
            //item.blnAtivo = false;
            unitOfWork.OpenConnection();           
            try
                {
                    ret = _repository.Inativar(item);
                    unitOfWork.CloseConnection();
                }
                catch (Exception ex)
                {
                    unitOfWork.CloseConnection();
                    throw ex;
                }
                return ret;            
        }

        public Motivo Inserir(Motivo item)
        {
            MotivoAlertaRepository _repository = new MotivoAlertaRepository(unitOfWork);           

            item.dtManutencao = DateTime.Now;
            item.blnAtivo = true;

            unitOfWork.OpenConnection();
            
                try
                {
                    item = _repository.Inserir(item);               
               
                    unitOfWork.CloseConnection();
                    return item;
                }
                catch (Exception ex)
                {                  
                    unitOfWork.CloseConnection();
                    throw ex;
                }
            }        

        public List<Motivo> Listar(Motivo item)
        {
            try
            {
                MotivoAlertaRepository _repository = new MotivoAlertaRepository(unitOfWork);
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Motivo> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Motivo Obter(Motivo item)
        {
            try
            {
                MotivoAlertaRepository _repository = new MotivoAlertaRepository(unitOfWork);
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Motivo item)
        {
            try
            {
                MotivoAlertaRepository _repository = new MotivoAlertaRepository(unitOfWork);
                return _repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(Motivo item)
        {
            throw new NotImplementedException();
        }       
    }
}
