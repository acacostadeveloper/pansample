﻿using Pan.Restritivos.Data.Repositories.Sistema;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Dal
{
    /// <summary>
    /// Camada de acesso a dados para gerenciamento de vigencia dos registros e bases
    /// </summary>
    public class DalRobo 
    {
        public int UpdateVigencia()
        {
            RoboRepository _Repository = new RoboRepository();
            try
            {
              return  _Repository.UpdateVigencia("SP_UPDATEVIGENCIA");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
