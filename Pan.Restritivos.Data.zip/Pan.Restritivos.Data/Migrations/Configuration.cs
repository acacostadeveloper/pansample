namespace Pan.Restritivos.Data.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    /// <summary>
    /// Configura��o do entity framework
    /// </summary>
    internal sealed class Configuration : DbMigrationsConfiguration<Pan.Restritivos.Data.Context.BreakAwayContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;

          //EGS 14.02.2018 - Resolver erro de "Automatic migration was not applied because it would result in data loss. Set AutomaticMigrationDataLossAllowed to 'true' on your DbMigrationsConfiguration to allow application of automatic migrations even if they might cause data loss. Alternately, use Update-Database with the '-Force' option, or scaffold an explicit migration.)"
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(Pan.Restritivos.Data.Context.BreakAwayContext context)
        {
          
        }
    }
}
