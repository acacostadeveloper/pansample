﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Context.Interfaces
{
    /// <summary>
    /// Interface que define o contexto do entity framework
    /// </summary>
    public interface IUnitOfWork
    {
        void Save();

        DbTransaction BeginTransaction();

        void OpenConnection();

        void CloseConnection();

    }
}
