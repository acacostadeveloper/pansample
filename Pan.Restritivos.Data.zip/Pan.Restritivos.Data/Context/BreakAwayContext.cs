﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Migrations;
using Pan.Restritivos.Data.Context.Interfaces;
using System.Data.Entity.Migrations;
using Pan.Restritivos.Model.Sistema;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Infrastructure.Annotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Common;
using Pan.Restritivos.Model.Configuracao;
using System.Configuration;

namespace Pan.Restritivos.Data.Context
{
    /// <summary>
    /// Contexto utilizado pelo entity framework para gerenciamento de base.
    /// </summary>
    public class BreakAwayContext : DbContext, IUnitOfWork
    {
        public BreakAwayContext()
        {
            this.Database.Connection.ConnectionString = ConfigurationManager.ConnectionStrings["PAN_RESTRITIVOSContext"].ConnectionString;
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<BreakAwayContext, Pan.Restritivos.Data.Migrations.Configuration>());

            Configuration.LazyLoadingEnabled = false;
            Configuration.ProxyCreationEnabled = false;

        }



        public DbSet<UsuarioItemAcesso> UsuarioItemAcessos { get; set; }
        public DbSet<ItemAcesso> ItemAcessos { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Sessaousuario> SessaoUsuario { get; set; }

        public DbSet<Cnpj> Cnpj { get; set; }
        public DbSet<CodigoBarra> CodigoBarra { get; set; }
        public DbSet<Cpf> Cpf { get; set; }
        public DbSet<DadoBancario> DadoBancario { get; set; }
        public DbSet<Endereco> Endereco { get; set; }
        public DbSet<Ip> Ip { get; set; }
        public DbSet<LinhaDigitavel> LinhaDigitavel { get; set; }
        public DbSet<Motivo> Motivo { get; set; }
        public DbSet<Peso> Peso { get; set; }
        public DbSet<Telefone> Telefone { get; set; }


        public DbSet<CnpjLog> CnpjLog { get; set; }
        public DbSet<CodigoBarraLog> CodigoBarraLog { get; set; }
        public DbSet<CpfLog> CpfLog { get; set; }
        public DbSet<DadoBancarioLog> DadoBancarioLog { get; set; }
        public DbSet<EnderecoLog> EnderecoLog { get; set; }
        public DbSet<IpLog> IpLog { get; set; }
        public DbSet<LinhaDigitavelLog> LinhaDigitavelLog { get; set; }
        public DbSet<TelefoneLog> TelefoneLog { get; set; }
        public DbSet<LayoutImportacao> LayoutImportacao { get; set; }

        public DbSet<ContaBlacklist> ContablackList { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();

        }
        public void Save()
        {
            base.SaveChanges();
        }

        public void OpenConnection()
        {
            base.Database.Connection.Open();
        }
        public void CloseConnection()
        {
            base.Database.Connection.Close();
        }

        public int ExecuteSqlCommand(string query)
        {
            object[] param = new object[0];

            int count = base.Database.ExecuteSqlCommand(query, param);
            return count;
        }

        public int ExecuteSqlCommand(string query, object[] param)
        {
            int count = base.Database.ExecuteSqlCommand(query, param);
            return count;
        }

        public DbTransaction BeginTransaction()
        {
            return base.Database.Connection.BeginTransaction();
        }
    }
}
