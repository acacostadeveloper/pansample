﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.SqlHelper
{

    /// <summary>
    /// Classe para acesso a banco de dados sem utlizar o entity framework
    /// </summary>
    public class SqlCommon
    {
        SqlConnection connection;
        SqlCommand command;
        SqlTransaction Tran;

        public SqlCommon() 
        {
            connection = new SqlConnection();
        }

        public void OpenTransaction() 
        {
            Tran = connection.BeginTransaction();
        }

        public void CommitTransaction()
        {
            Tran.Commit();
        }

        public void RoolbackTransaction()
        {
            Tran.Rollback();
        }

        public void OpenConnection(string conn)
        {
            connection.ConnectionString = conn;
            connection.Open();
        }
        public void CloseConnection()
        {
            connection.Close();
        }

        public List<T> ReadData<T>(string queryString)
        {
            try
            {
                using (command = new SqlCommand(queryString, connection))
                {
                   command.CommandType = CommandType.StoredProcedure;
                    using (var reader = command.ExecuteReader())
                        if (reader.HasRows)
                            return DataReaderMapToList<T>(reader);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        public bool Insert(string proc, Dictionary<string, string> param)
        {
            try
            {
                
                using (command = new SqlCommand(proc, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Transaction = Tran;
                    foreach (var item in param)
                    {
                        command.Parameters.Add(new SqlParameter() { ParameterName = item.Key, Value = item.Value,SqlDbType= SqlDbType.VarChar, Direction = ParameterDirection.Input});
                    }

                    command.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public int ExecNoReturn(string proc)
        {
            int count = 0;
            try
            {
                using (var command = new SqlCommand(proc, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Transaction = Tran;
                    count = command.ExecuteNonQuery();
                }
                return count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<T> DataReaderMapToList<T>(IDataReader dr)
        {
            List<T> list = new List<T>();
            T obj = default(T);
            while (dr.Read())
            {
                obj = Activator.CreateInstance<T>();
                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                {
                    if (!object.Equals(dr[prop.Name], DBNull.Value))
                    {
                        prop.SetValue(obj, dr[prop.Name], null);
                    }
                }
                list.Add(obj);
            }
            return list;
        }
    }
}
