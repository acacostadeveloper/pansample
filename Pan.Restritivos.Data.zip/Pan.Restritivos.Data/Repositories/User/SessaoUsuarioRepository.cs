﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.User;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.User
{
    /// <summary>
    /// Repositório referente á Sessão do usuário que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class SessaoUsuarioRepository : IDalBase<Sessaousuario>, IDisposable
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public SessaoUsuarioRepository(IUnitOfWork iunitofwork)
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }
        public void Dispose()
        {
            _context.Dispose();
        }
        public void limparSessao(Sessaousuario pSessaousuario)
        {
            bool saveFailed = true;
            do
            {
                try
                {
                    List<Sessaousuario> temp = _context.SessaoUsuario.Select(x => x).Where(x => x.login == pSessaousuario.login).ToList();
          
                    if (temp.Count() == 1)
                    {
                        _context.SessaoUsuario.Remove(temp[0]);
                        _context.SaveChanges();                   

                    }
                    else if (temp.Count() > 0)
                    {
                        _context.SessaoUsuario.RemoveRange(temp);
                        _context.SaveChanges();                 
                    }
                    saveFailed = false;

                }
                catch (DbUpdateConcurrencyException ex)
                {
                    saveFailed = true;
                    ex.Entries.Single().Reload();
                }
                catch (Exception ex)
                {
                    saveFailed = true;
                    throw ex;
                }
            } while (saveFailed);
        }

        //public bool atualizarSessao() 
        //{
        //  //  _context.
        //}





        public Sessaousuario Alterar(Sessaousuario item)
        {
            throw new NotImplementedException();
        }

        public List<Sessaousuario> Importar(List<Sessaousuario> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Sessaousuario item)
        {
            throw new NotImplementedException();
        }

        public Sessaousuario Inserir(Sessaousuario item)
        {
            try
            {
                var temp = _context.Set<Sessaousuario>().Add(item);
                _context.SaveChanges();
                return temp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Sessaousuario> Listar(Sessaousuario item)
        {
            return _context.Set<Sessaousuario>().Where(x => x.login == item.login || x.idSession == item.idSession).Select(x => x).ToList();
        }

        public List<Sessaousuario> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Sessaousuario Obter(Sessaousuario item)
        {
            throw new NotImplementedException();
        }

        public bool Validar(Sessaousuario item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Sessaousuario item)
        {
            throw new NotImplementedException();
        }
    }
}
