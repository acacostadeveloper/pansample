﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.User;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Validation;



namespace Pan.Restritivos.Data.Repositories.User
{
    /// <summary>
    /// Repositório referente á usuário que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class UsuarioRepository : IDalBase<Usuario>, IDisposable
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public UsuarioRepository(IUnitOfWork iunitofwork)
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public void Dispose()
        {
            _context.Dispose();
        }



        public Usuario Inserir(Usuario item)
        {
            try
            {
                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.nmUsuario         = item.nmUsuario.ToUpper();
                item.idUsuarioInclusao = item.idUsuario;
                item.DtUsuarioInclusao = DateTime.Now;
                item.blnAtivo          = true;
                _context.Set<Usuario>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public Usuario Alterar(Usuario item)
        {
            try
            {
                if (item.idUsuarioInclusao == 0)
                {
                    Usuario user           = _context.Set<Usuario>().Single(x => x.idUsuario == item.idUsuario);
                    item.idUsuarioInclusao = user.idUsuario;
                    item.DtUsuarioInclusao = user.DtUsuarioInclusao;
                }

                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                item.nmUsuario             = item.nmUsuario.ToUpper();
                item.idUsuarioManutencao   = item.idUsuarioManutencao;
                item.DtUsuarioManutencao   = DateTime.Now;
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inativar(Usuario item)
        {
            try
            {
                Usuario user = _context.Set<Usuario>().Single(x => x.idUsuario == item.idUsuario);

                //EGS 30.03.2018 - Novos campos de auditoria, usuario e datas ao incluir e alterar
                user.idUsuarioInclusao = item.idUsuario;
                user.DtUsuarioInclusao = DateTime.Now;
                user.blnAtivo          = false;
                var temp = _context.Entry<Usuario>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<Usuario> Importar(List<Usuario> item)
        {
            throw new NotImplementedException();
        }

        public List<Usuario> Listar(Usuario item)
        {

            List<Usuario> ret = new List<Usuario>();
            try
            {
          
                var temp = (from _Usuarios in _context.Usuarios
                            join _Usuarios2 in _context.Usuarios on _Usuarios.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                            from subUser in tm.DefaultIfEmpty()
                            let UsuarioManutencao = subUser.nmUsuario
                            where
                               ((string.IsNullOrEmpty(item.login)) || (_Usuarios.login.Contains(item.login)))
                                &&
                               ((string.IsNullOrEmpty(item.nmUsuario)) || (_Usuarios.nmUsuario.Contains(item.nmUsuario)))
                            select new
                           {
                               idUsuario            = _Usuarios.idUsuario,
                               nmUsuario            = _Usuarios.nmUsuario,
                               login                = _Usuarios.login,
                               nmUsuarioManutencao  =  UsuarioManutencao,
                               idUsuarioManutencao  = _Usuarios.idUsuarioManutencao,
                               dtManutencao         = _Usuarios.DtUsuarioManutencao,
                               blnAtivo             = _Usuarios.blnAtivo

                           }).ToList().Select(x => new Usuario()
                            {

                                idUsuario           = x.idUsuario,
                                nmUsuario           = x.nmUsuario,
                                login               = x.login,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                DtUsuarioManutencao = x.dtManutencao,
                                blnAtivo            = x.blnAtivo,
                                Acessos = (from acessos in _context.ItemAcessos
                                           join itens   in _context.UsuarioItemAcessos on acessos.idItemAcesso equals itens.idItemAcesso into tempItens
                                           from itens   in tempItens.Where(z => z.idUsuario == x.idUsuario).DefaultIfEmpty()
                                           select new
                                           {
                                               idUsuarioItemAcesso = (itens.idUsuarioItemAcesso == null ? 0 : itens.idUsuarioItemAcesso),
                                               idUsuario = (itens.idUsuario == null ? 0 : itens.idUsuario),
                                               idItemAcesso = (itens.idItemAcesso == null ? acessos.idItemAcesso : itens.idItemAcesso),
                                               blnIncluir = (itens.blnIncluir == null ? false : itens.blnIncluir),
                                               blnAlterar = (itens.blnAlterar == null ? false : itens.blnAlterar),
                                               blnInativar = (itens.blnInativar == null ? false : itens.blnInativar),
                                               blnConsultar = (itens.blnConsultar == null ? false : itens.blnConsultar),
                                               blnImportar = (itens.blnConsultar == null ? false : itens.blnImportar),
                                               txLink =  acessos.txLink,
                                               txItemAcesso = acessos.txItemAcesso,

                                           }).ToList().Select(y => new Acessos()
                                                     {
                                                         idUsuarioItemAcesso = y.idUsuarioItemAcesso,
                                                         idUsuario = y.idUsuario,
                                                         idItemAcesso = y.idItemAcesso,
                                                         blnIncluir = y.blnIncluir,
                                                         blnAlterar = y.blnAlterar,
                                                         blnInativar = y.blnInativar,
                                                         blnConsultar = y.blnConsultar,
                                                         blnImportar = y.blnImportar,
                                                         txItemAcesso = y.txItemAcesso,
                                                         txLink = y.txLink
                                                     }).ToList()
                            });

                return temp.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public Usuario Obter(Usuario item)
        {
            return _context.Set<Usuario>().Find(item);
        }

        public bool Validar(Usuario item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Usuario item)
        {
            throw new NotImplementedException();
        }

        public List<Usuario> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public bool verificaUsuarioAtivo(string login)
        {
            try
            {
                var temp = _context.Usuarios.Select(x => x).Where(x => x.login == login).FirstOrDefault();
                if (temp != null)
                    return temp.blnAtivo;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int getIdUserbyLogin(string login)
        {
            try
            {
                var temp = _context.Usuarios.Select(x => x).Where(x => x.login == login).FirstOrDefault();
                if (temp != null)
                    return temp.idUsuario;
                else
                    return 0;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Usuario getuser(int iduser)
        {
            try
            {
                return _context.Usuarios.Select(x => x).Where(x => x.idUsuario == iduser).FirstOrDefault();
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
