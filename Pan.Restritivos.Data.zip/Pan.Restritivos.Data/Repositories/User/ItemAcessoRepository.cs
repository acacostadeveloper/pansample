﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.User
{
    /// <summary>
    /// Repositório referente á Item de acesso que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class ItemAcessoRepository : IDalBase<ItemAcesso>, IDisposable
    {
       IUnitOfWork unitOfWork = new BreakAwayContext();
       private BreakAwayContext _context;
       public ItemAcessoRepository(IUnitOfWork iunitofwork)
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }
       public void Dispose()
       {
           _context.Dispose();
       }

       public ItemAcesso Alterar(ItemAcesso item)
       {
           throw new NotImplementedException();
       }

       public List<ItemAcesso> Importar(List<ItemAcesso> item)
       {
           throw new NotImplementedException();
       }

       public bool Inativar(ItemAcesso item)
       {
           throw new NotImplementedException();
       }

       public ItemAcesso Inserir(ItemAcesso item)
       {
           throw new NotImplementedException();
       }

       public List<ItemAcesso> Listar(ItemAcesso item)
       {
           throw new NotImplementedException();
       }

       public List<ItemAcesso> ListarLog(int id)
       {
           throw new NotImplementedException();
       }

       public ItemAcesso Obter(ItemAcesso item)
       {
           throw new NotImplementedException();
       }

       public bool Validar(ItemAcesso item)
       {
           throw new NotImplementedException();
       }

       public bool ValidarImportacao(ItemAcesso item)
       {
           throw new NotImplementedException();
       }
    }
}
