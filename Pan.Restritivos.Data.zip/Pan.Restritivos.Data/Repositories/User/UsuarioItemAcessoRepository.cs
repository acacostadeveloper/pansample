﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.User;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.User
{
    /// <summary>
    /// Repositório referente á items de acesso que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class UsuarioItemAcessoRepository : IDalBase<UsuarioItemAcesso>, IDisposable
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public UsuarioItemAcessoRepository(IUnitOfWork iunitofwork)
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }
        public void Dispose()
        {
            _context.Dispose();
        }
        public List<Acessos> getaccesspage(int idusuario)
        {
            List<Acessos> ret = new List<Acessos>();
            try
            {
                var temp = (from _UsuarioitemAcesso
                                           in _context.UsuarioItemAcessos
                            join _ItemAcesso in _context.ItemAcessos on
                                _UsuarioitemAcesso.idItemAcesso equals _ItemAcesso.idItemAcesso
                            where
                                _UsuarioitemAcesso.idUsuario == idusuario
                            select new Acessos()
                           {
                               idUsuario = _UsuarioitemAcesso.idUsuario,
                               idItemAcesso = _UsuarioitemAcesso.idItemAcesso,
                               idUsuarioItemAcesso = _UsuarioitemAcesso.idUsuarioItemAcesso,
                               blnAlterar = _UsuarioitemAcesso.blnAlterar,
                               blnConsultar = _UsuarioitemAcesso.blnConsultar,
                               blnInativar = _UsuarioitemAcesso.blnInativar,
                               blnIncluir = _UsuarioitemAcesso.blnIncluir,
                               blnImportar = _UsuarioitemAcesso.blnImportar,
                               txItemAcesso = _ItemAcesso.txItemAcesso,
                               txLink = _ItemAcesso.txLink
                           }).ToList();

                ret.AddRange(temp.ToList());
                return ret;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public List<Acessos> ListaFuncionalidades()
        {
            List<ItemAcesso> ret = new List<ItemAcesso>();
            try
            {
                var temp = (from _ItemAcesso in _context.ItemAcessos
                            select new
                            {
                                idItemAcesso = _ItemAcesso.idItemAcesso,
                                txItemAcesso = _ItemAcesso.txItemAcesso,
                                txLink = _ItemAcesso.txLink

                            }).ToList().Select(x => new Acessos()
                            {
                                idItemAcesso = x.idItemAcesso,
                                txItemAcesso = x.txItemAcesso,
                                txLink = x.txLink
                                
                            });

                return temp.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            //where
            //((idUsuario == 0) || (_ItemAcesso..login.Contains(item.login)))

        }


        public UsuarioItemAcesso Alterar(UsuarioItemAcesso item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UsuarioItemAcesso> Importar(List<UsuarioItemAcesso> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(UsuarioItemAcesso item)
        {
            throw new NotImplementedException();
        }

        public bool Excluir(int idUsuario)
        {
            bool ret = false;
            try
            {

                var temp = _context.UsuarioItemAcessos.Select(x => x).Where(x => x.idUsuario == idUsuario);

                _context.UsuarioItemAcessos.RemoveRange(temp);
                _context.SaveChanges();
                ret = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public UsuarioItemAcesso Inserir(UsuarioItemAcesso item)
        {
            try
            {
                _context.Set<UsuarioItemAcesso>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<UsuarioItemAcesso> Listar(UsuarioItemAcesso item)
        {
            throw new NotImplementedException();
        }

        public List<UsuarioItemAcesso> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public UsuarioItemAcesso Obter(UsuarioItemAcesso item)
        {
            throw new NotImplementedException();
        }

        public bool Validar(UsuarioItemAcesso item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(UsuarioItemAcesso item)
        {
            throw new NotImplementedException();
        }
    }
}
