﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á IP que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class IpRepository : IDalBase<Ip>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public IpRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Ip Alterar(Ip item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Ip> Importar(List<Ip> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Ip item)
        {
            try
            {
                Ip user = _context.Set<Ip>().Single(x => x.idIP == item.idIP);
                user.blnAtivo = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp = _context.Entry<Ip>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Ip Inserir(Ip item)
        {
            try
            {
                _context.Set<Ip>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Ip> Listar(Ip item)
        {
            List<Ip> temp = null;
            try
            {
         
                temp = (from _Ips in _context.Ip
                        join _Motivo in _context.Motivo on _Ips.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Ips.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Ips.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                          ((string.IsNullOrEmpty(item.nrIP)) || (_Ips.nrIP.Contains(item.nrIP)))
                          &&
                          ((item.nrPorta == 0) || (_Ips.nrPorta == item.nrPorta))
                          &&
                          (
                            ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_Ips.dtVigenciaInicio) >= DbFunctions.TruncateTime(item.dtVigenciaInicio)))
                                 &&
                                ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_Ips.dtVigenciaFim) <= DbFunctions.TruncateTime(item.dtVigenciaFim)))
                          )


                        select new
                        {
                            blnAtivo = _Ips.blnAtivo,
                            nrIP = _Ips.nrIP,
                            nrPorta = _Ips.nrPorta,
                            dtManutencao = _Ips.dtManutencao,
                            idIP = _Ips.idIP,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Ips.idUsuarioManutencao,                            
                            dtVigenciaInicio = _Ips.dtVigenciaInicio,
                            dtVigenciaFim = _Ips.dtVigenciaFim,
                            idPeso = _Ips.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _Ips.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _Ips.txObs
                        }).ToList().Select(x => new Ip()
                            {

                                blnAtivo = x.blnAtivo,
                                nrIP = x.nrIP,
                                nrPorta = x.nrPorta,
                                dtManutencao = x.dtManutencao,
                                idIP = x.idIP,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,                                
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<Ip> ListarLog(int id)
        {
            List<Ip> temp = null;
            try
            {
                temp = (from _Ips in _context.IpLog
                        join _Motivo in _context.Motivo on _Ips.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Ips.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Ips.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _Ips.idIP == id

                        select new
                        {
                            idIp = _Ips.idIP,
                            idIpLog = _Ips.idIPLog,
                            blnAtivo = _Ips.blnAtivo,
                            nrIP = _Ips.nrIP,
                            nrPorta = _Ips.nrPorta,
                            dtManutencao = _Ips.dtManutencao,                            
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Ips.idUsuarioManutencao,
                            dtVigenciaInicio = _Ips.dtVigenciaInicio,
                            dtVigenciaFim = _Ips.dtVigenciaFim,                            
                            idPeso = _Ips.idPeso,
                            idMotivo = _Ips.idMotivo,
                            txObs = _Ips.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao =_Ips.txAcao
                        }).ToList().Select(x => new Ip()
                        {

                            idIP = x.idIp,
                            idIpLog = x.idIpLog,
                            blnAtivo = x.blnAtivo,
                            nrIP = x.nrIP,
                            nrPorta = x.nrPorta,
                            dtManutencao = x.dtManutencao,                            
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public Ip Obter(Ip item)
        {
            try
            {
                return _context.Ip.Select(x => x).Where(x => (x.nrIP == item.nrIP && x.blnAtivo == true && (item.nrPorta != 0 ? x.nrPorta == item.nrPorta : x.nrPorta == x.nrPorta))).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Ip item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Ip item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
