﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á CNPJ que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class CnpjRepository : IDalBase<Cnpj>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public CnpjRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Cnpj Alterar(Cnpj item)
        {
            try
            {         
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Cnpj> Importar(List<Cnpj> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Cnpj item)
        {
            try
            {
                Cnpj user = _context.Set<Cnpj>().Single(x => x.idCnpj == item.idCnpj);
                user.blnAtivo = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp = _context.Entry<Cnpj>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Cnpj Inserir(Cnpj item)
        {
            try
            {
                _context.Set<Cnpj>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Cnpj> Listar(Cnpj item)
        {
            List<Cnpj> temp = null;
            try
            {
                temp = (from _Cnpjs in _context.Cnpj
                        join _Motivo in _context.Motivo on _Cnpjs.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Cnpjs.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Cnpjs.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                          ((string.IsNullOrEmpty(item.nrCnpj)) || (_Cnpjs.nrCnpj.Contains(item.nrCnpj)))
                         &&
                          ((string.IsNullOrEmpty(item.nmEmpresa)) || (_Cnpjs.nmEmpresa.Contains(item.nmEmpresa)))
                          &&
                          (
                              ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_Cnpjs.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                &&
                              ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_Cnpjs.dtVigenciaFim) <= item.dtVigenciaFim))
                          )


                        select new
                        {
                            blnAtivo = _Cnpjs.blnAtivo,
                            nrCnpj = _Cnpjs.nrCnpj,
                            dtManutencao = _Cnpjs.dtManutencao,
                            idCnpj = _Cnpjs.idCnpj,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Cnpjs.idUsuarioManutencao,
                            nmEmpresa = _Cnpjs.nmEmpresa,
                            dtVigenciaInicio = _Cnpjs.dtVigenciaInicio,
                            dtVigenciaFim = _Cnpjs.dtVigenciaFim,
                            idPeso = _Cnpjs.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _Cnpjs.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _Cnpjs.txObs
                        }).ToList().Select(x => new Cnpj()
                            {

                                blnAtivo = x.blnAtivo,
                                nrCnpj = x.nrCnpj,
                                dtManutencao = x.dtManutencao,
                                idCnpj = x.idCnpj,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,
                                nmEmpresa = x.nmEmpresa,
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<Cnpj> ListarLog(int id)
        {
            List<Cnpj> temp = null;
            try
            {
                temp = (from _Cnpjs in _context.CnpjLog
                        join _Motivo in _context.Motivo on _Cnpjs.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Cnpjs.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Cnpjs.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _Cnpjs.idCnpj == id

                        select new
                        {
                            idCnpj = _Cnpjs.idCnpj,
                            idCnpjLog = _Cnpjs.idCnpjLog,
                            blnAtivo = _Cnpjs.blnAtivo,
                            nrCnpj = _Cnpjs.nrCnpj,
                            dtManutencao = _Cnpjs.dtManutencao,                            
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Cnpjs.idUsuarioManutencao,
                            dtVigenciaInicio = _Cnpjs.dtVigenciaInicio,
                            dtVigenciaFim = _Cnpjs.dtVigenciaFim,
                            nmEmpresa = _Cnpjs.nmEmpresa,
                            idPeso = _Cnpjs.idPeso,
                            idMotivo = _Cnpjs.idMotivo,
                            txObs = _Cnpjs.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao =_Cnpjs.txAcao
                        }).ToList().Select(x => new Cnpj()
                        {

                            idCnpj = x.idCnpj,
                            idCnpjLog = x.idCnpjLog,
                            blnAtivo = x.blnAtivo,
                            nrCnpj = x.nrCnpj,
                            dtManutencao = x.dtManutencao,                            
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            nmEmpresa = x.nmEmpresa,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public Cnpj Obter(Cnpj item)
        {
            try
            {
                return _context.Cnpj.Select(x => x).Where(x => (x.nrCnpj == item.nrCnpj && x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Cnpj item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Cnpj item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
