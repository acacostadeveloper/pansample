﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Código de barras que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class CodigoBarraRepository : IDalBase<CodigoBarra>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public CodigoBarraRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public CodigoBarra Alterar(CodigoBarra item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<CodigoBarra> Importar(List<CodigoBarra> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(CodigoBarra item)
        {
            try
            {
                CodigoBarra user = _context.Set<CodigoBarra>().Single(x => x.idCodigoBarra == item.idCodigoBarra);
                user.blnAtivo = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp = _context.Entry<CodigoBarra>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public CodigoBarra Inserir(CodigoBarra item)
        {
            try
            {
                _context.Set<CodigoBarra>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<CodigoBarra> Listar(CodigoBarra item)
        {
            List<CodigoBarra> temp = null;
            try
            {
               
                temp = (from _CodigoBarras in _context.CodigoBarra
                        join _Motivo in _context.Motivo on _CodigoBarras.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _CodigoBarras.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _CodigoBarras.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                          ((string.IsNullOrEmpty(item.codBarra)) || (_CodigoBarras.codBarra.Contains(item.codBarra)))
                          &&
                          (
                              ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_CodigoBarras.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                &&
                              ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_CodigoBarras.dtVigenciaFim) <= item.dtVigenciaFim))
                          )


                        select new
                        {
                            blnAtivo = _CodigoBarras.blnAtivo,
                            codBarra = _CodigoBarras.codBarra,
                            dtManutencao = _CodigoBarras.dtManutencao,
                            idCodigoBarra = _CodigoBarras.idCodigoBarra,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _CodigoBarras.idUsuarioManutencao,                            
                            dtVigenciaInicio = _CodigoBarras.dtVigenciaInicio,
                            dtVigenciaFim = _CodigoBarras.dtVigenciaFim,
                            idPeso = _CodigoBarras.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _CodigoBarras.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _CodigoBarras.txObs
                        }).ToList().Select(x => new CodigoBarra()
                            {

                                blnAtivo = x.blnAtivo,
                                codBarra = x.codBarra,
                                dtManutencao = x.dtManutencao,
                                idCodigoBarra = x.idCodigoBarra,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,                                
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<CodigoBarra> ListarLog(int id)
        {
            List<CodigoBarra> temp = null;
            try
            {
                temp = (from _CodigoBarras in _context.CodigoBarraLog
                        join _Motivo in _context.Motivo on _CodigoBarras.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _CodigoBarras.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _CodigoBarras.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _CodigoBarras.idCodigoBarra == id

                        select new
                        {
                            idCodigoBarra = _CodigoBarras.idCodigoBarra,
                            idCodigoBarraLog = _CodigoBarras.idCodigoBarraLog,
                            blnAtivo = _CodigoBarras.blnAtivo,
                            codBarra = _CodigoBarras.codBarra,
                            dtManutencao = _CodigoBarras.dtManutencao,                            
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _CodigoBarras.idUsuarioManutencao,
                            dtVigenciaInicio = _CodigoBarras.dtVigenciaInicio,
                            dtVigenciaFim = _CodigoBarras.dtVigenciaFim,                            
                            idPeso = _CodigoBarras.idPeso,
                            idMotivo = _CodigoBarras.idMotivo,
                            txObs = _CodigoBarras.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao =_CodigoBarras.txAcao
                        }).ToList().Select(x => new CodigoBarra()
                        {

                            idCodigoBarra = x.idCodigoBarra,
                            idCodigoBarraLog = x.idCodigoBarraLog,
                            blnAtivo = x.blnAtivo,
                            codBarra = x.codBarra,
                            dtManutencao = x.dtManutencao,                            
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public CodigoBarra Obter(CodigoBarra item)
        {
            try
            {
                return _context.CodigoBarra.Select(x => x).Where(x => (x.codBarra == item.codBarra && x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(CodigoBarra item)
        {
            try
            {
                if (_context.CodigoBarra.Select(x => x).Where(x => (x.codBarra == item.codBarra)).FirstOrDefault() != null) { return true; };
                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(CodigoBarra item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
