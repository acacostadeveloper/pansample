﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Telefone que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class TelefoneRepository : IDalBase<Telefone>, IDisposable
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public TelefoneRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Telefone Alterar(Telefone item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Telefone> Importar(List<Telefone> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Telefone item)
        {
            try
            {
                Telefone _Telefone = _context.Set<Telefone>().Single(x => x.idTelefone == item.idTelefone);
                _Telefone.idUsuarioManutencao = item.idUsuarioManutencao;
                _Telefone.blnAtivo = false;
                var temp = _context.Entry<Telefone>(_Telefone).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Telefone Inserir(Telefone item)
        {
            try
            {
                _context.Set<Telefone>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Telefone> Listar(Telefone item)
        {
            List<Telefone> temp = null;

            if (item.nrDDD == 0){item.nrDDD = null;}
            if (item.nrTelefone == 0) { item.nrTelefone = null; }

            try
            {
                temp = (from _Telefones in _context.Telefone
                        join _Motivo in _context.Motivo on _Telefones.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Telefones.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Telefones.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario

                        where
                            (
                             ((item.nrDDD == null) || (_Telefones.nrDDD == item.nrDDD))
                             &&
                             ((item.nrTelefone == null) || (_Telefones.nrTelefone.ToString().Contains(item.nrTelefone.ToString())))
                            )
                            &&
                            (
                                ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_Telefones.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                  &&
                                ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_Telefones.dtVigenciaFim) <= item.dtVigenciaFim))
                            )                                           
                            
                        select new
                        {
                            blnAtivo = _Telefones.blnAtivo,
                            nrDDD = _Telefones.nrDDD,
                            dtManutencao = _Telefones.dtManutencao,
                            idTelefone = _Telefones.idTelefone,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Telefones.idUsuarioManutencao,
                            nrTelefone = _Telefones.nrTelefone,
                            dtVigenciaInicio = _Telefones.dtVigenciaInicio,
                            dtVigenciaFim = _Telefones.dtVigenciaFim,
                            idPeso = _Telefones.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _Telefones.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _Telefones.txObs
                        }).ToList().Select(x => new Telefone()
                        {

                            blnAtivo = x.blnAtivo,
                            nrDDD = x.nrDDD,
                            dtManutencao = x.dtManutencao,
                            idTelefone = x.idTelefone,
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            nrTelefone = x.nrTelefone,
                            idPeso = x.idPeso,
                            txMotivo = x.txMotivo,
                            idMotivo = x.idMotivo,
                            txPeso = x.txPeso,
                            txObs = x.txObs
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<Telefone> ListarLog(int id)
        {
            List<Telefone> temp = null;
            try
            {
                temp = (from _Telefone in _context.TelefoneLog
                        join _Motivo in _context.Motivo on _Telefone.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Telefone.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Telefone.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _Telefone.idTelefone == id

                        select new
                        {
                            idTelefone = _Telefone.idTelefone,
                            idTelefoneLog = _Telefone.idTelefoneLog,
                            blnAtivo = _Telefone.blnAtivo,
                            nrDDD = _Telefone.nrDDD,
                            dtManutencao = _Telefone.dtManutencao,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Telefone.idUsuarioManutencao,
                            dtVigenciaInicio = _Telefone.dtVigenciaInicio,
                            dtVigenciaFim = _Telefone.dtVigenciaFim,
                            nrTelefone = _Telefone.nrTelefone,
                            idPeso = _Telefone.idPeso,
                            idMotivo = _Telefone.idMotivo,
                            txObs = _Telefone.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao = _Telefone.txAcao
                        }).ToList().Select(x => new Telefone()
                        {

                            idTelefone = x.idTelefone,
                            idTelefoneLog = x.idTelefoneLog,
                            blnAtivo = x.blnAtivo,
                            nrDDD = x.nrDDD,
                            dtManutencao = x.dtManutencao,
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            nrTelefone = x.nrTelefone,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public Telefone Obter(Telefone item)
        {

            try
            {
                return _context.Telefone.Select(x => x).Where(x => (x.nrDDD == item.nrDDD && x.nrTelefone == item.nrTelefone && x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Telefone item)
        {
           
            try
            {
                if (_context.Telefone.Select(x => x).Where(x => (x.nrDDD == item.nrDDD && x.nrTelefone == item.nrTelefone)).FirstOrDefault() != null) { return true; };
                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(Telefone item)
        {
            throw new NotImplementedException();
        }

        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
