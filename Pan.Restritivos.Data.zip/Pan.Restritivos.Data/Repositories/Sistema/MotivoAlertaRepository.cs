﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Motivo de alerta que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
   public class MotivoAlertaRepository : IDalBase<Motivo>, IDisposable
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public MotivoAlertaRepository(IUnitOfWork iunitofwork)
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Motivo Alterar(Motivo item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Motivo> Importar(List<Motivo> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Motivo item)
        {
            try
            {
                    Motivo motiv = _context.Set<Motivo>().Single(x => x.idMotivo == item.idMotivo);
                    motiv.blnAtivo = false;
                    motiv.dtManutencao = DateTime.Now;
                    var temp = _context.Entry<Motivo>(motiv).State = EntityState.Modified;
                    _context.SaveChanges();                   
                    return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Motivo Inserir(Motivo item)
        {
            try
            {
                _context.Set<Motivo>().Add(item) ;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Motivo> Listar(Motivo item)
        {          
            List<Motivo> ret = new List<Motivo>();
            try
            {
                var temp = (from _Motivos in _context.Motivo
                            join _Motivos2 in _context.Usuarios on _Motivos.idUsuarioManutencao equals _Motivos2.idUsuario into tm
                            from subUser in tm.DefaultIfEmpty()
                            let UsuarioManutencao = subUser.nmUsuario
                            where
                               ((string.IsNullOrEmpty(item.codMotivo)) || (_Motivos.codMotivo.Contains(item.codMotivo)))
                                &&
                               ((string.IsNullOrEmpty(item.txMotivo)) || (_Motivos.txMotivo.Contains(item.txMotivo)))
                            select new
                            {
                                idMotivo = _Motivos.idMotivo,
                                codMotivo = _Motivos.codMotivo,
                                txMotivo = _Motivos.txMotivo,
                                nmUsuarioManutencao = UsuarioManutencao,
                                idUsuarioManutencao = _Motivos.idUsuarioManutencao,
                                dtManutencao = _Motivos.dtManutencao,
                                blnAtivo = _Motivos.blnAtivo

                            }).ToList().Select(x => new Motivo()
                            {
                                idMotivo = x.idMotivo,
                                codMotivo = x.codMotivo,
                                txMotivo = x.txMotivo,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtManutencao = x.dtManutencao,
                                blnAtivo = x.blnAtivo

                            });

                return temp.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Motivo> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Motivo Obter(Motivo item)
        {
            try
            {
                return _context.Motivo.Select(x => x).Where(x => (x.codMotivo == item.codMotivo) && (x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Motivo item)
        {

            try
            {
                if (_context.Motivo.Join(_context.Cpf, x => x.idMotivo, y => y.idMotivo, (x, y) => new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Motivo.Join(_context.Cnpj, x => x.idMotivo, y => y.idMotivo, (x, y) => new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Motivo.Join(_context.CodigoBarra, x => x.idMotivo, y => y.idMotivo, (x, y) => new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Motivo.Join(_context.DadoBancario, x => x.idMotivo, y => y.idMotivo, (x, y) => new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; ; }

                if (_context.Motivo.Join(_context.Endereco, x => x.idMotivo, y => y.idMotivo, (x, y) => new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; ; }

                if (_context.Motivo.Join(_context.Ip, x => x.idMotivo, y => y.idMotivo, (x, y) => new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Motivo.Join(_context.LinhaDigitavel, x => x.idMotivo, y => y.idMotivo, (x, y) =>
                    new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Motivo.Join(_context.Telefone, x => x.idMotivo, y => y.idMotivo, (x, y) =>
                  new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idMotivo).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
                         
        }       

        public bool ValidarImportacao(Motivo item)
        {
            throw new NotImplementedException();
        }
        public void Dispose()
        {
            _context.Dispose();
        }
       
    }
}
