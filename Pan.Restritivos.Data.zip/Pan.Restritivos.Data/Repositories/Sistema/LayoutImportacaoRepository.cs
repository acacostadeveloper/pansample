﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Configuracao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á layout de importação que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class LayoutImportacaoRepository
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public LayoutImportacaoRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public List<LayoutImportacao> Listar(string pBase)
        {
            List<LayoutImportacao> temp = null;
            try
            {
                temp = (from _LayoutImportacao in _context.LayoutImportacao

                        where
                       _LayoutImportacao.tipoArquivo == pBase

                        select new
                        {
                            tipoArquivo = _LayoutImportacao.tipoArquivo,
                            coluna = _LayoutImportacao.coluna,
                            ordem = _LayoutImportacao.ordem,
                            obrigatorio = _LayoutImportacao.obrigatorio

                        }).ToList().Select(x => new LayoutImportacao()
                        {
                            tipoArquivo = x.tipoArquivo,
                            coluna = x.coluna,
                            ordem = x.ordem,
                            obrigatorio = x.obrigatorio
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }


    }
}
