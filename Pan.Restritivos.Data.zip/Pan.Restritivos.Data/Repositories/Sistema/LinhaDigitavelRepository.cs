﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Linha digital que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class LinhaDigitavelRepository : IDalBase<LinhaDigitavel>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public LinhaDigitavelRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public LinhaDigitavel Alterar(LinhaDigitavel item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<LinhaDigitavel> Importar(List<LinhaDigitavel> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(LinhaDigitavel item)
        {
            try
            {
                LinhaDigitavel user = _context.Set<LinhaDigitavel>().Single(x => x.idLinhaDigitavel == item.idLinhaDigitavel);
                user.blnAtivo = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp = _context.Entry<LinhaDigitavel>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public LinhaDigitavel Inserir(LinhaDigitavel item)
        {
            try
            {
                _context.Set<LinhaDigitavel>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<LinhaDigitavel> Listar(LinhaDigitavel item)
        {
            List<LinhaDigitavel> temp = null;
            try
            {
                temp = (from _LinhaDigitavels in _context.LinhaDigitavel
                        join _Motivo in _context.Motivo on _LinhaDigitavels.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _LinhaDigitavels.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _LinhaDigitavels.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                          ((String.IsNullOrEmpty(item.nrLinhaDigitavel)) || (_LinhaDigitavels.nrLinhaDigitavel.Contains(item.nrLinhaDigitavel)))
                          &&
                          (
                              ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_LinhaDigitavels.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                &&
                              ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_LinhaDigitavels.dtVigenciaFim) <= item.dtVigenciaFim))
                          )


                        select new
                        {
                            blnAtivo = _LinhaDigitavels.blnAtivo,
                            nrLinhaDigitavel = _LinhaDigitavels.nrLinhaDigitavel,
                            dtManutencao = _LinhaDigitavels.dtManutencao,
                            idLinhaDigitavel = _LinhaDigitavels.idLinhaDigitavel,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _LinhaDigitavels.idUsuarioManutencao,                            
                            dtVigenciaInicio = _LinhaDigitavels.dtVigenciaInicio,
                            dtVigenciaFim = _LinhaDigitavels.dtVigenciaFim,
                            idPeso = _LinhaDigitavels.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _LinhaDigitavels.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _LinhaDigitavels.txObs
                        }).ToList().Select(x => new LinhaDigitavel()
                            {

                                blnAtivo = x.blnAtivo,
                                nrLinhaDigitavel = x.nrLinhaDigitavel,
                                dtManutencao = x.dtManutencao,
                                idLinhaDigitavel = x.idLinhaDigitavel,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,                                
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<LinhaDigitavel> ListarLog(int id)
        {
            List<LinhaDigitavel> temp = null;
            try
            {
                temp = (from _LinhaDigitavels in _context.LinhaDigitavelLog
                        join _Motivo in _context.Motivo on _LinhaDigitavels.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _LinhaDigitavels.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _LinhaDigitavels.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _LinhaDigitavels.idLinhaDigitavel == id

                        select new
                        {
                            idLinhaDigitavel = _LinhaDigitavels.idLinhaDigitavel,
                            idLinhaDigitavelLog = _LinhaDigitavels.idLinhaDigitavelLog,
                            blnAtivo = _LinhaDigitavels.blnAtivo,
                            nrLinhaDigitavel = _LinhaDigitavels.nrLinhaDigitavel,
                            dtManutencao = _LinhaDigitavels.dtManutencao,                            
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _LinhaDigitavels.idUsuarioManutencao,
                            dtVigenciaInicio = _LinhaDigitavels.dtVigenciaInicio,
                            dtVigenciaFim = _LinhaDigitavels.dtVigenciaFim,                            
                            idPeso = _LinhaDigitavels.idPeso,
                            idMotivo = _LinhaDigitavels.idMotivo,
                            txObs = _LinhaDigitavels.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao =_LinhaDigitavels.txAcao
                        }).ToList().Select(x => new LinhaDigitavel()
                        {

                            idLinhaDigitavel = x.idLinhaDigitavel,
                            idLinhaDigitavelLog = x.idLinhaDigitavelLog,
                            blnAtivo = x.blnAtivo,
                            nrLinhaDigitavel = x.nrLinhaDigitavel,
                            dtManutencao = x.dtManutencao,                            
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public LinhaDigitavel Obter(LinhaDigitavel item)
        {
            try
            {
                return _context.LinhaDigitavel.Select(x => x).Where(x => (x.nrLinhaDigitavel == item.nrLinhaDigitavel && x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(LinhaDigitavel item)
        {
            try
            {
                if (_context.LinhaDigitavel.Select(x => x).Where(x => (x.nrLinhaDigitavel == item.nrLinhaDigitavel)).FirstOrDefault() != null) { return true; };
                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(LinhaDigitavel item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
