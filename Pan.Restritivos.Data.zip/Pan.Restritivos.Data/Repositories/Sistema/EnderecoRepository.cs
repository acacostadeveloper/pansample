﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Endereço que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class EnderecoRepository : IDalBase<Endereco>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public EnderecoRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Endereco Alterar(Endereco item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Endereco> Importar(List<Endereco> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Endereco item)
        {
            try
            {
                Endereco user = _context.Set<Endereco>().Single(x => x.idEndereco == item.idEndereco);
                user.blnAtivo = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp = _context.Entry<Endereco>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Endereco Inserir(Endereco item)
        {
            try
            {
                _context.Set<Endereco>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Endereco> Listar(Endereco item)
        {
            List<Endereco> temp = null;
            try
            {
                temp = (from _Enderecos in _context.Endereco
                        join _Motivo in _context.Motivo on _Enderecos.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Enderecos.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Enderecos.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                             ((string.IsNullOrEmpty(item.nmBairro)) || (_Enderecos.nmBairro.Contains(item.nmBairro)))
                              &&
                             ((string.IsNullOrEmpty(item.nmCidade)) || (_Enderecos.nmCidade.Contains(item.nmCidade)))
                             &&
                             ((string.IsNullOrEmpty(item.nmLogradouro)) || (_Enderecos.nmLogradouro.Contains(item.nmLogradouro)))
                             &&
                             ((string.IsNullOrEmpty(item.nmUF)) || (_Enderecos.nmUF.Contains(item.nmUF)))                          
                            &&
                            (
                                ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_Enderecos.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                  &&
                                ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_Enderecos.dtVigenciaFim) <= item.dtVigenciaFim))
                            )                                           
                            

                        select new
                        {
                            blnAtivo = _Enderecos.blnAtivo,
                            nrEndereco = _Enderecos.nrEndereco,
                            nmBairro = _Enderecos.nmBairro,
                            nmCidade = _Enderecos.nmCidade,
                            nmLogradouro = _Enderecos.nmLogradouro,
                            nmUF = _Enderecos.nmUF,
                            nrCEP = _Enderecos.nrCEP,
                            tpLogradouro = _Enderecos.tpLogradouro,
                            dtManutencao = _Enderecos.dtManutencao,
                            idEndereco = _Enderecos.idEndereco,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Enderecos.idUsuarioManutencao,
                            dtVigenciaInicio = _Enderecos.dtVigenciaInicio,
                            dtVigenciaFim = _Enderecos.dtVigenciaFim,
                            idPeso = _Enderecos.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _Enderecos.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _Enderecos.txObs
                        }).ToList().Select(x => new Endereco()
                            {

                                blnAtivo = x.blnAtivo,
                                nrEndereco = x.nrEndereco,
                                nmBairro = x.nmBairro,
                                nmCidade = x.nmCidade,
                                nmLogradouro = x.nmLogradouro,
                                nmUF = x.nmUF,
                                nrCEP = x.nrCEP,
                                tpLogradouro = x.tpLogradouro,
                                dtManutencao = x.dtManutencao,
                                idEndereco = x.idEndereco,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<Endereco> ListarLog(int id)
        {
            List<Endereco> temp = null;
            try
            {
                temp = (from _Enderecos in _context.EnderecoLog
                        join _Motivo in _context.Motivo on _Enderecos.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Enderecos.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Enderecos.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _Enderecos.idEndereco == id

                        select new
                        {
                            idEndereco = _Enderecos.idEndereco,
                            idEnderecoLog = _Enderecos.idEnderecoLog,
                            blnAtivo = _Enderecos.blnAtivo,
                            nrEndereco = _Enderecos.nrEndereco,
                            nmBairro = _Enderecos.nmBairro,
                            nmCidade = _Enderecos.nmCidade,
                            nmLogradouro = _Enderecos.nmLogradouro,
                            nmUF = _Enderecos.nmUF,
                            nrCEP = _Enderecos.nrCEP,
                            tpLogradouro = _Enderecos.tpLogradouro,
                            dtManutencao = _Enderecos.dtManutencao,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Enderecos.idUsuarioManutencao,
                            dtVigenciaInicio = _Enderecos.dtVigenciaInicio,
                            dtVigenciaFim = _Enderecos.dtVigenciaFim,
                            idPeso = _Enderecos.idPeso,
                            idMotivo = _Enderecos.idMotivo,
                            txObs = _Enderecos.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao = _Enderecos.txAcao
                        }).ToList().Select(x => new Endereco()
                        {

                            idEndereco = x.idEndereco,
                            idEnderecoLog = x.idEnderecoLog,
                            blnAtivo = x.blnAtivo,
                            nrEndereco = x.nrEndereco,
                            nmBairro = x.nmBairro,
                            nmCidade = x.nmCidade,
                            nmLogradouro = x.nmLogradouro,
                            nmUF = x.nmUF,
                            nrCEP = x.nrCEP,
                            tpLogradouro = x.tpLogradouro,
                            dtManutencao = x.dtManutencao,
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public Endereco Obter(Endereco item)
        {
            try
            {
                return _context.Endereco.Select(x => x).Where(x => (x.nrCEP == item.nrCEP && x.nrEndereco == item.nrEndereco && x.blnAtivo == true && (!String.IsNullOrEmpty(item.txComplemento) ? x.txComplemento == item.txComplemento : x.txComplemento == x.txComplemento))).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Endereco item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Endereco item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
