﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente ao Robo de atualização de viegência que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class RoboRepository 
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public RoboRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public int UpdateVigencia(string query)
        {
            try
            {
               return _context.ExecuteSqlCommand(query);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
