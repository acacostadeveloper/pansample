﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á CPF que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class CpfRepository : IDalBase<Cpf>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public CpfRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Cpf Alterar(Cpf item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Cpf> Importar(List<Cpf> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Cpf item)
        {
            try
            {
                Cpf user                 = _context.Set<Cpf>().Single(x => x.idCpf == item.idCpf);
                user.blnAtivo            = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp                 = _context.Entry<Cpf>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Cpf Inserir(Cpf item)
        {
            try
            {
                _context.Set<Cpf>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Cpf> Listar(Cpf item)
        {
            List<Cpf> temp = null;
            try
            {
                temp = (from _Cpfs in _context.Cpf
                        join _Motivo in _context.Motivo on _Cpfs.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Cpfs.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Cpfs.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                          ((string.IsNullOrEmpty(item.nrCpf)) || (_Cpfs.nrCpf.Contains(item.nrCpf)))
                         &&
                          ((string.IsNullOrEmpty(item.nmTitular)) || (_Cpfs.nmTitular.Contains(item.nmTitular)))
                          &&
                          (
                              ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_Cpfs.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                &&
                              ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_Cpfs.dtVigenciaFim) <= item.dtVigenciaFim))
                          )                          
                        
                        select new
                        {
                            blnAtivo = _Cpfs.blnAtivo,
                            nrCpf = _Cpfs.nrCpf,
                            dtManutencao = _Cpfs.dtManutencao,
                            idCpf = _Cpfs.idCpf,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Cpfs.idUsuarioManutencao,
                            nmTitular = _Cpfs.nmTitular,
                            dtVigenciaInicio = _Cpfs.dtVigenciaInicio,
                            dtVigenciaFim = _Cpfs.dtVigenciaFim,
                            idPeso = _Cpfs.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _Cpfs.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _Cpfs.txObs
                        }).ToList().Select(x => new Cpf()
                            {

                                blnAtivo = x.blnAtivo,
                                nrCpf = x.nrCpf,
                                dtManutencao = x.dtManutencao,
                                idCpf = x.idCpf,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,
                                nmTitular = x.nmTitular,
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<Cpf> ListarLog(int id)
        {
            List<Cpf> temp = null;
            try
            {
                temp = (from _Cpfs in _context.CpfLog
                        join _Motivo in _context.Motivo on _Cpfs.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _Cpfs.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _Cpfs.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _Cpfs.idCpf == id

                        select new
                        {
                            idCpf = _Cpfs.idCpf,
                            idCpfLog = _Cpfs.idCpfLog,
                            blnAtivo = _Cpfs.blnAtivo,
                            nrCpf = _Cpfs.nrCpf,
                            dtManutencao = _Cpfs.dtManutencao,                            
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _Cpfs.idUsuarioManutencao,
                            dtVigenciaInicio = _Cpfs.dtVigenciaInicio,
                            dtVigenciaFim = _Cpfs.dtVigenciaFim,
                            nmTitular = _Cpfs.nmTitular,
                            idPeso = _Cpfs.idPeso,
                            idMotivo = _Cpfs.idMotivo,
                            txObs = _Cpfs.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao =_Cpfs.txAcao
                        }).ToList().Select(x => new Cpf()
                        {

                            idCpf = x.idCpf,
                            idCpfLog = x.idCpfLog,
                            blnAtivo = x.blnAtivo,
                            nrCpf = x.nrCpf,
                            dtManutencao = x.dtManutencao,                            
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            nmTitular = x.nmTitular,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public Cpf Obter(Cpf item)
        {
            try
            {
                return _context.Cpf.Select(x => x).Where(x => (x.nrCpf == item.nrCpf && x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Cpf item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Cpf item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
