﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Peso de alerta que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class PesoAlertaRepository : IDalBase<Peso>, IDisposable
    {
        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public PesoAlertaRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public Peso Alterar(Peso item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Peso> Importar(List<Peso> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Peso item)
        {
            try
            {
                Peso user = _context.Set<Peso>().Single(x => x.idPeso == item.idPeso);
                user.blnAtivo = false;
                var temp = _context.Entry<Peso>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Peso Inserir(Peso item)
        {
            try
            {
                _context.Set<Peso>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Peso> Listar(Peso item)
        {
            List<Peso> temp = null;
            try
            {
                temp = (from _pesos in _context.Peso
                        join _Usuarios2 in _context.Usuarios on _pesos.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                          ((string.IsNullOrEmpty(item.codPeso)) || (_pesos.codPeso.Contains(item.codPeso)))
                         &&
                          ((string.IsNullOrEmpty(item.txPeso)) || (_pesos.txPeso.Contains(item.txPeso)))

                        select new
                        {
                            blnAtivo = _pesos.blnAtivo,
                            codPeso = _pesos.codPeso,
                            dtManutencao = _pesos.dtManutencao,
                            idPeso = _pesos.idPeso,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _pesos.idUsuarioManutencao,
                            txPeso = _pesos.txPeso
                        }).ToList().Select(x => new Peso()
                            {

                                blnAtivo = x.blnAtivo,
                                codPeso = x.codPeso,
                                dtManutencao = x.dtManutencao,
                                idPeso = x.idPeso,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                txPeso = x.txPeso
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<Peso> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Peso Obter(Peso item)
        {
            try
            {
                return _context.Peso.Select(x => x).Where(x => (x.codPeso == item.codPeso) && (x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Peso item)
        {
            try
            {
                if (_context.Peso.Join(_context.Cpf, x => x.idPeso, y => y.idPeso, (x, y) => new 
                { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Peso.Join(_context.Cnpj, x => x.idPeso, y => y.idPeso, (x, y) => new 
                { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Peso.Join(_context.CodigoBarra, x => x.idPeso, y => y.idPeso, (x, y) => new 
                { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Peso.Join(_context.DadoBancario, x => x.idPeso, y => y.idPeso, (x, y) => new 
                { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; ; }

                if (_context.Peso.Join(_context.Endereco, x => x.idPeso, y => y.idPeso, (x, y) => new 
                { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; ; }

                if (_context.Peso.Join(_context.Ip, x => x.idPeso, y => y.idPeso, (x, y) => new 
                { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Peso.Join(_context.LinhaDigitavel, x => x.idPeso, y => y.idMotivo, (x, y) =>
                    new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                if (_context.Peso.Join(_context.Telefone, x => x.idPeso, y => y.idMotivo, (x, y) =>
                  new { a = x, b = y }).Where(xx => xx.b.idMotivo == item.idPeso).Select(xx => xx.a).FirstOrDefault() != null)
                { return true; }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
                         
        }

        public bool ValidarImportacao(Peso item)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
