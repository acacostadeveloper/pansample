﻿using Pan.Restritivos.Data.Context;
using Pan.Restritivos.Data.Context.Interfaces;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data.Repositories.Sistema
{
    /// <summary>
    /// Repositório referente á Dados bancários que implementa os mêtodos do contexto para interação com o entity framework
    /// </summary>
    public class DadoBancarioRepository : IDalBase<DadoBancario>, IDisposable
    {

        IUnitOfWork unitOfWork = new BreakAwayContext();
        private BreakAwayContext _context;

        public DadoBancarioRepository()
        {
            if (unitOfWork == null)
                throw new ArgumentNullException("unitOfWork");

            _context = unitOfWork as BreakAwayContext;
        }

        public DadoBancario Alterar(DadoBancario item)
        {
            try
            {
                _context.Entry(item).State = EntityState.Modified;
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<DadoBancario> Importar(List<DadoBancario> item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(DadoBancario item)
        {
            try
            {
                DadoBancario user = _context.Set<DadoBancario>().Single(x => x.idDadoBancario == item.idDadoBancario);
                user.blnAtivo = false;
                user.idUsuarioManutencao = item.idUsuarioManutencao;
                var temp = _context.Entry<DadoBancario>(user).State = EntityState.Modified;
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public DadoBancario Inserir(DadoBancario item)
        {
            try
            {
                _context.Set<DadoBancario>().Add(item);
                _context.SaveChanges();
                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<DadoBancario> Listar(DadoBancario item)
        {
            List<DadoBancario> temp = null;
            try
            {
                temp = (from _DadoBancarios in _context.DadoBancario
                        join _Motivo in _context.Motivo on _DadoBancarios.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _DadoBancarios.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _DadoBancarios.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                              (
                                  ((string.IsNullOrEmpty(item.nrCPFCNPJ)) || (_DadoBancarios.nrCPFCNPJ.Contains(item.nrCPFCNPJ)))
                                  &&
                                  ((item.nrBanco == 0) || (_DadoBancarios.nrBanco == item.nrBanco))
                                  &&
                                  ((item.nrAgencia == 0) || (_DadoBancarios.nrAgencia == item.nrAgencia))
                                  &&
                                  ((string.IsNullOrEmpty(item.nrAgenciaDigito)) || (_DadoBancarios.nrAgenciaDigito.Contains(item.nrAgenciaDigito)))
                                  &&
                                  ((item.nrConta == 0) || (_DadoBancarios.nrConta == item.nrConta))
                                  &&
                                  ((string.IsNullOrEmpty(item.nrContaDigito)) || (_DadoBancarios.nrContaDigito.Contains(item.nrContaDigito)))
                                  &&
                                  ((string.IsNullOrEmpty(item.nmCliente)) || (_DadoBancarios.nmCliente.Contains(item.nmCliente)))
                              )
                              &&
                              (
                              ((item.dtVigenciaInicio == DateTime.MinValue) || (DbFunctions.TruncateTime(_DadoBancarios.dtVigenciaInicio) >= item.dtVigenciaInicio))
                                &&
                             ((!item.dtVigenciaFim.HasValue) || (DbFunctions.TruncateTime(_DadoBancarios.dtVigenciaFim) <= item.dtVigenciaFim))
                              )


                        select new
                        {
                            blnAtivo = _DadoBancarios.blnAtivo,
                            nrAgencia = _DadoBancarios.nrAgencia,
                            nrAgenciaDigito = _DadoBancarios.nrAgenciaDigito,
                            nrBanco = _DadoBancarios.nrBanco,
                            nrConta = _DadoBancarios.nrConta,
                            nrContaDigito = _DadoBancarios.nrContaDigito,
                            nrCPFCNPJ = _DadoBancarios.nrCPFCNPJ,
                            nmCliente = _DadoBancarios.nmCliente,
                            dtManutencao = _DadoBancarios.dtManutencao,
                            idDadoBancario = _DadoBancarios.idDadoBancario,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _DadoBancarios.idUsuarioManutencao,
                            dtVigenciaInicio = _DadoBancarios.dtVigenciaInicio,
                            dtVigenciaFim = _DadoBancarios.dtVigenciaFim,
                            idPeso = _DadoBancarios.idPeso,
                            txMotivo = _Motivo.txMotivo,
                            idMotivo = _DadoBancarios.idMotivo,
                            txPeso = _Peso.txPeso,
                            txObs = _DadoBancarios.txObs
                        }).ToList().Select(x => new DadoBancario()
                            {

                                blnAtivo = x.blnAtivo,
                                nrAgencia = x.nrAgencia,
                                nrAgenciaDigito = x.nrAgenciaDigito,
                                nrBanco = x.nrBanco,
                                nrConta = x.nrConta,
                                nrContaDigito = x.nrContaDigito,
                                nrCPFCNPJ = x.nrCPFCNPJ,
                                nmCliente = x.nmCliente,
                                dtManutencao = x.dtManutencao,
                                idDadoBancario = x.idDadoBancario,
                                nmUsuarioManutencao = x.nmUsuarioManutencao,
                                idUsuarioManutencao = x.idUsuarioManutencao,
                                dtVigenciaInicio = x.dtVigenciaInicio,
                                dtVigenciaFim = x.dtVigenciaFim,
                                idPeso = x.idPeso,
                                txMotivo = x.txMotivo,
                                idMotivo = x.idMotivo,
                                txPeso = x.txPeso,
                                txObs = x.txObs
                            }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public List<DadoBancario> ListarLog(int id)
        {
            List<DadoBancario> temp = null;
            try
            {
                temp = (from _DadoBancarios in _context.DadoBancarioLog
                        join _Motivo in _context.Motivo on _DadoBancarios.idMotivo equals _Motivo.idMotivo
                        join _Peso in _context.Peso on _DadoBancarios.idPeso equals _Peso.idPeso
                        join _Usuarios2 in _context.Usuarios on _DadoBancarios.idUsuarioManutencao equals _Usuarios2.idUsuario into tm
                        from subUser in tm.DefaultIfEmpty()
                        let UsuarioManutencao = subUser.nmUsuario
                        where
                         _DadoBancarios.idDadoBancario == id

                        select new
                        {
                            idDadoBancario = _DadoBancarios.idDadoBancario,
                            idDadoBancarioLog = _DadoBancarios.idDadoBancarioLog,
                            blnAtivo = _DadoBancarios.blnAtivo,
                            nrAgencia = _DadoBancarios.nrAgencia,
                            nrAgenciaDigito = _DadoBancarios.nrAgenciaDigito,
                            nrCPFCNPJ = _DadoBancarios.nrCPFCNPJ,
                            nmCliente = _DadoBancarios.nmCliente,
                            nrBanco = _DadoBancarios.nrBanco,
                            nrConta = _DadoBancarios.nrConta,
                            nrContaDigito = _DadoBancarios.nrContaDigito,
                            dtManutencao = _DadoBancarios.dtManutencao,
                            nmUsuarioManutencao = UsuarioManutencao,
                            idUsuarioManutencao = _DadoBancarios.idUsuarioManutencao,
                            dtVigenciaInicio = _DadoBancarios.dtVigenciaInicio,
                            dtVigenciaFim = _DadoBancarios.dtVigenciaFim,
                            idPeso = _DadoBancarios.idPeso,
                            idMotivo = _DadoBancarios.idMotivo,
                            txObs = _DadoBancarios.txObs,
                            txMotivo = _Motivo.txMotivo,
                            txPeso = _Peso.txPeso,
                            txAcao = _DadoBancarios.txAcao
                        }).ToList().Select(x => new DadoBancario()
                        {

                            idDadoBancario = x.idDadoBancario,
                            idDadobancarioLog = x.idDadoBancarioLog,
                            blnAtivo = x.blnAtivo,
                            nrAgencia = x.nrAgencia,
                            nrAgenciaDigito = x.nrAgenciaDigito,
                            nrCPFCNPJ = x.nrCPFCNPJ,
                            nmCliente = x.nmCliente,
                            nrBanco = x.nrBanco,
                            nrConta = x.nrConta,
                            nrContaDigito = x.nrContaDigito,
                            dtManutencao = x.dtManutencao,
                            nmUsuarioManutencao = x.nmUsuarioManutencao,
                            idUsuarioManutencao = x.idUsuarioManutencao,
                            dtVigenciaInicio = x.dtVigenciaInicio,
                            dtVigenciaFim = x.dtVigenciaFim,
                            idPeso = x.idPeso,
                            idMotivo = x.idMotivo,
                            txObs = x.txObs,
                            txMotivo = x.txMotivo,
                            txPeso = x.txPeso,
                            txAcao = x.txAcao
                        }).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return temp;
        }

        public DadoBancario Obter(DadoBancario item)
        {
            try
            {
                return _context.DadoBancario.Select(x => x).Where(x => (x.nrAgencia == item.nrAgencia && x.nrBanco == item.nrBanco && x.nrConta == item.nrConta && x.blnAtivo == true)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(DadoBancario item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(DadoBancario item)
        {
            throw new NotImplementedException();
        }


        void IDisposable.Dispose()
        {
            _context.Dispose();
        }
    }
}
