﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Data
{
    /// <summary>
    /// Interface genérica para definição do gerenciamento de bases restritivos  
    /// </summary>
    /// <typeparam name="T">Entidade utlizada pela classe que impementa a interface</typeparam>
    public interface IDalBase<T>
    {
        T Alterar(T item);
        List<T> Importar(List<T> item);
        bool Inativar(T item);
        T Inserir(T item);
        List<T> Listar(T item);
        List<T> ListarLog(int id);
        T Obter(T item);
        bool Validar(T item);
        bool ValidarImportacao(T item);
    }
}
