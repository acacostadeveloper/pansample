﻿var app = angular.module('PanApp', ['ngPatternRestrict',
    'ui.bootstrap',
    'ngRoute',
    'LocalStorageModule',
    'angular-loading-bar',
    'ui.utils.masks',
    'angularUtils.directives.dirPagination',
    'flow',
    'ngInputModified',
    'angularUtils.directives.dirPagination',
    'angular-hmac-sha512',
    'angular-jwt']);

if (self == top) {    
    document.documentElement.style.display = 'block';    
} else {    
    top.location = self.location;    
}


app.config(function ($routeProvider) {

    $routeProvider.when("/home", {
        controller: "homeController",
        templateUrl: "/app/views/home.html"
    });

    $routeProvider.when("/403", {
        controller: "homeController",
        templateUrl: "/app/views/403.html"
    });


    $routeProvider.when("/login", {
        controller: "loginController",
        templateUrl: "/app/views/login.html"
    });

    // ----------------------------------------------------- MENU "BASE" -----------------------
    $routeProvider.when("/cnpj", {
        controller: "cnpjController",
        templateUrl: "/app/views/base/cnpj.html"
    });

    $routeProvider.when("/cpf", {
        controller: "cpfController",
        templateUrl: "/app/views/base/cpf.html"
    });
    $routeProvider.when("/dadosbancarios", {
        controller: "dadosBancariosController",
        templateUrl: "/app/views/base/dadosbancarios.html"
    });

    $routeProvider.when("/telefone", {
        controller: "telefoneController",
        templateUrl: "/app/views/base/telefone.html"
    });

    $routeProvider.when("/ip", {
        controller: "ipController",
        templateUrl: "/app/views/base/ip.html"
    });

    $routeProvider.when("/codigobarra", {
        controller: "codigobarraController",
        templateUrl: "/app/views/base/codigobarra.html"
    });

    $routeProvider.when("/endereco", {
        controller: "enderecoController",
        templateUrl: "/app/views/base/endereco.html"
    });

    $routeProvider.when("/linhadigitavel", {
        controller: "linhaDigitavelController",
        templateUrl: "/app/views/base/linhadigitavel.html"
    });

    // ----------------------------------------------------- MENU "CADASTRO" ---------------------
    $routeProvider.when("/usuario", {
        controller: "usuarioController",
        templateUrl: "/app/views/cadastro/usuario.html"
    });
    $routeProvider.when("/pesoalerta", {
        controller: "pesoAlertaController",
        templateUrl: "/app/views/cadastro/pesoAlerta.html"
    });

    $routeProvider.when("/motivoalerta", {
        controller: "motivoalertaController",
        templateUrl: "/app/views/cadastro/motivoalerta.html"
    });
    $routeProvider.when("/relatoriobase", {
        controller: "relatoriobaseController",
        templateUrl: "/app/views/cadastro/relatoriobase.html"
    });
    // ----------------------------------------------------- MENU "FILTRO" ---------------------
    //EGS IT Singular 16.01.2018 - SRT Cadastro de Tipo Agrupamento
    $routeProvider.when("/tipoagrupamento", {
        controller: "tipoagrupamentoController",
        templateUrl: "/app/views/filtros/tipoagrupamento.html"
    });
    //EGS IT Singular 15.01.2018 - SRT Cadastro de Tipo Operador
    $routeProvider.when("/tipooperador", {
        controller: "tipooperadorController",
        templateUrl: "/app/views/filtros/tipooperador.html"
    });
    //EGS IT Singular 17.01.2018 - SRT Cadastro de Periodo agrupamento
    $routeProvider.when("/periodoagrupamento", {
        controller: "periodoagrupamentoController",
        templateUrl: "/app/views/filtros/periodoagrupamento.html"
    });
    //EGS IT Singular 14.01.2018 - SRT Cadastro de Entidade Filtro
    $routeProvider.when("/entidade", {
        controller: "entidadeController",
        templateUrl: "/app/views/filtros/entidade.html"
    });
    //EGS IT Singular 14.01.2018 - SRT Cadastro de Entidade Atributo
    $routeProvider.when("/entidadeatributo", {
        controller: "entidadeatributoController",
        templateUrl: "/app/views/filtros/entidadeatributo.html"
    });

    // ----------------------------------------------------- MENU "TABELAS" --------------------
    // TABELAS ------------------ EGS IT Singular 05.01.2018 - SRT Cadastro em geral -----------
    //de instituicao Financeira
    $routeProvider.when("/instituicaofinanceira", {
        controller: "instituicaofinanceiraController",
        templateUrl: "/app/views/tabela/instituicaofinanceira.html"
    });
    //EGS IT Singular 31.12.2017 - SRT Cadastro de Alcada
    $routeProvider.when("/alcada", {
        controller: "alcadaController",
        templateUrl: "/app/views/tabela/alcada.html"
    });
    //EGS IT Singular 12.01.2018 - SRT Cadastro de Tipo de Origem
    $routeProvider.when("/tipoorigem", {
        controller: "tipoorigemController",
        templateUrl: "/app/views/tabela/tipoorigem.html"
    });
    //EGS IT Singular 15.01.2018 - SRT Cadastro de Tipo de Destino
    $routeProvider.when("/tipodestino", {
        controller: "tipodestinoController",
        templateUrl: "/app/views/tabela/tipodestino.html"
    });
    //EGS IT Singular 17.01.2018 - SRT Cadastro de Email de Alerta
    $routeProvider.when("/emailalerta", {
        controller: "emailalertaController",
        templateUrl: "/app/views/tabela/emailalerta.html"
    });
    //EGS IT Singular 18.01.2018 - SRT Cadastro de Lista Branca
    $routeProvider.when("/listabranca", {
        controller: "listabrancaController",
        templateUrl: "/app/views/tabela/listabranca.html"
    });
    //EGS IT Singular 18.01.2018 - SRT Cadastro de Lista Negra
    $routeProvider.when("/listanegra", {
        controller: "listanegraController",
        templateUrl: "/app/views/tabela/listanegra.html"
    });
    //EGS IT Singular 19.01.2018 - SRT Cadastro de Tipo de Mensagem
    $routeProvider.when("/tipomensagem", {
        controller: "tipomensagemController",
        templateUrl: "/app/views/tabela/tipomensagem.html"
    });

    // ----------------------------------------------------- MENU "PARAMETRIZA" ----------------
    // PARAMETRIZACAO ----------- EGS IT Singular 19.01.2018 - SRT Monitoramento de Requisições
    $routeProvider.when("/regravalidacao", {
        controller: "regravalidacaoController",
        templateUrl: "/app/views/parametrizacao/regravalidacao.html"
    });
    $routeProvider.when("/monitoramento", {
        controller: "monitoramentoController",
        templateUrl: "/app/views/parametrizacao/monitoramento.html"
    });


    // ----------------------------------------------------- MENU "IMPORTACAO" --------------------- 30.05.2018 
    $routeProvider.when("/importacao", {
        controller: "importacaoController",
        templateUrl: "/app/views/importacao/importacao.html"
    });

    // -----------------------------------------------------------------------------------------

    $routeProvider.otherwise({ redirectTo: "/login" });
});



app.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.xsrfCookieName = 'FORM-XSRF';
}]);

app.config(['$crypthmacProvider', function ($crypthmacProvider) {
    $crypthmacProvider.setCryptoSecret('a1b2c3d4e5');
}]);



//===============================================================================================================================
//         Portas (Site , Serviço, WS    e SMT  )
//Desenvolvimento: 35024, 35023  , 35022 e 35021
//Homologação    : 35024, 35025  , 35026 e 35021
//Produção       : 35024, 35025  , 35026 e 35021
//===============================================================================================================================
var serviceVersao = '1.0629.0000';
var urlAtual      = window.location.href;

if(urlAtual.substring(0, 16) === "http://localhost") 
{
    var serviceBase        = 'http://localhost:35023/';                          //WcfRestfull PADRAO
    var serviceBaseSRT     = 'http://localhost:35021/';                          //SRT - LOCAL PADRAO
    var serviceTextoLogin  = 'DEVP';
} else
{
    if (urlAtual.substring(0, 21) == "http://restritivosdes")
    {
        var serviceBase       = 'http://restritivosdes.grupopan.com:35023/';    //WcfRestfull
        var serviceBaseSRT    = 'http://restritivosdes.grupopan.com:35021/';    //SRT Local
        var serviceTextoLogin = 'DEVP_DNS';
    }
    else
    {
        if (urlAtual.substring(0, 21) == "http://restritivoshml")
        {
            var serviceBase       = 'http://restritivoshml.grupopan.com:35025/';    //WcfRestfull
            var serviceBaseSRT    = 'http://restritivoshml.grupopan.com:35021/';    //SRT - HOMOLOGACAO
            var serviceTextoLogin = 'HML';
        }
        else
        {
            if (urlAtual.substring(0, 21) == "http://restritivos")
            {
                var serviceBase       = 'http://restritivos.grupopan.com:35025/';    //WcfRestfull
                var serviceBaseSRT    = 'http://restritivos.grupopan.com:35021/';    //SRT - PRODUCAO
                var serviceTextoLogin = '';
            }
        }
    }
}
//===============================================================================================================================
//===============================================================================================================================


app.constant('ngAuthSettings', {
    apiServiceBaseUri   : serviceBase,
    apiServiceBaseUriSRT: serviceBaseSRT,
    apiServiceTextoLogin: serviceTextoLogin,
    apiServiceVersao    : serviceVersao
});




app.config(function ($httpProvider) {
    $httpProvider.interceptors.push('authInterceptorService');
});

app.config(['flowFactoryProvider', function (flowFactoryProvider) {
    flowFactoryProvider.defaults = {
        target: serviceBase & 'api/configuracao/upload',
        permanentErrors: [404, 500, 501],
        maxChunkRetries: 1,
        chunkRetryInterval: 5000,
        simultaneousUploads: 4
    };

}]);


app.run(['loginService', function (authService) {
    authService.fillAuthData();
}]);
app.factory('maskCheck', function () {
    var maskID = {
        new: function (m, v) {

            if (m == '###.###.###-##|##.###.###/####-##') {
                if (v.length > 14) {
                    return maskID.new('##.###.###/####-##', v);
                } else {
                    return maskID.new('###.###.###-##', v);
                }
            }

            if (m == '## ####-####|## #####-####') {
                if (v.length > 12) {
                    return maskID.new('## #####-####', v);
                } else {
                    return maskID.new('## ####-####', v);
                }
            }

            var tv = "";
            var ret = "";
            var character = "#";
            var separator = "|";
            var maskUse = "";
            v = maskID.empty(v);
            if (v == "") {
                return v
            };
            var temp = m.split(separator);
            var dif = 1000;

            var vm = v;
            // removing the mask value existing
            for (var i = 0; i < v.length; i++) {
                if (!isNaN(v.substr(i, 1))) {
                    tv = tv + v.substr(i, 1);
                }
            }

            v = tv;

            // dynamic format mask
            for (var i = 0; i < temp.length; i++) {
                var mult = "";
                var validate = 0;
                for (var j = 0; j < temp[i].length; j++) {
                    if (temp[i].substr(j, 1) == "]") {
                        temp[i] = temp[i].substr(j + 1);
                        break;
                    }
                    if (validate == 1) mult = mult + temp[i].substr(j, 1);
                    if (temp[i].substr(j, 1) == "[") validate = 1;
                }
                for (var j = 0; j < v.length; j++) {
                    temp[i] = mult + temp[i];
                }
            }

            // check which masks use
            if (temp.length == 1) {
                maskUse = temp[0];
                var cleanMask = "";
                for (var j = 0; j < maskUse.length; j++) {
                    if (maskUse.substr(j, 1) == character) {
                        cleanMask = cleanMask + character;
                    }
                }
                var tam = cleanMask.length;
            } else {
                // clean different characters of the character of the mask
                for (var i = 0; i < temp.length; i++) {
                    var cleanMask = "";
                    for (var j = 0; j < temp[i].length; j++) {
                        if (temp[i].substr(j, 1) == character) {
                            cleanMask = cleanMask + character;
                        }
                    }
                    if (v.length > cleanMask.length) {
                        if (dif > (v.length - cleanMask.length)) {
                            dif = v.length - cleanMask.length;
                            maskUse = temp[i];
                            tam = cleanMask.length;
                        }
                    } else if (v.length < cleanMask.length) {
                        if (dif > (cleanMask.length - v.length)) {
                            dif = cleanMask.length - v.length;
                            maskUse = temp[i];
                            tam = cleanMask.length;
                        }
                    } else {
                        maskUse = temp[i];
                        tam = cleanMask.length;
                        break;
                    }
                }
            }



            // validating mask size according to the size of the value
            if (v.length > tam) {
                v = v.substr(0, tam);
            } else if (v.length < tam) {
                var masct = "";
                var j = v.length;
                for (var i = maskUse.length - 1; i >= 0; i--) {
                    if (j == 0) break;
                    if (maskUse.substr(i, 1) == character) {
                        j--;
                    }
                    masct = maskUse.substr(i, 1) + masct;
                }
                maskUse = masct;
            }

            // Apply mask
            j = maskUse.length - 1;
            for (var i = v.length - 1; i >= 0; i--) {
                if (maskUse.substr(j, 1) != character) {
                    ret = maskUse.substr(j, 1) + ret;
                    j--;
                }
                ret = v.substr(i, 1) + ret;
                j--;
            }
            return ret;
        },

        empty: function (v) {
            var vclean = "";
            var len = v.length;
            for (var i = 0; i < 30; i++) {
                if (v.substr(i, 1) == " ") {
                } else {
                    vclean = vclean + v.substr(i, 1);
                }
            }
            return vclean;
        }
    };

    return maskID;
});
app.directive('ngMask', ['maskCheck', function (maskCheck) {
    return {
        restrict: 'A',
        scope: {
            ngModel: '=',
            mask: '@',
            valueMax: '@'
        },
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {

            var newMask = (!scope.mask ? '[#]' : scope.mask);
            var newCheck = (!scope.valueMax ? "" : parseFloat(scope.valueMax.replace('.', '').replace(',', '')));

            scope.ngModel = maskCheck.new(newMask, scope.ngModel.replace('.', ''));

            if (scope.ngModel) {
                scope.ngModel = maskCheck.new(newMask, scope.ngModel);
            }

            elem.bind("keyup", function () {

                scope.$apply(function () {

                    scope.ngModel = maskCheck.new(newMask, scope.ngModel);
                    var newValue = parseFloat(scope.ngModel.replace('.', '').replace(',', ''));
                    if (newCheck) {
                        if (newValue > newCheck) {
                            scope.ngModel = maskCheck.new(newMask, scope.valueMax);
                        }
                    } else {
                        scope.ngModel = maskCheck.new(newMask, scope.ngModel);
                    }
                });
            });
        }
    }
}]);
app.directive('passwordConfirm', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        scope: {
            matchTarget: '=',
        },
        require: 'ngModel',
        link: function link(scope, elem, attrs, ctrl) {
            var validator = function (value) {
                if (scope.matchTarget != null) {
                    ctrl.$setValidity('match', value === scope.matchTarget);
                    return value;
                }
            }

            ctrl.$parsers.unshift(validator);
            ctrl.$formatters.push(validator);

            // This is to force validator when the original password gets changed
            scope.$watch('matchTarget', function (newval, oldval) {
                validator(ctrl.$viewValue);
            });

        }
    };
}]);
app.directive("passwordStrength", function () {

    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ctrl) {
            scope.$watch(function () {
                return (ctrl.$pristine && angular.isUndefined(ctrl.$modelValue)) || $parse(attrs.match)(scope) === ctrl.$modelValue;
            }, function (currentValue) {
                ctrl.$setValidity('match', currentValue);
            });

            //This part is supposed to check the strength
            ctrl.$parsers.unshift(function (viewValue) {
                var pwdValidLength, pwdHasLetter, pwdHasNumber;

                pwdValidLength = (viewValue && viewValue.length >= 8 ? true : false);
                pwdHasLetter = (viewValue && /[A-z]/.test(viewValue)) ? true : false;
                pwdHasNumber = (viewValue && /\d/.test(viewValue)) ? true : false;

                if (pwdValidLength && pwdHasLetter && pwdHasNumber) {
                    ctrl.$setValidity('pwd', true);
                    scope.strength = 'Forte';
                    scope.class = 'alert-success';
                } else {
                    ctrl.$setValidity('pwd', false);
                    scope.strength = 'Fraca';
                    scope.class = 'alert-danger';
                }
                return viewValue;
            });
        }
    };
});
function isEmpty(value) {
    return angular.isUndefined(value) || value === '' || value === null || value !== value;
}
app.directive('ngMin', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attr, ctrl) {
            scope.$watch(attr.ngMin, function () {
                ctrl.$setViewValue(ctrl.$viewValue);
            });
            var minValidator = function (value) {
                var min = attr.ngMin || 0;
                if (!isEmpty(value) && value < min) {
                    ctrl.$setValidity('ngMin', false);

                    return undefined;
                } else {
                    ctrl.$setValidity('ngMin', true);
                    return value;
                }
            };

            ctrl.$parsers.push(minValidator);
            ctrl.$formatters.push(minValidator);
        }
    };
});
app.directive('ngMax', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attr, ctrl) {
            scope.$watch(attr.ngMax, function () {
                ctrl.$setViewValue(ctrl.$viewValue);
            });
            var maxValidator = function (value) {
                var max = attr.ngMax || Infinity;
                if (!isEmpty(value) && value > max) {
                    ctrl.$setValidity('ngMax', false);

                    return undefined;
                } else {
                    ctrl.$setValidity('ngMax', true);

                    return value;
                }
            };

            ctrl.$parsers.push(maxValidator);
            ctrl.$formatters.push(maxValidator);
        }
    };
});
app.filter('ordenar', function () {
    return function (items, predicate, reverse) {

        items.sort(function (a, b) {            
            return a[predicate].localeCompare(b[predicate]);
        });
        return items;
    };
})
app.filter('ativo', function () {
    return function(input) {
        return input ? 'Ativo' : 'Inativo';
    }
})
app.directive('fileHandler', function (readFile) {
    'use strict';

    return {
        link: function (scope, element) {
            element.on('change', function (event) {
                var file = event.target.files[0];
                readFile(file).then(function (content) {                    
                });
            });
        }
    };
})
app.directive('fileBrowser', function (readFile) {
    'use strict';

    return {
        template: '<input id="inputReadFile" type="file" style="display: none;" />' +
            '<ng-transclude></ng-transclude>',
        transclude: true,
        link: function (scope, element, attrs) {

            var fileInput = $('#inputReadFile');

            fileInput.on('change', function (event) {

                var file = event.target.files[0];

                if ((file.name).match(/[0-9a-z]+$/i) == "xlsx") {
                    scope.$eval(attrs.fileBrowser);                    
                    readFile.readFile(file).then(function (content) { });
                }
                else {
                    scope.ArquivoInvalido();
                }

            });

            element.on('click', function () {
                fileInput[0].value = "";
                fileInput[0].click();
            });
        }
    };
});
app.directive('pwCheck', function () {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            elem.on('change', function () {
                scope.$apply(function () {
                    var len = elem.val().length;
                    ctrl.$setValidity('zero', true);

                    if (len === 10) {
                        ctrl.$setValidity('zero', false);
                    }

                });
            });
        }
    }
});