﻿app.factory('instituicaofinanceiraService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var instituicaofinanceiraServiceFactory = {};


    var _pesquisar = function (instituicaofinanceira)
    {
        var Temp = JSON.parse(JSON.stringify(instituicaofinanceira));
        return $http.get(serviceBase + 'api/instituicaofinanceira', { params: { nmInstituicaoFinanceira: Temp.nmInstituicaoFinanceira, nrCnpj: Temp.nrCnpj } }).then(function (response) {
            return response;
        })
    };
   
    
    var _Inserir = function (instituicaofinanceira)
    {
        var Temp = JSON.parse(JSON.stringify(instituicaofinanceira));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/instituicaofinanceira', Temp).then(function (response) {
            return response;
        });
    }



    var _Alterar = function (instituicaofinanceira) {
        var Temp = JSON.parse(JSON.stringify(instituicaofinanceira));
        return $http.put(serviceBase + 'api/instituicaofinanceira', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idInstituicaoFinanceira) {
        var id = JSON.parse(JSON.stringify(idInstituicaoFinanceira));
        return $http.delete(serviceBase + 'api/instituicaofinanceira', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    instituicaofinanceiraServiceFactory.Inserir         = _Inserir;
    instituicaofinanceiraServiceFactory.pesquisar       = _pesquisar;
    instituicaofinanceiraServiceFactory.Alterar         = _Alterar;
    instituicaofinanceiraServiceFactory.Inativar        = _Inativar;

    return instituicaofinanceiraServiceFactory;
}]);