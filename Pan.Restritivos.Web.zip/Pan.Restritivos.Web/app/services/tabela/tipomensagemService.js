﻿app.factory('tipomensagemService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var tipomensagemServiceFactory = {};


    var _pesquisar = function (tipomensagem)
    {
        var Temp = JSON.parse(JSON.stringify(tipomensagem));
        return $http.get(serviceBase + 'api/tipomensagem', { params: { nrCodigo: Temp.nrCodigo, nmDescricao: Temp.nmDescricao } }).then(function (response) 
        {
        return response;
        });
    }

  
    
    var _Inserir = function (tipomensagem)
    {
        var Temp = JSON.parse(JSON.stringify(tipomensagem));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/tipomensagem', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (tipomensagem) {
        var Temp = JSON.parse(JSON.stringify(tipomensagem));
        return $http.put(serviceBase + 'api/tipomensagem', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idTipoMensagem) {
        var id = JSON.parse(JSON.stringify(idTipoMensagem));
        return $http.delete(serviceBase + 'api/tipomensagem', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    tipomensagemServiceFactory.Inserir         = _Inserir;
    tipomensagemServiceFactory.pesquisar       = _pesquisar;
    tipomensagemServiceFactory.Alterar         = _Alterar;
    tipomensagemServiceFactory.Inativar        = _Inativar;

    return tipomensagemServiceFactory;
}]);