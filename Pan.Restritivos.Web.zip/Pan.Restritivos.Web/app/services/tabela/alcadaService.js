﻿app.factory('alcadaService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var alcadaServiceFactory = {};


    var _pesquisar = function (alcada)
    {
        var Temp = JSON.parse(JSON.stringify(alcada));
        return $http.get(serviceBase + 'api/alcada', { params: { cdAlcada: Temp.cdAlcada, nmDescricao: Temp.nmDescricao } }).then(function (response) {
            return response;
        })
    };

    
    //EGS 30.03.2018 - Pesquisar por Sistema Origem
    var _pesquisarSistema = function (SistemaOrigem) {
        var Temp = JSON.parse(JSON.stringify(SistemaOrigem));
        return $http.get(serviceBase + 'api/sistemaorigem').then(function (response) { return response; })
    };

    
    var _Inserir = function (alcada)
    {
        var Temp = JSON.parse(JSON.stringify(alcada));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/alcada', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (alcada) {

        var Temp = JSON.parse(JSON.stringify(alcada));
        return $http.put(serviceBase + 'api/alcada', Temp).then(function (response)
        {
            return response;
        });
    }



    var _Inativar = function (idalcada) {
        var id = JSON.parse(JSON.stringify(idalcada));
        return $http.delete(serviceBase + 'api/alcada?id='+idalcada).then(function (response) {
            return response;
        });

    };

    /*===========================================================================================================
    // Programa...:  Rotina para gravar LOG em arquivo, problema ao alterar tabelas pelo Servico
    // Autor......:  Edinaldo Silva (IT Singular)
    // Data.......:  30.05.2017
    ===========================================================================================================*/
    var _GravaLog = function (Texto) {
        //Cria Objeto ActiveX
        objFSO = new ActiveXObject("Scripting.FileSystemObject");

        //pasta a ser salvo o arquivo
        var arquivo = 'C:\\Temp\\RestritivoApi.Log';

        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var s = fso.OpenTextFile(arquivo, 8, true, 0);
        s.write(Texto);
        s.WriteBlankLines(1);
        s.Close();
    };


    alcadaServiceFactory.Inserir          = _Inserir;
    alcadaServiceFactory.pesquisar        = _pesquisar;
    alcadaServiceFactory.pesquisarSistema = _pesquisarSistema;
    alcadaServiceFactory.Alterar          = _Alterar;
    alcadaServiceFactory.Inativar         = _Inativar;
    alcadaServiceFactory.GravaLog         = _GravaLog;

    return alcadaServiceFactory;
}]);