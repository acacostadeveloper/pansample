﻿app.factory('tipodestinoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var tipodestinoServiceFactory = {};


    var _pesquisar = function (tipodestino)
    {
        var Temp = JSON.parse(JSON.stringify(tipodestino));
        return $http.get(serviceBase + 'api/tipodestino', { params: { nmDestino: Temp.nmDestino, nmTipoConta: Temp.nmTipoConta, nmTipoPessoa: Temp.nmTipoPessoa } }).then(function (response) { return response; })
    };

    
    var _Inserir = function (tipodestino)
    {
        var Temp = JSON.parse(JSON.stringify(tipodestino));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/tipodestino', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (tipodestino) {
        var Temp = JSON.parse(JSON.stringify(tipodestino));
        return $http.put(serviceBase + 'api/tipodestino', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idTipoDestino) {
        var id = JSON.parse(JSON.stringify(idTipoDestino));
        return $http.delete(serviceBase + 'api/tipodestino', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    tipodestinoServiceFactory.Inserir         = _Inserir;
    tipodestinoServiceFactory.pesquisar       = _pesquisar;
    tipodestinoServiceFactory.Alterar         = _Alterar;
    tipodestinoServiceFactory.Inativar        = _Inativar;

    return tipodestinoServiceFactory;
}]);