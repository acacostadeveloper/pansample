﻿app.factory('listabrancaService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var listabrancaServiceFactory = {};


    var _pesquisar = function (listabranca)
    {
        var Temp = JSON.parse(JSON.stringify(listabranca));
        return $http.get(serviceBase + 'api/listabranca', { params: { nrCNPJ: Temp.nrCNPJ, nmListaBranca: Temp.nmListaBranca, nrBanco: Temp.nrBanco, nrAgencia: Temp.nrAgencia, nrConta: Temp.nrConta } }).then(function (response) {
            return response;
        })
    };

   
    
    var _Inserir = function (listabranca)
    {
        var Temp = JSON.parse(JSON.stringify(listabranca));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/listabranca', Temp).then(function (response) {
            return response;
        });
    }



    var _Alterar = function (listabranca) {
        var Temp = JSON.parse(JSON.stringify(listabranca));
        return $http.put(serviceBase + 'api/listabranca', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idListaBranca) {
        var id = JSON.parse(JSON.stringify(idListaBranca));
        return $http.delete(serviceBase + 'api/listabranca', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    listabrancaServiceFactory.Inserir         = _Inserir;
    listabrancaServiceFactory.pesquisar       = _pesquisar;
    listabrancaServiceFactory.Alterar         = _Alterar;
    listabrancaServiceFactory.Inativar        = _Inativar;

    return listabrancaServiceFactory;
}]);