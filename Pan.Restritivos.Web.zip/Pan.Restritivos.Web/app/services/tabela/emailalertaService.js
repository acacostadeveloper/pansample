﻿app.factory('emailalertaService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var emailalertaServiceFactory = {};


    var _pesquisar = function (emailalerta)
    {
        var Temp = JSON.parse(JSON.stringify(emailalerta));
        return $http.get(serviceBase + 'api/emailalerta', { params: { idEmailAlerta: Temp.idEmailAlerta, nmEmailAlerta: Temp.nmEmailAlerta, IdSistemaOrigem: Temp.IdSistemaOrigem } }).then(function (response) {
            return response;
        })
    };


    //EGS 30.06.2018 - Pesquisar por Sistema Origem
    var _pesquisarSistema = function (SistemaOrigem) {
        var Temp = JSON.parse(JSON.stringify(SistemaOrigem));
        return $http.get(serviceBase + 'api/sistemaorigem').then(function (response) { return response; })
    };

    
    var _Inserir = function (emailalerta)
    {
        var Temp = JSON.parse(JSON.stringify(emailalerta));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/emailalerta', Temp).then(function (response) {
            return response;
        });
    }



    var _Alterar = function (emailalerta) {
        var Temp = JSON.parse(JSON.stringify(emailalerta));
        return $http.put(serviceBase + 'api/emailalerta', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idEmailAlerta) {
        var id = JSON.parse(JSON.stringify(idEmailAlerta));
        return $http.delete(serviceBase + 'api/emailalerta?id='+id).then(function (response) {
            return response;
        });

    };

    emailalertaServiceFactory.Inserir          = _Inserir;
    emailalertaServiceFactory.pesquisar        = _pesquisar;
    emailalertaServiceFactory.pesquisarSistema = _pesquisarSistema;
    emailalertaServiceFactory.Alterar          = _Alterar;
    emailalertaServiceFactory.Inativar         = _Inativar;

    return emailalertaServiceFactory;
}]);