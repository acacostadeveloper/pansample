﻿app.factory('tipoorigemService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var tipoorigemServiceFactory = {};


    var _pesquisar = function (tipoorigem)
    {
        var Temp = JSON.parse(JSON.stringify(tipoorigem));
        return $http.get(serviceBase + 'api/tipoorigem', { params: { nmOrigem: Temp.nmOrigem, nmTipoConta: Temp.nmTipoConta, nmTipoPessoa: Temp.nmTipoPessoa } }).then(function (response) { return response; })
    };
    
    
    var _Inserir = function (tipoorigem)
    {
        var Temp = JSON.parse(JSON.stringify(tipoorigem));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/tipoorigem', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (tipoorigem) {
        var Temp = JSON.parse(JSON.stringify(tipoorigem));
        return $http.put(serviceBase + 'api/tipoorigem', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idTipoOrigem) {
        var id = JSON.parse(JSON.stringify(idTipoOrigem));
        return $http.delete(serviceBase + 'api/tipoorigem', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    tipoorigemServiceFactory.Inserir         = _Inserir;
    tipoorigemServiceFactory.pesquisar       = _pesquisar;
    tipoorigemServiceFactory.Alterar         = _Alterar;
    tipoorigemServiceFactory.Inativar        = _Inativar;

    return tipoorigemServiceFactory;
}]);