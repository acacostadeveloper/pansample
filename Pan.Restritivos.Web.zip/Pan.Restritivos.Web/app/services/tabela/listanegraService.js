﻿app.factory('listanegraService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var listanegraServiceFactory = {};


    var _pesquisar = function (listanegra)
    {
        var Temp = JSON.parse(JSON.stringify(listanegra));
        return $http.get(serviceBase + 'api/listanegra', { params: { nrCNPJ: Temp.nrCNPJ, nmListaNegra: Temp.nmListaNegra, nrBanco: Temp.nrBanco, nrAgencia: Temp.nrAgencia, nrConta: Temp.nrConta } }).then(function (response) {
            return response;
        })
    };

    
    var _Inserir = function (listanegra)
    {
        var Temp = JSON.parse(JSON.stringify(listanegra));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/listanegra', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (listanegra) {
        var Temp = JSON.parse(JSON.stringify(listanegra));
        return $http.put(serviceBase + 'api/listanegra', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idListaNegra) {
        var id = JSON.parse(JSON.stringify(idListaNegra));
        return $http.delete(serviceBase + 'api/listanegra', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    listanegraServiceFactory.Inserir         = _Inserir;
    listanegraServiceFactory.pesquisar       = _pesquisar;
    listanegraServiceFactory.Alterar         = _Alterar;
    listanegraServiceFactory.Inativar        = _Inativar;

    return listanegraServiceFactory;
}]);