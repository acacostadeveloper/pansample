﻿app.factory('motivoalertaService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUri;
    var motivoalertaServiceFactory = {};


    var _Inserir = function (motivoalerta) {
     
        return $http.post(serviceBase + 'api/motivoalerta/Inserir', motivoalerta).then(function (response) {
            return response;
        });
    }

    var _pesquisar = function (motivoalerta) {
        return $http.get(serviceBase + 'api/motivoalerta/Listar', { params: { codMotivo: motivoalerta.codMotivo, txMotivo: motivoalerta.txMotivo } }).then(function (response) {
            return response;
        })
    };

    var _Alterar = function (motivoalerta) {

        return $http.post(serviceBase + 'api/motivoalerta/Alterar', motivoalerta).then(function (response) {
            return response;
        });

    };


    var _Inativar = function (idMotivo) {

        return $http.get(serviceBase + 'api/motivoalerta/Inativar', { params: { idMotivo: idMotivo } }).then(function (response) {
            return response;
        });

    };

    motivoalertaServiceFactory.Inserir = _Inserir;
    motivoalertaServiceFactory.pesquisar = _pesquisar;
    motivoalertaServiceFactory.Alterar = _Alterar;
    motivoalertaServiceFactory.Inativar = _Inativar;

    return motivoalertaServiceFactory;
}]);