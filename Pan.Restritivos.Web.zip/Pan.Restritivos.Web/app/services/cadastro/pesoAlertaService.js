﻿'use strict';
app.factory('pesoAlertaService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var usuarioServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro) {
            return $http.get(serviceBase + 'api/pesoalerta/Listar', { params: { codPeso: filtro.codPeso, txPeso: filtro.txPeso } }).then(function (response) {
                return response;
            })
        }

        var _Inserir = function (pesoalerta) {

            return $http.post(serviceBase + 'api/pesoalerta/Inserir', pesoalerta).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (pesoalerta) {

            return $http.post(serviceBase + 'api/pesoalerta/Inativar', pesoalerta).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (pesoalerta) {

            return $http.post(serviceBase + 'api/pesoalerta/Alterar', pesoalerta).then(function (response) {
                return response;
            });
        }

        usuarioServiceFactory.Inativar = _Inativar;
        usuarioServiceFactory.pesquisar = _pesquisar;
        usuarioServiceFactory.Inserir = _Inserir;
        usuarioServiceFactory.Alterar = _Alterar;

        return usuarioServiceFactory;
    }]);