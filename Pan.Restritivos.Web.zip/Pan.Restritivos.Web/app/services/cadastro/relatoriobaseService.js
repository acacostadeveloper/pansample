﻿'use strict';
app.factory('relatoriobaseService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var cpfServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }

        var _lista = function (base) {
            var filtro;

            switch (base) {

                case "cpf":
                    filtro = { params: { nrCpf: "", nmTitular: "", dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "cnpj":
                    filtro = { params: { nrCnpj: "", nmEmpresa: "", dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "codigobarra":
                    filtro = { params: { codBarra: "", dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "dadosbancarios":
                    filtro = { params: { nrBanco: 0, nrAgencia: 0, nrAgenciaDigito: "", nrConta: 0, nrContaDigito: "", nmCliente: "", nrCPFCNPJ: "", dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "endereco":
                    filtro = { params: { nmLogradouro: "", nmBairro: "", nmCidade: "", nmUF: "", dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "ip":
                    filtro = { params: { nrIP: "", nrPorta: 0, dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "linhadigitavel":
                    filtro = { params: { nrLinhaDigitavel: "", dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
                case "telefone":
                    filtro = { params: { nrDDD: 0, nrTelefone: 0, dtVigenciaInicio: "", dtVigenciaFim: "" } };
                    break;
              
            }


            return $http.get(serviceBase + 'api/' + base + '/Listar', filtro).then(function (response) {
                return response;
            })
        }

        cpfServiceFactory.lista = _lista;


        return cpfServiceFactory;
    }]);