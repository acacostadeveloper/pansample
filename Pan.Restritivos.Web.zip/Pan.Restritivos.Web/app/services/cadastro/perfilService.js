﻿'use strict';
app.factory('perfilService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    loginService.verificaSessao();

    var serviceBase = ngAuthSettings.apiServiceBaseUri;

    var perfilServiceFactory = {};

    var _authentication = {
        isAuth: false,
        userName: ""
    };

    var _externalAuthData = {
        provider: "",
        userName: "",
        externalAccessToken: ""
    };

    var _getmenu = function (idperfil) {
        return $http.get(serviceBase + 'api/configuracao/acessos', { params: { idperfil: idperfil } }).then(function (response) {
            return response;
        })
    };

    var _addperfil = function (perfil) {

        return $http.post(serviceBase + 'api/configuracao/addperfil', perfil).then(function (response) {
            return response;
        });

    }

    var _editarperfil = function (perfil) {

        return $http.post(serviceBase + 'api/configuracao/editarperfil', perfil).then(function (response) {
            return response;
        });

    }

    var _pesquisar = function (flagstatus) {

        return $http.get(serviceBase + 'api/configuracao/pesquisar', { params: { flagstatus: flagstatus } }).then(function (response) {
            return response;
        })
    };

    var _deletar = function (idPerfil) {

        return $http.get(serviceBase + 'api/configuracao/deletar', { params: { idPerfil: idPerfil } }).then(function (response) {
            return response;
        })
    };

    var _getperfil = function (idperfil) {
        return $http.get(serviceBase + 'api/configuracao/getperfil', { params: { idperfil: idperfil } }).then(function (response) {
            return response;
        })
    };


    perfilServiceFactory.getmenu = _getmenu;
    perfilServiceFactory.addperfil = _addperfil;
    perfilServiceFactory.editarperfil = _editarperfil;
    perfilServiceFactory.pesquisar = _pesquisar;
    perfilServiceFactory.deletar = _deletar;
    perfilServiceFactory.getperfil = _getperfil;

    return perfilServiceFactory;
}]);