﻿'use strict';
app.factory('usuarioService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    loginService.verificaSessao();

    var serviceBase = ngAuthSettings.apiServiceBaseUri;

    var usuarioServiceFactory = {};

    var _authentication = {
        isAuth: false,
        userName: ""
    };

    var _externalAuthData = {
        provider: "",
        userName: "",
        externalAccessToken: ""
    };

 
    var _pesquisar = function (dadosusuariofiltro) {
        return $http.get(serviceBase + 'api/usuario/Listar', { params: { login: dadosusuariofiltro.login, nmUsuario: dadosusuariofiltro.nmUsuario } }).then(function (response) {
            return response;
        })
    };

    var _ListaFuncionalidades = function (dadosusuariofiltro) {
        return $http.get(serviceBase + 'api/usuario/ListaFuncionalidades').then(function (response) {
            return response;
        })
    };

    var _getListaPerfil = function () {
        return $http.get(serviceBase + 'api/usuario/getListaPerfil').then(function (response) {
            return response;
        })
    };

    var _getListaUsuarioSuplente = function (idUsuarioAtual) {
        return $http.get(serviceBase + 'api/usuario/getListaUsuarioSuplente', { params: { idUsuarioAtual: idUsuarioAtual } }).then(function (response) {
            return response;
        })
    };

    var _getListaCargo = function () {
        return $http.get(serviceBase + 'api/usuario/getListaCargo').then(function (response) {
            return response;
        })
    };

    var _getListaDepartamento = function () {
        return $http.get(serviceBase + 'api/usuario/getListaDepartamento').then(function (response) {
            return response;
        })
    };

    var _getuser = function (iduser) {
        return $http.get(serviceBase + 'api/usuario/getuser', { params: { iduser: iduser } }).then(function (response) {
            return response;
        })
    };

    var _getusuariologado = function () {
        return $http.get(serviceBase + 'api/usuario/getusuariologado').then(function (response) {
            return response;
        })
    };

    var _Inserir = function (usuario) {

        return $http.post(serviceBase + 'api/usuario/Inserir', usuario).then(function (response) {
            return response;
        });
    }

    var _Inativar = function (iduser) {

        return $http.get(serviceBase + 'api/usuario/Inativar', { params: { iduser: iduser } }).then(function (response) {
            return response;
        })
};

    var _Alterar = function (usuario) {

        return $http.post(serviceBase + 'api/usuario/Alterar', usuario).then(function (response) {
            return response;
        });

    }

    var _getListaDepartamentoLogin = function (iduser) {
        return $http.get(serviceBase + 'api/usuario/getListaDepartamentoLogin', { params: { iduser: iduser } }).then(function (response) {
            return response;
        })
    }


    var _getReadWrite = function (caminho) {
        return $http.get(serviceBase + 'api/usuario/getReadWrite', { params: {caminho: caminho} }).then(function (response) {
            return response;
        })
    };

    var _validaUsuarioExistenteAD = function (login) {
        return $http.get(serviceBase + 'api/usuario/validaUsuarioExistenteAD', { params: { login: login } }).then(function (response) {
            return response;
        })
    };


    usuarioServiceFactory.Inativar = _Inativar;
    usuarioServiceFactory.getListaDepartamento = _getListaDepartamento;
    usuarioServiceFactory.getListaCargo = _getListaCargo;
    usuarioServiceFactory.getListaPerfil = _getListaPerfil;
    usuarioServiceFactory.pesquisar = _pesquisar;
    usuarioServiceFactory.getuser = _getuser;
    usuarioServiceFactory.getusuariologado = _getusuariologado;
    usuarioServiceFactory.Inserir = _Inserir;
    usuarioServiceFactory.Alterar = _Alterar;
    usuarioServiceFactory.getListaUsuarioSuplente = _getListaUsuarioSuplente;
    usuarioServiceFactory.getListaDepartamentoLogin = _getListaDepartamentoLogin;
    usuarioServiceFactory.getReadWrite = _getReadWrite;
    usuarioServiceFactory.validaUsuarioExistenteAD = _validaUsuarioExistenteAD;
    usuarioServiceFactory.ListaFuncionalidades = _ListaFuncionalidades;
    

    return usuarioServiceFactory;
}]); 