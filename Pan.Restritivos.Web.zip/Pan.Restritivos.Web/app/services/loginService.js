﻿'use strict';
app.factory('loginService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', '$location', 'jwtHelper', function ($http, $q, localStorageService, ngAuthSettings, $location, jwtHelper) {

    var serviceBase = ngAuthSettings.apiServiceBaseUri;

    var authServiceFactory = {};

    var _authentication = {
        isAuth: false,
        login: "",
        userName: "",
        acessos: [],
        mensagens: [],
        endSession: false,
        sessionID: 0,
        deslogouSessaoAnterior: false
    };

    var _externalAuthData = {
        provider: "",
        userName: "",
        externalAccessToken: ""
    };

    var headerSkipAuthorization = {
        headers: { 'Skip-Authorization': 'true' }
    };

    var _getaccesspage = function (link) {

        var retorno = {
            status: false,
            acesso: []
        };

        // Verificar se o usuário possui permissão de leitura para visualizar a tela em questão
        var permissao = $.grep(_authentication.acessos, function (e) { return e.txLink == link; });
        if (permissao.length > 0) {
            retorno.acesso = permissao[0];
        } else {
            retorno.acesso = null;
        }

        // Verifica se existe usuário logado
        if (_authentication.isAuth == false) {
            retorno.status = false;
        }
        else
        {
            retorno.status = true;
        }

        // Se chegou neste ponto, o usuário está logado, então libera as páginas HOME e 403
        if (link == '/home' || link == '/403') {
            retorno.status = true;
        }
        return retorno;
    }

    var _login = function (loginData) {
        var key = CryptoJS.enc.Utf8.parse('7061737323313233');
        var iv  = CryptoJS.enc.Utf8.parse('7061737323313233');
        var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(loginData.senha), key,
            {
                keySize: 128 / 8,
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            });

        //_logOut();
        var deferred = $q.defer();

        //## Criação do sessionID
        _authentication.sessionID = _createSessionID(loginData.usuario);

        var dataToken = {
            "Login": loginData.usuario,
            "Senha": encrypted.toString(),
            "SessionId": _authentication.sessionID
        }
             

        $http.post(serviceBase + 'api/token', dataToken, headerSkipAuthorization).success(function (response) {
        
            localStorageService.set('authorizationData', { token: response.token, sessionId: response.SessionId });
            _authentication.isAuth                 = true;
            _authentication.login                  = response.Login;
            _authentication.userName               = response.NomeUsuario;
            _authentication.acessos                = response.Roles;
            _authentication.deslogouSessaoAnterior = response.deslogouSessaoAnterior;

            deferred.resolve(response);

        }).error(function (err, status) {
            _logOut();
            deferred.reject(err);
        });

        return deferred.promise;

    };

    var _logOut = function () {

        var sessao = {
            login: _authentication.login,
            sessionID: _authentication.sessionID
        };
        
        $http.post(serviceBase + 'api/usuario/limparSessao',  { login: sessao.login, sessionID: sessao.sessionID } , headerSkipAuthorization).then(function (response) {

            _authentication.isAuth = false;
            _authentication.login = "";
            _authentication.userName = "";
            _authentication.acessos = [];
            _authentication.mensagens = [];
            _authentication.endSession = false;
            _authentication.sessionID = 0;
            _authentication.deslogouSessaoAnterior = false;

            localStorageService.remove('authorizationData');
            return response;
        });
    };

    var _fillAuthData = function () {

        var authorizationData = localStorageService.get('authorizationData');

        if (authorizationData) {

            var token = null;

            //## Verifica se o token está expirado
            if (jwtHelper.isTokenExpired(authorizationData.token)) {
                localStorageService.remove('authorizationData');
                _authentication.endSession = true;
                _authentication.isAuth = false;
                _authentication.userName = "";
                _authentication.acessos = [],
                _authentication.mensagens = []
                $location.path('/403');
            }
            else {
                token = jwtHelper.decodeToken(authorizationData.token);
            }

            if (token) {
                _authentication.isAuth = true;
                _authentication.login = token.Login;
                _authentication.userName = token.NomeUsuario;
                _authentication.acessos = token.Roles;
                _authentication.deslogouSessaoAnterior = token.deslogouSessaoAnterior;
                _authentication.sessionID = token.SessionId;

                if ($location.path() == "/login" || $location.path() == "") {
                    $location.path('/home');
                }

            }
        }
    };

    var _verificaSessao = function () {
        return;
    };

    var _createSessionID = function (x) {
        function s4() { return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1); }
        function uniqueKey(y) { var dataAtual = new Date(Date.now()); return dataAtual.getHours().toString() + y + dataAtual.getMinutes().toString() + dataAtual.getSeconds().toString() }
        return Math.floor((1 + Math.random()) * 0x10000);//s4() + s4() + '-' + s4() + '-' + uniqueKey(x) + '-' + s4() + '-' + s4() + s4();
    }

    authServiceFactory.authentication = _authentication;
    authServiceFactory.login = _login;
    authServiceFactory.logOut = _logOut;
    authServiceFactory.fillAuthData = _fillAuthData;
    authServiceFactory.getaccesspage = _getaccesspage;
    authServiceFactory.verificaSessao = _verificaSessao;
    authServiceFactory.urlWcfRestful = serviceBase;

    return authServiceFactory;
}]);