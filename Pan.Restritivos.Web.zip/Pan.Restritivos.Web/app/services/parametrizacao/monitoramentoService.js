﻿app.factory('monitoramentoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase    = ngAuthSettings.apiServiceBaseUriSRT;
    var monitoramentoServiceFactory = {};


    var _pesquisar = function (monitoramento)
    {
        var Temp = JSON.parse(JSON.stringify(monitoramento));
        return $http.get(serviceBase + 'api/mensagemtransferencia', { params: { dtInclusaoInicio: Temp.dtInclusaoInicio, dtInclusaoFinal: Temp.dtInclusaoFinal, nrStatus: Temp.nrStatus, NroBoleto: Temp.NroBoleto, nrValInicio: Temp.nrValInicio, nrValFinal: Temp.nrValFinal } }).then(function (response) {
            return response;
        })
    };


    // EGS 05.02.2018 - Envia os dados para WS autbank, mas não esta enviando os dados, uma bosta !!
    var _pesquisarWSAutBank = function (dadosautbank)
    {
        var Temp = JSON.parse(JSON.stringify(dadosautbank));

        var startTime             = new Date();
        var startMsec1            = startTime.getMilliseconds();
        Temp.agencia              = startMsec1;
        Temp.codEvento            = "EVE942";    // + startMsec1;
        Temp.HoraVencto           = "13:21";
        Temp.Valor                = (startMsec1 * 45.17);
        var startTime             = new Date();
        var startMsec2            = startTime.getMilliseconds();
        Temp.AgenciaDeb           = startMsec2;
        Temp.ContaDeb             = "154"+startMsec2;
        Temp.BancoCredito         = "341";
        var startTime             = new Date();
        var startMsec3            = startTime.getMilliseconds();
        Temp.AgenciaCred          = startMsec2 + startMsec3;
        Temp.ContaCred            = startMsec3 + startMsec1;
        Temp.TipoContaCred        = "MESMA TITULARIDADE";                //CC=Conta, PP=Poupanca
        Temp.CnpjCpfCliCred       = "03.093.120/0003-03";            //"148"+startMsec1+"168"+startMsec2;
        Temp.NomeCliCred          = "JOAO DAS COVES";
        Temp.Finalidade           = "CREDITO";
        var startTime             = new Date();
        var startMsec4            = startTime.getMilliseconds();
        Temp.Historico            = "Com historico definido...";
        Temp.Tarifado             = "True";
        Temp.ValidaPtoCorteSpb    = "True";
        Temp.CodUsuario           = "USU01";
        Temp.CnpjCpfCliRem        = "14873816890";
        Temp.NomeCliRem           = "IT SINGULAR";
        Temp.CnpjCpfCliCred2      = "14873816890";
        Temp.NomeCliCred2         = "PEDRO DAS COVES NEVES";
        Temp.CodIdentdTransf      = "STR0006";                       //Utilizado para STR0006, STR0007, STR0008, PAG0108
        Temp.Origem               = "CLIENTE";
        Temp.SisOrigem            = "SANTANDER";
        Temp.DataVencto           = "26/03/2018";
        Temp.TipoPessoaCred       = "FISICA";
        Temp.Prioridade           = "TODAS";                         //Prioridade (“B”, “C”, “D”)
        Temp.DataAgendPag         = "11/11/2018";
        Temp.DebAutorizado        = "True";
        Temp.SensibilizaCC        = "True";
        Temp.NroBoleto            = "BOL01";
        Temp.CodCliente           = "XXCLI01";
        Temp.TipoPessoaInvest     = "FISICA";
        Temp.CnpjCpfInvest        = "04245321000170";
        Temp.NomeRzSocialInvest   = "PANAMERICANO INVEST";
        Temp.ComplementoHistorico = "BATATINHA QUANDO NASCE";
        Temp.NumOrigem            = "ORIG01";
        Temp.SubSistemaO          = "12";
        Temp.CanalEntrada         = "P";                             //P - Pessoal/Presencial   E-Eletrônico    I-Internet  ---  Obs.: Se não informado, o e-Bank assumirá como default “P” – Pessoal/Presencial
        Temp.IspbCred             = "False";

        return $http.post(serviceBase + 'api/mensagemtransferencia', Temp).then(function (response)
        {
            var resposta = response;
            alert("Retorno do webservice: \n\n" + response.data.descricaoErro);

            return response;
        });
        var resposta = response;        
    };


    





    //================================================================================ \\
    // EGS 30.02.2018 - EGS IT Singular
    // Para blooquear ou desbloquear o Monitoramento, conforme estatus atual
    //================================================================================ \\
    var _AlterarBloqueio = function (monitoramentostatus) {
        var Temp = JSON.parse(JSON.stringify(monitoramentostatus));

        return $http.put(serviceBase + 'api/mensagemtransferencia', Temp).then(function (response) {
            return response;
        });

    };



    monitoramentoServiceFactory.pesquisar          = _pesquisar;
    monitoramentoServiceFactory.pesquisarWSAutBank = _pesquisarWSAutBank;
    monitoramentoServiceFactory.AlterarBloqueio    = _AlterarBloqueio;

    return monitoramentoServiceFactory;
}]);