﻿app.factory('regravalidacaoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService',
    function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var regravalidacaoServiceFactory = {};


    var _pesquisar = function (regravalidacao)
    {
        var Temp = JSON.parse(JSON.stringify(regravalidacao));
        return $http.get(serviceBase + 'api/regravalidacao', { params: { nmDescricao: Temp.nmDescricao, nmConsequencia: Temp.nmConsequencia, nrCriticidade: Temp.nrCriticidade } }).then(function (response) {
            return response;
        })
    };
    
    var _Inserir = function (regravalidacao)
    {
        var Temp = JSON.parse(JSON.stringify(regravalidacao));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/regravalidacao', Temp).then(function (response) {
            return response;
        });
    }

    var _Alterar = function (regravalidacao) {
        var Temp = JSON.parse(JSON.stringify(regravalidacao));
        return $http.put(serviceBase + 'api/regravalidacao', Temp).then(function (response) {
            return response;
        });
    }

    var _Inativar = function (idRegraValidacao) {
        var id = JSON.parse(JSON.stringify(idRegraValidacao));
        return $http.delete(serviceBase + 'api/regravalidacao', { params: { id: id, ativar: false } }).then(function (response) {
            return response;
        });
    };


    //EGS 22.01.2018 - IT Singular, mesmo metodo de ATIVAR/DESATIVAR, se tiver ativado, desativa, e versa e vice
    var _Ativar = function (idRegraValidacao) {
        var id = JSON.parse(JSON.stringify(idRegraValidacao));
        return $http.delete(serviceBase + 'api/regravalidacao', { params: { id: id, ativar: true } }).then(function (response) {
            return response;
        });
    };











    //EGS Alterar uma clausula
    var _AlterarClausula = function (regravalidaclausula) {
        var Temp = JSON.parse(JSON.stringify(regravalidaclausula));
        return $http.put(serviceBase + 'api/regravalidaclausula', Temp).then(function (response) {
            return response;
        });
    }


    //EGS Inativa o item da Clausula da Regra informada
    var _InativarClausula = function (idRegraValidaClausula) {
        var id = JSON.parse(JSON.stringify(idRegraValidaClausula));
        return $http.delete(serviceBase + 'api/regravalidaclausula', { params: { id: id } }).then(function (response) {
            return response;
        });
    };


    //EGS Inserir uma clausula
    var _InserirClausula = function (regravalidaclausula) {
        var Temp = JSON.parse(JSON.stringify(regravalidaclausula));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/regravalidaclausula', Temp).then(function (response) {
            return response;
        });
    }


    //EGS Pesquisa os itens da Clausula da Regra informada
    var _pesquisarclausula = function (id) {
        var Temp = JSON.parse(JSON.stringify(id));
        return $http.get(serviceBase + 'api/regravalidaclausula', { params: { idRegraValidacao: id } }).then(function (response) {
            return response;
        })
    };
    //EGS Pesquisa os itens Tipo Operador
    var _pesquisar_tipooperador = function () {
        return $http.get(serviceBase + 'api/tipooperador').then(function (response) {
            return response;
        })
    };
    //EGS Pesquisa os itens de Entidade Filtro
    var _pesquisar_entidade = function () {
        return $http.get(serviceBase + 'api/entidade').then(function (response) {
            return response;
        })
    };
    //EGS Pesquisa os itens de Entidade Atributo
    var _pesquisar_entidadeatributo = function () {
        return $http.get(serviceBase + 'api/entidadeatributo').then(function (response) {
            return response;
        })
    };
    //EGS Pesquisa os itens de Entidade Atributo pelo ID da Entidade
    var _pesquisar_entidadeatributo_ID = function (id) {
        return $http.get(serviceBase + 'api/entidadeatributo', { params: { idEntidade: id } }).then(function (response) {
            return response;
        })
    };
    //EGS Pesquisa os itens de Tipo Agrupamento
    var _pesquisar_tipoagrupamento = function () {
        return $http.get(serviceBase + 'api/tipoagrupamento').then(function (response) {
            return response;
        })
    };
    //EGS Pesquisa os itens de Periodo Agrupamento
    var _pesquisar_periodoagrupamento = function () {
        return $http.get(serviceBase + 'api/periodoagrupamento').then(function (response) {
            return response;
        })
    };


    regravalidacaoServiceFactory.Inserir                       = _Inserir;
    regravalidacaoServiceFactory.InserirClausula               = _InserirClausula;
    regravalidacaoServiceFactory.pesquisar                     = _pesquisar;
    regravalidacaoServiceFactory.pesquisarclausula             = _pesquisarclausula;
    regravalidacaoServiceFactory.pesquisar_tipooperador        = _pesquisar_tipooperador;
    regravalidacaoServiceFactory.pesquisar_entidade            = _pesquisar_entidade;
    regravalidacaoServiceFactory.pesquisar_entidadeatributo    = _pesquisar_entidadeatributo;
    regravalidacaoServiceFactory.pesquisar_entidadeatributo_ID = _pesquisar_entidadeatributo_ID;
    regravalidacaoServiceFactory.pesquisar_tipoagrupamento     = _pesquisar_tipoagrupamento;
    regravalidacaoServiceFactory.pesquisar_periodoagrupamento  = _pesquisar_periodoagrupamento;
    regravalidacaoServiceFactory.Alterar                       = _Alterar;
    regravalidacaoServiceFactory.AlterarClausula               = _AlterarClausula;
    regravalidacaoServiceFactory.Ativar                        = _Ativar;
    regravalidacaoServiceFactory.Inativar                      = _Inativar;
    regravalidacaoServiceFactory.InativarClausula              = _InativarClausula;

    return regravalidacaoServiceFactory;
}]);