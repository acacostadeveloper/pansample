﻿'use strict';
app.factory('cpfService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var cpfServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro) {
            return $http.get(serviceBase + 'api/cpf/Listar', { params: { nrCpf: filtro.nrCpf, nmTitular: filtro.nmTitular, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim } }).then(function (response) {
                return response;
            })
        }

        
        var _Inserir = function (cpf) {

            var cpfTemp = JSON.parse(JSON.stringify(cpf));
            var split = cpfTemp.dtVigenciaInicio.split('/');
            cpfTemp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (cpfTemp.dtVigenciaFim != null) {
                var splitFim = cpfTemp.dtVigenciaFim.split('/');
                cpfTemp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/cpf/Inserir', cpfTemp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (cpf) {

            return $http.post(serviceBase + 'api/cpf/Inativar', cpf).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (cpf) {

            var cpfTemp = JSON.parse(JSON.stringify(cpf));
            var split = cpfTemp.dtVigenciaInicio.split('/');
            cpfTemp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (cpfTemp.dtVigenciaFim != null) {
                var splitFim = cpfTemp.dtVigenciaFim.split('/');
                cpfTemp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/cpf/Alterar', cpfTemp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (cpf) {

            return $http.post(serviceBase + 'api/cpf/Importar', cpf).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idCpf) {

            return $http.get(serviceBase + 'api/cpf/ListarLog', { params: { idCpf: idCpf } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (cpf) {

            return $http.post(serviceBase + 'api/cpf/Validar', cpf).then(function (response) {
                return response;
            });
        }


        cpfServiceFactory.pesquisar = _pesquisar;
        cpfServiceFactory.Inserir = _Inserir;
        cpfServiceFactory.Alterar = _Alterar;
        cpfServiceFactory.Importar = _Importar;
        cpfServiceFactory.ListarLog = _ListarLog;
        cpfServiceFactory.Inativar = _Inativar;

        return cpfServiceFactory;
    }]);