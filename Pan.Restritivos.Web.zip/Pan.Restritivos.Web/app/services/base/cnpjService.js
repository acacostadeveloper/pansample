﻿'use strict';
app.factory('cnpjService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var CnpjServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro) {
            return $http.get(serviceBase + 'api/Cnpj/Listar', { params: { nrCnpj: filtro.nrCnpj, nmEmpresa: filtro.nmEmpresa, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim } }).then(function (response) {
                return response;
            })
        }

        
        var _Inserir = function (Cnpj) {

            var Temp = JSON.parse(JSON.stringify(Cnpj));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }


            return $http.post(serviceBase + 'api/Cnpj/Inserir', Temp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (Cnpj) {

            return $http.post(serviceBase + 'api/Cnpj/Inativar', Cnpj).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (Cnpj) {
            var Temp = JSON.parse(JSON.stringify(Cnpj));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/Cnpj/Alterar', Temp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (Cnpj) {

            return $http.post(serviceBase + 'api/Cnpj/Importar', Cnpj).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idCnpj) {

            return $http.get(serviceBase + 'api/Cnpj/ListarLog', { params: { idCnpj: idCnpj } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (Cnpj) {

            return $http.post(serviceBase + 'api/Cnpj/Validar', Cnpj).then(function (response) {
                return response;
            });
        }


        CnpjServiceFactory.pesquisar = _pesquisar;
        CnpjServiceFactory.Inserir = _Inserir;
        CnpjServiceFactory.Alterar = _Alterar;
        CnpjServiceFactory.Importar = _Importar;
        CnpjServiceFactory.ListarLog = _ListarLog;
        CnpjServiceFactory.Inativar = _Inativar;

        return CnpjServiceFactory;
    }]);