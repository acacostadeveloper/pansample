﻿'use strict';
app.factory('enderecoService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var enderecoServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro) {
            return $http.get(serviceBase + 'api/endereco/Listar', { params: { nmLogradouro: filtro.nmLogradouro, nmBairro: filtro.nmBairro,nmCidade: filtro.nmCidade,nmUF: filtro.nmUF, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim } }).then(function (response) {
                return response;
            })
        }
        
        
        var _Inserir = function (endereco) {
            var Temp = JSON.parse(JSON.stringify(endereco));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }
            return $http.post(serviceBase + 'api/endereco/Inserir', Temp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (endereco) {

            return $http.post(serviceBase + 'api/endereco/Inativar', endereco).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (endereco) {
            var Temp = JSON.parse(JSON.stringify(endereco));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }
            return $http.post(serviceBase + 'api/endereco/Alterar', Temp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (endereco) {

            return $http.post(serviceBase + 'api/endereco/Importar', endereco).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idEndereco) {

            return $http.get(serviceBase + 'api/endereco/ListarLog', { params: { idEndereco: idEndereco } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (endereco) {

            return $http.post(serviceBase + 'api/endereco/Validar', endereco).then(function (response) {
                return response;
            });
        }


        enderecoServiceFactory.pesquisar = _pesquisar;
        enderecoServiceFactory.Inserir = _Inserir;
        enderecoServiceFactory.Alterar = _Alterar;
        enderecoServiceFactory.Importar = _Importar;
        enderecoServiceFactory.ListarLog = _ListarLog;
        enderecoServiceFactory.Inativar = _Inativar;

        return enderecoServiceFactory;
    }]);