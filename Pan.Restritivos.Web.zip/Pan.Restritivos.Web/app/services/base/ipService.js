﻿'use strict';
app.factory('ipService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var ipServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro)
        {
            if (filtro.nrPorta == "" || filtro.nrPorta == null || filtro.nrPorta == undefined) {
                filtro.nrPorta = 0;
            }

            return $http.get(serviceBase + 'api/ip/Listar', { params: { nrIP: filtro.nrIP, nrPorta: filtro.nrPorta, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim } }).then(function (response) {
                return response;
            })
        }


        var _Inserir = function (ip) {

            var ipTemp = JSON.parse(JSON.stringify(ip));
            var split = ipTemp.dtVigenciaInicio.split('/');
            ipTemp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (ipTemp.dtVigenciaFim != null) {
                var splitFim = ipTemp.dtVigenciaFim.split('/');
                ipTemp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/ip/Inserir', ipTemp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (ip) {

            return $http.post(serviceBase + 'api/ip/Inativar', ip).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (ip) {

            var ipTemp = JSON.parse(JSON.stringify(ip));
            var split = ipTemp.dtVigenciaInicio.split('/');
            ipTemp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (ipTemp.dtVigenciaFim != null) {

                var splitFim = ipTemp.dtVigenciaFim.split('/');
                ipTemp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }
            return $http.post(serviceBase + 'api/ip/Alterar', ipTemp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (ip) {

            return $http.post(serviceBase + 'api/ip/Importar', ip).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idIP) {

            return $http.get(serviceBase + 'api/ip/ListarLog', { params: { idIP: idIP } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (cpf) {

            return $http.post(serviceBase + 'api/ip/Validar', cpf).then(function (response) {
                return response;
            });
        }


        ipServiceFactory.pesquisar = _pesquisar;
        ipServiceFactory.Inserir = _Inserir;
        ipServiceFactory.Alterar = _Alterar;
        ipServiceFactory.Importar = _Importar;
        ipServiceFactory.ListarLog = _ListarLog;
        ipServiceFactory.Inativar = _Inativar;

        return ipServiceFactory;
    }]);