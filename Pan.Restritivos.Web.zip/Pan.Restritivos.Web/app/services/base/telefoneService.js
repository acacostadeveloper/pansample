﻿app.factory('telefoneService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUri;
    var telefoneServiceFactory = {};


    var _Inserir = function (telefone) {

        var Temp = JSON.parse(JSON.stringify(telefone));
        var split = Temp.dtVigenciaInicio.split('/');
        Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

        if (Temp.dtVigenciaFim != null) {
            var splitFim = Temp.dtVigenciaFim.split('/');
            Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
        }


        return $http.post(serviceBase + 'api/telefone/Inserir', Temp).then(function (response) {
            return response;
        });
    }

    var _pesquisar = function (telefone) {
        return $http.get(serviceBase + 'api/telefone/Listar', { params: { nrDDD: telefone.nrDDD, nrTelefone: telefone.nrTelefone, dtVigenciaInicio: telefone.dtVigenciaInicio, dtVigenciaFim: telefone.dtVigenciaFim } }).then(function (response) {
            return response;
        })
    };

    var _Alterar = function (telefone) {

        var Temp = JSON.parse(JSON.stringify(telefone));
        var split = Temp.dtVigenciaInicio.split('/');
        Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

        if (Temp.dtVigenciaFim != null) {
            var splitFim = Temp.dtVigenciaFim.split('/');
            Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
        }

        return $http.post(serviceBase + 'api/telefone/Alterar', Temp).then(function (response) {
            return response;
        });

    };


    var _Inativar = function (telefone) {

        return $http.post(serviceBase + 'api/telefone/Inativar', telefone).then(function (response) {
            return response;
        });

    };

    var _ListarLog = function (idTelefone) {

        return $http.get(serviceBase + 'api/telefone/ListarLog', { params: { idTelefone: idTelefone } }).then(function (response) {
            return response;
        });
    }

    telefoneServiceFactory.Inserir = _Inserir;
    telefoneServiceFactory.pesquisar = _pesquisar;
    telefoneServiceFactory.Alterar = _Alterar;
    telefoneServiceFactory.Inativar = _Inativar;
    telefoneServiceFactory.ListarLog = _ListarLog;

    return telefoneServiceFactory;
}]);