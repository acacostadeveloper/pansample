﻿'use strict';
app.factory('codigobarraService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var codigoBarraServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro) {
            return $http.get(serviceBase + 'api/codigobarra/Listar', { params: { codBarra: filtro.codBarra, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim } }).then(function (response) {
                return response;
            })
        }


        var _Inserir = function (codigoBarra) {
            var Temp = JSON.parse(JSON.stringify(codigoBarra));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/codigobarra/Inserir', Temp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (codigoBarra) {

            return $http.post(serviceBase + 'api/codigobarra/Inativar', codigoBarra).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (codigoBarra) {
            var Temp = JSON.parse(JSON.stringify(codigoBarra));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/codigobarra/Alterar', Temp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (codigoBarra) {

            return $http.post(serviceBase + 'api/codigobarra/Importar', codigoBarra).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idCodigoBarra) {

            return $http.get(serviceBase + 'api/codigobarra/ListarLog', { params: { idCodigoBarra: idCodigoBarra } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (codigoBarra) {

            return $http.post(serviceBase + 'api/codigobarra/Validar', codigoBarra).then(function (response) {
                return response;
            });
        }


        codigoBarraServiceFactory.pesquisar = _pesquisar;
        codigoBarraServiceFactory.Inserir = _Inserir;
        codigoBarraServiceFactory.Alterar = _Alterar;
        codigoBarraServiceFactory.Importar = _Importar;
        codigoBarraServiceFactory.ListarLog = _ListarLog;
        codigoBarraServiceFactory.Inativar = _Inativar;

        return codigoBarraServiceFactory;
    }]);