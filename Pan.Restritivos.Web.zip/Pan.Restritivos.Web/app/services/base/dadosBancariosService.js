﻿'use strict';
app.factory('dadosBancariosService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var dadosBancariosFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }

        var _pesquisar = function (filtro) {

            var nrBanco = 0;
            var nrAgencia = 0;
            var nrConta = 0;

            if(filtro.nrBanco != "")
                nrBanco = filtro.nrBanco;

            if (filtro.nrAgencia != "")
                nrAgencia = filtro.nrAgencia;

            if (filtro.nrConta != "")
                nrConta = filtro.nrConta;

            var temp = { nrBanco: nrBanco, nrAgencia: nrAgencia, nrAgenciaDigito: filtro.nrAgenciaDigito, nrConta: nrConta, nrContaDigito: filtro.nrContaDigito, nmCliente: filtro.nmCliente, nrCPFCNPJ: filtro.nrCPFCNPJ, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim }


            return $http.get(serviceBase + 'api/dadosbancarios/Listar', {
                params: temp
            }).then(function (response) {
                    return response;
                })
        }


        var _Inserir = function (dadobancario) {
            var Temp = JSON.parse(JSON.stringify(dadobancario));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }

            return $http.post(serviceBase + 'api/dadosbancarios/Inserir', Temp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (dadobancario) {

            return $http.post(serviceBase + 'api/dadosbancarios/Inativar', dadobancario).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (dadobancario) {
            var Temp = JSON.parse(JSON.stringify(dadobancario));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }
            return $http.post(serviceBase + 'api/dadosbancarios/Alterar', Temp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (dadobancario) {

            return $http.post(serviceBase + 'api/dadosbancarios/Importar', dadobancario).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idDadoBancario) {

            return $http.get(serviceBase + 'api/dadosbancarios/ListarLog', { params: { idDadoBancario: idDadoBancario } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (dadobancario) {

            return $http.post(serviceBase + 'api/dadosbancarios/Validar', dadobancario).then(function (response) {
                return response;
            });
        }


        dadosBancariosFactory.pesquisar = _pesquisar;
        dadosBancariosFactory.Inserir = _Inserir;
        dadosBancariosFactory.Alterar = _Alterar;
        dadosBancariosFactory.Importar = _Importar;
        dadosBancariosFactory.ListarLog = _ListarLog;
        dadosBancariosFactory.Inativar = _Inativar;

        return dadosBancariosFactory;
    }]);