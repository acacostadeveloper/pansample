﻿'use strict';
app.factory('linhaDigitavelService', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService) {

        loginService.verificaSessao();

        var serviceBase = ngAuthSettings.apiServiceBaseUri;

        var linhaDigitavelServiceFactory = {};

        var _authentication = {
            isAuth: false,
            userName: ""
        }

        var _externalAuthData = {
            provider: "",
            userName: "",
            externalAccessToken: ""
        }


        var _pesquisar = function (filtro) {
            return $http.get(serviceBase + 'api/linhadigitavel/Listar', { params: { nrLinhaDigitavel: filtro.nrLinhaDigitavel, dtVigenciaInicio: filtro.dtVigenciaInicio, dtVigenciaFim: filtro.dtVigenciaFim } }).then(function (response) {
                return response;
            })
        }

        
        var _Inserir = function (linhadigitavel) {
            var Temp = JSON.parse(JSON.stringify(linhadigitavel));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }
            return $http.post(serviceBase + 'api/linhadigitavel/Inserir', Temp).then(function (response) {
                return response;
            });
        }

        var _Inativar = function (linhadigitavel) {

            return $http.post(serviceBase + 'api/linhadigitavel/Inativar', linhadigitavel).then(function (response) {
                return response;
            })
        }

        var _Alterar = function (linhadigitavel) {
            var Temp = JSON.parse(JSON.stringify(linhadigitavel));
            var split = Temp.dtVigenciaInicio.split('/');
            Temp.dtVigenciaInicio = new Date(split[2], split[1] - 1, split[0]);

            if (Temp.dtVigenciaFim != null) {
                var splitFim = Temp.dtVigenciaFim.split('/');
                Temp.dtVigenciaFim = new Date(split[2], split[1] - 1, split[0]);
            }
            return $http.post(serviceBase + 'api/linhadigitavel/Alterar', Temp).then(function (response) {
                return response;
            });
        }

        var _Importar = function (linhadigitavel) {

            return $http.post(serviceBase + 'api/linhadigitavel/Importar', linhadigitavel).then(function (response) {
                return response;
            });
        }

        var _ListarLog = function (idLinhaDigitavel) {

            return $http.get(serviceBase + 'api/linhadigitavel/ListarLog', { params: { idLinhaDigitavel: idLinhaDigitavel } }).then(function (response) {
                return response;
            });
        }

        var _Validar = function (linhadigitavel) {

            return $http.post(serviceBase + 'api/linhadigitavel/Validar', linhadigitavel).then(function (response) {
                return response;
            });
        }


        linhaDigitavelServiceFactory.pesquisar = _pesquisar;
        linhaDigitavelServiceFactory.Inserir = _Inserir;
        linhaDigitavelServiceFactory.Alterar = _Alterar;
        linhaDigitavelServiceFactory.Importar = _Importar;
        linhaDigitavelServiceFactory.ListarLog = _ListarLog;
        linhaDigitavelServiceFactory.Inativar = _Inativar;

        return linhaDigitavelServiceFactory;
    }]);