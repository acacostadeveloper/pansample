﻿'use strict';
app.factory('utilService', ['$http', '$q', '$uibModal', '$uibModalStack', function ($http, $q, $uibModal, $uibModalStack) {

    var utilServiceFactory = {};
    var modalProcessing = undefined;

    var _showPleaseWaitModal = (function () {
        modalProcessing = $uibModal.open({
            templateUrl: 'myModalPleaseWait.html',
            backdrop: 'static',
            keyboard: false
        });
    });


    var _hidePleaseWaitModal = (function () {
        if (modalProcessing != undefined) {
            modalProcessing.close();
            modalProcessing.dismiss();
        }
    });

    

    var _getAcessosByPath = function (path) {

        var local = JSON.parse(localStorage.getItem("ls.authorizationData"));
        local = JSON.parse(local.acessos);

        var response = $.grep(local, function (x) { return x.link == path; })[0];
        return response;
    }
       
    var _inserirLog = function (errorMessage) {
        return $http.post(serviceBase + 'api/configuracao/incluirlog', JSON.stringify(errorMessage)).then(function (response) {
            return response;
        })
    }

    var _exportarExcel = function (tablename, filename, lstDados) {

        var lstEstruturaTabela = [];
        var dadosExportacao = [];

        //## Percorre o header do grid
        var colunasHeaders = $('#' + tablename).find('.table-header').find('th');
        colunasHeaders.each(function (index) {

            if (colunasHeaders[index].getAttribute('data-export') != undefined) {
                lstEstruturaTabela.push({
                    'titulo': colunasHeaders[index].innerHTML,
                    'data': colunasHeaders[index].getAttribute('data-export'),
                    'tipo': colunasHeaders[index].getAttribute('data-type')
                });
            }
        });

        //## Percorre as linhas de dados existentes no objeto original
        for (var lin = 0; lin < lstDados.length; lin++) {

            var strObjeto = "";

            //## Percorre as colunas da estrutura
            for (var col = 0; col < lstEstruturaTabela.length; col++) {

                var nmPropriedade = lstEstruturaTabela[col].titulo

                var colunaData = lstEstruturaTabela[col].data;
                var dado = "";

                //## Se o data-export informado for um objeto...
                if (colunaData.indexOf('.') != -1) {
                    //## Quebrar em uma array em todos os "."
                    var objeto = colunaData.split('.');
                    var campoatual = undefined;

                    //## Percorre cada campo, até o último atributo esperado
                    for (var nvl = 0; nvl < objeto.length; nvl++) {
                        if (campoatual == undefined) {
                            campoatual = lstDados[lin][objeto[nvl]];
                        } else {
                            campoatual = campoatual[objeto[nvl]];
                        }
                        //## Se for o último campo, então é a propriedade final, preenche a variável dado
                        if (nvl == (objeto.length-1)){
                            dado = campoatual;
                        }
                    }
                }
                else {
                    dado = lstDados[lin][colunaData];
                }

                if (dado == undefined) {
                    dado = "";
                }


                if (lstEstruturaTabela[col].tipo == "bool") {

                    if (dado == false)
                        dado = "Inativo";
                    else
                        dado = "Ativo";
                }

                //## Verifica se o valor pode ser convertido em data
                if (lstEstruturaTabela[col].tipo == "data") {
                    if (Date.parse(dado)) {
                        //## Formata a data
                        dado = new Date(dado).toLocaleDateString();
                    }
                    dado = dado.trim();
                }
                if (lstEstruturaTabela[col].tipo == "datahora") {
                    if (Date.parse(dado)) {
                        //## Formata a data
                        var dtTemp = new Date(dado);
                        dado = dtTemp.toLocaleDateString() + " " + dtTemp.toLocaleTimeString();
                    }
                    dado = dado.trim();
                }

                //## Monta a propriedade do objeto
                strObjeto += JSON.stringify(nmPropriedade) + ':' + JSON.stringify(dado) + ',';
            }

            //## Prepara a string para converter em objeto posteriormente
            strObjeto = "'{" + strObjeto.substr(0, (strObjeto.length - 1)) + "}'";
            strObjeto = strObjeto.replace('\t', '');
            strObjeto = strObjeto.replace(/(?:\\[rn])+/g, " ");

            //## Insere o dado no objeto que será exportado
            dadosExportacao.push(JSON.parse(eval(strObjeto)));
        }

        var mystyle = {
            headers: true,
            column: { style: { Font: { Bold: "1" } } },
            sheetid: 'Dados'
        };

        alasql.promise('SELECT * INTO XLSX("' + filename + '",?) FROM ?', [mystyle, dadosExportacao])
            .then(function (data) {
                return;
            }).catch(function (err) {
                throw err;
            });
    };

    var _exportarListaExcel = function (filename, lstDados) {

        var mystyle = {
            headers: true,
            column: { style: { Font: { Bold: "1" } } },
            sheetid: 'Dados'
        };

        alasql.promise('SELECT * INTO XLSX("' + filename + '",?) FROM ?', [mystyle, lstDados])
         .then(function (data) {
             return;
         }).catch(function (err) {
             throw err;
         });
    };



    utilServiceFactory.exportarExcel = _exportarExcel;
    utilServiceFactory.exportarListaExcel = _exportarListaExcel;
    utilServiceFactory.showPleaseWaitModal = _showPleaseWaitModal;
    utilServiceFactory.hidePleaseWaitModal = _hidePleaseWaitModal;
    utilServiceFactory.inserirLog = _inserirLog;
    utilServiceFactory.getAcessosByPath = _getAcessosByPath;
    

    return utilServiceFactory;

}]);