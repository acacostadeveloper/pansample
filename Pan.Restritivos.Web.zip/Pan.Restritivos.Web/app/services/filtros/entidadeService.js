﻿'use strict';
app.factory('entidadeService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var entidadeServiceFactory = {};


    var _pesquisar = function (entidade) {
        var Temp = JSON.parse(JSON.stringify(entidade));
        return $http.get(serviceBase + 'api/entidade', { params: { cdEntidade: Temp.cdEntidade, nmEntidade: Temp.nmEntidade } }).then(function (response) {
            return response;
        })
    };

    
    var _Inserir = function (entidade)
    {
        var Temp = JSON.parse(JSON.stringify(entidade));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/entidade', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (entidade) {
        var Temp = JSON.parse(JSON.stringify(entidade));
        return $http.put(serviceBase + 'api/entidade', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idEntidade) {
        var id = JSON.parse(JSON.stringify(idEntidade));
        return $http.delete(serviceBase + 'api/entidade', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    entidadeServiceFactory.Inserir         = _Inserir;
    entidadeServiceFactory.pesquisar       = _pesquisar;
    entidadeServiceFactory.Alterar         = _Alterar;
    entidadeServiceFactory.Inativar        = _Inativar;

    return entidadeServiceFactory;
}]);