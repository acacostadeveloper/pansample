﻿'use strict';
app.factory('tipoagrupamentoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var tipoagrupamentoServiceFactory = {};


    var _pesquisar = function (tipoagrupamento) {
        var Temp = JSON.parse(JSON.stringify(tipoagrupamento));
        return $http.get(serviceBase + 'api/tipoagrupamento', { params: { cdTipoAgrupamento: Temp.cdTipoAgrupamento, nmDescricao: Temp.nmDescricao } }).then(function (response) {
            return response;
        })
    };

    
    var _Inserir = function (tipoagrupamento)
    {
        var Temp = JSON.parse(JSON.stringify(tipoagrupamento));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/tipoagrupamento', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (tipoagrupamento) {
        var Temp = JSON.parse(JSON.stringify(tipoagrupamento));
        return $http.put(serviceBase + 'api/tipoagrupamento', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idTipoAgrupamento) {
        var id = JSON.parse(JSON.stringify(idTipoAgrupamento));
        return $http.delete(serviceBase + 'api/tipoagrupamento', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    tipoagrupamentoServiceFactory.Inserir         = _Inserir;
    tipoagrupamentoServiceFactory.pesquisar       = _pesquisar;
    tipoagrupamentoServiceFactory.Alterar         = _Alterar;
    tipoagrupamentoServiceFactory.Inativar        = _Inativar;

    return tipoagrupamentoServiceFactory;
}]);