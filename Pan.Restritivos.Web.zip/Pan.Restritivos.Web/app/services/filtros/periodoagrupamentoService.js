﻿'use strict';
app.factory('periodoagrupamentoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var periodoagrupamentoServiceFactory = {};


    var _pesquisar = function (periodoagrupamento) {
        var Temp = JSON.parse(JSON.stringify(periodoagrupamento));
        return $http.get(serviceBase + 'api/periodoagrupamento', { params: { cdPeriodoAgrupamento: Temp.cdPeriodoAgrupamento, nmDescricao: Temp.nmDescricao } }).then(function (response) {
            return response;
        })
    };

   
    var _Inserir = function (periodoagrupamento)
    {
        var Temp = JSON.parse(JSON.stringify(periodoagrupamento));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/periodoagrupamento', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (periodoagrupamento) {
        var Temp = JSON.parse(JSON.stringify(periodoagrupamento));
        return $http.put(serviceBase + 'api/periodoagrupamento', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idPeriodoAgrupamento) {
        var id = JSON.parse(JSON.stringify(idPeriodoAgrupamento));
        return $http.delete(serviceBase + 'api/periodoagrupamento', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    periodoagrupamentoServiceFactory.Inserir         = _Inserir;
    periodoagrupamentoServiceFactory.pesquisar       = _pesquisar;
    periodoagrupamentoServiceFactory.Alterar         = _Alterar;
    periodoagrupamentoServiceFactory.Inativar        = _Inativar;

    return periodoagrupamentoServiceFactory;
}]);