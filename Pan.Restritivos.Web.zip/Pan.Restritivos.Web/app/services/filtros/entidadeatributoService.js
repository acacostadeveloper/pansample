﻿'use strict';
app.factory('entidadeatributoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var entidadeatributoServiceFactory = {};


    var _pesquisar = function (entidadeatributo) {
        var Temp = JSON.parse(JSON.stringify(entidadeatributo));
        return $http.get(serviceBase + 'api/entidadeatributo', { params: { idEntidade: Temp.idEntidade, cdAtributo: Temp.cdAtributo, nmAtributo: Temp.nmAtributo } }).then(function (response) {
            return response;
        })
    };

    var _pesquisarString = function (entidadeatributo) {
        var String = entidadeatributo;
        if ((String != '') && (String != null)) {
            return $http.get(serviceBase + 'api/entidadeatributo?nmNome=' + String).then(function (response) { return response; })
        }
        else {
            return $http.get(serviceBase + 'api/entidadeatributo').then(function (response) { return response; })
        }
    };
    

    //EGS Pesquisa as Entidades Filtro 22.01.2018
    var _pesquisar_entidade = function () {
        return $http.get(serviceBase + 'api/entidade').then(function (response) {
            return response;
        })
    };


    var _Inserir = function (entidadeatributo)
    {
        var Temp = JSON.parse(JSON.stringify(entidadeatributo));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/entidadeatributo', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (entidadeatributo) {
        var Temp = JSON.parse(JSON.stringify(entidadeatributo));
        return $http.put(serviceBase + 'api/entidadeatributo', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idEntidadeAtributo) {
        var id = JSON.parse(JSON.stringify(idEntidadeAtributo));
        return $http.delete(serviceBase + 'api/entidadeatributo', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    entidadeatributoServiceFactory.Inserir                   = _Inserir;
    entidadeatributoServiceFactory.pesquisar                 = _pesquisar;
    entidadeatributoServiceFactory.pesquisarString           = _pesquisarString;
    entidadeatributoServiceFactory.pesquisar_entidade        = _pesquisar_entidade;
    entidadeatributoServiceFactory.Alterar                   = _Alterar;
    entidadeatributoServiceFactory.Inativar                  = _Inativar;

    return entidadeatributoServiceFactory;
}]);