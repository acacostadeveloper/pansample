﻿'use strict';
app.factory('tipooperadorService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var tipooperadorServiceFactory = {};


    var _pesquisar = function (tipooperador) {
        var Temp = JSON.parse(JSON.stringify(tipooperador));
        return $http.get(serviceBase + 'api/tipooperador', { params: { cdTipoOperador: Temp.cdTipoOperador, nmDescricao: Temp.nmDescricao } }).then(function (response) {
            return response;
        })
    };

    
    var _Inserir = function (tipooperador)
    {
        var Temp = JSON.parse(JSON.stringify(tipooperador));
        Temp.blnativo = true;
        return $http.post(serviceBase + 'api/tipooperador', Temp).then(function (response) {
            return response;
        });
    }


    var _Alterar = function (tipooperador) {

        var Temp = JSON.parse(JSON.stringify(tipooperador));

        return $http.put(serviceBase + 'api/tipooperador', Temp).then(function (response) {
            return response;
        });
    }



    var _Inativar = function (idTipoOperador) {
        var id = JSON.parse(JSON.stringify(idTipoOperador));
        return $http.delete(serviceBase + 'api/tipooperador', { params: { id: id } }).then(function (response) {
            return response;
        });

    };

    tipooperadorServiceFactory.Inserir         = _Inserir;
    tipooperadorServiceFactory.pesquisar       = _pesquisar;
    tipooperadorServiceFactory.Alterar         = _Alterar;
    tipooperadorServiceFactory.Inativar        = _Inativar;

    return tipooperadorServiceFactory;
}]);