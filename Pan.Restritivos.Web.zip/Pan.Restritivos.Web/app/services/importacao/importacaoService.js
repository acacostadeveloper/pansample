﻿'use strict';
app.factory('importacaoService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    var serviceBase = ngAuthSettings.apiServiceBaseUriSRT;
    var importacaoServiceFactory = {};


    var _EnviarArquivoCSV = function (pArquivoCSV) {
        var Temp = JSON.parse(JSON.stringify(pArquivoCSV));

        //do nothing if there's no files
        if (Temp.length != 0) {

            return $http({url          : serviceBase + 'api/importacao',
                          method       : 'POST',
                          responseType : 'json',
                          data         : JSON.stringify(pArquivoCSV),
                          headers      : {'Content-Type' : 'application/json'}
            }).then(function (response) {
                return response;
            })
        }
    };

    importacaoServiceFactory.EnviarArquivoCSV = _EnviarArquivoCSV;

    return importacaoServiceFactory;
}]);