﻿'use strict';
app.factory('authInterceptorService', ['$q', '$injector', '$location', 'localStorageService', 'jwtHelper', function ($q, $injector, $location, localStorageService, jwtHelper) {

    var authInterceptorServiceFactory = {};

    var _request = function (config) {
        config.headers = config.headers || {};

        var authData = localStorageService.get('authorizationData');
        if (authData) {
            config.headers.Authorization = 'Bearer ' + authData.token;
            config.headers['X-SessionId'] = authData.sessionId;
        }
        return config;
    }

    var _requestError = function (rejection) {
        return $q.reject(rejection);
    }

    var _response = function (response) {
        //JWT Token: If the token is a valid JWT token, new or refreshed, save it in the localStorage
        var loginService = $injector.get('loginService');
        var storagedToken = localStorageService.get('authorizationData');
        var receivedToken = { token: response.headers('Authorization') };
        var receivedSessionId = { sessionId: response.headers('X-SessionId') };

        // APENAS RESPONSE PARA O WCF Restful
        if (response.config.url.indexOf(loginService.urlWcfRestful) != -1) {

            // Se encontrou o token
            if (receivedToken.token) {

                // Remove o Bearer
                receivedToken.token = receivedToken.token.split('Bearer ')[1];

                // Verifica se o mesmo está expirado
                var tokenExpired = jwtHelper.isTokenExpired(receivedToken.token);

                // Atualiza o token
                if ((storagedToken.token !== receivedToken.token) && !tokenExpired) {
                    localStorageService.set('authorizationData', { token: receivedToken.token, sessionId: receivedSessionId.sessionId });
                }
            }
        }

        return response;
    }

    var _responseError = function (rejection) {
        var loginService = $injector.get('loginService');
        switch (rejection.status) {
            case 401:
                // Deauthenticate the global user
                loginService.logOut();
                $location.path('/');
                break;
            case 403:
                // Add unauthorized behaviour
                break;
        }

        return $q.reject(rejection);
    }

    authInterceptorServiceFactory.request = _request;
    authInterceptorServiceFactory.requestError = _requestError;
    authInterceptorServiceFactory.response = _response;
    authInterceptorServiceFactory.responseError = _responseError;

    return authInterceptorServiceFactory;
}]);