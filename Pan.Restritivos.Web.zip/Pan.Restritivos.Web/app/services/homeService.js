﻿'use strict';
app.factory('homeService', ['$http', '$q', 'localStorageService', 'ngAuthSettings', 'loginService', function ($http, $q, localStorageService, ngAuthSettings, loginService) {

    loginService.verificaSessao();

    var serviceBase = ngAuthSettings.apiServiceBaseUri;

    var homeServiceFactory = {};

    var _authentication = {
        isAuth: false,
        userName: ""
    };    

    var _pesquisar = function (argumento) {        
        return $http.get(serviceBase + 'api/Home/pesquisar', {argumento : argumento}).then(function (response) {
            return response;
        })
    };
        
    homeServiceFactory.pesquisar = _pesquisar;

    return homeServiceFactory;
}]);