﻿'use strict';
app.factory('readFile', [
    '$http',
    '$q',
    'localStorageService',
    'ngAuthSettings',
    'loginService',
    '$window',
    function (
        $http,
        $q,
        localStorageService,
        ngAuthSettings,
        loginService,
        $window) {

        var serviceBase = ngAuthSettings.apiServiceBaseUri;
        var readFileFactory = {};
        var arquivo = {};

        var _readFile = function (input) {
            var deferred = $q.defer();
            var file = input;
            var reader = new FileReader();
            var nomearq = file.name;

            reader.onloadend = function () {
                arquivo = reader.result;              
                localStorageService.remove('arquivo');
                localStorageService.set('arquivo', arquivo);         
            }

            if (file) {
                reader.readAsDataURL(file);                
                return deferred.promise;
            }
        }


        var _Importar = function (base) {
         

            var item = { arq: localStorageService.get('arquivo'), tipoBase: base };

            return $http.post(serviceBase + "api/" + base + "/Importar", item).then(function (response) {                
                return response;
            });

        }

        readFileFactory.readFile = _readFile;
        readFileFactory.Importar = _Importar;

        return readFileFactory;

    }]);