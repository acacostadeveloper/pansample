﻿app.controller('tipoagrupamentoController', ['$scope', '$route', '$location', 'tipoagrupamentoService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, tipoagrupamentoService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################
    $scope.filtro = { cdTipoAgrupamento: "", nmDescricao: "" };


    $scope.dadostipoagrupamento = {
        idTipoAgrupamento: 0,     
        cdTipoAgrupamento: "",     
        nmDescricao: "",           
        IdUsuarioInclusao: 0,     
        UsuarioInclusaoNome: "",   
        DtUsuarioInclusao: 0,     
        IdUsuarioManutencao: 0,   
        UsuarioManutencaoNome: "",
        DtUsuarioManutencao: 0,   
        blnAtivo: false              
    }

    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.filtro.cdTipoAgrupamento = "";
        $scope.filtro.nmDescricao       = "";

        tipoagrupamentoService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }


    //EGS IT Singular 31.12.2017 - Traz todos os registros do filtro
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        tipoagrupamentoService.pesquisar(filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
          //$scope.filtro = {};
        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }








    $scope.VoltarInicio = function () {   
        $scope.dadostipoagrupamento = null;
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadostipoagrupamento = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadostipoagrupamento = $.grep($scope.responsepesq, function (x) { return x.idTipoAgrupamento == id; })[0];
        if ($scope.dadostipoagrupamento.blnAtivo == true) {
            $scope.dadostipoagrupamento.blnAtivo = '1'
        } else {
            $scope.dadostipoagrupamento.blnAtivo = '0'
        };


     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };

    $scope.Save = function () {          
        utilService.showPleaseWaitModal();        
        tipoagrupamentoService.Inserir($scope.dadostipoagrupamento).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        if ($scope.dadostipoagrupamento.blnAtivo == '1') {
            $scope.dadostipoagrupamento.blnAtivo = true
        } else {
            $scope.dadostipoagrupamento.blnAtivo = false
        };

        tipoagrupamentoService.Alterar($scope.dadostipoagrupamento).then(function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }





    $scope.Inativar = function (idTipoAgrupamento) {
        utilService.showPleaseWaitModal();
        tipoagrupamentoService.Inativar(idTipoAgrupamento).then(function (response) {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };   

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }
                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.delete = function (idTipoAgrupamento) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idTipoAgrupamento);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };




}]);