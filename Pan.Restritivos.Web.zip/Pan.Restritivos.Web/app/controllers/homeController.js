﻿'use strict';
app.controller('homeController', ['$scope', '$location', 'ngAuthSettings', 'homeService', '$uibModal', 'loginService', 'usuarioService', 'utilService', function ($scope, $location, ngAuthSettings, homeService, $uibModal, loginService, usuarioService, utilService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar = false;
    $scope.blnIncluir = false;
    if (path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.argumento = "";
    $scope.responsepesq = [];
    $scope.tarefas = [];
    $scope.tarefaspendentes = [];
    $scope.tarefasandamento = [];
    $scope.tarefasfinalizadas = [];
    $scope.mensagens = [];
    $scope.usuarioLogado = "";
    $scope.habilitarResposta = false;

    $scope.authentication = loginService.authentication;
    $scope.showgraphSidebar = true;
    

    //EGS 30.04.2018 Mostra variaveis de ambiente, DEVP, HML e PROD
    $scope._VariavelAmbiente = {
        WebConfigPathServiceBase   : ngAuthSettings.apiServiceBaseUri,
        WebConfigPathServiceBaseSRT: ngAuthSettings.apiServiceBaseUriSRT,
        WebConfigAmbiente          : ngAuthSettings.apiServiceTextoLogin,
        WebConfigVersao            : ngAuthSettings.apiServiceVersao
    };



    $scope.carregar = function (isSearch) {


    };

   

    $scope.openModal = function () {
        $uibModal.open({
            templateUrl: 'myModalContent.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.cancel = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

 

    $scope.openInformationSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalContentSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openNoData = function () {
        $uibModal.open({
            templateUrl: 'myModalNoData.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.modelState) {
                    for (var i = 0; i < response.data.modelState[key].length; i++) {
                        $scope.errors.push(response.data.modelState[key][i]);
                    }
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

}]);