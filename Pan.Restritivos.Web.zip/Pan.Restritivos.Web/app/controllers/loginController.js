﻿'use strict';
app.controller('loginController', ['$scope', '$location', 'ngAuthSettings', 'loginService', '$sce', '$uibModal', '$crypthmac', function ($scope, $location, ngAuthSettings, loginService, $sce, $uibModal, $crypthmac) {


    $scope.bemVindoEnable = true;
    $scope.autentication  = true;
    $scope.currentPath    = $location.path();
    $scope.nomeperfil     = "";
    $scope.nomealcada     = "";
    $scope.closealert     = true;    
    $scope.mensagemerro   = "";
    $scope.location       = $location;
    $scope.login = {
        usuario: "",
        senha: "",
        perfil: [],
        alcada: []
    }
    $scope.authentication = loginService.authentication;  
    $scope.perfil = [];
    $scope.alcada = [];
    $scope.perfisselecionados = [];
    $scope.deptoselecionados = [];
    $scope.perfillista = [];
    $scope.filterOptions = { host: { id: 1, hostName: "" } }
    $scope.filterDeptoOptions = { host: { id: 1, hostName: "" } }
    $scope.enableLoading = false;


    $scope.carregar = function ()
    {
        $('#user').focus();
    };

    //EGS 30.04.2018 Mostra variaveis de ambiente, DEVP, HML e PROD
    $scope._VariavelAmbiente = {
        WebConfigPathServiceBase   : ngAuthSettings.apiServiceBaseUri,
        WebConfigPathServiceBaseSRT: ngAuthSettings.apiServiceBaseUriSRT,
        WebConfigAmbiente          : ngAuthSettings.apiServiceTextoLogin,
        WebConfigVersao            : ngAuthSettings.apiServiceVersao
    };


    $scope.login = function () {
        $scope.mensagemerro  = "";
        $scope.enableLoading = true;
        
        if ($scope.login.usuario == null)
        {
            //$scope.login.usuario = "14873816890";
            //$scope.login.senha   = "BPan1804";
        }

        loginService.login($scope.login).then(function (response) {            
            $scope.autentication = false;
            $scope.bemVindoEnable = false;
            $scope.enableLoading = false;

            var t = $("#bemvindo");
            if (t.css("visibility") == "hidden") {
                t.css("visibility", "visible");
            }

            if (response.deslogouSessaoAnterior == true)
            {
                $scope.openModalSessaoAnteriorDeslogada();
            } else {
                $location.path('/home');
            }
            
        }, function (err) {
            $scope.enableLoading = false;
            $scope.closealert = false;
            $scope.autentication = true;
            $scope.classemsg = 'danger';
            if (err != null) {
                $scope.mensagemerro = $sce.trustAsHtml("<strong>" + err.errors[0] + "</strong>");
            }
        });
    }

    $scope.logout = function () {
        $scope.autentication = false;
        loginService.logOut();
        $location.path('/login');
    }

    $scope.deleteItem = function (index) {
        $scope.perfisselecionados.splice(index, 1);
    }

    $scope.deleteDepto = function (index) {
        $scope.deptoselecionados.splice(index, 1);
    }

    $scope.addperfilsel = function () {                
        
        for (var i = 0; i < $scope.filterOptions.host.length; i++) {
            
            $scope.perfisselecionados.push({
                id: $scope.perfisselecionados.length + 1,
                value: $scope.filterOptions.host[i].id,
                text: $scope.filterOptions.host[i].hostName
            });            
        }               
    }

    $scope.adddeptosel = function () {        
        for (var i = 0; i < $scope.filterDeptoOptions.host.length; i++) {
            $scope.deptoselecionados.push({
                id: $scope.deptoselecionados.length + 1,
                value: $scope.filterDeptoOptions.host[i].id,
                text: $scope.filterDeptoOptions.host[i].hostName
            });
        }        
    }

    $scope.addperfil = function () {

        $scope.perfil.push({
            nome: $scope.nomeperfil
        });

        $scope.login.perfil = $scope.perfil;

        // Clear input fields after push
        $scope.nomeperfil = "";        

    };

    $scope.addalcada = function () {

        $scope.alcada.push({
            nome: $scope.nomealcada
        });

        $scope.login.alcada = $scope.alcada;

        // Clear input fields after push
        $scope.nomealcada = "";

    };

    $scope.closeAlert = function () {
        $scope.closealert = true;
    };

    $scope.autentication = false;

    $scope.openModal = function () {

        var path = $location.path();

        var res = path.split("/").join("");

        $uibModal.open({
            //templateUrl: 'myModalContent.html',
            templateUrl: 'app/views/help/' + res + '.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.cancel = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openModalSessaoAnteriorDeslogada = function () {
        $uibModal.open({
            templateUrl: 'myModalSessaoAnteriorDeslogada.html',
            backdrop: 'static',
            windowClass: 'modal',
            scope: $scope,
            keyboard: false,
            controller: function ($scope, $uibModalInstance, $log) {

                $scope.OK = function () {
                    $uibModalInstance.close();
                    $location.path('/home');
                };
            }
        });
    };

}]);