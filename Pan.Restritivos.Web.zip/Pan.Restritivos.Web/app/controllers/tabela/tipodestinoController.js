﻿app.controller('tipodestinoController', ['$scope', '$route', '$location', 'tipodestinoService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, tipodestinoService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { nmDestino: "", nmTipoConta: "", nmTipoPessoa: "" };

    $scope.dadostipodestino = {
        idTipoDestino: 0,
        nmDestino: "",
        nmTipoConta: "",
        nmTipoPessoa: "",
        blnPossuiContaDigital: false,
        blAtivo: false
    }


    //EGS IT Singular 15.01.2018 - Tipo de Pessoa
    $scope.lstListaPessoas = [
                        { nmListaPessoas: 'FISICA' },
                        { nmListaPessoas: 'JURIDICA' }];

    //EGS IT Singular 15.01.2018 - Tipo de Conta
    $scope.lstListaContas = [
                        { nmListaContas: 'CONTA CORRENTE' },
                        { nmListaContas: 'CONTA INVESTIMENTO' },
                        { nmListaContas: 'CONTA POUPANCA' }];

    //EGS IT Singular 15.01.2018 - Tipo de Destino
    $scope.lstListaDestinos = [
                        { nmListaDestinos: 'MESMA TITULARIDADE' },
                        { nmListaDestinos: 'TERCEIROS' },
                        { nmListaDestinos: 'OUTROS' }];


    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        //EGS 30.06.2018 Limpa os filtros para trazer todos os registros
        $scope.filtro.nmDestino    = "";
        $scope.filtro.nmTipoConta  = "";
        $scope.filtro.nmTipoPessoa = "";

        tipodestinoService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }




    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        if (filtro.nmDestino.nmListaDestinos   == undefined) { $scope.filtro.nmDestino    = "" } else { $scope.filtro.nmDestino    = filtro.nmDestino.nmListaDestinos;   }
        if (filtro.nmTipoConta.nmListaContas   == undefined) { $scope.filtro.nmTipoConta  = "" } else { $scope.filtro.nmTipoConta  = filtro.nmTipoConta.nmListaContas;   }
        if (filtro.nmTipoPessoa.nmListaPessoas == undefined) { $scope.filtro.nmTipoPessoa = "" } else { $scope.filtro.nmTipoPessoa = filtro.nmTipoPessoa.nmListaPessoas; }

        tipodestinoService.pesquisar(filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });        
    }









    $scope.VoltarInicio = function () {   
        $scope.dadostipodestino = null;
      //$scope.filtro = {};
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadostipodestino = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosaltertipodestino                 = $.grep($scope.responsepesq    , function (x) { return x.idTipoDestino   == id; })[0];
        $scope.dadosaltertipodestino.TipoDestinoSel  = $.grep($scope.lstListaDestinos, function (x) { return x.nmListaDestinos == $scope.dadosaltertipodestino.nmDestino    ; })[0];
        $scope.dadosaltertipodestino.TipoContaSel    = $.grep($scope.lstListaContas  , function (x) { return x.nmListaContas   == $scope.dadosaltertipodestino.nmTipoConta  ; })[0];
        $scope.dadosaltertipodestino.TipoPessoaSel   = $.grep($scope.lstListaPessoas , function (x) { return x.nmListaPessoas  == $scope.dadosaltertipodestino.nmTipoPessoa ; })[0];

        if ($scope.dadosaltertipodestino.blnAtivo == true) {
            $scope.dadosaltertipodestino.blnAtivo = '1'
        } else {
            $scope.dadosaltertipodestino.blnAtivo = '0'
        };
        if ($scope.dadosaltertipodestino.blnPossuiContaDigital == true) {
            $scope.dadosaltertipodestino.blnPossuiContaDigital = '1'
        } else {
            $scope.dadosaltertipodestino.blnPossuiContaDigital = '0'
        };
     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };

    $scope.ChangeBoolSim = function (status) {

        if (status == true)
            return 'Sim';
        else
            return 'Não';
    };

    $scope.Save = function () {          
        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadostipodestino.nmDestino    = $scope.dadostipodestino.nmDestino.nmListaDestinos;
        $scope.dadostipodestino.nmTipoConta  = $scope.dadostipodestino.nmTipoConta.nmListaContas;
        $scope.dadostipodestino.nmTipoPessoa = $scope.dadostipodestino.nmTipoPessoa.nmListaPessoas;

        //EGS IT Singular 30.06.2018 - Estava gravando sempre NAO
        if ($scope.dadostipodestino.blnPossuiContaDigital == '1') {
            $scope.dadostipodestino.blnPossuiContaDigital = true
        } else {
            $scope.dadostipodestino.blnPossuiContaDigital = false
        };

        tipodestinoService.Inserir($scope.dadostipodestino).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadosaltertipodestino.nmDestino    = $scope.dadosaltertipodestino.TipoDestinoSel.nmListaDestinos;
        $scope.dadosaltertipodestino.nmTipoConta  = $scope.dadosaltertipodestino.TipoContaSel.nmListaContas;
        $scope.dadosaltertipodestino.nmTipoPessoa = $scope.dadosaltertipodestino.TipoPessoaSel.nmListaPessoas;

        if ($scope.dadosaltertipodestino.blnAtivo == '1') {
            $scope.dadosaltertipodestino.blnAtivo = true
        } else {
            $scope.dadosaltertipodestino.blnAtivo = false
        };
        if ($scope.dadosaltertipodestino.blnPossuiContaDigital == '1') {
            $scope.dadosaltertipodestino.blnPossuiContaDigital = true
        } else {
            $scope.dadosaltertipodestino.blnPossuiContaDigital = false
        };


        tipodestinoService.Alterar($scope.dadosaltertipodestino).then(function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }





    $scope.Inativar = function (idTipoDestino) {
        utilService.showPleaseWaitModal();
        tipodestinoService.Inativar(idTipoDestino).then(function (response) {           
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };   

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }
                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.delete = function (idTipoDestino) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idTipoDestino);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };




}]);