﻿app.controller('emailalertaController', ['$scope', '$route', '$location', 'emailalertaService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, emailalertaService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { idEmailAlerta: 0,  nmEmailAlerta: "", IdSistemaOrigem: 0};

    $scope.dadosemailalerta = {
        idEmailAlerta      : 0,
        nmEmailAlerta      : "",
        IdSistemaOrigem    : "",
        IdUsuarioInclusao  : 0,
        DtUsuarioinclusao  : 0,
        IdUsuarioManutencao: 0,
        DtUsuarioManutencao: 0,
        blAtivo            : false
    }


    //EGS Filtro de Sistema Origem 30.06.2018
    $scope.DadosSistemaOrigem = {
        IdSistemaOrigem: 0,
        cdSistemaOrigem: "",
        blAtivo: false
    }

    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.filtro.idEmailAlerta   = '';
        $scope.filtro.nmEmailAlerta   = '';
        $scope.filtro.IdSistemaOrigem =  0;

        emailalertaService.pesquisar($scope.filtro).then(function (response)
        {
            $scope.responsepesq = response.data;

            //Sistema Origem Filtro 30.06.2018
            emailalertaService.pesquisarSistema($scope.DadosSistemaOrigem).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosSistemaOrigem = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosSistemaOrigem = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });

            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });

    }



        //EGS IT Singular 30.06.2018 - Traz todos os registros do filtro
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.06.2018 - Atuliza dados informados para gravar na tabela
        if (filtro.IdSistemaOrigem == undefined)
        {
            $scope.filtro.IdSistemaOrigem = 0
        } else
        {   $scope.filtro.IdSistemaOrigem = filtro.IdSistemaOrigem.IdSistemaOrigem; }

        emailalertaService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;

            //Sistema Origem Filtro 30.03.2018
            emailalertaService.pesquisarSistema($scope.DadosSistemaOrigem).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosSistemaOrigem = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosSistemaOrigem = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });

            utilService.hidePleaseWaitModal();
            $scope.msg = true;
            $scope.filtro = {};

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }








    $scope.VoltarInicio = function () {   
        $scope.dadosemailalerta = null;
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadosemailalerta = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosalteremailalerta = $.grep($scope.responsepesq     , function (x) { return x.idEmailAlerta    == id; })[0];

        $scope.dadosalteremailalerta.SistemaOrigemSel = $.grep($scope.DadosSistemaOrigem, function (x) { return x.IdSistemaOrigem == $scope.dadosalteremailalerta.IdSistemaOrigem; })[0];

        if ($scope.dadosalteremailalerta.blnAtivo == true) {
            $scope.dadosalteremailalerta.blnAtivo = '1'
        } else {
            $scope.dadosalteremailalerta.blnAtivo = '0'
        };
     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };

    $scope.Save = function () {          
        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.06.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadosemailalerta.IdSistemaOrigem = $scope.dadosemailalerta.SistemaOrigemSel.IdSistemaOrigem;

        emailalertaService.Inserir($scope.dadosemailalerta).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        //EGS IT Singular 24.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadosalteremailalerta.IdSistemaOrigem = $scope.dadosalteremailalerta.SistemaOrigemSel.IdSistemaOrigem;

        if ($scope.dadosalteremailalerta.blnAtivo == '1') {
            $scope.dadosalteremailalerta.blnAtivo = true
        } else {
            $scope.dadosalteremailalerta.blnAtivo = false
        };

        emailalertaService.Alterar($scope.dadosalteremailalerta).then(function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }





    $scope.Inativar = function (idEmailAlerta) {
        utilService.showPleaseWaitModal();
        emailalertaService.Inativar(idEmailAlerta).then(function (response) {           
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };
    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };   
    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };
    $scope.delete = function (idEmailAlerta) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idEmailAlerta);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };
    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };
    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

}]);