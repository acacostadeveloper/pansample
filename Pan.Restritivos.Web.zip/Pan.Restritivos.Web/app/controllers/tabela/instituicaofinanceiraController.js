﻿app.controller('instituicaofinanceiraController', ['$scope', '$route', '$location', 'instituicaofinanceiraService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, instituicaofinanceiraService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { nmInstituicaoFinanceira: "", nrCnpj: "" };

    $scope.dadosinstituicaofinanceira = {
        nmInstituicaoFinanceira: "",
        nrCnpj: "",
        nrCodigoCompensacao: "",
        dsSegmento: "",
        dsGrupoEconomico: "",
        blnPossuiContaDigital: false,
        blAtivo: false
    }


        //EGS IT Singular 30.06.2018 - Campo segmento deve posuir combo com multipla escolha, conforme documetação (opções: Múltiplo; Comercial; Caixa Econômica; Cooperativa; Investimento)
    $scope.TipoSeguimentos = [
                        { nmTipoSeguimento: 'MULTIPLO' },
                        { nmTipoSeguimento: 'COMERCIAL' },
                        { nmTipoSeguimento: 'CAIXA ECONOMICA' },
                        { nmTipoSeguimento: 'COOPERATIVA' },
                        { nmTipoSeguimento: 'INVESTIMENTO' }];


    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.filtro.nrCnpj                  = '';
        $scope.filtro.nmInstituicaoFinanceira = '';

        instituicaofinanceiraService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }


    //EGS IT Singular 30.06.2018 - Traz todos os registros do filtro
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        instituicaofinanceiraService.pesquisar(filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
            $scope.filtro = {};
        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }









    $scope.VoltarInicio = function () {   
        $scope.dadosinstituicaofinanceira = null;
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadosinstituicaofinanceira = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosinstituicaofinanceira                = $.grep($scope.responsepesq   , function (x) { return x.idInstituicaoFinanceira == id; })[0];

        $scope.dadosinstituicaofinanceira.MsgSeguimentos = $.grep($scope.TipoSeguimentos, function (x) { return x.nmTipoSeguimento == $scope.dadosinstituicaofinanceira.dsSegmento; })[0];

        if ($scope.dadosinstituicaofinanceira.blnAtivo == true) {
            $scope.dadosinstituicaofinanceira.blnAtivo = '1'
        } else {
            $scope.dadosinstituicaofinanceira.blnAtivo = '0'
        };
        if ($scope.dadosinstituicaofinanceira.blnPossuiContaDigital == true) {
            $scope.dadosinstituicaofinanceira.blnPossuiContaDigital = '1'
        } else {
            $scope.dadosinstituicaofinanceira.blnPossuiContaDigital = '0'
        };

     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };


    $scope.ChangeCorLinha = function (status) {

        if (status == true)
            return 'Sim';
        else
            return '';
    };


    $scope.Save = function () {          
        utilService.showPleaseWaitModal();


        //EGS IT Singular 30.06.2018 - Estava gravando sempre NAO
        if ($scope.dadosinstituicaofinanceira.blnPossuiContaDigital == '1') {
            $scope.dadosinstituicaofinanceira.blnPossuiContaDigital = true
        } else {
            $scope.dadosinstituicaofinanceira.blnPossuiContaDigital = false
        };


        //EGS IT Singular 05.01.2017 - Consequencias e Criticidade
        $scope.dadosinstituicaofinanceira.dsSegmento = $scope.dadosinstituicaofinanceira.MsgSeguimentos.nmTipoSeguimento;

        instituicaofinanceiraService.Inserir($scope.dadosinstituicaofinanceira).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        $scope.dadosinstituicaofinanceira.dsSegmento = $scope.dadosinstituicaofinanceira.MsgSeguimentos.nmTipoSeguimento;

        if ($scope.dadosinstituicaofinanceira.blnAtivo == '1') {
            $scope.dadosinstituicaofinanceira.blnAtivo = true
        } else {
            $scope.dadosinstituicaofinanceira.blnAtivo = false
        };

        if ($scope.dadosinstituicaofinanceira.blnPossuiContaDigital == '1') {
            $scope.dadosinstituicaofinanceira.blnPossuiContaDigital = true
        } else {
            $scope.dadosinstituicaofinanceira.blnPossuiContaDigital = false
        };

        instituicaofinanceiraService.Alterar($scope.dadosinstituicaofinanceira).then(function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }





    $scope.Inativar = function (idInstituicaoFinanceira) {
        utilService.showPleaseWaitModal();
        instituicaofinanceiraService.Inativar(idInstituicaoFinanceira).then(function (response) {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };   

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.delete = function (idInstituicaoFinanceira) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idInstituicaoFinanceira);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };




}]);