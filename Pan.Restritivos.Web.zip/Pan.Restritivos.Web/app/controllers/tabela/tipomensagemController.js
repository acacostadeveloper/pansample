﻿app.controller('tipomensagemController', ['$scope', '$route', '$location', 'tipomensagemService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, tipomensagemService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { nrCodigo: "",  nmDescricao: ""};

    $scope.dadostipomensagem = {
        idTipoMensagem: 0,
        nrCodigo      : "",
        nmDescricao   : "",
        blnSensibConta: false,
        blAtivo       : false
    }


    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.filtro.nrCodigo    = "";
        $scope.filtro.nmDescricao = "";

        tipomensagemService.pesquisar($scope.dadostipomensagem).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }




    //EGS IT Singular 31.12.2017 - Traz todos os registros do filtro
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        tipomensagemService.pesquisar(filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
            $scope.filtro = {};
        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });        
    }









    $scope.VoltarInicio = function () {   
        $scope.dadostipomensagem = null;
        $scope.filtro = {};
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadostipomensagem = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosaltertipomensagem  = $.grep($scope.responsepesq, function (x) { return x.idTipoMensagem == id; })[0];

        if ($scope.dadosaltertipomensagem.blnAtivo == true) {
            $scope.dadosaltertipomensagem.blnAtivo = '1'
        } else {
            $scope.dadosaltertipomensagem.blnAtivo = '0'
        };
        if ($scope.dadosaltertipomensagem.blnSensibConta == true) {
            $scope.dadosaltertipomensagem.blnSensibConta = '1'
        } else {
            $scope.dadosaltertipomensagem.blnSensibConta = '0'
        };
     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };

    $scope.ChangeBoolSim = function (status) {

        if (status == true)
            return 'Sim';
        else
            return 'Não';
    };

    $scope.Save = function () {          
        utilService.showPleaseWaitModal();

        //EGS IT Singular 30.06.2018 - Estava gravando sempre NAO
        if ($scope.dadostipomensagem.blnSensibConta == '1') {
            $scope.dadostipomensagem.blnSensibConta = true
        } else {
            $scope.dadostipomensagem.blnSensibConta = false
        };

        tipomensagemService.Inserir($scope.dadostipomensagem).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        if ($scope.dadosaltertipomensagem.blnAtivo == '1') {
            $scope.dadosaltertipomensagem.blnAtivo = true
        } else {
            $scope.dadosaltertipomensagem.blnAtivo = false
        };
        if ($scope.dadosaltertipomensagem.blnSensibConta == '1') {
            $scope.dadosaltertipomensagem.blnSensibConta = true
        } else {
            $scope.dadosaltertipomensagem.blnSensibConta = false
        };


        tipomensagemService.Alterar($scope.dadosaltertipomensagem).then(function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }





    $scope.Inativar = function (idTipoMensagem) {
        utilService.showPleaseWaitModal();
        tipomensagemService.Inativar(idTipoMensagem).then(function (response) {           
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };   

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }
                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.delete = function (idTipoMensagem) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idTipoMensagem);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };




}]);