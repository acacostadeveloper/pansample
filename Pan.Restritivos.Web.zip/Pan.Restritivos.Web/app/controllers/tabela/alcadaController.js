﻿app.controller('alcadaController', ['$scope', '$route', '$location', 'alcadaService', '$uibModal', '$sce', 'utilService', 'loginService', 'usuarioService',
    function ($scope, $route, $location, alcadaService, $uibModal, $sce, utilService, loginService, usuarioService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;
    $scope.errors = [];

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { cdAlcada: "", nmDescricao: "" };

    $scope.dadosalcada = {
        idAlcada: 0,
        nmDescricao: "",
        cdAlcada: "",
        idUsuario: 0,
        IdSistemaOrigem: 0,
        nrNivel: 1,
        blAtivo: false
    }
 
    //EGS Filtro de Usuario
    $scope.DadosTipoUsuario = {
        idUsuario: 0,
        login: "",
        nmUsuario: "",
        blAtivo: false
    }
    //EGS Filtro de Sistema Origem 30.03.2018
    $scope.DadosSistemaOrigem = {
        IdSistemaOrigem: 0,
        cdSistemaOrigem: "",
        blAtivo: false
    }

    $scope.dadosusuariofiltro = {
        login: "",
        nmUsuario: "",
        dtInclusaoDe: "",
        dtInclusaoPara: "",
        flagstatus: "S"
    };



    //EGS IT Singular 30.06.2018 - Nivel da Alcada
    $scope.TipoNivel = [
                        { nrTipoNivel: '0'  },
                        { nrTipoNivel: '1'  },
                        { nrTipoNivel: '2'  },
                        { nrTipoNivel: '3'  },
                        { nrTipoNivel: '4'  },
                        { nrTipoNivel: '5'  },
                        { nrTipoNivel: '6'  },
                        { nrTipoNivel: '7'  },
                        { nrTipoNivel: '8'  },
                        { nrTipoNivel: '9'  },
                        { nrTipoNivel: '10' }];


    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };



    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.filtro.cdAlcada    = '';
        $scope.filtro.nmDescricao = '';

        alcadaService.pesquisar($scope.filtro).then(function (response)
        {
            $scope.responsepesq = response.data;

            //Usuario Filtro 30.03.2018
            usuarioService.pesquisar($scope.DadosTipoUsuario).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosTipoUsuario = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosTipoUsuario = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });

            //Sistema Origem Filtro 30.03.2018
            alcadaService.pesquisarSistema($scope.DadosSistemaOrigem).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosSistemaOrigem = [];
                for (var i = 0; i < $scope.ret.length; i++)
                {
                    $scope.DadosSistemaOrigem = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });

            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }
        



    //EGS IT Singular 30.06.2018 - Traz todos os registros do filtro
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        alcadaService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;

            //Usuario Filtro 30.03.2018
            usuarioService.pesquisar($scope.DadosTipoUsuario).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosTipoUsuario = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosTipoUsuario = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });

            //Sistema Origem Filtro 30.03.2018
            alcadaService.pesquisarSistema($scope.DadosSistemaOrigem).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosSistemaOrigem = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosSistemaOrigem = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });

            utilService.hidePleaseWaitModal();
            $scope.msg = true;
            $scope.filtro = {};

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }








    $scope.VoltarInicio = function () {   
        $scope.dadosalcada = null;
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadosalcada = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosalcada = $.grep($scope.responsepesq, function (x) { return x.idAlcada == id; })[0];

        $scope.dadosalcada.AlcadaUsuarioSel = $.grep($scope.DadosTipoUsuario  , function (x) { return x.idUsuario       == $scope.dadosalcada.idUsuario      ; })[0];
        $scope.dadosalcada.SistemaOrigemSel = $.grep($scope.DadosSistemaOrigem, function (x) { return x.IdSistemaOrigem == $scope.dadosalcada.IdSistemaOrigem; })[0];
        $scope.dadosalcada.MsgNivelAlter    = $.grep($scope.TipoNivel         , function (x) { return x.nrTipoNivel     == $scope.dadosalcada.nrNivel        ; })[0];

        if ($scope.dadosalcada.blnAtivo == true) {
            $scope.dadosalcada.blnAtivo = '1'
        } else {
            $scope.dadosalcada.blnAtivo = '0'
        };


     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };

    $scope.Save = function () {

        utilService.showPleaseWaitModal();

        //EGS IT Singular 24.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadosalcada.idUsuario       = $scope.dadosalcada.idUsuario.idUsuario;
        $scope.dadosalcada.IdSistemaOrigem = $scope.dadosalcada.IdSistemaOrigem.IdSistemaOrigem;
        $scope.dadosalcada.nrNivel         = $scope.dadosalcada.MsgNivelSel.nrTipoNivel;

        alcadaService.Inserir($scope.dadosalcada).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

      //$scope._GravaLog('Inicio da rotina de alteracao');
        utilService.showPleaseWaitModal();

        //EGS IT Singular 24.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadosalcada.idUsuario       = $scope.dadosalcada.AlcadaUsuarioSel.idUsuario;
        $scope.dadosalcada.IdSistemaOrigem = $scope.dadosalcada.SistemaOrigemSel.IdSistemaOrigem;
        $scope.dadosalcada.nrNivel         = $scope.dadosalcada.MsgNivelAlter.nrTipoNivel;

        if ($scope.dadosalcada.blnAtivo == '1') {
            $scope.dadosalcada.blnAtivo = true
        } else {
            $scope.dadosalcada.blnAtivo = false
        };

      //$scope._GravaLog('Chama servico Alcada para alterar');
        alcadaService.Alterar($scope.dadosalcada).then(function (response)
        {
            
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response)  //EGS 30.05.2018
            {
                utilService.hidePleaseWaitModal();
              /*alert('Erro ao alterar Alcada: ' + response.data.errors);
                $scope._GravaLog('Erro ao alterar Alcada - response: '            + response);
                $scope._GravaLog('Erro ao alterar Alcada - response.data: '       + response.data);
                $scope._GravaLog('Erro ao alterar Alcada - response.data.erros: ' + response.data.errors);*/
                $scope.openInformationError(response);
            }
         );
    }





    $scope.Inativar = function (idalcada) {
        utilService.showPleaseWaitModal();
        alcadaService.Inativar(idalcada).then(function (response) {           
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };


    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

              //$scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }
                $scope.ok = function () {
                    $uibModalInstance.close();
                };

            }
        });
    };


    $scope.delete = function (idalcada) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idalcada);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações da Alçada?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };




    /*===========================================================================================================
    // Programa...:  Rotina para gravar LOG em arquivo, problema ao alterar tabelas
    // Autor......:  Edinaldo Silva (IT Singular)
    // Data.......:  30.05.2017
    ===========================================================================================================*/
    $scope._GravaLog = function (Texto)
    {
        //Cria Objeto ActiveX
        objFSO = new ActiveXObject("Scripting.FileSystemObject");

        //pasta a ser salvo o arquivo
        var arquivo = 'C:\\Temp\\RestritivoApi.Log';

        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var s = fso.OpenTextFile(arquivo, 8, true, 0);
        s.write(Texto);
        s.WriteBlankLines(1); 
        s.Close();
    };

}]);