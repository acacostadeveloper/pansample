﻿app.controller('tipoorigemController', ['$scope', '$route', '$location', 'tipoorigemService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, tipoorigemService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { nmOrigem: "", nmTipoConta: "", nmTipoPessoa:"" };

    $scope.dadostipoorigem = {
        idTipoOrigem: 0,
        nmOrigem: "",
        nmTipoConta: "",
        nmTipoPessoa: "",
        blnPossuiContaDigital: false,
        blAtivo: false
    }


    //EGS IT Singular 17.01.2018 - Tipo de Pessoa
    $scope.lstListaPessoas = [
                        { nmListaPessoas: 'FISICA' },
                        { nmListaPessoas: 'JURIDICA' }];

    //EGS IT Singular 17.01.2018 - Tipo de Conta
    $scope.lstListaContas = [
                        { nmListaContas: 'CONTA CORRENTE' },
                        { nmListaContas: 'CONTA INVESTIMENTO' },
                        { nmListaContas: 'CONTA POUPANCA' }];

    //EGS IT Singular 17.01.2018 - Tipo de Origens
    $scope.lstListaOrigem = [
                        { nmListaOrigem: 'CLIENTE' },
                        { nmListaOrigem: 'BANCO'   },
                        { nmListaOrigem: 'OUTRO'   }];


    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        //EGS 30.06.2018 Limpa os filtros para trazer todos os registros
        $scope.filtro.nmOrigem     = "";
        $scope.filtro.nmTipoConta  = "";
        $scope.filtro.nmTipoPessoa = "";

        tipoorigemService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg    = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });

    }




        //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        if (filtro.nmOrigem.nmListaOrigem      == undefined) { $scope.filtro.nmOrigem     = "" } else { $scope.filtro.nmOrigem     = filtro.nmOrigem.nmListaOrigem;}
        if (filtro.nmTipoConta.nmListaContas   == undefined) { $scope.filtro.nmTipoConta  = "" } else { $scope.filtro.nmTipoConta  = filtro.nmTipoConta.nmListaContas; }
        if (filtro.nmTipoPessoa.nmListaPessoas == undefined) { $scope.filtro.nmTipoPessoa = "" } else { $scope.filtro.nmTipoPessoa = filtro.nmTipoPessoa.nmListaPessoas; }


        tipoorigemService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg    = true;
        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
        
    }









    $scope.VoltarInicio = function () {   
        $scope.dadostipoorigem = null;
      //$scope.filtro = {};
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadostipoorigem = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosaltertipoorigem                 = $.grep($scope.responsepesq    , function (x) { return x.idTipoOrigem    == id; })[0];
        $scope.dadosaltertipoorigem.TipoOrigemSel   = $.grep($scope.lstListaOrigem  , function (x) { return x.nmListaOrigem   == $scope.dadosaltertipoorigem.nmOrigem    ; })[0];
        $scope.dadosaltertipoorigem.TipoContaSel    = $.grep($scope.lstListaContas  , function (x) { return x.nmListaContas   == $scope.dadosaltertipoorigem.nmTipoConta ; })[0];
        $scope.dadosaltertipoorigem.TipoPessoaSel   = $.grep($scope.lstListaPessoas , function (x) { return x.nmListaPessoas  == $scope.dadosaltertipoorigem.nmTipoPessoa; })[0];

        if ($scope.dadosaltertipoorigem.blnAtivo == true) {
            $scope.dadosaltertipoorigem.blnAtivo = '1'
        } else {
            $scope.dadosaltertipoorigem.blnAtivo = '0'
        };
        if ($scope.dadosaltertipoorigem.blnPossuiContaDigital == true) {
            $scope.dadosaltertipoorigem.blnPossuiContaDigital = '1'
        } else {
            $scope.dadosaltertipoorigem.blnPossuiContaDigital = '0'
        };
     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };

    $scope.ChangeBoolSim = function (status) {

        if (status == true)
            return 'Sim';
        else
            return 'Não';
    };

    $scope.Save = function () {          
        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadostipoorigem.nmOrigem     = $scope.dadostipoorigem.nmOrigem.nmListaOrigem;
        $scope.dadostipoorigem.nmTipoConta  = $scope.dadostipoorigem.nmTipoConta.nmListaContas;
        $scope.dadostipoorigem.nmTipoPessoa = $scope.dadostipoorigem.nmTipoPessoa.nmListaPessoas;

        //EGS IT Singular 30.06.2018 - Estava gravando sempre NAO
        if ($scope.dadostipoorigem.blnPossuiContaDigital == '1') {
            $scope.dadostipoorigem.blnPossuiContaDigital = true
        } else {
            $scope.dadostipoorigem.blnPossuiContaDigital = false
        };


        tipoorigemService.Inserir($scope.dadostipoorigem).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });       
    }




    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.01.2018 - Atuliza dados informados para gravar na tabela
        $scope.dadosaltertipoorigem.nmOrigem     = $scope.dadosaltertipoorigem.TipoOrigemSel.nmListaOrigem;
        $scope.dadosaltertipoorigem.nmTipoConta  = $scope.dadosaltertipoorigem.TipoContaSel.nmListaContas;
        $scope.dadosaltertipoorigem.nmTipoPessoa = $scope.dadosaltertipoorigem.TipoPessoaSel.nmListaPessoas;

        if ($scope.dadosaltertipoorigem.blnAtivo == '1') {
            $scope.dadosaltertipoorigem.blnAtivo = true
        } else {
            $scope.dadosaltertipoorigem.blnAtivo = false
        };
        if ($scope.dadosaltertipoorigem.blnPossuiContaDigital == '1') {
            $scope.dadosaltertipoorigem.blnPossuiContaDigital = true
        } else {
            $scope.dadosaltertipoorigem.blnPossuiContaDigital = false
        };


        tipoorigemService.Alterar($scope.dadosaltertipoorigem).then(function (response)
        {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }





    $scope.Inativar = function (idTipoOrigem) {
        utilService.showPleaseWaitModal();
        tipoorigemService.Inativar(idTipoOrigem).then(function (response) {           
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);          
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                
                        $route.reload();
               
                };
            }
        });
    };   

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }
                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.delete = function (idTipoOrigem) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {                  
                    $scope.Inativar(idTipoOrigem);
                        $uibModalInstance.close();
                };
                $scope.cancel = function () {                    
                    $uibModalInstance.dismiss('cancel');                  
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {       
            $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';              
                $scope.ok = function () {                 
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };




}]);