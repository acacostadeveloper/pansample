﻿'use strict';
app.controller('menuController', ['$scope', '$location', '$element', 'loginService', function ($scope, $location, $element, loginService) {

    $scope.mensagem = "";
    $scope.menuacessos = [];
    $scope.authentication = loginService.authentication;
    $scope.exibeMnuCadastros = false;
    $scope.exibeMnuConsultas = false;
    $scope.exibeMnuSolicitacoes = false;
    $scope.exibeMnuAtendimento = false;
    $scope.exibeMnuRelatorios = false;
    $scope.exibeMnuMensagens = false;

    if (angular.isArray($scope.authentication.acessos)) {        
        $scope.menuacessos = $scope.authentication.acessos;
    }
    else {
        
        $scope.menuacessos = angular.fromJson($scope.authentication.acessos);        
    }

    $scope.desabilitaMenus = function () {
        $scope.exibeMnuCadastros    = $.grep($scope.menuacessos, function (e) { return (e.nmmenu == 'CADASTROS' && e.visible == 'S') }).length > 0;
        $scope.exibeMnuConsultas    = $.grep($scope.menuacessos, function (e) { return (e.nmmenu == 'CONSULTAS' && e.visible == 'S') }).length > 0;
        $scope.exibeMnuSolicitacoes = $.grep($scope.menuacessos, function (e) { return (e.nmmenu == 'SOLICITAÇÕES' && e.visible == 'S') }).length > 0;

        $scope.exibeMnuAtendimento  = $.grep($scope.menuacessos, function (e) { return (e.nmmenu == 'ATENDIMENTO' && e.visible == 'S') }).length > 0;

        $scope.exibeMnuRelatorios   = $.grep($scope.menuacessos, function (e) { return (e.nmmenu == 'RELATÓRIOS' && e.visible == 'S') }).length > 0;
        $scope.exibeMnuMensagens    = $.grep($scope.menuacessos, function (e) { return (e.nmmenu == 'MENSAGENS' && e.visible == 'S') }).length > 0;
    };

    $scope.carregar = function () {
        //$scope.desabilitaMenus();
    };


}]);

app.directive('active', function () {
    return {
        link: function (scope, element, attrs) {
            
            element.bind('click', function () {
                if (element.hasClass('active')) {                    
                    element.addClass('active');
                }
                //Remove the active from all the child elements
                element.parent().children().removeClass('active');

                //Add active class to the clicked buttong
                //element.toggleClass('active');
            })
        },
    }
});