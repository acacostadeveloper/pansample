﻿app.controller('linhaDigitavelController', ['$scope', '$location', 'linhaDigitavelService', '$uibModal', '$sce', 'loginService', 'utilService', 'pesoAlertaService', 'motivoalertaService', 'readFile', '$route',
function ($scope, $location, linhaDigitavelService, $uibModal, $sce, loginService, utilService, pesoAlertaService, motivoalertaService, readFile, $route) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar = false;
    $scope.blnIncluir = false;
    $scope.blnImportar = false;
    if (path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
            if (retorno.acesso.blnImportar == false) {
                $scope.blnImportar = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################



    //###################################################################################
    //Inicio - Variaveis

    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;
    $scope.hdstep4 = true;
    $scope.valido = false;


    $scope.erroArquivo = "";

    $scope.InputCpfAlterar = false;
    $scope.listImportacao = [];
    $scope.filtro = { nrLinhaDigitavel: "", dtVigenciaInicio: "", dtVigenciaFim: "" };

    //Fim - Variaveis
    //###################################################################################




    //###################################################################################
    //Inicio - Metodos

    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.CarregarGrid();

        pesoAlertaService.pesquisar({ codPeso: "", txPeso: "" }).then(function (response) {
            $scope.ret = response.data;
            $scope.pesosAlerta = [];
            for (var i = 0; i < $scope.ret.length; i++) {
                $scope.pesosAlerta = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
            }

            utilService.hidePleaseWaitModal();
            $scope.msg = true;

        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });


        motivoalertaService.pesquisar({ codMotivo: "", txMotivo: "" }).then(function (response) {

            $scope.ret = response.data;
            $scope.motivosAlerta = [];
            for (var i = 0; i < $scope.ret.length; i++) {
                $scope.motivosAlerta = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
            }

            utilService.hidePleaseWaitModal();
            $scope.msg = true;

        },
          function (response) {
              utilService.hidePleaseWaitModal();
              $scope.openInformationError(response);
          });
    }

    $scope.CarregarGrid = function () {

        linhaDigitavelService.pesquisar($scope.filtro).then(function (response) {

            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        },
      function (response) {
          utilService.hidePleaseWaitModal();
          $scope.openInformationError(response);
      });

    }

    $scope.VoltarInicio = function () {
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
        $scope.hdstep4 = true;
        $scope.dados = {};
        $scope.filtro = {};
        $scope.valido = false;
    }

    $scope.AbrirNovo = function () {
        $scope.dados = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
        $scope.hdstep4 = true;
    }

    $scope.AbrirAlterar = function (id) {
        $scope.dados = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosAlter = JSON.parse(JSON.stringify($.grep($scope.responsepesq, function (x) { return x.idLinhaDigitavel == id; })[0]));

        $scope.dadosAlter.blnAtivo = $scope.dadosAlter.blnAtivo.toString();

        $scope.dadosAlter.dtVigenciaInicio = new Date($scope.dadosAlter.dtVigenciaInicio).toLocaleDateString();
        if ($scope.dadosAlter.dtVigenciaFim != null)
            $scope.dadosAlter.dtVigenciaFim = new Date($scope.dadosAlter.dtVigenciaFim).toLocaleDateString();

        $scope.dadosAlter.motivoSel = $.grep($scope.motivosAlerta, function (x) { return x.idMotivo == $scope.dadosAlter.idMotivo; })[0];
        $scope.dadosAlter.pesoSel = $.grep($scope.pesosAlerta, function (x) { return x.idPeso == $scope.dadosAlter.idPeso; })[0];
    }

    $scope.AbrirHistorico = function (id) {
        $scope.dados = null;

        $scope.openHistorico(id);

        //$scope.lis$scopetorico = $scope.Historico(id);
    }

    $scope.upload = function () {

        var a = document.getElementById('fileInput').click();
        readFile.InputFile(document.getElementById('fileInput'));

        // uploadService
    }

    $scope.Save = function () {
        utilService.showPleaseWaitModal();

        $scope.dados.idMotivo = $scope.dados.motivoSel.idMotivo;
        $scope.dados.idPeso = $scope.dados.pesoSel.idPeso;
        $scope.dados.idLinhaDigitavel = $scope.dados.pesoSel.idLinhaDigitavel;

        $scope.dados.dtVigenciaInicio = $scope.date2String($scope.dados.dtVigenciaInicio);
        if ($scope.dados.dtVigenciaFim != null)
            $scope.dados.dtVigenciaFim = $scope.date2String($scope.dados.dtVigenciaFim);

        linhaDigitavelService.Inserir($scope.dados).then(function (response) {
            $scope.mensagem = 'Registro incluído com sucesso.'
            utilService.hidePleaseWaitModal();
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });

    }

    $scope.Alterar = function () {

        utilService.showPleaseWaitModal();

        $scope.dadosAlter.idMotivo = $scope.dadosAlter.motivoSel.idMotivo;
        $scope.dadosAlter.idPeso = $scope.dadosAlter.pesoSel.idPeso;

        $scope.dadosAlter.dtVigenciaInicio = $scope.date2String($scope.dadosAlter.dtVigenciaInicio);
        if ($scope.dadosAlter.dtVigenciaFim != null)
            $scope.dadosAlter.dtVigenciaFim =  $scope.date2String($scope.dadosAlter.dtVigenciaFim);


        linhaDigitavelService.Alterar($scope.dadosAlter).then(function (response) {

            utilService.hidePleaseWaitModal();

            $scope.mensagem = 'Registro alterado com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);

        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    };

    $scope.Excluir = function (idLinhaDigitavel) {
        $scope.openExcluir(idLinhaDigitavel);

    }

    $scope.Historico = function (idLinhaDigitavel) {

        utilService.showPleaseWaitModal();
        linhaDigitavelService.ListarLog(idLinhaDigitavel).then(function (response) {

            $scope.listHistorico = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        },
      function (response) {
          utilService.hidePleaseWaitModal();
          $scope.openInformationError(response);
      });
    }

    $scope.CarregarHistoricoItem = function (id) {

        $scope.dadosHist = $.grep($scope.listHistorico, function (x) { return x.idLinhaDigitavelLog == id; })[0];

        $scope.dadosHist.motivoSel = $scope.dadosHist.txMotivo;
        $scope.dadosHist.pesoSel = $scope.dadosHist.txPeso;

        $scope.dadosHist.dtVigenciaInicio = new Date($scope.dadosHist.dtVigenciaInicio);

        if ($scope.dadosHist.dtVigenciaFim != null)
            $scope.dadosHist.dtVigenciaFim = new Date($scope.dadosHist.dtVigenciaFim);

    }

    $scope.ChangeBool = function (status) {

        if (status == undefined)
            return null;
        else if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    }

    $scope.ChangeOk = function (status) {

        if (status == undefined)
            return null;
        else if (status == true)
            return 'Erro';
        else
            return 'Sucesso';
    }
    //Fim - Metodos
    //###################################################################################


    //###################################################################################
    //Inicio - Datepicker

    $scope.ValidarData = function (date) {
        if (date != "") {
            if (date != undefined) {
                date = $scope.date2String(date);
                if (typeof (date) !== "object") {

                    var valid = true;
                    var separator = '/';
                    if (date != undefined) {

                        var aoDate,
                            ms,
                            month, day, year;

                        if (separator === undefined) {
                            separator = '/';
                        }

                        aoDate = date.split(separator);

                        if (aoDate.length !== 3) {
                            valid = false;
                        }

                        day = aoDate[0] - 0;
                        month = aoDate[1] - 1;
                        year = aoDate[2] - 0;

                        if (year < 1900 || year > 3000) {
                            valid = false;
                        }

                        ms = (new Date(year, month, day)).getTime();

                        aoDate = new Date();
                        aoDate.setTime(ms);

                        if (aoDate.getFullYear() !== year ||
                            aoDate.getMonth() !== month ||
                            aoDate.getDate() !== day) {
                            valid = false;
                        }

                        if (valid == true) {
                            $scope.valido = false;
                            return "";
                        }
                        else {
                            $scope.valido = true;
                            return "ng-invalid";
                        }
                    }
                }
            }
        }
    };

    $scope.formatadata = function (id) {
        var data = document.getElementById(id).value;
        var keycode = event.keyCode;

        $scope.ValidarData(data);

        if (data.length < 1) {
            $scope.valido = false;
            return;
        }

        if (keycode != 8) {
            if (data.length == 2) {
                data = data + '/';
                document.getElementById(id).value = data;
            };
            if (data.length == 5) {
                data = data + '/';
                document.getElementById(id).value = data;
            }
        }
    };

    $scope.date2String = function (str) {

        if (typeof (str) == "object") {
            str = str.getDate() + "/" + (str.getMonth() + 1) + "/" + str.getUTCFullYear();
        }
        return str;
    }

    $scope.gerarData = function (str) {

        var partes = str.split("/");
        return new Date(partes[2], partes[1] - 1, partes[0]);
    }

    $scope.verificaClassError = function (tipo) {
        var inicio = document.getElementById('dtinicio' + tipo).value;
        var fim = document.getElementById('dtfim' + tipo).value;

        if (fim != '' || inicio != '') {
            if ($scope.gerarData(inicio) > $scope.gerarData(fim)) {
                $scope.valido = true;
                return "ng-invalid";
            }
            else {
                $scope.valido = false;
                $scope.ValidarData(inicio);
                $scope.ValidarData(fim);
                return "";
            }
        }
    };

    $scope.today = function () {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
        return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
    };

    $scope.toggleMin = function () {
        $scope.minDate = Date.now();
    };
    $scope.toggleMin();
    $scope.maxDate = new Date(2020, 5, 22);

    $scope.opendate = function ($event) {
        $scope.status.opened = true;
    };

    $scope.opendtInicio = function ($event) {
        $scope.statusDtInicio.opened = true;
    };

    $scope.opendtFinal = function ($event) {
        $scope.statusDtFinal.opened = true;
    };

    $scope.openPrazo = function ($event) {
        $scope.statusPrazo.opened = true;
    };

    $scope.openValidade = function ($event) {
        $scope.statusValidade.opened = true;
    };

    $scope.setDate = function (year, month, day) {
        $scope.dt = new Date(year, month, day);
    };

    $scope.dateOptions = {
        formatYear: 'yyyy',
        startingDay: 1
    };

    $scope.formats = ['dd/MM/yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.status = {
        opened: false
    };

    $scope.statusDtInicio = {
        opened: false
    };

    $scope.statusDtFinal = {
        opened: false
    };

    $scope.statusValidade = {
        opened: false
    };

    $scope.statusPrazo = {
        opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 2);
    $scope.events =
      [
        {
            date: tomorrow,
            status: 'full'
        },
        {
            date: afterTomorrow,
            status: 'partially'
        }
      ];

    $scope.getDayClass = function (date, mode) {
        if (mode === 'day') {
            var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

            for (var i = 0; i < $scope.events.length; i++) {
                var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                if (dayToCheck === currentDay) {
                    return $scope.events[i].status;
                }
            }
        }

        return '';
    };

    //Fim - Datepicker
    //###################################################################################


    //###################################################################################
    //Inicio - Modal

    $scope.openImportacao = function (list) {
        $uibModal.open({
            templateUrl: 'ModalImportacao.html',
            backdrop: 'static',
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                

                $scope.listImportacao = list;


                $scope.ok = function () {

                    $scope.$parent.dadosHist = {};
                    $uibModalInstance.dismiss('cancel');
                };
            }
        });
    };

    $scope.openHistorico = function (idLinhaDigitavel) {
        $uibModal.open({
            templateUrl: 'ModalHistorico.html',
            backdrop: 'static',
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {

                $scope.Historico(idLinhaDigitavel);

                $scope.ok = function () {
                    $scope.dadosHist = {
                        nrLinhaDigitavel: "",                  
                        dtVigenciaInicio: "",
                        dtVigenciaFim: "",
                        motivoSel: "",
                        pesoSel: "",
                        txObs: "",
                        blnAtivo: ""
                    };
                    $scope.$parent.dadosHist = {};
                    $uibModalInstance.dismiss('cancel');
                };
            }
        });
    };

    $scope.openUpload = function () {

        $uibModal.open({
            templateUrl: 'ModalUpload.html',
            backdrop: 'static',
            windowClass: 'modal modal-dialog-min',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    utilService.showPleaseWaitModal();
                    readFile.Importar("linhadigitavel").then(function (response) {
                        
                        utilService.hidePleaseWaitModal();
                        $scope.listImportacao = response.data;
                        $scope.openImportacao($scope.listImportacao);
                    },
                  function (response) {
                      utilService.hidePleaseWaitModal();
                      $scope.openInformationError(response);
                  });
                    $uibModalInstance.dismiss('cancel');
                };

                $scope.cancel = function () {
                    $scope.dados = null;
                    $uibModalInstance.dismiss('cancel');
                };
            }
        });
    };

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalContentSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.exportarExcel = function (tablename, filename, listImportacao) {
        try {
            utilService.exportarExcel(tablename, filename, listImportacao);
            $scope.openExportSuccess();
        }
        catch (err) {
            var objErro = { errorMessage: "Exportação - Local: '" + $location.path() + "' - " + err.message };
            utilService.inserirLog(objErro);
            $scope.openExportError(err);
        }
    };

    $scope.openExportSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalExportSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openExportError = function (err) {
        $uibModal.open({
            templateUrl: 'myModalExportError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.excecao = err.message;
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.Inativar = function (idLinhaDigitavel) {
        utilService.showPleaseWaitModal();

        var LinhaDigitavel = { idLinhaDigitavel: idLinhaDigitavel };

        linhaDigitavelService.Inativar(LinhaDigitavel).then(function (response) {
            utilService.hidePleaseWaitModal();
            $scope.mensagem = 'Registro excluído com sucesso.'
            $scope.openInformationSuccess($scope.mensagem);
        }, function (response) {
            $scope.openInformationError(response);
        });
    };

    $scope.delete = function (idLinhaDigitavel) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja excluir as informações? ';
                $scope.ok = function () {
                    $scope.$parent.Inativar(idLinhaDigitavel);
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não excluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.insert = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja incluir as informações?';
                $scope.ok = function () {
                    $scope.Save();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não incluído.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.alter = function () {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = 'Deseja alterar as informações?';
                $scope.ok = function () {
                    $scope.Alterar();
                    $uibModalInstance.close();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = 'Registro não alterado.';
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

    $scope.ArquivoInvalido = function () {
        $uibModal.open({
            templateUrl: 'myModalArquivoInvalido.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = "Arquivo invalido.";

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        })
    };
    //Fim - Modal
    //###################################################################################





    //###################################################################################
    //Inicio - Datepicker

    $scope.ValidarData = function (date) {


        if (date != "") {
            if (date != undefined) {
                date = $scope.date2String(date);
                if (typeof (date) !== "object") {

                    var valid = true;
                    var separator = '/';
                    if (date != undefined) {

                        var aoDate,
                            ms,
                            month, day, year;

                        if (separator === undefined) {
                            separator = '/';
                        }

                        aoDate = date.split(separator);

                        if (aoDate.length !== 3) {
                            valid = false;
                        }

                        day = aoDate[0] - 0;
                        month = aoDate[1] - 1;
                        year = aoDate[2] - 0;

                        if (year < 1900 || year > 3000) {
                            valid = false;
                        }

                        ms = (new Date(year, month, day)).getTime();

                        aoDate = new Date();
                        aoDate.setTime(ms);

                        if (aoDate.getFullYear() !== year ||
                            aoDate.getMonth() !== month ||
                            aoDate.getDate() !== day) {
                            valid = false;
                        }

                        if (valid == true) {
                            $scope.valido = false;
                            return "";
                        }
                        else {
                            $scope.valido = true;
                            return "ng-invalid";
                        }
                    }
                }
            }
        }
    };

    $scope.formatadata = function (id) {
        var data = document.getElementById(id).value;
        var keycode = event.keyCode;

        $scope.ValidarData(data);

        if (data.length < 1) {
            $scope.valido = false;
            return;
        }

        if (keycode != 8) {
            if (data.length == 2) {
                data = data + '/';
                document.getElementById(id).value = data;
            };
            if (data.length == 5) {
                data = data + '/';
                document.getElementById(id).value = data;
            }
        }
    };

    $scope.date2String = function (str) {

        if (typeof (str) == "object") {
            str = str.getDate() + "/" + (str.getMonth() + 1) + "/" + str.getUTCFullYear();
        }
        return str;
    }

    $scope.gerarData = function (str) {

        var partes = str.split("/");
        return new Date(partes[2], partes[1] - 1, partes[0]);
    }

    $scope.verificaClassError = function (tipo) {
        var inicio = document.getElementById('dtinicio' + tipo).value;
        var fim = document.getElementById('dtfim' + tipo).value;

        if (fim != '' || inicio != '') {
            if ($scope.gerarData(inicio) > $scope.gerarData(fim)) {
                $scope.valido = true;
                return "ng-invalid";
            }
            else {
                $scope.valido = false;
                $scope.ValidarData(inicio);
                $scope.ValidarData(fim);
                return "";
            }
        }
    };

    $scope.today = function () {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
        return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
    };

    $scope.toggleMin = function () {
        $scope.minDate = Date.now();
    };
    $scope.toggleMin();
    $scope.maxDate = new Date(2020, 5, 22);

    $scope.opendate = function ($event) {
        $scope.status.opened = true;
    };

    $scope.opendtInicio = function ($event) {
        $scope.statusDtInicio.opened = true;
    };

    $scope.opendtFinal = function ($event) {
        $scope.statusDtFinal.opened = true;
    };

    $scope.openPrazo = function ($event) {
        $scope.statusPrazo.opened = true;
    };

    $scope.openValidade = function ($event) {
        $scope.statusValidade.opened = true;
    };

    $scope.setDate = function (year, month, day) {
        $scope.dt = new Date(year, month, day);
    };

    $scope.dateOptions = {
        formatYear: 'yyyy',
        startingDay: 1
    };

    $scope.formats = ['dd/MM/yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.status = {
        opened: false
    };

    $scope.statusDtInicio = {
        opened: false
    };

    $scope.statusDtFinal = {
        opened: false
    };

    $scope.statusValidade = {
        opened: false
    };

    $scope.statusPrazo = {
        opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 2);
    $scope.events =
      [
        {
            date: tomorrow,
            status: 'full'
        },
        {
            date: afterTomorrow,
            status: 'partially'
        }
      ];

    $scope.getDayClass = function (date, mode) {
        if (mode === 'day') {
            var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

            for (var i = 0; i < $scope.events.length; i++) {
                var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                if (dayToCheck === currentDay) {
                    return $scope.events[i].status;
                }
            }
        }

        return '';
    };

    //Fim - Datepicker
    //###################################################################################
    
}]);
