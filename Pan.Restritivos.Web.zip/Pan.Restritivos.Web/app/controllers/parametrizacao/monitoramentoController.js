﻿'use strict';
app.controller('monitoramentoController', ['$scope', '$route', '$http', '$location', 'monitoramentoService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $http, $route, $location, monitoramentoService, $uibModal, $sce, utilService, loginService) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar  = false;
    $scope.blnIncluir  = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.filtro = { dtInclusaoInicio: "", dtInclusaoFinal: "", nrStatus: "", NroBoleto: "", nrValInicio: "", nrValFinal: ""};

    $scope.dadosmonitoramento = {
        idMensagemTransferencia: 0,
        Finalidade             : "",
        Prioridade             : "",
        NroBoleto              : "",
        DtDataInclusao         : "",
        EventoCodigo           : "",
        CodigoOrigem           : "",
        SistemaOrigem          : "",
        Deb_NumBanco           : "",
        Deb_NumAgencia         : "",
        Deb_NumConta           : "",
        Cre_NumBanco           : "",
        Cre_NumAgencia         : "",
        Cre_NumConta           : "",
        Valor                  :  0,
        ValorString            : "",
        nrStatus               :  0,
        blnAtivo               : false
    }



    $scope.dadosmonitoramentostatus = {
        idMensagemTransferencia: 0,
        nrStatus: 0
    }


    //EGS IT SIngular 05.02.2018 - Transmite dados para NOSSO webapi AutBank
    $scope.dadosautbank = {
        agencia              : "",
        codEvento            : "",
        horaVencto           : "",
        valor                :  0,
        agenciaDeb           : "",
        contaDeb             : "",
        bancoCredito         : "",
        agenciaCred          : "",
        contaCred            : "",
        tipoContaCred        : "",
        cnpjCpfCliCred       : "",
        nomeCliCred          : "",
        finalidade           : "",
        historico            : "",
        tarifado             : "",
        validaPtoCorteSpb    : "",
        codUsuario           : "",
        cnpjCpfCliRem        : "",
        nomeCliRem           : "",
        cnpjCpfCliCred2      : "",
        nomeCliCred2         : "",
        codIdentdTransf      : "",
        origem               : "",
        sisOrigem            : "",
        dataVencto           : "",
        tipoPessoaCred       : "",
        prioridade           : "",
        dataAgendPag         : "",
        debAutorizado        : "",
        sensibilizaCC        : "",
        nroBoleto            : "",
        codCliente           : "",
        tipoPessoaInvest     : "",
        cnpjCpfInvest        : "",
        nomeRzSocialInvest   : "",
        complementoHistorico : "",
        numOrigem            : "",
        subSistemaO          : "",
        canalEntrada         : "",
        ispbCred             : ""
    }
    
   //EGS IT SIngular 05.02.2018 - Transmite dados para NOSSO webapi AutBank
    $scope.responseAutBank = {
        codErro              : 0 ,
        descricaoErro        : "",
        nsuSpb               : "",
        severidadeErro       :  0
    }


    // 0=Liberada  1=Desbloqueada 2=Bloqueada  3=Recusada
    //EGS IT Singular 20.01.2018 - Tipo de Status
    $scope.lstListaStatus = [
                        { nmListaStatus: '0-LIBERADA'    },
                        { nmListaStatus: '1-DESBLOQUEADA'},
                        { nmListaStatus: '2-BLOQUEADA'   },
                        { nmListaStatus: '3-RECUSADA'    },
                        { nmListaStatus: '9-PROCESSANDO' }];

    //EGS IT Singular 20.01.2018 - Tipo de Conta Origem
    $scope.lstListaOrigemTipo = [
                        { nmListaOrigemTipo: '1-CLIENTE' },
                        { nmListaOrigemTipo: '2-BANCO'   }];

    //EGS IT Singular 20.01.2018 - Tipo de Destino
    $scope.lstListaClienteTipo = [
                        { nmListaClienteTipo: '1-FISICA' },
                        { nmListaClienteTipo: '2-JURIDICA' }];


    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };





    //EGS IT Singular 31.12.2017 - Traz todos os registros
    $scope.carregar = function () {

        utilService.showPleaseWaitModal();

        $scope.filtro.dtInclusaoInicio = ""  ;
        $scope.filtro.dtInclusaoFinal  = ""  ;
        $scope.filtro.nrStatus         = "-1";
        $scope.filtro.NroBoleto        = ""  ;
        $scope.filtro.nrValInicio      = ""  ;
        $scope.filtro.nrValFinal       = ""  ;

        monitoramentoService.pesquisar($scope.filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }




    //EGS IT Singular 31.12.2017 - Traz todos os registros do filtro
    $scope.carregarString = function (filtro) {

        utilService.showPleaseWaitModal();

        //EGS IT Singular 15.06.2018 - Atuliza dados informados para gravar na tabela
        if (filtro.nrStatus.nmListaStatus == undefined) {
            $scope.filtro.nrStatus = -1
        } else { $scope.filtro.nrStatus = filtro.nrStatus.nmListaStatus.substring(0, 1); }


        monitoramentoService.pesquisar(filtro).then(function (response) {
            $scope.responsepesq = response.data;
            utilService.hidePleaseWaitModal();
            $scope.msg = true;
          //$scope.filtro = {};
        },
        function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });        
    }



    //EGS IT Singular 31.01.2018 - Carrega dados do webservice Autbank
    $scope.carregarWSAutBank = function () {
        $scope.dadosautbank.agencia   = '';
        monitoramentoService.pesquisarWSAutBank($scope.dadosautbank).then(function (response)
        {
            $scope.responseAutBank = response.data;
            setTimeout(function ()
            {
               $scope.carregar('');
            },2000);
        });
        $scope.carregar('');
    }





    $scope.VoltarInicio = function () {   
        $scope.dadosmonitoramento = null;
        $scope.filtro = {};
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }



    $scope.AbrirAlterar = function (id) {
        $scope.dados   = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;
        $scope.hdstep4 = true;

        $scope.dadosaltermonitoramento = $.grep($scope.responsepesq, function (x) { return x.idMensagemTransferencia == id; })[0];
        $scope.bExibeBotaoBloquear     = false;
        $scope.bExibeBotaoDesBloquear  = false;
        $scope.bExibeBotaoRecusar      = false;
        //------------------------------------------------------------ Descricao do Status ----------------------------------------------
        var strStatus  = '';
        if ($scope.dadosaltermonitoramento.nrStatus == '0') {
            strStatus = '0-LIBERADA';
          //$scope.bExibeBotaoBloquear = true;
          //$scope.bExibeBotaoRecusar  = true;
        } else {
            if ($scope.dadosaltermonitoramento.nrStatus == '1') {
                strStatus = '1-DESBLOQUEADA';
              //$scope.bExibeBotaoBloquear = true;
              //$scope.bExibeBotaoRecusar  = true;
            } else {
                if ($scope.dadosaltermonitoramento.nrStatus == '2') {
                    strStatus = '2-BLOQUEADA';
                    $scope.bExibeBotaoDesBloquear = true;
                    $scope.bExibeBotaoRecusar     = true;
                } else {
                    if ($scope.dadosaltermonitoramento.nrStatus == '3') {
                        strStatus = '3-RECUSADA';
                    } else {
                        strStatus = '9-PROCESSANDO';
                    }
                }
            }
        };
        $scope.dadosaltermonitoramento.TipoStatusSel   = $.grep($scope.lstListaStatus      , function (x) { return x.nmListaStatus      == strStatus ; })[0];



        if ($scope.dadosaltermonitoramento.blnAtivo == true) {
            $scope.dadosaltermonitoramento.blnAtivo = '1'
        } else {
            $scope.dadosaltermonitoramento.blnAtivo = '0'
        };
        if ($scope.dadosaltermonitoramento.Deb_ContaDigital == true) {
            $scope.dadosaltermonitoramento.Deb_ContaDigital = '1'
        } else {
            $scope.dadosaltermonitoramento.Deb_ContaDigital = '0'
        };
        if ($scope.dadosaltermonitoramento.Cre_ContaDigital == true) {
            $scope.dadosaltermonitoramento.Cre_ContaDigital = '1'
        } else {
            $scope.dadosaltermonitoramento.Cre_ContaDigital = '0'
        };
        if ($scope.dadosaltermonitoramento.ClienteExpostoPublic == true) {
            $scope.dadosaltermonitoramento.ClienteExpostoPublic = '1'
        } else {
            $scope.dadosaltermonitoramento.ClienteExpostoPublic = '0'
        };        
        if ($scope.dadosaltermonitoramento.Tarifado == true) {
            $scope.dadosaltermonitoramento.Tarifado = '1'
        } else {
            $scope.dadosaltermonitoramento.Tarifado = '0'
        };
        if ($scope.dadosaltermonitoramento.SensibilizaConta == true) {
            $scope.dadosaltermonitoramento.SensibilizaConta = '1'
        } else {
            $scope.dadosaltermonitoramento.SensibilizaConta = '0'
        };

     }




    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    };


    //EGS 20.02.2018 Mostra label do monitoramento
    /*
    { nmListaStatus: '0-LIBERADA'    },
    { nmListaStatus: '1-DESBLOQUEADA'},
    { nmListaStatus: '2-BLOQUEADA'   },
    { nmListaStatus: '3-RECUSADA'    }];
    */
    $scope.ChangeBoolStatus = function (status) {

        if (status == 0)
            return 'LIBERADA';
        else
            if (status == 1)
                return 'DESBLOQUEADA';
            else
                if (status == 2)
                    return 'BLOQUEADA';
                else
                    if (status == 3)
                        return 'RECUSADA';
                    else
                        return 'PROCESSANDO';
        
    };
        
        





    $scope.Save = function () {          
        utilService.showPleaseWaitModal();   
    }

    $scope.openInformationSuccess = function (mensagem) {
        $uibModal.open({
            templateUrl: 'myModalInformation.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = mensagem;
                $scope.ok = function () {
                    $uibModalInstance.close();
                        $route.reload();
                };
            }
        });
    };   

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.formatadata = function (id) {
        var data = document.getElementById(id).value;
        var keycode = event.keyCode;

        $scope.ValidarData(data);

        if (data.length < 1) {
            $scope.valido = false;
            return;
        }

        if (keycode != 8) {
            if (data.length == 2) {
                data = data + '/';
                document.getElementById(id).value = data;
            };
            if (data.length == 5) {
                data = data + '/';
                document.getElementById(id).value = data;
            }
        }
    };

    $scope.statusDtInicio = { opened: false };

    $scope.statusDtFinal  = {opened: false  };

    $scope.opendtInicio = function ($event) {
        $scope.statusDtInicio.opened = true;
    };

    $scope.opendtFinal = function ($event) {
        $scope.statusDtFinal.opened = true;
    };

    $scope.ValidarData = function (date) {
        if (date != "") {
            if (date != undefined) {
                date = $scope.date2String(date);
                if (typeof (date) !== "object") {

                    var valid = true;
                    var separator = '/';
                    if (date != undefined) {

                        var aoDate,
                            ms,
                            month, day, year;

                        if (separator === undefined) {
                            separator = '/';
                        }

                        aoDate = date.split(separator);

                        if (aoDate.length !== 3) {
                            valid = false;
                        }

                        day = aoDate[0] - 0;
                        month = aoDate[1] - 1;
                        year = aoDate[2] - 0;

                        if (year < 1900 || year > 3000) {
                            valid = false;
                        }

                        ms = (new Date(year, month, day)).getTime();

                        aoDate = new Date();
                        aoDate.setTime(ms);

                        if (aoDate.getFullYear() !== year ||
                            aoDate.getMonth() !== month ||
                            aoDate.getDate() !== day) {
                            valid = false;
                        }

                        if (valid == true) {
                            $scope.valido = false;
                            return "";
                        }
                        else {
                            $scope.valido = true;
                            return "ng-invalid";
                        }
                    }
                }
            }
        }
    };

    $scope.verificaClassError = function (tipo) {
        var inicio = document.getElementById('dtinicio' + tipo).value;
        var fim = document.getElementById('dtfim' + tipo).value;

        if (fim != '' || inicio != '') {
            if ($scope.gerarData(inicio) > $scope.gerarData(fim)) {
                $scope.valido = true;
                return "ng-invalid";
            }
            else {
                $scope.valido = false;
                $scope.ValidarData(inicio);
                $scope.ValidarData(fim);
                return "";
            }
        }
    };



    //================================================================================ \\
    // EGS 30.05.2018 - EGS IT Singular
    // Para blooquear ou desbloquear o Monitoramento, conforme estatus atual
    //================================================================================ \\
    $scope.BotaoBloquear = function (idMensagemTransferencia) {

        $scope.sTextoPergunta                                   = 'Deseja BLOQUEAR o Monitoramento [' + idMensagemTransferencia + '] ?';
        $scope.sNewStatus                                       = 'O bloqueio do Monitoramento não executado';
        $scope.sNewStatus                                       = 2;  //De Liberada para Bloqueada
        $scope.dadosmonitoramentostatus.idMensagemTransferencia = idMensagemTransferencia;
        $scope.dadosmonitoramentostatus.nrStatus                = $scope.sNewStatus

        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = $scope.sTextoPergunta;
                $scope.ok = function () {
                    monitoramentoService.AlterarBloqueio($scope.dadosmonitoramentostatus);
                    $uibModalInstance.close();
                    $scope.carregarString('');
                    $scope.VoltarInicio();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = $scope.sTextoResposta;
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };





    //================================================================================ \\
    // EGS 30.05.2018 - EGS IT Singular
    // Para blooquear ou desbloquear o Monitoramento, conforme estatus atual
    //================================================================================ \\
    $scope.BotaoDesBloquear = function (idMensagemTransferencia) {

        $scope.sTextoPergunta                                   = 'Deseja DESBLOQUEAR o Monitoramento [' + idMensagemTransferencia + '] ?';
        $scope.sTextoResposta                                   = 'O desbloqueio do Monitoramento não executado';
        $scope.sNewStatus                                       = 1;  //De Liberada para DesBloqueada
        $scope.dadosmonitoramentostatus.idMensagemTransferencia = idMensagemTransferencia;
        $scope.dadosmonitoramentostatus.nrStatus                = $scope.sNewStatus


        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = $scope.sTextoPergunta;
                $scope.ok = function () {
                    monitoramentoService.AlterarBloqueio($scope.dadosmonitoramentostatus);
                    $uibModalInstance.close();
                    $scope.carregarString('');
                    $scope.VoltarInicio();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = $scope.sTextoResposta;
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };






    //================================================================================ \\
    // EGS 30.05.2018 - EGS IT Singular
    // Para RECUSAR o Monitoramento, conforme estatus atual
    //================================================================================ \\
    $scope.BotaoRecusar = function (idMensagemTransferencia) {

        $scope.sTextoPergunta                                   = 'Deseja RECUSAR o Monitoramento [' + idMensagemTransferencia + '] ?';
        $scope.sTextoResposta                                   = 'Ação do Monitoramento não executado';
        $scope.sNewStatus                                       = 3;  //De Bloqueada para Recusada
        $scope.dadosmonitoramentostatus.idMensagemTransferencia = idMensagemTransferencia;
        $scope.dadosmonitoramentostatus.nrStatus                = $scope.sNewStatus


        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = $scope.sTextoPergunta;
                $scope.ok = function () {
                    monitoramentoService.AlterarBloqueio($scope.dadosmonitoramentostatus);
                    $uibModalInstance.close();
                    $scope.carregarString('');
                    $scope.VoltarInicio();
                };
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                    $scope.mensagem = $scope.sTextoResposta;
                    $scope.openInformationSuccess($scope.mensagem);
                    $uibModalInstance.close();
                };
            }
        })
    };

}]);