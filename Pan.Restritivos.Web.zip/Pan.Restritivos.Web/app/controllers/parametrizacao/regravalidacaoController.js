﻿'use strict';
app.controller('regravalidacaoController', ['$scope', '$route', '$location', 'regravalidacaoService', '$uibModal', '$sce', 'utilService', 'loginService',
    function ($scope, $route, $location, regravalidacaoService, $uibModal, $sce, utilService, loginService) {

        //###################################################################################
        //Inicio - Gerenciamento de permissão
        //###################################################################################
        var path = $location.path();
        $scope.blnInativar = false;
        $scope.blnAlterar = false;
        $scope.blnIncluir = false;

        if (path != '/' && path != '/403') {
            var retorno = loginService.getaccesspage(path);
            if (retorno.status == false || retorno.acesso == null) {
                $location.path('/403');
                return;
            }
            else {

                if (retorno.acesso.blnConsultar == false) {
                    $location.path('/403');
                }
                if (retorno.acesso.blnInativar == false) {
                    $scope.blnInativar = true;
                }
                if (retorno.acesso.blnAlterar == false) {
                    $scope.blnAlterar = true;
                }
                if (retorno.acesso.blnIncluir == false) {
                    $scope.blnIncluir = true;
                }
            }
        }
        //###################################################################################
        //Fim - Gerenciamento de permissão
        //###################################################################################

        $scope.filtro = { nmDescricao: "", nmConsequencia:"", nrCriticidade: 0 };

        $scope.dadosregravalidacao = {
            idRegraValidacao: 0,
            nmDescricao: "",
            nmConsequencia: "",
            nrCriticidade: 0,
            blAtivo: false
        }

        //EGS Clausula da Regra
        $scope.dadosregravalidaclausula = {
            idRegraValidaClausula: 0,
            idRegraValidacao: 0,
            idEntidade: 0,
            idEntidadeAtributo: 0,
            idTipoOperador: 0,
            idPeriodoAgrupamento: 0,
            idTipoAgrupamento: 0,
            nrValor: "",
            blAtivo: false
        }

        //EGS IT Singular 05.01.2018 - Consequencia da Regra
        $scope.TipoConsequencias = [
                            { nmTipoConsequencia: 'ALERTAR' },
                            { nmTipoConsequencia: 'RECUSAR' },
                            { nmTipoConsequencia: 'BLOQUEAR' }];


        //EGS IT Singular 05.01.2018 - Criticidade
        $scope.TipoCriticidades = [
                            { nrTipoCriticidade: '0' },
                            { nrTipoCriticidade: '1' },
                            { nrTipoCriticidade: '2' },
                            { nrTipoCriticidade: '3' },
                            { nrTipoCriticidade: '4' },
                            { nrTipoCriticidade: '5' },
                            { nrTipoCriticidade: '6' },
                            { nrTipoCriticidade: '7' },
                            { nrTipoCriticidade: '8' },
                            { nrTipoCriticidade: '9' },
                            { nrTipoCriticidade: '10' }];

        //EGS Tipo Operador da Clasula
        $scope.DadosClausulaTipoOperador = {
            idTipoOperador: 0,
            cdTipoOperador: "",
            nmDescricao: "",
            blAtivo: false
        }
        //EGS Entidade Filtro
        $scope.DadosClausulaEntidade = {
            idEntidade: 0,
            cdEntidade: "",
            nmEntidade: "",
            blAtivo: false
        }
        //EGS Entidade Atributo
        $scope.DadosClausulaEntidadeAtributo = {
            idEntidadeAtributo: 0,
            idEntidade: 0,
            nmEntidade: "",
            nmAtributo: "",
            blAtivo: false
        }
        //EGS Tipo Agrupamento
        $scope.DadosClausulaTipoAgrupamento = {
            idTipoAgrupamento: 0,
            cdTipoAgrupamento: "",
            nmDescricao: "",
            blAtivo: false
        }
        //EGS Periodo Agrupamento
        $scope.DadosClausulaPeriodoAgrupamento = {
            idPeriodoAgrupamento: 0,
            cdPeriodoAgrupamento: "",
            nmDescricao: "",
            blAtivo: false
        }


        $scope.hdstep1 = false;    //Pesquisa
        $scope.hdstep2 = true;    //Novo item
        $scope.hdstep3 = true;    //alteracao item
        $scope.hdstep4 = true;    //grid de clausulas
        $scope.hdstep5 = true;    //Inclusao de nova clausula
        $scope.hdstep6 = true;    //Alterar Clausula


        $scope.doTheBack = function () {
            window.history.back();
        };




        //EGS IT Singular 05.01.2018- Traz todos os registros
        $scope.carregar = function () {

            utilService.showPleaseWaitModal();

            //EGS 30.06.2018 - Limpa o filtro
            $scope.filtro.nmDescricao    = "";
            $scope.filtro.nmConsequencia = "";
            $scope.filtro.nrCriticidade  = 0 ;

            regravalidacaoService.pesquisar($scope.filtro).then(function (response) {
                $scope.responsepesq = response.data;

                //Tipo Operador da Clausula
                regravalidacaoService.pesquisar_tipooperador().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaTipoOperador = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaTipoOperador = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Entidade Filtro
                regravalidacaoService.pesquisar_entidade().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaEntidade = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaEntidade = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Entidade Atributo
                regravalidacaoService.pesquisar_entidadeatributo().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaEntidadeAtributo = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaEntidadeAtributo = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Tipo Agrupamento
                regravalidacaoService.pesquisar_tipoagrupamento().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaTipoAgrupamento = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaTipoAgrupamento = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Periodo Agrupamento
                regravalidacaoService.pesquisar_periodoagrupamento().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaPeriodoAgrupamento = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaPeriodoAgrupamento = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });

                utilService.hidePleaseWaitModal();
                $scope.msg = true;
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });

            utilService.hidePleaseWaitModal();

        }








        //EGS IT Singular 05.01.2018- Traz todos os registros
        $scope.carregarString = function (filtro) {

            utilService.showPleaseWaitModal();

            //EGS IT Singular 15.06.2018 - Atuliza dados informados para gravar na tabela
            if ($scope.filtro.nmConsequencia.nmTipoConsequencia == undefined) { $scope.filtro.nmConsequencia = "" } else { $scope.filtro.nmConsequencia = $scope.filtro.nmConsequencia.nmTipoConsequencia; }
            if ($scope.filtro.nrCriticidade.nrTipoCriticidade   == undefined) { $scope.filtro.nrCriticidade  = 0  } else { $scope.filtro.nrCriticidade  = $scope.filtro.nrCriticidade.nrTipoCriticidade; }

            regravalidacaoService.pesquisar($scope.filtro).then(function (response) {
                $scope.responsepesq = response.data;

                //Tipo Operador da Clausula
                regravalidacaoService.pesquisar_tipooperador().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaTipoOperador = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaTipoOperador = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Entidade Filtro
                regravalidacaoService.pesquisar_entidade().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaEntidade = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaEntidade = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Entidade Atributo
                regravalidacaoService.pesquisar_entidadeatributo().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaEntidadeAtributo = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaEntidadeAtributo = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Tipo Agrupamento
                regravalidacaoService.pesquisar_tipoagrupamento().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaTipoAgrupamento = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaTipoAgrupamento = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });
                //Periodo Agrupamento
                regravalidacaoService.pesquisar_periodoagrupamento().then(function (response) {
                    $scope.ret = response.data;
                    $scope.DadosClausulaPeriodoAgrupamento = [];
                    for (var i = 0; i < $scope.ret.length; i++) {
                        $scope.DadosClausulaPeriodoAgrupamento = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                    }
                });

                utilService.hidePleaseWaitModal();
                $scope.msg = true;
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });

            utilService.hidePleaseWaitModal();

        }




        $scope.AbrirAlterar = function (id) {
            $scope.dados = null;
            $scope.hdstep1 = true;     //Pesquisa
            $scope.hdstep2 = true;     //Novo item
            $scope.hdstep3 = false;     //alteracao item
            $scope.hdstep4 = false;     //grid de clausulas
            $scope.hdstep5 = true;     //Inclusao de nova clausula
            $scope.hdstep6 = true;     //Alterar Clausula


            $scope.dadosregravalidacao = $.grep($scope.responsepesq, function (x) { return x.idRegraValidacao == id; })[0];


            regravalidacaoService.pesquisarclausula(id).then(function (response) {
                $scope.responsepesqclausula = response.data;
                $scope.dadosregravalidaclausula = $.grep($scope.responsepesqclausula, function (x) { return x.idRegraValidacao == id; })[0];
            });


            $scope.dadosregravalidacao.MsgConsequencia = $.grep($scope.TipoConsequencias, function (x) { return x.nmTipoConsequencia == $scope.dadosregravalidacao.nmConsequencia; })[0];
            $scope.dadosregravalidacao.MsgCriticidade  = $.grep($scope.TipoCriticidades , function (x) { return x.nrTipoCriticidade  == $scope.dadosregravalidacao.nrCriticidade ; })[0];
            

            if ($scope.dadosregravalidacao.blnAtivo == true) {
                $scope.dadosregravalidacao.blnAtivo = '1'
            } else {
                $scope.dadosregravalidacao.blnAtivo = '0'
            };

        }



        $scope.Save = function () {
            utilService.showPleaseWaitModal();

            //EGS IT Singular 05.01.2017 - Consequencias e Criticidade
            $scope.dadosregravalidacao.nmConsequencia = $scope.dadosregravalidacao.MsgConsequencia.nmTipoConsequencia;
            $scope.dadosregravalidacao.nrCriticidade  = $scope.dadosregravalidacao.MsgCriticidade.nrTipoCriticidade;

            regravalidacaoService.Inserir($scope.dadosregravalidacao).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });
        }




        $scope.Alterar = function () {

            utilService.showPleaseWaitModal();

            $scope.dadosregravalidacao.nmConsequencia = $scope.dadosregravalidacao.MsgConsequencia.nmTipoConsequencia;
            $scope.dadosregravalidacao.nrCriticidade  = $scope.dadosregravalidacao.MsgCriticidade.nrTipoCriticidade;


            if ($scope.dadosregravalidacao.blnAtivo == '1') {
                $scope.dadosregravalidacao.blnAtivo = true
            } else {
                $scope.dadosregravalidacao.blnAtivo = false
            };

            regravalidacaoService.Alterar($scope.dadosregravalidacao).then(function (response) {
                utilService.hidePleaseWaitModal();
                $scope.mensagem = 'Registro alterado com sucesso.'
                $scope.openInformationSuccess($scope.mensagem);

            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        }

        $scope.Inativar = function (idRegraValidacao) {
            utilService.showPleaseWaitModal();
            regravalidacaoService.Inativar(idRegraValidacao).then(function (response) {
                utilService.hidePleaseWaitModal();
                $scope.mensagem = 'Registro excluído com sucesso.'
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        };
        $scope.Ativar = function (idRegraValidacao) {
            utilService.showPleaseWaitModal();
            regravalidacaoService.Ativar(idRegraValidacao).then(function (response) {
                utilService.hidePleaseWaitModal();
                $scope.mensagem = 'Registro ativado com sucesso.'
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        };



        $scope.insert = function () {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja incluir as informações?';
                    $scope.ok = function () {
                        $scope.Save();
                        $uibModalInstance.close();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não incluído.';
                        $scope.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };




        $scope.alter = function () {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja alterar as informações?';
                    $scope.ok = function () {
                        $scope.Alterar();
                        $uibModalInstance.close();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não alterado.';
                        $scope.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };





        //---------------------------------------------------------------------------------- CLAUSULA ------------------------------------------------------------
        //EGS Alterar dados da clausula
        $scope.AbrirAlterClausula = function (idRegraValidaclausula) {
            $scope.dados = null;
            $scope.hdstep1 = true;     //Pesquisa
            $scope.hdstep2 = true;     //Novo item
            $scope.hdstep3 = false;     //alteracao item
            $scope.hdstep4 = false;     //grid de clausulas
            $scope.hdstep5 = true;     //Inclusao de nova clausula
            $scope.hdstep6 = false;     //Alterar Clausula

            $scope.dadosAlterClausula                       = JSON.parse(JSON.stringify($.grep($scope.responsepesqclausula, function (x) { return x.idRegraValidaClausula == idRegraValidaclausula; })[0]));
            $scope.dadosAlterClausula.EntidadeSel           = $.grep($scope.DadosClausulaEntidade          , function (x) { return x.idEntidade           == $scope.dadosAlterClausula.idEntidade; })[0];
            $scope.dadosAlterClausula.EntidadeAtributoSel   = $.grep($scope.DadosClausulaEntidadeAtributo  , function (x) { return x.idEntidadeAtributo   == $scope.dadosAlterClausula.idEntidadeAtributo; })[0];
            $scope.dadosAlterClausula.TipoOperadorSel       = $.grep($scope.DadosClausulaTipoOperador      , function (x) { return x.idTipoOperador       == $scope.dadosAlterClausula.idTipoOperador; })[0];
            $scope.dadosAlterClausula.TipoAgrupamentoSel    = $.grep($scope.DadosClausulaTipoAgrupamento   , function (x) { return x.idTipoAgrupamento    == $scope.dadosAlterClausula.idTipoAgrupamento; })[0];
            $scope.dadosAlterClausula.PeriodoAgrupamentoSel = $.grep($scope.DadosClausulaPeriodoAgrupamento, function (x) { return x.idPeriodoAgrupamento == $scope.dadosAlterClausula.idPeriodoAgrupamento; })[0];

            if ($scope.dadosAlterClausula.blnAtivo == true) {
                $scope.dadosAlterClausula.blnAtivo = '1'
            } else {
                $scope.dadosAlterClausula.blnAtivo = '0'
            };

        }


        //EGS Savar a nova clausula
        $scope.SaveClausula = function () {
            utilService.showPleaseWaitModal();

            //EGS IT Singular 15.01.2018 - Atuliza dados informados para gravar na tabela
            $scope.dadosregravalidaclausula.idEntidade           = $scope.dadosregravalidaclausula.EntidadeDescricao.idEntidade;
            $scope.dadosregravalidaclausula.idEntidadeAtributo   = $scope.dadosregravalidaclausula.EntidadeAtributoDescricao.idEntidadeAtributo;
            $scope.dadosregravalidaclausula.idTipoOperador       = $scope.dadosregravalidaclausula.TipoOperadorDescricao.idTipoOperador;
            $scope.dadosregravalidaclausula.idTipoAgrupamento    = $scope.dadosregravalidaclausula.TipoAgrupamentoDescricao.idTipoAgrupamento;
            $scope.dadosregravalidaclausula.idPeriodoAgrupamento = $scope.dadosregravalidaclausula.PeriodoAgrupamentoDescricao.idPeriodoAgrupamento;
            $scope.dadosregravalidaclausula.idRegraValidacao     = $scope.dadosregravalidacao.idRegraValidacao;

            regravalidacaoService.InserirClausula($scope.dadosregravalidaclausula).then(function (response) {
                $scope.mensagem = 'Registro da Clausula incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                $scope.openInformationError(response);
            });
        }

        //EGS Chama URL para alterar clausula
        $scope.AlterarClausula = function () {

            utilService.showPleaseWaitModal();

            //EGS IT Singular 15.01.2018 - Atuliza dados informados para gravar na tabela
            $scope.dadosAlterClausula.idEntidade = $scope.dadosAlterClausula.EntidadeSel.idEntidade;
            $scope.dadosAlterClausula.idEntidadeAtributo = $scope.dadosAlterClausula.EntidadeAtributoSel.idEntidadeAtributo;
            $scope.dadosAlterClausula.idTipoOperador = $scope.dadosAlterClausula.TipoOperadorSel.idTipoOperador;
            $scope.dadosAlterClausula.idTipoAgrupamento = $scope.dadosAlterClausula.TipoAgrupamentoSel.idTipoAgrupamento;
            $scope.dadosAlterClausula.idPeriodoAgrupamento = $scope.dadosAlterClausula.PeriodoAgrupamentoSel.idPeriodoAgrupamento;


            if ($scope.dadosAlterClausula.blnAtivo == '1') {
                $scope.dadosAlterClausula.blnAtivo = true
            } else {
                $scope.dadosAlterClausula.blnAtivo = false
            };

            regravalidacaoService.AlterarClausula($scope.dadosAlterClausula).then(function (response) {
                utilService.hidePleaseWaitModal();
                $scope.mensagem = 'Registro alterado com sucesso.'
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });

        }




        //EGS IT Singular 25.01.2018 - Preenche dados do atributo, conforme Entidade selecionada
        $scope.PreencheAtributos = function () {

            var idEntidade = $scope.dadosAlterClausula.EntidadeSel.idEntidade;
            if (idEntidade == null) { idEntidade = 1 };

            regravalidacaoService.pesquisar_entidadeatributo_ID(idEntidade).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosClausulaEntidadeAtributo = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosClausulaEntidadeAtributo = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });
            utilService.hidePleaseWaitModal();
        }


        //EGS IT Singular 25.03.2018 - Preenche dados do atributo, conforme Entidade selecionada, ao INCLUIR nova clausula
        $scope.PreencheAtribIncluir = function () {

            var idEntidade = $scope.dadosregravalidaclausula.EntidadeDescricao.idEntidade;
            if (idEntidade == null) { idEntidade = 1 };

            regravalidacaoService.pesquisar_entidadeatributo_ID(idEntidade).then(function (response) {
                $scope.ret = response.data;
                $scope.DadosClausulaEntidadeAtributo = [];
                for (var i = 0; i < $scope.ret.length; i++) {
                    $scope.DadosClausulaEntidadeAtributo = $.grep($scope.ret, function (x) { return x.blnAtivo == true; });
                }
            });
            utilService.hidePleaseWaitModal();
        }




        //EGS Inclusao de Clausula
        $scope.insertClausula = function () {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja incluir as informações?';
                    $scope.ok = function () {
                        $scope.SaveClausula();
                        $uibModalInstance.close();
                        $scope.VoltarAlterClausula();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não incluído.';
                        $scope.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };

        //EGS IT Singular 10.01.2017 - Pergunta se deseja Inativar uma clausula
        $scope.deleteClausula = function (idRegraValidaClausula) {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja excluir a Clausula da Regra ? ';
                    $scope.ok = function () {
                        $scope.InativarClausula(idRegraValidaClausula);
                        $uibModalInstance.close();
                        $scope.VoltarAlterClausula();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não excluído.';
                        $scope.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };

        //EGS IT Singular 10.01.2017 - Inativar uma clausula
        $scope.InativarClausula = function (idRegraValidaClausula) {
            utilService.showPleaseWaitModal();
            regravalidacaoService.InativarClausula(idRegraValidaClausula).then(function (response) {
                utilService.hidePleaseWaitModal();
                $scope.mensagem = 'Registro excluído com sucesso.'
                $scope.openInformationSuccess($scope.mensagem);
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        };


        $scope.altClausula = function () {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja alterar as informações?';
                    $scope.ok = function () {
                        $scope.AlterarClausula();
                        $uibModalInstance.close();
                        $scope.VoltarAlterClausula();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não alterado.';
                        $scope.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };


        $scope.VoltarInicio = function () {
            $scope.dadosregravalidacao = null;
            $scope.dadosregravalidaclausula = null;
            $scope.hdstep1 = false;    //Pesquisa
            $scope.hdstep2 = true;     //Novo item
            $scope.hdstep3 = true;     //alteracao item
            $scope.hdstep4 = true;     //grid de clausulas
            $scope.hdstep5 = true;     //Inclusao de nova clausula
            $scope.hdstep6 = true;     //Alterar Clausula
        }

        $scope.VoltarAlterClausula = function () {
            $scope.hdstep1 = true;    //Pesquisa
            $scope.hdstep2 = true;    //Novo item
            $scope.hdstep3 = false;    //alteracao item
            $scope.hdstep4 = false;    //grid de clausulas
            $scope.hdstep5 = true;    //Inclusao de nova clausula
            $scope.hdstep6 = true;    //Alterar Clausula
        }


        $scope.VoltarNewClausula = function () {
            $scope.hdstep1 = true;    //Pesquisa
            $scope.hdstep2 = true;    //Novo item
            $scope.hdstep3 = false;    //alteracao item
            $scope.hdstep4 = false;    //grid de clausulas
            $scope.hdstep5 = true;    //Inclusao de nova clausula
            $scope.hdstep6 = true;    //Alterar Clausula
        }

        $scope.AbrirNovo = function () {
            $scope.dadosregravalidacao = null;
            $scope.dadosregravalidaclausula = null;
            $scope.statusLogin = "";
            $scope.hdstep1 = true;     //Pesquisa
            $scope.hdstep2 = false;    //Novo item
            $scope.hdstep3 = true;     //alteracao item
            $scope.hdstep4 = true;     //grid de clausulas
            $scope.hdstep5 = true;     //Inclusao de nova clausula
            $scope.hdstep6 = true;     //Alterar Clausula
        }


        //EGS IT Singular 05.01.2017 - Nova Clausula da regra
        $scope.NovaClausula = function (id) {
            $scope.dadosregravalidaclausula = null;
            $scope.hdstep1 = true;     //Pesquisa
            $scope.hdstep2 = true;     //Novo item
            $scope.hdstep3 = false;    //alteracao item
            $scope.hdstep4 = false;    //grid de clausulas
            $scope.hdstep5 = false;    //Inclusao de nova clausula
            $scope.hdstep6 = true;    //Alterar Clausula
        };




        $scope.ChangeBool = function (status) {
            if (status == true)
                return 'Ativo';
            else
                return 'Inativo';
        };


        $scope.ChangeCorLinha = function (status) {

            if (status == true)
                return 'Sim';
            else
                return '';
        };

        $scope.openInformationSuccess = function (mensagem) {
            $uibModal.open({
                templateUrl: 'myModalInformation.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = mensagem;
                    $scope.ok = function () {
                        $uibModalInstance.close();

                        $route.reload();

                    };
                }
            });
        };




        $scope.openInformationError = function (response) {
            $uibModal.open({
                templateUrl: 'myModalContentError.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {

                    $scope.errors = [];
                    for (var key in response.data.errors) {
                        $scope.errors.push(response.data.errors[key]);
                    }

                    $scope.ok = function () {
                        $uibModalInstance.close();
                    };
                }
            });
        };

    }]);



