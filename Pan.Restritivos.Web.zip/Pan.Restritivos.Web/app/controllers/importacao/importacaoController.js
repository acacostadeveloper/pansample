﻿app.controller('importacaoController', ['$scope', '$location', '$http', 'importacaoService', '$uibModal', '$sce', 'loginService', 'utilService', '$route',
function ($scope, $location, $http, importacaoService, $uibModal, $sce, loginService, utilService, $route) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar = false;
    $scope.blnIncluir = false;
    $scope.blnImportar = false;
    if (path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
            if (retorno.acesso.blnImportar == false) {
                $scope.blnImportar = true;
            }
        }
    }
    $scope.ArquivoCSVTexto = {
        value: 'Esperando ...'
    };

    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################



    //###################################################################################
    //Inicio - Variaveis

    $scope.hdstep1 = false;
    $scope.hdstep2 = true;

    $scope.dadosimportacao = {
        base: "listanegra",
        nmImportaLocalizacao: "C:\ITSingular52\LISTANEGRA.csv",
        txRetorno: ""
    }

    $scope.importacao = {
        Tabela: "",
        ArquivoCSV: ""
    }







    $scope.openImport = function (scope) {
        $uibModal.open({
            templateUrl: 'ModalUpload.html',
            backdrop: 'static',
            windowClass: 'modal modal-dialog-min',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    utilService.showPleaseWaitModal();

                    $scope.EnviarArquivoCSV();
                    utilService.hidePleaseWaitModal();
                    $uibModalInstance.close();
                };

                $scope.cancel = function () {
                    $scope.importacao = null;
                    $uibModalInstance.close();
                };
            }
        });
    };




    $scope.EnviarArquivoCSV = function () {
        $scope.dadosimportacao.txRetorno = "";
        $scope.hdstep2                   = true;
        try {

            if ($scope.importacao.ArquivoCSV.length <= 50)
            {
                $scope.mensagem          = 'Arquivo CSV não informado...';
                $scope.openExportValidate($scope.mensagem);
            }
            else
            {
                $scope.importacao.Tabela = $scope.dadosimportacao.base;

                importacaoService.EnviarArquivoCSV($scope.importacao).then(function (response)
                {
                    var texto = response.data;
                    var palavras = texto.split(" ");
                    texto = palavras.join("\n");
                    $scope.hdstep2                    = false;
                    $scope.dadosimportacao.txRetorno  = texto;
                    utilService.hidePleaseWaitModal();
                });                
            }
        }
        catch (err) {
            var objErro = { errorMessage: "Importação CSV: '" + $location.path() + "' - " + err.message };
            utilService.inserirLog(objErro);
            $scope.ArquivoCSVRetorno = "Importação CSV: " + err.message;
            $scope.openExportError(err);
        }
    };

    





    //Fim - Metodos
    //###################################################################################


    //###################################################################################
    //Inicio - Modal

    $scope.openInformationSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalContentSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };
    $scope.openInformationError   = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };
    $scope.openExportSuccess      = function () {
        $uibModal.open({
            templateUrl: 'myModalExportSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };
    $scope.openExportValidate     = function (MessageText) {
        $uibModal.open({
            templateUrl: 'myModalQuestion.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.mensagem = MessageText;
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };
    $scope.openExportError        = function (err) {
        $uibModal.open({
            templateUrl: 'myModalExportError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.excecao = err.message;
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

}]);




//================================================================================ \\
// EGS 30.05.2018 - EGS IT Singular
// Funcao para carregar os dados do CSV para a memoria
//================================================================================ \\
app.directive('fileTxt', function () {
    return {
        require: 'ngModel',
        scope: true,
        link: function ($scope, elem, attrs, ngModel)
        {
            elem.on('change', function (e)
            {
                $scope.hdstep1 = true;
                $scope.hdstep2 = false;
                var reader     = new FileReader();
                reader.onload = (function (reader)
                {
                    return function ()
                    {
                        $scope.$apply(function ()
                        {
                            $scope.ArquivoCSVTexto.value = reader.result.substring(0, 1000) + ' .......... continua !!';
                            $scope.importacao.ArquivoCSV = reader.result;
                        });
                        return reader.result.substring(0, 1000) + ' .......... continua !!';
                    }
                })(reader);
                reader.readAsText(elem[0].files[0]);
            });
        }
    }
});

