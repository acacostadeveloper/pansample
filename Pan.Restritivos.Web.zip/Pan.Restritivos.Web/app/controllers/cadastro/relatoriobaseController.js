﻿'use strict';
app.controller('relatoriobaseController', ['$scope', '$location', 'relatoriobaseService', '$uibModal', '$sce', 'loginService', 'utilService', '$route',
function ($scope, $location, relatoriobaseService, $uibModal, $sce, loginService, utilService, $route) {

    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar = false;
    $scope.blnIncluir = false;
    $scope.blnImportar = false;
    if (path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
            if (retorno.acesso.blnImportar == false) {
                $scope.blnImportar = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################



    //###################################################################################
    //Inicio - Variaveis

    $scope.hdstep1 = false;

    $scope.listImportacao = [];

    //Fim - Variaveis
    //###################################################################################


    //###################################################################################
    //Inicio - Metodos

    $scope.openExport = function () {

        $uibModal.open({
            templateUrl: 'ModalUpload.html',
            backdrop: 'static',
            windowClass: 'modal modal-dialog-min',
            scope: $scope,
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    utilService.showPleaseWaitModal();
                    $scope.exportarExcel();
                    utilService.hidePleaseWaitModal();
                    $uibModalInstance.close();
                };

                $scope.cancel = function () {
                    $scope.dados = null;
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.formatadata = function (id) {
        var data = document.getElementById(id).value;
        var keycode = event.keyCode;

        if (keycode != 8) {
            //if (!((data >= "0") && (data <= "9"))) {
            //    document.getElementById(id).value = null;
            //}

            if (data.length == 2) {
                data = data + '/';
                document.getElementById(id).value = data;

            };
            if (data.length == 5) {
                data = data + '/';
                document.getElementById(id).value = data;
            };
        }

    };

    $scope.exportarExcel = function () {
        try {

            relatoriobaseService.lista($scope.dados.base).then(function (response) {
                var listImportacao = response.data;

                utilService.exportarExcel("tb" + $scope.dados.base, $scope.dados.base + ".xlsx", listImportacao);
                
                    $scope.openExportSuccess();
                    utilService.hidePleaseWaitModal();
                    
                
            },
            function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            })



        }
        catch (err) {
            var objErro = { errorMessage: "Exportação - Local: '" + $location.path() + "' - " + err.message };
            utilService.inserirLog(objErro);
            $scope.openExportError(err);
        }
    };

    //Fim - Metodos
    //###################################################################################


    //###################################################################################
    //Inicio - Modal

    $scope.openInformationSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalContentSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    $uibModalInstance.close();
                    $route.reload();
                };
            }
        });
    };

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openExportSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalExportSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openExportError = function (err) {
        $uibModal.open({
            templateUrl: 'myModalExportError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.excecao = err.message;
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    //Fim - Modal
    //###################################################################################


}]);
