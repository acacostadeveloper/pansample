﻿'use strict';
app.controller('perfilController', ['$scope', '$filter', '$location', 'perfilService', '$sce', '$uibModal', '$route', '$timeout', 'usuarioService', 'utilService', 'loginService', function ($scope, $filter, $location, perfilService, $sce, $uibModal, $route, $timeout, usuarioService, utilService, loginService) {

    $scope.alert = { showalertdanger: false };

    $scope.mensagem = "";
    $scope.errors = [];
    $scope.nomeperfil = "";
    $scope.nomealcada = "";
    $scope.mensagemerro = "";
    $scope.modelProcessing = undefined;

    $scope.login = {
        usuario: "",
        senha: "",
        perfil: [],
        alcada: []
    }

    $scope.perfil = {
        nomePerfil: "",
        nome: "",
        permitRepro: false,
        permitFinPed: false,
        permintEncPed: false,
        menu: $scope.menu
    }
    $scope.menu = [];
    $scope.idperfil = "";
    $scope.gravar = [];
    $scope.readonly = true;
    $scope.caminho = "/perfil/consultar";
    $scope.flagstatus = "";

    if (loginService.getaccesspage($scope.caminho) == false)
    {
        $location.path('/403');
    };
 

    $scope.carregar = function () {
        utilService.showPleaseWaitModal();

        if ($route.current.params.idperfil != null) {
            $scope.idperfil = $route.current.params.idperfil
        }

        perfilService.getmenu($scope.idperfil).then(function (result) {
            $scope.menu = result.data;

            perfilService.pesquisar().then(function (response) {
                $scope.responsepesq = response.data;

                if ($route.current.params.idperfil != null) {
                    perfilService.getperfil($scope.idperfil).then(function (response) {
                        $scope.perfil = response.data;
                        utilService.hidePleaseWaitModal();
                    }, function (response) {
                        utilService.hidePleaseWaitModal();
                        $scope.openInformationError(response);
                    })
                } else {
                    utilService.hidePleaseWaitModal();
                }

            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    }

    $scope.setchecked = function (id, event) {
        $scope.updateLeitura(id, event.target.checked);
    };

    $scope.setcheckedgravacao = function (id, event) {
        $scope.updateGravacao(id, event.target.checked);
    };

    $scope.updateLeitura = function (id, check) {
        for (var i = 0; i < $scope.menu.length; i++) {
            for (var j = 0; j < $scope.menu[i].itensmenu.length; j++) {
                if ($scope.menu[i].itensmenu[j].id == id) {
                    if (check == false && $scope.menu[i].itensmenu[j].gravacao == true) {
                        $scope.menu[i].itensmenu[j].gravacao = false;
                    }
                    $scope.menu[i].itensmenu[j].leitura = check;
                }

            }

        }
    }

    $scope.updateGravacao = function (id, check) {
        for (var i = 0; i < $scope.menu.length; i++) {
            for (var j = 0; j < $scope.menu[i].itensmenu.length; j++) {
                if ($scope.menu[i].itensmenu[j].id == id) {
                    if (check == true && $scope.menu[i].itensmenu[j].leitura != true) {
                        $scope.menu[i].itensmenu[j].leitura = check;
                    }
                    $scope.menu[i].itensmenu[j].gravacao = check;
                }

            }

        }
    }

    $scope.salverperfil = function () {
        $scope.perfil.menu = $scope.menu;
        if ($scope.idperfil != null && $scope.idperfil != "") {
            utilService.showPleaseWaitModal();

            perfilService.editarperfil($scope.perfil).then(function () {
                $scope.openInformationSuccess();

                utilService.hidePleaseWaitModal();

            }, function (response) {
                $scope.openInformationError(response);
                utilService.hidePleaseWaitModal();
            })
        }
        else {

            //$scope.openPleaseWait();
            utilService.showPleaseWaitModal();

            perfilService.addperfil($scope.perfil).then(function () {
                $scope.openInformationSuccess();
                utilService.hidePleaseWaitModal();
            }, function (response) {
                $scope.openInformationError(response);
                utilService.hidePleaseWaitModal();
            })
        }
    }

    $scope.pesquisar = function () {
        $scope.responsepesq = perfilService.pesquisar($scope.flagstatus).then(function (response) {
            $scope.responsepesq = response.data;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });
    };

    $scope.deletar = function (idItem, $uibModalInstance) {
        utilService.showPleaseWaitModal();
        perfilService.deletar(idItem).then(function (response) {
            $scope.pesquisar();
            $route.reload();
            $uibModalInstance.close();
            utilService.hidePleaseWaitModal();
            $scope.openInformationSuccess();
        }, function (response) {
            $scope.openInformationError(response);
            utilService.hidePleaseWaitModal();
        }
    )
    };

    $scope.open = function (idItem) {
        $uibModal.open({
            templateUrl: 'myModalContent.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    this.deletar(idItem, $uibModalInstance);
                    $uibModalInstance.close();
                }

                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                };
            }
        });
    };

    $scope.openInformationSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalContentSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    $uibModalInstance.close();

                    $location.path('/perfil/consultar');
                };
            }
        });
    };

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.exportarExcel = function (tablename, filename) {
        try {
            utilService.exportarExcel(tablename, filename, $scope.responsepesq);
            $scope.openExportSuccess();
        }
        catch (err) {
            var objErro = { errorMessage: "Exportação - Local: '" + $location.path() + "' - " + err.message };
            utilService.inserirLog(objErro);
            $scope.openExportError(err);
        }
    };

    $scope.openExportSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalExportSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openExportError = function (err) {
        $uibModal.open({
            templateUrl: 'myModalExportError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.excecao = err.message;
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.doTheBack = function () {
        window.history.back();
    };

}]);

