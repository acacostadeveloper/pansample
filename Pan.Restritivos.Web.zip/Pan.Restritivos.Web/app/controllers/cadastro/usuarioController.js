﻿'use strict';

app.controller('usuarioController', ['$scope', '$route', '$location', 'usuarioService', '$uibModal', '$sce', 'utilService', 'loginService', function ($scope, $route, $location, usuarioService, $uibModal, $sce, utilService, loginService) {
    //###################################################################################
    //Inicio - Gerenciamento de permissão
    //###################################################################################
    var path = $location.path();
    $scope.blnInativar = false;
    $scope.blnAlterar = false;
    $scope.blnIncluir = false;

    if (path != '/' && path != '/403') {
        var retorno = loginService.getaccesspage(path);
        if (retorno.status == false || retorno.acesso == null) {
            $location.path('/403');
            return;
        }
        else {

            if (retorno.acesso.blnConsultar == false) {
                $location.path('/403');
            }
            if (retorno.acesso.blnInativar == false) {
                $scope.blnInativar = true;
            }
            if (retorno.acesso.blnAlterar == false) {
                $scope.blnAlterar = true;
            }
            if (retorno.acesso.blnIncluir == false) {
                $scope.blnIncluir = true;
            }
        }
    }
    //###################################################################################
    //Fim - Gerenciamento de permissão
    //###################################################################################

    $scope.alert = { showalertdanger: false };
    $scope.users = [];
    $scope.perfil = { id: "", nomePerfil: "" };
    $scope.dadosusuariofiltro = {
        login: "",
        nmUsuario: "",
        dtInclusaoDe: "",
        dtInclusaoPara: "",
        flagstatus: "S"
    };


    $scope.msg = true;
    $scope.gravar = [];
    $scope.readonly = true;

    $scope.perfisfiltro = [];
    $scope.perfisselecionados = [];
    $scope.grupodepto = [];
    $scope.hdstep1 = false;
    $scope.hdstep2 = true;
    $scope.hdstep3 = true;

    $scope.doTheBack = function () {
        window.history.back();
    };

    $scope.carregar = function () {

        utilService.showPleaseWaitModal();
        usuarioService.pesquisar($scope.dadosusuariofiltro).then(function (response)
        {
            $scope.responsepesq = response.data;

            utilService.hidePleaseWaitModal();
            $scope.msg = true;
        }, function (response) {
            utilService.hidePleaseWaitModal();
            $scope.openInformationError(response);
        });


        usuarioService.ListaFuncionalidades().then(function (response) {
            $scope.responseAcessos = response.data;
            $scope.msg = true;
        }, function (response) {

            $scope.openInformationError(response);
        });

    }

    $scope.VoltarInicio = function () {
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;
    }

    $scope.AbrirNovo = function () {
        $scope.dadosusuario = null;
        $scope.statusLogin = "";
        $scope.hdstep1 = true;
        $scope.hdstep2 = false;
        $scope.hdstep3 = true;
    }


    $scope.AbrirAlterar = function (id) {
        $scope.dadosusuario = null;
        $scope.hdstep1 = true;
        $scope.hdstep2 = true;
        $scope.hdstep3 = false;

        $scope.statusLogin     = 'loginValido';
        $scope.dadosusuario    = $.grep($scope.responsepesq, function (x) { return x.idUsuario == id; })[0];
        $scope.responseAcessos = $scope.dadosusuario.Acessos;

    }

    $scope.Save = function () {

        var acesso = [{
            blnIncluir: true,
            blnAlterar: true,
            blnInativar: true,
            blnConsultar: true,
            idItemAcesso: 0
        }];

        $scope.dadosusuario.Acessos = $scope.responseAcessos;

        utilService.showPleaseWaitModal();
        
        usuarioService.Inserir($scope.dadosusuario).then(function (response) {

            utilService.hidePleaseWaitModal();
            $scope.openInformationSuccess();

        }, function (response) {
            $scope.openInformationError(response);
        });
    }

    $scope.Alterar = function () {

        $scope.dadosusuario.Acessos = $scope.responseAcessos;

        utilService.showPleaseWaitModal();

        usuarioService.Alterar($scope.dadosusuario).then(function (response) {

            utilService.hidePleaseWaitModal();
            $scope.openInformationSuccess();

        }, function (response) {
            $scope.openInformationError(response);
        });
    }

    $scope.Excluir = function (iduser) {

        utilService.showPleaseWaitModal();

        usuarioService.Inativar(iduser).then(function (response) {

            utilService.hidePleaseWaitModal();
            $scope.openInformationSuccess();

        }, function (response) {
            $scope.openInformationError(response);
        });
    }

    $scope.ChangeBool = function (status) {

        if (status == true)
            return 'Ativo';
        else
            return 'Inativo';
    }


    $scope.updateCheck = function (id, check, tipo) {
        check = event.target.checked;
        var temp = $.grep($scope.responseAcessos, function (x) { return x.idItemAcesso == id; })[0];

        var index = $scope.responseAcessos.indexOf(temp);

        switch (tipo) {
            case "INCLUIR":
                temp.blnIncluir = check;
                if (check == true)
                    temp.blnConsultar = true;
                break;
            case "ALTERAR":
                temp.blnAlterar = check;
                if (check == true)
                    temp.blnConsultar = true;
                break;
            case "INATIVAR":
                temp.blnInativar = check;
                if (check == true)
                    temp.blnConsultar = true;
                break;
            case "IMPORTAR":
                temp.blnImportar = check;
                if (check == true)
                    temp.blnConsultar = true;
                break;
            case "CONSULTAR":
                temp.blnConsultar = check;
                if (check == false) {
                    temp.blnIncluir = check;
                    temp.blnAlterar = check;
                    temp.blnInativar = check;
                    temp.blnImportar = check;
                }
                break;
        }
        $scope.responseAcessos[index] = temp;
    }

    $scope.validaLoginAD = function () {

        $scope.statusLogin = "processando";

        if ($scope.dadosusuario.login == "" || $scope.dadosusuario.login == undefined) {
            $scope.loginValido = undefined;
            $scope.loginCadastrado = undefined;
            $scope.statusLogin = undefined;
            $scope.exibirStatusLogin();
        }
        else {
            //## Verifica se o usuário existe no AD
            usuarioService.validaUsuarioExistenteAD($scope.dadosusuario.login).then(function (response) {
                $scope.loginValido = response.data;

                //## Se o usuário estiver válido, Verifica se o usuário já possui cadastro
                if ($scope.loginValido == true) {
                    $scope.dadosusuariofiltro.login = $scope.dadosusuario.login;
                    $scope.dadosusuariofiltro.flagstatus = undefined;
                    usuarioService.pesquisar($scope.dadosusuariofiltro).then(function (response) {
                        if (response.data.length > 0) {
                            $scope.loginValido = undefined;
                            $scope.loginCadastrado = true;
                        } else {
                            $scope.loginCadastrado = undefined;
                        }
                        $scope.exibirStatusLogin();
                    });
                } else {
                    $scope.exibirStatusLogin();
                }
            }, function (response) {
                $scope.openInformationError(response);
            });
        }

    };

    $scope.exibirStatusLogin = function () {
        if ($scope.loginValido == true) {
            $scope.statusLogin = "loginValido";
            $scope.step1.$invalid = false;
        }
        else if ($scope.loginValido == false) {
            $scope.statusLogin = "loginInvalido";
            $scope.step1.$invalid = true;
        }
        else if ($scope.loginCadastrado == true) {
            $scope.statusLogin = "loginCadastrado";
            $scope.step1.$invalid = true;
        }
    };

    $scope.verificaClassError = function () {
        if ($scope.statusLogin == "loginValido") {
            return "";
        }
        else {
            return "ng-invalid";
        }
    };

    $scope.salvarusuario = function () {
        $scope.dadosusuario.perfis = $scope.perfisselecionados;
        $scope.dadosusuario.departamentos = $scope.deptoselecionados;
        if ($scope.iduser != null && $scope.iduser != "") {
            utilService.showPleaseWaitModal();
            usuarioService.editarusuario($scope.dadosusuario).then(function () {
                $scope.openInformationSuccess();
                utilService.hidePleaseWaitModal();
            }, function (response) {
                $scope.openInformationError(response);
                utilService.hidePleaseWaitModal();
            })
        }
        else {
            utilService.showPleaseWaitModal();
            usuarioService.addusuario($scope.dadosusuario).then(function () {
                $scope.openInformationSuccess();
                utilService.hidePleaseWaitModal();
            }, function (response) {
                $scope.openInformationError(response);
                utilService.hidePleaseWaitModal();
            })
        }
    }

    $scope.deletar = function (idItem, $uibModalInstance) {
        utilService.showPleaseWaitModal();
        usuarioService.deletar(idItem).then(function () {
            $uibModalInstance.close();
            $scope.openInformationSuccess();
            utilService.hidePleaseWaitModal();
        }, function (response) {
            $scope.openInformationError(response);
            utilService.hidePleaseWaitModal();
        });
    };

    $scope.open = function (idItem) {
        $uibModal.open({
            templateUrl: 'myModalContent.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    this.deletar(idItem, $uibModalInstance);
                };

                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                };
            }
        });
    };

    $scope.openInformationSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalContentSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.ok = function () {
                    $uibModalInstance.close();
                    if ($route.current.originalPath == "/usuario/novo" || $route.current.originalPath == "/usuario/editar/:iduser") {
                        $location.path('/usuario/consultar');
                    }
                    else {
                        $route.reload();
                    }
                };
            }
        });
    };

    $scope.openInformationError = function (response) {
        $uibModal.open({
            templateUrl: 'myModalContentError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {

                $scope.errors = [];
                for (var key in response.data.errors) {
                    $scope.errors.push(response.data.errors[key]);
                }

                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.exportarExcel = function (tablename, filename) {
        try {
            utilService.exportarExcel(tablename, filename, $scope.responsepesq);
            $scope.openExportSuccess();
        }
        catch (err) {
            var objErro = { errorMessage: "Exportação - Local: '" + $location.path() + "' - " + err.message };
            utilService.inserirLog(objErro);
            $scope.openExportError(err);
        }
    };

    $scope.openExportSuccess = function () {
        $uibModal.open({
            templateUrl: 'myModalExportSuccess.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.openExportError = function (err) {
        $uibModal.open({
            templateUrl: 'myModalExportError.html',
            backdrop: true,
            windowClass: 'modal',
            controller: function ($scope, $uibModalInstance) {
                $scope.excecao = err.message;
                $scope.ok = function () {
                    $uibModalInstance.close();
                };
            }
        });
    };

    $scope.formatadata = function (id) {
        var data = document.getElementById(id).value;
        var keycode = event.keyCode;

        if (keycode != 8) {

            if (data.length == 2) {
                data = data + '/';
                document.getElementById(id).value = data;

            };
            if (data.length == 5) {
                data = data + '/';
                document.getElementById(id).value = data;
            };
        }

    };

    $scope.gerarData = function (str) {
        var partes = str.split("/");
        return new Date(partes[2], partes[1] - 1, partes[0]);
    }

    $scope.validata = function () {

        var inicio = $scope.gerarData(document.getElementById('dtinicio').value);
        var fim = $scope.gerarData(document.getElementById('dtfim').value);

        if (inicio > fim) {
            document.getElementById('dtinicio').value = "";
            document.getElementById('dtfim').value = "";
            return false
        }
        else { return true };

    }



    //Inicio datepicker

    $scope.today = function () {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
        return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
    };

    $scope.toggleMin = function () {
        $scope.minDate = "01/01/1990";
    };
    $scope.toggleMin();
    $scope.maxDate = new Date(2020, 5, 22);

    $scope.opendate = function ($event) {
        $scope.status.opened = true;
    };

    $scope.opendtInicio = function ($event) {
        $scope.statusDtInicio.opened = true;
    };

    $scope.opendtFinal = function ($event) {
        $scope.statusDtFinal.opened = true;
    };

    $scope.openPrazo = function ($event) {
        $scope.statusPrazo.opened = true;
    };

    $scope.openValidade = function ($event) {
        $scope.statusValidade.opened = true;
    };

    $scope.setDate = function (year, month, day) {
        $scope.dt = new Date(year, month, day);
    };


    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd/MM/yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.status = {
        opened: false
    };

    $scope.statusDtInicio = {
        opened: false
    };

    $scope.statusDtFinal = {
        opened: false
    };

    $scope.statusValidade = {
        opened: false
    };

    $scope.statusPrazo = {
        opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 2);
    $scope.events =
      [
        {
            date: tomorrow,
            status: 'full'
        },
        {
            date: afterTomorrow,
            status: 'partially'
        }
      ];

    $scope.getDayClass = function (date, mode) {
        if (mode === 'day') {
            var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

            for (var i = 0; i < $scope.events.length; i++) {
                var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                if (dayToCheck === currentDay) {
                    return $scope.events[i].status;
                }
            }
        }

        return '';
    };
    //fim datepicker



}]);