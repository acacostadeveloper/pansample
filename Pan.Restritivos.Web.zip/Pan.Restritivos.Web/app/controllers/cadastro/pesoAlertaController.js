﻿'use strict';

app.controller('pesoAlertaController', [
    '$scope',
    '$route',
    '$location',
    'pesoAlertaService',
    '$uibModal',
    '$sce',
    'utilService',
    'loginService',
    function (
        $scope,
        $route,
        $location,
        pesoAlertaService,
        $uibModal,
        $sce,
        utilService,
        loginService) {
        //###################################################################################
        //Inicio - Gerenciamento de permissão
        //###################################################################################
        var path = $location.path();
        $scope.blnInativar = false;
        $scope.blnAlterar = false;
        $scope.blnIncluir = false;

        if (path != '/' && path != '/403') {
            var retorno = loginService.getaccesspage(path);
            if (retorno.status == false || retorno.acesso == null) {
                $location.path('/403');
                return;
            }
            else {

                if (retorno.acesso.blnConsultar == false) {
                    $location.path('/403');
                }
                if (retorno.acesso.blnInativar == false) {
                    $scope.blnInativar = true;
                }
                if (retorno.acesso.blnAlterar == false) {
                    $scope.blnAlterar = true;
                }
                if (retorno.acesso.blnIncluir == false) {
                    $scope.blnIncluir = true;
                }
            }
        }
        //###################################################################################
        //Fim - Gerenciamento de permissão
        //###################################################################################

        $scope.alert = { showalertdanger: false };
        $scope.msg = true;
       
        $scope.hdstep1 = false;
        $scope.hdstep2 = true;
        $scope.hdstep3 = true;

        $scope.erroArquivo = "";

        $scope.filtro = { codPeso: "", txPeso: "" };

        $scope.doTheBack = function () {
            window.history.back();
        };

        $scope.carregar = function () {

            utilService.showPleaseWaitModal();
            pesoAlertaService.pesquisar($scope.filtro).then(function (response) {
                $scope.responsepesq = response.data;
                utilService.hidePleaseWaitModal();
                $scope.msg = true;
            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });

        }

        $scope.VoltarInicio = function () {
            $scope.hdstep1 = false;
            $scope.hdstep2 = true;
            $scope.hdstep3 = true;
        }

        $scope.AbrirNovo = function () {
            $scope.dados = null;
            $scope.statusLogin = "";
            $scope.hdstep1 = true;
            $scope.hdstep2 = false;
            $scope.hdstep3 = true;
        }


        $scope.AbrirAlterar = function (id) {
            $scope.dados = null;
            $scope.hdstep1 = true;
            $scope.hdstep2 = true;
            $scope.hdstep3 = false;

            $scope.statusLogin = 'loginValido';
            $scope.dados = $.grep($scope.responsepesq, function (x) { return x.idPeso == id; })[0];
            if ($scope.dados.blnAtivo == true) {
                $scope.dados.blnAtivo = '1'
            } else {
                $scope.dados.blnAtivo = '0'
            };
            $scope.responseAcessos = $scope.dados.Acessos;

        }

        $scope.Save = function () {

            utilService.showPleaseWaitModal();
            pesoAlertaService.Inserir($scope.dados).then(function (response) {
                $scope.mensagem = 'Registro incluído com sucesso.'
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);

            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        }

        $scope.Alterar = function () {
           
            utilService.showPleaseWaitModal();
            if ($scope.dados.blnAtivo == '1') {
                $scope.dados.blnAtivo = true
            } else {
                $scope.dados.blnAtivo = false
            };
            pesoAlertaService.Alterar($scope.dados).then(function (response) {
                utilService.hidePleaseWaitModal();
                $scope.mensagem = 'Registro alterado com sucesso.'
                $scope.openInformationSuccess($scope.mensagem);

            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        }

        $scope.Excluir = function (idpeso) {

            utilService.showPleaseWaitModal();
            var peso = { idPeso: idpeso };

            pesoAlertaService.Inativar(peso).then(function (response) {
                if (response.data == true) {
                    $scope.mensagem = 'Registro excluído com sucesso.'
                } 
                utilService.hidePleaseWaitModal();
                $scope.openInformationSuccess($scope.mensagem);

            }, function (response) {
                utilService.hidePleaseWaitModal();
                $scope.openInformationError(response);
            });
        }

        $scope.ChangeBool = function (status) {

            if (status == true)
                return 'Ativo';
            else
                return 'Inativo';
        }

        //-------------------------------------------
        $scope.insert = function () {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja incluir as informações?';
                    $scope.ok = function () {
                        $scope.Save();
                        $uibModalInstance.close();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não incluído.';
                        this.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };

        $scope.delete = function (idPeso) {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja excluir as informações? ';
                    $scope.ok = function () {
                        this.Excluir(idPeso);
                        $uibModalInstance.close();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não excluído.';
                        this.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };


        $scope.alter = function () {
            $uibModal.open({
                templateUrl: 'myModalQuestion.html',
                backdrop: true,
                windowClass: 'modal',
                scope: $scope,
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = 'Deseja alterar as informações?';
                    $scope.ok = function () {
                        $scope.Alterar();
                        $uibModalInstance.close();
                    };
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                        $scope.mensagem = 'Registro não alterado.';
                        this.openInformationSuccess($scope.mensagem);
                        $uibModalInstance.close();
                    };
                }
            })
        };
        //-------------------------------------------






        $scope.open = function (idItem) {
            $uibModal.open({
                templateUrl: 'myModalContent.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {
                    $scope.ok = function () {
                        this.deletar(idItem, $uibModalInstance);
                    };

                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                    };
                }
            });
        };

        $scope.openInformationSuccess = function (mensagem) {
            $uibModal.open({
                templateUrl: 'myModalContentSuccess.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {
                    $scope.mensagem = mensagem;
                    $scope.ok = function () {
                        $uibModalInstance.close();
                        if ($route.current.originalPath == "/usuario/novo" || $route.current.originalPath == "/usuario/editar/:iduser") {
                            $location.path('/usuario/consultar');
                        }
                        else {
                            $route.reload();
                        }
                    };
                }
            });
        };

        $scope.openInformationError = function (response) {
            $uibModal.open({
                templateUrl: 'myModalContentError.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {

                    $scope.errors = [];
                    for (var key in response.data.errors) {
                        $scope.errors.push(response.data.errors[key]);
                    }

                    $scope.ok = function () {
                        $uibModalInstance.close();
                        $route.reload();
                    };
                }
            });
        };

        $scope.exportarExcel = function (tablename, filename) {
            try {
                utilService.exportarExcel(tablename, filename, $scope.responsepesq);
                $scope.openExportSuccess();
            }
            catch (err) {
                var objErro = { errorMessage: "Exportação - Local: '" + $location.path() + "' - " + err.message };
                utilService.inserirLog(objErro);
                $scope.openExportError(err);
            }
        };

        $scope.openExportSuccess = function () {
            $uibModal.open({
                templateUrl: 'myModalExportSuccess.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {
                    $scope.ok = function () {
                        $uibModalInstance.close();
                    };
                }
            });
        };

        $scope.openExportError = function (err) {
            $uibModal.open({
                templateUrl: 'myModalExportError.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $uibModalInstance) {
                    $scope.excecao = err.message;
                    $scope.ok = function () {
                        $uibModalInstance.close();
                    };
                }
            });
        };

        $scope.formatadata = function (id) {
            var data = document.getElementById(id).value;
            var keycode = event.keyCode;

            if (keycode != 8) {
                //if (!((data >= "0") && (data <= "9"))) {
                //    document.getElementById(id).value = null;
                //}

                if (data.length == 2) {
                    data = data + '/';
                    document.getElementById(id).value = data;

                };
                if (data.length == 5) {
                    data = data + '/';
                    document.getElementById(id).value = data;
                };
            }

        };

        $scope.gerarData = function (str) {
            var partes = str.split("/");
            return new Date(partes[2], partes[1] - 1, partes[0]);
        }

        $scope.validata = function () {

            var inicio = $scope.gerarData(document.getElementById('dtinicio').value);
            var fim = $scope.gerarData(document.getElementById('dtfim').value);

            if (inicio > fim) {
                document.getElementById('dtinicio').value = "";
                document.getElementById('dtfim').value = "";
                return false
            }
            else { return true };

        }



        //Inicio datepicker

        $scope.today = function () {
            $scope.dt = new Date();
        };
        $scope.today();

        $scope.clear = function () {
            $scope.dt = null;
        };

        // Disable weekend selection
        $scope.disabled = function (date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.toggleMin = function () {
            $scope.minDate = "01/01/1990";
        };
        $scope.toggleMin();
        $scope.maxDate = new Date(2020, 5, 22);

        $scope.opendate = function ($event) {
            $scope.status.opened = true;
        };

        $scope.opendtInicio = function ($event) {
            $scope.statusDtInicio.opened = true;
        };

        $scope.opendtFinal = function ($event) {
            $scope.statusDtFinal.opened = true;
        };

        $scope.openPrazo = function ($event) {
            $scope.statusPrazo.opened = true;
        };

        $scope.openValidade = function ($event) {
            $scope.statusValidade.opened = true;
        };

        $scope.setDate = function (year, month, day) {
            $scope.dt = new Date(year, month, day);
        };


        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1
        };

        $scope.formats = ['dd/MM/yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];

        $scope.status = {
            opened: false
        };

        $scope.statusDtInicio = {
            opened: false
        };

        $scope.statusDtFinal = {
            opened: false
        };

        $scope.statusValidade = {
            opened: false
        };

        $scope.statusPrazo = {
            opened: false
        };

        var tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        var afterTomorrow = new Date();
        afterTomorrow.setDate(tomorrow.getDate() + 2);
        $scope.events =
          [
            {
                date: tomorrow,
                status: 'full'
            },
            {
                date: afterTomorrow,
                status: 'partially'
            }
          ];

        $scope.getDayClass = function (date, mode) {
            if (mode === 'day') {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                for (var i = 0; i < $scope.events.length; i++) {
                    var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                    if (dayToCheck === currentDay) {
                        return $scope.events[i].status;
                    }
                }
            }

            return '';
        };
        //fim datepicker



    }]);