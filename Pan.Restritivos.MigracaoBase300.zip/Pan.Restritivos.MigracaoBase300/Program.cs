﻿using Pan.Restritivos.Business.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.MigracaoBase300
{
    class Program
    {
        static void Main(string[] args)
        {
            BllMigracao300 _bll = new BllMigracao300();

            try
            {
                _bll.Processar();
            }
            catch (Exception ex)
            {
                BllMigracao300.SalvarErro(ex);
            }
        }
    }
}
