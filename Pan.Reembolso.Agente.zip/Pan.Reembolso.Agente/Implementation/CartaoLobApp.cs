﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Agente.Interface;

namespace Pan.Reembolso.Agente.Implementation
{
    public class CartaoLobApp : ICartaoLobApp
    {

        public void ObterContrato(Pan.Reembolso.Entidades.Contrato contrato) 
        {
            // not implemented 
        }
    }
}
