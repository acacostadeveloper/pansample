﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries
{
    internal static class FuncaoVeiculosSql
    {
        internal readonly static string clienteEndereco = "";
        internal readonly static string clienteDadosBancarios = "";
    }
}
