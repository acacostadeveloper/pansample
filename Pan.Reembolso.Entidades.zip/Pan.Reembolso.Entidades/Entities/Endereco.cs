﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Endereco
    {
        [DataMember]
        public string nomeLogradouro { get; set; }
        [DataMember]
        public string numero { get; set; }
        [DataMember]
        public string complemento { get; set; }
        [DataMember]
        public string cep { get; set; }
        [DataMember]
        public string bairro { get; set; }
        [DataMember]
        public string cidade { get; set; }
        [DataMember]
        public string estado { get; set; }

    }
}
