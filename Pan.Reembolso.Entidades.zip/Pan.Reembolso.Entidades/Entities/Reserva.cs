﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Reserva : Conta
    {
        [DataMember]
        public string cnpjSacado { get; set; }
        [DataMember]
        public string nomeSacado { get; set; }
        [DataMember]
        public string tipoPessoaSacado { get; set; }
    }
}
