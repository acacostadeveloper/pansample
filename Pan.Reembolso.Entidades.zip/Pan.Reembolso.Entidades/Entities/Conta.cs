﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public abstract class Conta
    {
        [DataMember]
        public string numeroBanco { get; set; }
        [DataMember]
        public string numeroAgencia { get; set; }
        [DataMember]
        public string digitoAgencia { get; set; }
        [DataMember]
        public string numeroConta { get; set; }
        [DataMember]
        public string digitoConta { get; set; }
        [DataMember]
        public string tipoConta { get; set; }
    }
}
