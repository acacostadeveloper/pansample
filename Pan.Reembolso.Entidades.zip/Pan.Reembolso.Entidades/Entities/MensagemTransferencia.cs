﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MensagemTransferencia : MensagemTransferenciaPadrao
    {
        [DataMember]
        public Reserva contaReserva { get; set; }
        [DataMember]
        public ContaCredito contaCredito { get; set; }
        [DataMember]
        public string numeroRequisicao { get; set; }
        [DataMember]
        public DateTime dataRegistro { get; set; }
        [DataMember]
        public DateTime? dataLiquidacao { get; set; }
        [DataMember]
        public string statusMensagem { get; set; }

        public MensagemTransferencia() 
        {
            contaReserva = new Reserva();
            contaCredito = new ContaCredito();
        }
    }
}
