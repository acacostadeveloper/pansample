﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[DEPARTAMENTO]")]
    [Serializable]
    public class DepartamentoDatabase
    {
        [Key]
        public int idDepartamento {get; set;}
        public string codigoDepartamento {get; set;}
        public string descricaoDepartamento {get; set;}
        public DateTime dataInclusao {get; set;}
        public DateTime? dataAlteracao {get; set;}
        public string indicadorAtivo {get; set;}
    }
}
