﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[PAGAMENTO]")]
    [Serializable]
    public class PagamentoDatabase
    {
        [Key]
        public int idPagamento {get; set;}
        public int idColigada {get; set;}
        public int idProcessoOrigem {get; set;}
        public DateTime dataRegistro {get; set;}
        public DateTime dataPagamento {get; set;}
        public string tipoPagamento {get; set;}
        public decimal valorPagamento {get; set;}
    }
}
