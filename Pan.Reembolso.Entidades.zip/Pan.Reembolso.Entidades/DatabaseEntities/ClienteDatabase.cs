﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CLIENTE]")]
    [Serializable]
    public class ClienteDatabase
    {
        [Key]
        public int idCliente {get; set;}
        public string nomeCliente {get; set;}
        public string tipoPessoa {get; set;}
        public string cpfCnpj {get; set;}
        public string dddCelular {get; set;}
        public string numeroCelular {get; set;}
        public string dddFixo {get; set;}
        public string numeroFixo {get; set;}
    }
}
