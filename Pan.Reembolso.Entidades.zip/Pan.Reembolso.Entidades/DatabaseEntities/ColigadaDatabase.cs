﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[COLIGADA]")]
    [Serializable]
    public class ColigadaDatabase
    {
        [Key]
        public int idColigada {get; set;}
        public string codigoColigada {get; set;}
        public string nomeColigada {get; set;}
        public string cnpjColigada {get; set;}
        public DateTime dataInclusao {get; set;}
        public DateTime? dataAlteracao {get; set;}
        public string indicadorAtivo {get; set;}
    }
}
