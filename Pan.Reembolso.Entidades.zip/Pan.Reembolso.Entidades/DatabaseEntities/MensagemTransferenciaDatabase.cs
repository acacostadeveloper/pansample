﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[MENSAGEM_TRANSFERENCIA]")]
    [Serializable]
    public class MensagemTransferenciaDatabase
    {
        [Key]
        public int idMensagem { get; set; }
        public int idMensagemPadrao { get; set; }
        public int idContaReserva { get; set; }
        public int idContaCredito { get; set; }
        public string numeroRequisicao { get; set; }
        public DateTime dataRegistro { get; set; }
        public DateTime? dataLiquidacao { get; set; }
        public string statusMensagem { get; set; }
    }
}
