﻿using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    internal class ReembolsoHelper
    {
        bool isValidated = true;

        internal bool ValidarReembolso(Entidades.Reembolso value)
        {
            // todo: Tratar status individualmente para cada validação 
            ReembolsoTypes.StatusReembolsoType status;

            status = ValidarDadosCliente(value.contrato.cliente);
            status = ValidarContrato(value.contrato);

            return isValidated;
        }

        private ReembolsoTypes.StatusReembolsoType ValidarDadosCliente(Entidades.Cliente value) 
        {
            // Todo: Verificar reagras impeditivas (conta insuficiente ou fraudada)


            isValidated = false;

            return ReembolsoTypes.StatusReembolsoType.RejeitadoClienteInexistente;
        }

        private ReembolsoTypes.StatusReembolsoType ValidarContrato(Entidades.Contrato value)
        {
            // Todo: Verificar regras impeditivas (registro de óbito)

            isValidated = false;

            return ReembolsoTypes.StatusReembolsoType.RejeitadoContratoInexistente;
        }

    }
}
