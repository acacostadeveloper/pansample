﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Domain.Fornecedor.Endereco.Municipio
{
    public class Municipio
    {
        public string CodigoMunicipio { get; set; }
        public string UFMunicipio { get; set; }
        public string NomeMunicipio { get; set; }
    }
}
