﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Domain.Fornecedor.Endereco
{
    public class Endereco
    {
        public  string Logradouro { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Uf { get; set; }
        public string Cep { get; set; }
        public string TipoEndereco { get; set; }
        public string Telefone { get; set; }
        public string Ramal { get; set; }
        public string Fax { get; set; }
        public string Contato { get; set; }
        public Municipio.Municipio Municipio { get; set; }

    }
}
