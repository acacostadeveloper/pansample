﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Domain.Fornecedor
{
    public class Fornecedor
    {
        public Endereco.Endereco Endereco{ get; set; }
        public ContaBancaria.ContaBancaria ContaBancaria { get; set; }
        public Favorecido.Favorecido Favorecido { get; set; }
        public string  CpfCnpj { get; set; }
        public long Codigo { get; set; }
        public string Nome { get; set; }
        public string NomeCompleto { get; set; }
        public string RazaoSocial { get; set; }
        public string Email { get; set; }
        public string TipoPessoa { get; set; }
        public bool Isento { get; set; }
        public bool Mensalista { get; set; }
        public bool SubEstabelecido { get; set; }
        public bool Bloqueado { get; set; }
        public bool PermiteDocFiscal { get; set; }
        public bool FatMultipla { get; set; }
        public bool NaoValidaValorCodBarra { get; set; }
    }
}
