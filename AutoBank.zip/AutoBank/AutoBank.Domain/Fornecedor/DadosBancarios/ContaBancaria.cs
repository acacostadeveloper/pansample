﻿using AutoBank.Domain.Fornecedor.Favorecido;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Domain.Fornecedor.ContaBancaria
{
    public class ContaBancaria
    {
        public string CpfCnpj { get; set; }
        public int Sequencia { get; set; }
        public string Nome { get; set; }
        public int Banco { get; set; }
        public string Agencia { get; set; }
        public string Conta { get; set; }
        public int QtdDV { get; set; }
        public string TipoConta { get; set; }
        public string Ispb { get; set; }
    }
}
