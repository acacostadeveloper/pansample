﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Domain.Fornecedor.Favorecido
{
    public class Favorecido
    {
        public string TipoPessoa { get; set; }
        public string Nome { get; set; }
        public string CpfCnpj { get; set; }
        public int Sequencia { get; set; }
        public string Pagamento { get; set; }
    }
}
