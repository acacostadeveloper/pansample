﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoBank.Application.Repositories;
using AutoBank.Domain.Fornecedor;
using AutoBank.Domain.Fornecedor.ContaBancaria;
using AutoBank.Domain.Fornecedor.Endereco;
using AutoBank.Domain.Fornecedor.Favorecido;

namespace AutoBank.Application.Commands.CadastrarFornecedor
{
    class CadastrarFornecedorUseCase : ICadastrarFornecedorUseCase
    {
        private readonly IFornecedorWriteOnlyRepository _fornecedorWriteOnlyRepository;

        public CadastrarFornecedorUseCase(IFornecedorWriteOnlyRepository fornecedorWriteOnlyRepository)
        {
            this._fornecedorWriteOnlyRepository = fornecedorWriteOnlyRepository;
        }


        public async Task<long> Execute(Fornecedor fornecedor, ContaBancaria contaBancaria, Endereco endereco, Favorecido favorecido)
        {
            await _fornecedorWriteOnlyRepository.Add(fornecedor, contaBancaria, endereco, favorecido);

            // TODO Verificar Retoneo WService
            return 0;
        }
    }
}
