﻿using AutoBank.Domain.ContaBancaria;
using AutoBank.Domain.Fornecedor;
using AutoBank.Domain.Fornecedor.ContaBancaria;
using AutoBank.Domain.Fornecedor.Endereco;
using AutoBank.Domain.Fornecedor.Favorecido;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Application.Commands.CadastrarFornecedor
{
    interface ICadastrarFornecedorUseCase
    {
        Task<long> Execute(Fornecedor fornecedor, ContaBancaria contaBancaria, Endereco endereco, Favorecido favorecido);
    }

}
