﻿using AutoBank.Domain.Fornecedor;
using AutoBank.Domain.Fornecedor.ContaBancaria;
using AutoBank.Domain.Fornecedor.Endereco;
using AutoBank.Domain.Fornecedor.Favorecido;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Application.Repositories
{
    public interface IFornecedorWriteOnlyRepository
    {
        Task Add(Fornecedor fornecedor, ContaBancaria contaBancaria, Endereco endereco, Favorecido favorecido);
    }
}
