﻿using AutoBank.Domain.Fornecedor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Application.Results
{
    public sealed class FornecedorResult
    {
        List<Fornecedor> Fornecedores { get; }

        public FornecedorResult(List<Fornecedor> fornecedores)
        {
            this.Fornecedores = fornecedores;
        }
    }
}
