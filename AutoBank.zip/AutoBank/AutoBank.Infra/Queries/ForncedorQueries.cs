﻿using AutoBank.Application.Queries;
using AutoBank.Application.Results;
using AutoBank.Infra.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Infra.Queries
{
    public class ForncedorQueries : IForncedorQueries
    {

        private readonly string _pathToExcelFile;

        public ForncedorQueries(string pathToExcelFile)
        {
            _pathToExcelFile = pathToExcelFile;
        }

        public Task<FornecedorResult> GetFornecedor()
        {
            var query1 = from a in ConxObject.UrlConnexion.Worksheet<CadastroOrigem>()
                         select a;


            foreach (var result in query1)
            {
                //string products = "ProductId : {0}, ProductName: {1}";
                //Console.WriteLine(string.Format(products, result.ProductId, result.ProductName));
            }

            // TODO Mapper

            return new List<Fornecedor>();
        }
    }
}
