﻿using AutoBank.Application.Repositories;
using AutoBank.Domain.Fornecedor;
using AutoBank.Infra.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Infra.Repository
{
    public class FornecedorExcelRepository : IFornecedorReadOnlyRepository
    {
        public async Task<List<Fornecedor>> Get()
        {
            // Parametrizar PATH
            string pathToExcelFile = @"C:\Temp\Origem\Cadastro_origem.xlsx";

            ConnexionExcel ConxObject = new ConnexionExcel(pathToExcelFile);
            //Query a worksheet with a header row  

            var query1 = from a in ConxObject.UrlConnexion.Worksheet<CadastroOrigem>()
                         select a;


            foreach (var result in query1)
            {
                //string products = "ProductId : {0}, ProductName: {1}";
                //Console.WriteLine(string.Format(products, result.ProductId, result.ProductName));
            }

            // TODO Mapper

            return new List<Fornecedor>();
        }
    }
}
