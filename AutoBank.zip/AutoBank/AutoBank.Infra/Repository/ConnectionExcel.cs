﻿using LinqToExcel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Infra.Repository
{
    public class ConnexionExcel
    {
        public string _pathExcel;
        public ExcelQueryFactory _urlConnexion;
        public ConnexionExcel(string path)
        {
            this._pathExcel = path;
            this._urlConnexion = new ExcelQueryFactory(_pathExcel);
        }
        public string PathExcelFile
        {
            get
            {
                return _pathExcel;
            }
        }
        public ExcelQueryFactory UrlConnexion
        {
            get
            {
                return _urlConnexion;
            }
        }
    }
}
