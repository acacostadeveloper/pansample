﻿using AutoBank.Application.Repositories;
using AutoBank.Domain.Fornecedor;
using AutoBank.Domain.Fornecedor.ContaBancaria;
using AutoBank.Domain.Fornecedor.Endereco;
using AutoBank.Domain.Fornecedor.Favorecido;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Infra.Repository
{
    public class AutoBankServiceRepository : IFornecedorWriteOnlyRepository
    {
        public async Task Add(Fornecedor fornecedor, ContaBancaria contaBancaria, Endereco endereco, Favorecido favorecido)
        {
            // TODO Chamar servico de Inclusao Fornecedor
            return;
        }

    }
}
