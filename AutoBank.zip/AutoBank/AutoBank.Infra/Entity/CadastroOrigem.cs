﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoBank.Infra.Entity
{
    public class CadastroOrigem
    {
        public string ID { get; set; }
        public string Status_Origem { get; set; }
        public string ID_Origem { get; set; }
        public string Ds_Legado { get; set; }
        public string TipoRelacionamento { get; set; }
        public string Sub_Relacionamento { get; set; }
        public string TipoTerceiro { get; set; }
        public string CNPJ_Raiz { get; set; }
        public string CNPJ_CPF { get; set; }
        public string Nome { get; set; }
        public string ApelidoLoja { get; set; }
        public string Dt_CadUnidade { get; set; }
        public string Dt_Inativ_Unidade { get; set; }
        public string Dt_UltProducao { get; set; }
        public string QtdeProducao { get; set; }
        public string Motivo_Bloqueio { get; set; }
        public string Notificacao { get; set; }
        public string Dt_Notificacao { get; set; }
        public string NrCNPJ_Master { get; set; }
        public string Ds_StatusCNPJ_Master { get; set; }
        public string Logradouro { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public string Municipio { get; set; }
        public string UF { get; set; }
        public string CEP { get; set; }
        public string Email { get; set; }
        public string DDD { get; set; }
        public string Telefone { get; set; }
        public string EndOrigem { get; set; }
        public string Logradouro_Atend { get; set; }
        public string Complemento_Atend { get; set; }
        public string Bairro_Atend { get; set; }
        public string Municipio_Atend { get; set; }
        public string UF_Atend { get; set; }
        public string CEP_Atend { get; set; }
        public string CRK { get; set; }
        public string ContaAutBank { get; set; }
        public string ContaGarantida { get; set; }
        public string Avalista { get; set; }
        public string Leves { get; set; }
        public string Pesados { get; set; }
        public string Motos { get; set; }
        public string PossuiConsignado { get; set; }
        public string PossuiConsig_Card { get; set; }
        public string PossuiVeiculo { get; set; }
        public string PossuiImovel { get; set; }
        public string PossuiConsorcio { get; set; }
        public string Unicad { get; set; }
        public string GerenteComercial { get; set; }
        public string GerenteRegional { get; set; }
        public string SuperintendenteExecutivo { get; set; }
    }
}
