﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model
{
    /// <summary>
    /// Classe para exeções customizadas
    /// </summary>
    [DataContract]
    public class ServiceFault
    {
        private string _message;
        private IDictionary _Data;

        public ServiceFault(Exception ex)
        {
            _message = ex.Message;
            _Data = ex.Data;
        }

        [DataMember]
        public string Message { get { return _message; } set { _message = value; } }
        [DataMember]
        public IDictionary Data { get { return _Data; } set { _Data = value; } }
    }
}
