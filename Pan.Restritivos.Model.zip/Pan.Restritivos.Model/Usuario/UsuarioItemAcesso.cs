﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Restritivos.Model.User
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbUsuarioItemAcesso")]
    public class UsuarioItemAcesso
    {
        [Key]
        public int idUsuarioItemAcesso { get; set; }

        [Required]
        public int idUsuario { get; set; }

        [Required]
        public int idItemAcesso { get; set; }

        [Required]
        public bool blnIncluir { get; set; }

        [Required]
        public bool blnAlterar { get; set; }

        [Required]
        public bool blnInativar { get; set; }

        [Required]
        public bool blnConsultar { get; set; }

        [Required]
        public bool blnImportar { get; set; }

        public Usuario Usuarios { get; set; }

        public ItemAcesso ItemAcessos { get; set; }
    }
}
