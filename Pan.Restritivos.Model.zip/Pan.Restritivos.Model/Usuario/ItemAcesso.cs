﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.User
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbItemAcesso")]
    public class ItemAcesso
    {
        [Key]
        public int idItemAcesso { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string txItemAcesso {get; set;}
        
        [Required]
        [MaxLength(50)]
        public string txLink {get; set;}

    }
}
