﻿using Pan.Restritivos.Model.Configuracao;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.User
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbUsuario")]
    [Serializable]
    public class Usuario
    {
        [Key]
        public int      idUsuario { get; set; }

        [Required]
        public string   login { get; set; }

        [Required]
        public string   nmUsuario { get; set; }

        [Required]
        public int      idUsuarioInclusao { get; set; }
        [Required]
        public DateTime DtUsuarioInclusao { get; set; }

        public int? idUsuarioManutencao { get; set; }
        public DateTime? DtUsuarioManutencao { get; set; }

        [Required]
        public bool     blnAtivo { get; set; }

        [NotMapped]
        public List<UsuarioItemAcesso> UsuarioItemAcesso { get; set; }

        [NotMapped]
        public List<Acessos> Acessos { get; set; }
        

        [NotMapped]
        public string  nmUsuarioManutencao { get; set; }

    }
}
