﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Restritivos.Model.User
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbSessaousuario")]
    public class Sessaousuario
    {
        [Key]
        public int Id { get; set; }

       [Required]
        public int idSession { get; set; }

        [Required]
        public string login { get; set; }

        [Required]
        [MaxLength]
        public string token { get; set; }

        [Required]
        public DateTime dtultimarequisicao { get; set; }
    }
}
