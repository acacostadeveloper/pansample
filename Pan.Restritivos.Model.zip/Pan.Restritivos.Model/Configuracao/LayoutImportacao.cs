﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.Configuracao
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary>    
    [Table("tbLayoutImportacao")]
    public class LayoutImportacao
    {
        [Key]
        public int idLayoutImportacao { get; set; }

        [MaxLength(20)]
        public string tipoArquivo { get; set; }
        [MaxLength(50)]
        public string coluna { get; set; }
        public int ordem { get; set; }
        public bool obrigatorio { get; set; }

    }
}
