﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.Configuracao
{
    /// <summary>
    /// Entidade utilizada para expor exeções custoimizadas
    /// Pública á todas as camadas
    /// </summary>
    public class customException : Exception
    {
        public string msg { get; set; }

        public customException() { }

        public customException(string msg) 
        {
            this.msg = msg;
        }
    }
}
