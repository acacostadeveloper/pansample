﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.Configuracao
{
    public class Migracao300
    {
        //public string nrCpf { get; set; }
        //public string motivo { get; set; }
        //public string peso { get; set; }


        public string SC_CPF_CLIENTE { get; set; }

        public string SC_DESC_ANTPEN_ALERTA { get; set; }

        public string SC_DESC_ULT_ALERTA { get; set; }

    }
}
