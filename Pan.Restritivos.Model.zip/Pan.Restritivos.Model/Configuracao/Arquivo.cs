﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.Configuracao
{
    /// <summary>
    /// Entidade utilizada para importação de planilha xlsx
    /// Pública á todas as camadas
    /// </summary>
    public class Arquivo
    {
        public string arq { get; set; }
        public string tipoBase { get; set; }
        public int idUsuarioManutencao { get; set; }
        public string NomeUsuario { get; set; }
    }
}
