﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Model.Configuracao
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary>
    [Serializable]
    public class Acessos 
    {
        private List<Acessos> lista;

        public Acessos() 
        {
            lista = new List<Acessos>();
        }
        public void Add(Acessos d)
        {
            lista.Add(d);
        }

        public void AddRange(IEnumerable<Acessos> d)
        {
            lista.AddRange(d);
        }
        

        public int idItemAcesso { get; set; }

        public string txItemAcesso { get; set; }

        public string txLink { get; set; }

        public int idUsuarioItemAcesso { get; set; }

        public int idUsuario { get; set; }

        public bool blnIncluir { get; set; }

        public bool blnAlterar { get; set; }

        public bool blnInativar { get; set; }

        public bool blnConsultar { get; set; }

        public bool blnImportar { get; set; }

        

        public IEnumerator<Acessos> GetEnumerator()
        {
            return lista.GetEnumerator();
        }

        

        //IEnumerator IEnumerable.GetEnumerator()
        //{
        //    return GetEnumerator();
        //}
    }
       
    
}
