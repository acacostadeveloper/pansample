﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Pan.Restritivos.Model.User;

namespace Pan.Restritivos.Model.Sistema
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbBlackListContaBancaria")]
    public class ContaBlacklist
    {
        [Key]
        public int idBlackList { get; set; }

        [Required]
        public int nrBanco { get; set; }

        [Required]
        public int nrAgencia { get; set; }
        
        [Required]
        public int nrConta { get; set; }

        public DateTime dtInclusao { get; set; }

        public DateTime dtAlteracao { get; set; }

        [Required]
        public int idUsuarioInclusao { get; set; }

        [Required]
        public string statusBlackList { get; set; }
    }
}
