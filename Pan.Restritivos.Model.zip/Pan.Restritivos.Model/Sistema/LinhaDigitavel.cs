﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Pan.Restritivos.Model.User;

namespace Pan.Restritivos.Model.Sistema
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbLinhaDigitavel")]
    public class LinhaDigitavel
    {

        [Key]
        public int idLinhaDigitavel { get; set; }

        [Required]
        public string nrLinhaDigitavel { get; set; }
              

        [Required]
        public DateTime dtVigenciaInicio { get; set; }
        
        public DateTime? dtVigenciaFim { get; set; }

        [Required]
        public int idMotivo { get; set; }

        [Required]
        public int idPeso { get; set; }

        [Required]
        public int idUsuarioManutencao { get; set; }

        [Required]
        public DateTime dtManutencao { get; set; }

        [MaxLength(100)]
        public string txObs { get; set; }

        [Required]
        public bool blnAtivo { get; set; }

        [NotMapped]
        public string nmUsuarioManutencao { get; set; }

        [NotMapped]
        public string txMotivo { get; set; }

        [NotMapped]
        public string txPeso { get; set; }

        [NotMapped]
        public string txErro { get; set; }

        [NotMapped]
        public string codMotivo { get; set; }

        [NotMapped]
        public string codPeso { get; set; }

        [NotMapped]
        public string txAcao { get; set; }

        [NotMapped]
        public bool bnlErro { get; set; }

        [NotMapped]
        public int idLinhaDigitavelLog { get; set; }

        public Usuario tbUsuario { get; set; }
        public Motivo tbMotivo { get; set; }
        public Peso tbPeso { get; set; }


    }
}
