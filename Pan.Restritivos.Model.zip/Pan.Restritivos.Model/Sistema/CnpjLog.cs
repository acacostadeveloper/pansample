﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Pan.Restritivos.Model.User;

namespace Pan.Restritivos.Model.Sistema
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
    [Table("tbCnpjLog")]
    public class CnpjLog
    {

        [Key]
        public int idCnpjLog { get; set; }
        
        public int idCnpj { get; set; }
        

        [Required]
        [MaxLength(50)]
        public string nrCnpj { get; set; }

        [MaxLength(50)]
        public string nmEmpresa { get; set; }

        [Required]
        public DateTime dtVigenciaInicio { get; set; }
        
        public DateTime? dtVigenciaFim { get; set; }

        [Required]
        public int idMotivo { get; set; }

        [Required]
        public int idPeso { get; set; }

        [Required]
        public int idUsuarioManutencao { get; set; }

        [Required]
        public DateTime dtManutencao { get; set; }

        [MaxLength(100)]
        public string txObs { get; set; }

        [Required]
        public bool blnAtivo { get; set; }

        [Required]
        [MaxLength(10)]
        public string txAcao { get; set; }

    }
}
