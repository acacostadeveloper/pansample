﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Restritivos.Model.Sistema
{
    /// <summary>
    /// Entidade utilizada pelo entity framework para definição e persistencia da base de dados.
    /// Pública á todas as camadas
    /// </summary> 
      [Serializable]
    [Table("tbMotivo")]
    public class Motivo
    {
        [Key]
        public int idMotivo { get; set; }
       [Required]
        public string codMotivo { get; set; }
       [Required]
        public string txMotivo { get; set; }
        [Required]
        public int idUsuarioManutencao { get; set; }
        [Required]
        public DateTime dtManutencao { get; set; }
       [Required] 
        public bool blnAtivo { get; set; }
       [NotMapped]
       public string nmUsuarioManutencao { get; set; }

    }
}
