﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class TrocaVersaoServico : ITrocaVersaoServico
    {
        TrocaVersaoService.TrocaVersaoServicoClient _proxy = new TrocaVersaoService.TrocaVersaoServicoClient();

        
        public TrocaVersao SolicitarTrocaVersao(string numeroConta, int logoContaDestino, string codigoPCTDestino, int codigoTipoEmbossingDestino, string codigoCalculoAnuidadeDestino, string codigoFormatoPlastico,
            string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTrocaVersao = _proxy.SolicitarTrocaVersao(   numeroConta, 
                                                                  logoContaDestino, 
                                                                  codigoPCTDestino, 
                                                                  codigoTipoEmbossingDestino, 
                                                                  codigoCalculoAnuidadeDestino, 
                                                                  codigoFormatoPlastico,
                                                                  codigoAtendente, 
                                                                  textoComplementar, 
                                                                  nomeOrigem, 
                                                                  channel, 
                                                                  codigoLogo, 
                                                                  codigoLoja, 
                                                                  nomeUsuario);

                return oTrocaVersao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SolicitarTrocaVersao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public TrocaVersao ConsultarParametro(string codigoLogo, string nomeOrigem, string channel, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarParametro(codigoLogo, nomeOrigem, channel, codigoLoja, nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarParametro", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
