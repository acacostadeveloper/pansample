﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class TelesaqueServico : ITelesaqueServico
    {
        TelesaqueService.TelesaqueServicoClient _proxy = new TelesaqueService.TelesaqueServicoClient();

        
        public HistoricosTelesaque ConsultarHistoricoTelesaque(string numeroCartao, DateTime dataInicio, DateTime dataFim, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oHistoricosTelesaque = _proxy.ConsultarHistoricoTelesaque(numeroCartao,
                                                                              dataInicio,
                                                                              dataFim,
                                                                              chaveRestart,
                                                                              nomeOrigem,
                                                                              channel,
                                                                              codigoLogo,
                                                                              codigoLoja,
                                                                              nomeUsuario);

                return oHistoricosTelesaque;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ExcluirDadosListaNegra", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public EfetivaTelesaque EfetivarTelesaque(string numeroCartao, int organizacaoEstabelecimento, int numeroEstabelecimento, string tipoTransacao, decimal valorSaqueSolicitado, int numeroParcelas, string nomeOrigem, string codigoAtendente, 
            string textoComplementar, int codigoBanco, string codigoAgencia, string codigoConta, int codigoCompensacao, string flagProdutoAgregado, string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string tipoTelesaque)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oEfetivaTelesaque = _proxy.EfetivarTelesaque(numeroCartao, 
                                                                 organizacaoEstabelecimento, 
                                                                 numeroEstabelecimento, 
                                                                 tipoTransacao, 
                                                                 valorSaqueSolicitado, 
                                                                 numeroParcelas, 
                                                                 nomeOrigem, 
                                                                 codigoAtendente, 
                                                                 textoComplementar, 
                                                                 codigoBanco, 
                                                                 codigoAgencia, 
                                                                 codigoConta, 
                                                                 codigoCompensacao, 
                                                                 flagProdutoAgregado, 
                                                                 channel, 
                                                                 codigoLogo, 
                                                                 codigoLoja, 
                                                                 nomeUsuario,
                                                                 tipoTelesaque);

                return oEfetivaTelesaque;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "EfetivarTelesaque", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public SimulaTelesaque SimularTelesaque(string numeroCartao, int organizacaoEstabelecimento, int numeroEstabelecimento, string tipoTransacao, decimal valorSaqueSolicitado, int numeroParcelas, string nomeOrigem, int codigoCompensacao,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string flagProdutoAgregado, string tipoTelesaque)
        {            
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSimulaTelesaque = _proxy.SimularTelesaque(numeroCartao, 
                                                              organizacaoEstabelecimento, 
                                                              numeroEstabelecimento, 
                                                              tipoTransacao, 
                                                              valorSaqueSolicitado, 
                                                              numeroParcelas, 
                                                              nomeOrigem, 
                                                              codigoCompensacao,
                                                              channel, 
                                                              codigoLogo, 
                                                              codigoLoja, nomeUsuario, 
                                                              flagProdutoAgregado,
                                                              tipoTelesaque);

                return oSimulaTelesaque;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SimularTelesaque", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
