﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class SeguroServico : ISeguroServico
    {
        private SeguroService.SeguroServicoClient _proxy = new SeguroService.SeguroServicoClient();

        
        public Seguro AderirSeguros(string numeroCartao, int codigoProduto, string codigoPlano, string nomeOrigem, string codigoAtendente, string textoComplementar, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSeguro = _proxy.AderirSeguros(numeroCartao,
                                                   codigoProduto, 
                                                   codigoPlano, 
                                                   nomeOrigem, 
                                                   codigoAtendente, 
                                                   textoComplementar, 
                                                   channel,
                                                   codigoLogo, 
                                                   codigoLoja, 
                                                   nomeUsuario);

                return oSeguro;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "AderirSeguros", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Seguro CancelarSeguros(string numeroCartao, int codigoProduto, string codigoPlano, string nomeOrigem, string codigoAtendente, string textoComplementar,
            int sequenciaProduto, string codigoMotivoCancelamento, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSeguro = _proxy.CancelarSeguros(   numeroCartao, 
                                                        codigoProduto, 
                                                        codigoPlano, 
                                                        nomeOrigem, 
                                                        codigoAtendente, 
                                                        textoComplementar,
                                                        sequenciaProduto, 
                                                        codigoMotivoCancelamento, 
                                                        channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario);

                return oSeguro;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "CancelarSeguros", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Seguro ConsultarParametrizacaoSeguros(string codigoLogo, string chaveRestart, string nomeOrigem, string channel, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSeguro = _proxy.ConsultarParametrizacaoSeguros(codigoLogo, 
                                                                    chaveRestart, 
                                                                    nomeOrigem, 
                                                                    channel, 
                                                                    codigoLoja, 
                                                                    nomeUsuario);

                return oSeguro;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarParametrizacaoSeguros", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Seguro ConsultarSegurosCartao(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSeguro = _proxy.ConsultarSegurosCartao(numeroCartao, 
                                                            chaveRestart, 
                                                            nomeOrigem, 
                                                            channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario);

                return oSeguro;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarSegurosCartao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
