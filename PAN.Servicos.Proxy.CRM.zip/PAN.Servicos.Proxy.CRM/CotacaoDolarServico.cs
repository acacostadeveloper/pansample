﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using PAN.Servicos.Proxy.CRM.Helper;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class CotacaoDolarServico : ICotacaoDolarServico
    {
        private CotacaoDolarService.CotacaoDolarServicoClient _proxy = new CotacaoDolarService.CotacaoDolarServicoClient();

        public CotacoesDolar ConsultarCotacaoDolar(string codigoIndice, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);
                
                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oCotacaoDolar = _proxy.ConsultarCotacaoDolar(   codigoIndice, 
                                                                    chaveRestart, 
                                                                    nomeOrigem, 
                                                                    channel, 
                                                                    codigoLogo, 
                                                                    codigoLoja, 
                                                                    nomeUsuario);

                return oCotacaoDolar;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarCotacaoDolar", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
