﻿using PAN.Entidades.CRM;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ISenhaServico
    {
        /// <summary>
        /// Serviço Consultar Tentativas Senha Invalida
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Senha ConsultarTentativasSenhaInvalida(string numeroCartao, string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Manutenção de Troca de Senha
        /// </summary>
        /// <param name="numeroConta">Número da Conta</param>
        /// <param name="numeroCartaoMascarado">Número do Cartão com mascara</param>
        /// <param name="senhaAtual">Senha atual do cartão</param>
        /// <param name="senhaNova">Nova Senha do cartão </param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Senha AlterarSenha(string numeroConta, string numeroCartaoMascarado, string senhaAtual, string senhaNova, string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Manutenção de Validar Senha
        /// </summary>
        /// <param name="numeroConta">Número da Conta</param>
        /// <param name="numeroCartaoMascarado">Número do Cartão com mascara</param>
        /// <param name="senhaAtual">Senha atual do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Senha ValidarSenha(string numeroConta, string numeroCartaoMascarado, string senhaAtual, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Seriço Manutençao de Desbloquar Senha
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do Serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Senha DesbloquearSenha(string numeroCartao, string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
