﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IContratoParceladoServico
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroConta">Número da Conta</param>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="numeroContrato">Número do Contrato</param>
        /// <param name="dataVencimentoParcela">Data do Vencimento da Parcela</param>
        /// <param name="tipoManutencao">Tipo de manutenção</param>
        /// <param name="funcaoSolicitada">Função solicitada</param>
        /// <param name="motivoCancelamento">Motivo do Cancelamento</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>        
        /// <returns></returns>
        [OperationContract]
        ContratoParcelado ManterContratosParcelados(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, DateTime? dataVencimentoParcela, string tipoManutencao, string funcaoSolicitada,
            int motivoCancelamento, string codigoAtendente, string textoComplementar, string nomeOrigem);
    }
}
