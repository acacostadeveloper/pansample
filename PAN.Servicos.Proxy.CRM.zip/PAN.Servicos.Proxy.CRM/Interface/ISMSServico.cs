﻿using PAN.Entidades.CRM;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ISMSServico
    {
        /// <summary>
        /// Serviço de Aderir Pacotes SMS
        /// Permitir aderir as informações do pacote de mensagens SMS por número do cartão.
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoPacote">Código do pacote</param>
        /// <param name="nomeApelido">Apelido que o Portador deseja receber na mensagem</param>
        /// <param name="horaReceber">Horário que o Portador deseja receber o SMS</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        PacoteSMS AderirPacotesSMS(string numeroCartao, int codigoPacote, string nomeApelido, DateTime horaReceber, string codigoAtendente, string textoComplementar, string origem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço de Alteração Pacotes SMS
        /// Permitir alterar as informações do pacote de mensagens SMS por número do cartão.
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoPacote">Código do pacote </param>
        /// <param name="nomeApelido">Apelido que o Portador deseja receber na mensagem</param>
        /// <param name="horaReceber">Horário que o Portador deseja receber o SMS</param>
        /// <param name="numeroPacoteFuturo">Número do Pacote futuro para os casos de solicitação de substituição de pacote</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        PacoteSMS AlterarPacotesSMS(string numeroCartao, int codigoPacote, string nomeApelido, DateTime horaReceber, int numeroPacoteFuturo, string codigoAtendente, string textoComplementar, string origem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Cancelar Pacotes SMS
        /// Permitir cancelar as informações do pacote de mensagens SMS por número do cartão.
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoPacote">Código do pacote</param>
        /// <param name="codigoMotivoCancel">Motivo do cancelamento</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        PacoteSMS CancelarPacoteSMS(string numeroCartao, int codigoPacote, int codigoMotivoCancel, string codigoAtendente, string textoComplementar, string origem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço de Consultar Pacotes SMS
        /// Permitir consultar as informações do pacote de mensagens SMS por número do cartão.
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        RetornoConsultaPacoteSMS ConsultarPacotesSMS(string numeroCartao, string chaveRestart, string origem, string channel, string codigoLogo, string codigoLoja, 
            string nomeUsuario);
        
        /// <summary>
        /// Serviço de Consultar Parametrização Pacote SMS
        /// Permitir consultar as informações do pacote de mensagens SMS por número do cartão.
        /// </summary>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        RetornoConsultaPacoteSMS ConsultarParametrizacaoPacotesSMS(string codigoLogo, string chaveRestart, string origem, string channel, string codigoLoja, 
            string nomeUsuario);
        
        /// <summary>
        /// Serviço de Subistituir Pacotes SMS
        /// Permitir substituir as informações do pacote de mensagens SMS por número do cartão.
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoPacote">Código do pacote</param>
        /// <param name="numeroPacoteFuturo">Número do Pacote futuro para os casos de solicitação de substituição de pacote</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        PacoteSMS SubstituirPacotesSMS(string numeroCartao, int codigoPacote, int numeroPacoteFuturo, string codigoAtendente, string textoComplementar, 
            string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}