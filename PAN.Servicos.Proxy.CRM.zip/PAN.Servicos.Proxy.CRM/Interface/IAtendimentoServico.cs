﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IAtendimentoServico
    {
        /// <summary>
        /// Operação Consulta Histórico Atendimento Por Número de Caso
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroCaso">Número do caso</param>
        /// <param name="chaveRestart">Chave de restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        RegistroAtendimento ConsultarRegistroAtendimentoNumeroCaso(string numeroCartao, string numeroCaso, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Consultar Registro de Atendimento Por Período
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="dataInicio">Data de início da Pesquisa</param>
        /// <param name="dataFim">Data final da Pesquisa</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        RegistroAtendimento ConsultarRegistroAtendimentoPeriodo(string numeroCartao, DateTime dataInicio, DateTime dataFim, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Consulta Ações de Atendimento
        /// </summary>
        /// <param name="acao">Código da ação a consultar</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        AcaoAtendimento ConsultarAcoesAtendimento(string acao, string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço Inclusão de Registro de Atendimento
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="codigoAcao">Código de Ação cadastrada no Sistema</param>
        /// <param name="codigoSequenciaAcao">Sequencia de ação parametrizada para a ação</param>
        /// <param name="dataHoraEnvioSolicitacao">Data e Hora da solicitação</param>
        /// <param name="descricaoHitorico1">Descritivo da Primeira linha do histórico do arquivo de histórico</param>
        /// <param name="descricaoHitorico2">Descritivo da Segunda linha do histórico do arquivo de histórico</param>
        /// <param name="descricaoHistorico3">Descritivo da Terceira linha do histórico do arquivo de histórico</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        RegistroAtendimento IncluirResgistroAtendimento(string numeroCartao, string codigoAcao, string codigoSequenciaAcao, DateTime dataHoraEnvioSolicitacao,
            string descricaoHitorico1, string descricaoHitorico2, string descricaoHistorico3, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
