﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ICartaoContaServico
    {
        /// <summary>
        /// Serviço de Alteração de Dados Monetários do Cartão Titular
        /// </summary>
        /// <param name="numeroCartao">Número do cartão Titular</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="descricaoTextoComplementar">Texto complementar</param>
        /// <param name="codigoAtendente">Id do atendente</param>
        /// <param name="diaVencimentoFatura">Dia de vencimento da fatura</param>
        /// <param name="flgDebitoContaCorrente">Indicativo débito em Conta Corrente</param>
        /// <param name="codigoBancoDebitoConta">Código do Banco para débito em conta</param>
        /// <param name="codigoAgenciaDebitoConta">Código da agência para débito em conta</param>
        /// <param name="numeroContaCorrenteDebito">Código da conta corrente utilizado para débito</param>
        /// <param name="codigoBancoTelesaque">Código do Banco do Telesaque</param>
        /// <param name="codigoCompensacaoTelesque">Código de Compensação do Telesaque</param>
        /// <param name="codigoAgenciaTelesaque">Código agência Telesaque</param>
        /// <param name="codigoContaTelesaque">Código da conta de Telesaque</param>
        /// <param name="valorLimeteCredito">Limite de crédito da conta</param>
        /// <param name="flgFaturaEmail">Aviso de Fatura por e-mail</param>
        /// <param name="dataAvisoFatura">Data de adesão do aviso de fatura</param>
        /// <param name="dataCancelamentoAvisoFaturaEmail">Data de cancelamento do aviso de fatura</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>      
        /// <param name="faturaVirtual">Se o cliente deseja receber fatura virtual</param>
        /// <param name="dataAdesaoFaturaVirtual">Data da adesão do aviso de fatura virtual</param>
        /// <param name="dataCancelamentoAvisoFaturaVirtual">Data de cancelamento do aviso de fatura virtual</param>
        /// <returns></returns>
        [OperationContract]
        MonetariosCartaoTitular AlterarDadosMonetariosCartaoTitular(string numeroCartao, string nomeOrigem, string descricaoTextoComplementar, string codigoAtendente, int diaVencimentoFatura,
            string flgDebitoContaCorrente, int? codigoBancoDebitoConta, int? codigoAgenciaDebitoConta, string numeroContaCorrenteDebito, int? codigoBancoTelesaque, int? codigoCompensacaoTelesque,
            int? codigoAgenciaTelesaque, string codigoContaTelesaque, decimal valorLimeteCredito, string flgFaturaEmail, DateTime? dataAvisoFatura, DateTime? dataCancelamentoAvisoFaturaEmail, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario, string faturaVirtual, DateTime? dataAdesaoFaturaVirtual, DateTime? dataCancelamentoAvisoFaturaVirtual);

        /// <summary>
        /// Serviço de Consulta informações de Cartões
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão ou Número do token do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        InformacaoCartao ConsultarInformacoesCartao(string numeroCartao, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consulta Contas/Cartões Titular e Adicionais de clientes por nome e ou CPF.
        /// </summary>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="cpf">Número do CPF do cliente</param>
        /// <param name="nomeCliente">Nome do cliente</param>
        /// <param name="numeroCartaoTitular">Número do cartão do Titular</param>
        /// <param name="chaveResetart">Chave de restart do serviço</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Cartoes ConsultarCartaoNome(string origem, string cpf, string nomeCliente, string numeroCartaoTitular, string chaveResetart, string codigoLoja, string codigoLogo, string channel, string nomeUsuario);

        /// <summary>
        /// Serviço de Consulta informações cadastrais e monetárias de uma Conta
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="origem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Conta ConsultarInformacoesConta(string numeroCartao, string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consulta de informações referentes a situação de entrega dos cartões embossados
        /// </summary>
        /// <param name="numeroCpfCgc">CPF/CGC </param>
        /// <param name="numeroCartao">Numero do cartão</param>
        /// <param name="numeroAr">AR</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        EnvioCartoes ConsultarEnvioCartoes(string numeroCpfCgc, string numeroCartao, int numeroAr, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Inclusão de Cartão Adicional
        /// </summary>
        /// <param name="numeroConta">Número da conta para a solicitação de Cartão Adicional</param>
        /// <param name="nomeEmbossing">Nome Embossamento do cartão</param>
        /// <param name="codigoSexoPortador">Sexo do portador</param>
        /// <param name="flgCobraTarifa">Deve cobrar tarifa</param>
        /// <param name="codigoTipoCartao">Tipo de Cartão</param>
        /// <param name="flgDependente">Cartão é Dependente</param>
        /// <param name="valorLimeiteDependente">Limite de Crédito do dependente</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Código do Atendente</param>
        /// <param name="textoComplementar">Descrição a ser registrada</param>
        /// <param name="flagCartaoVirtual">CartaoVirtual</param>
        /// <param name="numeroUnico">Número único</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="codigoLojaVenda">Codigo da loja aonde foi feita a venda do cartão</param>
        /// <param name="codigoVendedor">ID do vendedor que fez a venda do cartão</param>
        /// <param name="cpfCartaoAdicional">Cpf do cartão adicional</param>
        /// <param name="dataNascimentoCartaoAdicional">Data de Nascimento do cartão adicional</param>  
        /// <returns></returns>
        [OperationContract]
        CartaoAdicional IncluirCartaoAdicional(string numeroConta, string nomeEmbossing, string codigoSexoPortador, string flgCobraTarifa, string codigoTipoCartao, string flgDependente, 
            decimal? valorLimeiteDependente, string nomeOrigem, string codigoAtendente, string textoComplementar, string flagCartaoVirtual, long numeroUnico, string channel, string codigoLogo, 
            string codigoLoja, string nomeUsuario, string codigoLojaVenda, string codigoVendedor, string cpfCartaoAdicional, DateTime? dataNascimentoCartaoAdicional);

        /// <summary>
        /// Serviço De Manutenção de Dados de Cartão
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeEmbossing">Nome de Eebossamento do cartão</param>
        /// <param name="codigoSexoPortador">Sexo do Portador</param>
        /// <param name="valorLimiteDependente">Limite do Cartão Dependente</param>
        /// <param name="flagCobraTarifa">Existe cobrança de Tarifa</param>
        /// <param name="codigoAcaoEmbossing">Código de Ação</param>
        /// <param name="quantidadeCartoesSolicitados">Quantidade de Cartões solicitados</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Código do Atendente</param>
        /// <param name="textoComplementar">Descrição relativa à alteração</param>
        /// <param name="flagIndicaDependente">Cartão é dependente</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        ManterDadosCartao ManterDadosCartao(string numeroCartao, string nomeEmbossing, string codigoSexoPortador, decimal? valorLimiteDependente, string flagCobraTarifa, string codigoAcaoEmbossing,
            int? quantidadeCartoesSolicitados, string nomeOrigem, string codigoAtendente, string textoComplementar, string flagIndicaDependente, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço Consulta Cartões de uma Conta (Titulares E Adicionais)
        /// </summary>
        /// <param name="numeroCartao">Número do cartão Titular da conta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="chaveRestart">Chave de restart do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        CartoesContas ConsultarCartoesConta(string numeroCartao, string nomeOrigem, string chaveRestart, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        ///  Serviço de Bloquear Conta
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="codigoBloqueio">Código de Bloqueio</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto complementar</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        BloqueioDesbloqueioContaCartao BloquearConta(string numeroCartao, string codigoBloqueio, string nomeOrigem, string codigoAtendente, string textoComplementar, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço de Desbloquar Conta
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroRgTitular">Número do RG do Titular</param>
        /// <param name="tipoDocumento">Tipo Documento(0-CPF/1-CNPJ)</param>
        /// <param name="documentoTitular">Documento do Titular </param>
        /// <param name="dataNascimentoTitular">Data de Nascimento do Titular</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto complementar</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        BloqueioDesbloqueioContaCartao DesbloquearConta(string numeroCartao, string numeroRgTitular, int tipoDocumento, string documentoTitular, DateTime dataNascimentoTitular, string nomeOrigem, string codigoAtendente, string textoComplementar, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço de Bloquear Cartão
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="codigoBloqueio">Código de Bloqueio</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto complementar</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        BloqueioDesbloqueioContaCartao BloquearCartao(string numeroCartao, string codigoBloqueio, string nomeOrigem, string codigoAtendente, string textoComplementar, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Desbloquear Cartão
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroRGTitular">Número do RG do Titular</param>
        /// <param name="tipoDocumento">Tipo Documento</param>
        /// <param name="documentoTitular">Documento do Titular</param>
        /// <param name="dataNascimentoTitular">Data de Nascimento do Titular</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto complementar</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        BloqueioDesbloqueioContaCartao DesbloquearCartao(string numeroCartao, string numeroRGTitular, int tipoDocumento, string documentoTitular, DateTime dataNascimentoTitular, string nomeOrigem, string codigoAtendente, string textoComplementar, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
