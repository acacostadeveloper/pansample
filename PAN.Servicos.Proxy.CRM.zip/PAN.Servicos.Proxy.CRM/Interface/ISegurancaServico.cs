﻿using PAN.Entidades.CRM;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ISegurancaServico
    {
        [OperationContract]
        string GetToken(string userName, string password);
    }
}
