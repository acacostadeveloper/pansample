﻿using PAN.Entidades.CRM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ITaxaTarifasServico
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="tarifaSaquePCT">Tarifas de saque de uma Pct</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        ParametrosTaxasTarifas ConsultarTaxasTarifas(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string tarifaSaquePCT, string nomeOrigem);
    }
}
