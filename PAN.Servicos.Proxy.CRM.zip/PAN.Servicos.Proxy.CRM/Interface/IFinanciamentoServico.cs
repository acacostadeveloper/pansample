﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    /// <summary>
    /// Serviço Consulta de Financiamentos
    /// </summary>
    [ServiceContract]
    public interface IFinanciamentoServico
    {
        /// <summary>
        /// Operação Consultar Lista de Contratos de Financiamento Ativos 
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="chaveRestart">Chave para restart da consulta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Financiamento ConsultarListaContratosAtivos(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Consultar Lista de Contratos de Financiamento Inativos
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="chaveRestart">Chave para restart da consulta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Financiamento ConsultarListaContratosInativos(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Consultar Lista de Todos Contratos de Financiamento
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="chaveRestart">Chave para restart da consulta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Financiamento ConsultarListaTodosContratos(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Consultar Detalhes do Financiamento
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="chaveRestart">Chave para restart da consulta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="numeroFinanciamento">Número do Financiamento</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Financiamento ConsultarDetalhesFinanciamento(string numeroCartao, string chaveRestart, string nomeOrigem, long numeroFinanciamento,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Consultar Parcelas do Financiamento
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="chaveRestart">Chave para restart da consulta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="numeroFinanciamento">Número do Financimento</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Financiamento ConsultarParcelasFinanciamento(string numeroCartao, string chaveRestart, string nomeOrigem, long numeroFinanciamento,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
