﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;


namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IAnuidadeServico
    {
        /// <summary>
        /// Operação Consultar Anuidade
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Anuidade ConsultarAnuidade(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Manutenção de Anuidade de Cartão Adicional
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="codigoStatus">Código do Status da Anuidade do cartão adicional</param>
        /// <param name="codigoAtendente">Identificação do Atendente no sistema de segurança da Organização</param>
        /// <param name="nomeTextoComplementar">Texto complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Anuidade ManutencaoAnuidadeCartaoAdicional(string numeroCartao, string codigoStatus, string codigoAtendente, string nomeTextoComplementar, string nomeOrigem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
