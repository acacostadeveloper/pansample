﻿using PAN.Entidades.CRM;
using System.ServiceModel;


namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ITransacoesServicos
    {
        /// <summary>
        /// Serviço de Consulta de Transações em Disputa de uma determinada Conta/Cartão.
        /// </summary>
        /// <param name="numeroCartao">Número do cartão Titular da conta</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Transacoes ConsultarTransacoesArmazenadas(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consulta de Transações Armazenadas de uma determinada Conta/Cartão
        /// </summary>
        /// <param name="numeroCartao">Número do cartão Titular da conta</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Transacoes ConsultarTransacoesDisputa(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
