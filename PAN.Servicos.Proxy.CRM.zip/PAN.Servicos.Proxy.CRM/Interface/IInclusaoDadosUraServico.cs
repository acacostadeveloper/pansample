﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;


namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IInclusaoDadosUraServico
    {
        /// <summary>
        /// Operação Incluir Dados URA
        /// </summary>
        /// <param name="nomeOrigem">Nome Origem</param>
        /// /// <param name="nomeUsuario">Nome Usuário</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroTelefone">Número do telefone de origem da chamada</param>
        /// <param name="numeroDDI">Número identificador do país de origem da chamada</param>
        /// <param name="numeroDDD">Número identificador da região de origem da chamada</param>
        /// <param name="idEvento"></param>
        /// <param name="flagTelefone"></param>
        /// <param name="callId"></param>
        /// <param name="data"></param>
        /// <param name="valorLimiteDeCredito"></param>
        /// <returns></returns>
        [OperationContract]
        RegistroInclusaoDadosURA IncluirDadosURA(string nomeOrigem, string nomeUsuario, string numeroCartao, string numeroTelefone, int numeroDDI, int numeroDDD, int idEvento, string flagTelefone, int callId, DateTime data, double valorLimiteDeCredito);

    }
}
