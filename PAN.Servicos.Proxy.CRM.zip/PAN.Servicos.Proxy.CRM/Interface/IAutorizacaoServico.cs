﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IAutorizacaoServico
    {
        /// <summary>
        /// Seriviço de Consulta Detalhe de Autorização
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="dataHoraAutorizacao">Data e Hora da Autorização</param>
        /// <param name="codigoLogAutorizacao">Arquivo onde a autorização está localizada</param>
        /// <param name="codigoIdentificacaoRegistro">Chave de identificação do registro</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        DetalheAutorizacao ConsultarDetalhesAutorizacao(string numeroCartao, DateTime dataHoraAutorizacao, string codigoLogAutorizacao, string codigoIdentificacaoRegistro, string nomeOrigem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consulta de Lista de Autorização
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="dataInicial">Data Inicial das Autorizações</param>
        /// <param name="dataFinal">Data Final das Autorizações</param>
        /// <param name="codigoRequisicao">Tipo da Requisição</param>
        /// <param name="codigoTransacao">Tipo de Transação</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        ListaAutorizacoes ConsultarAutorizacoes(string numeroCartao, DateTime dataInicial, DateTime dataFinal, string codigoRequisicao, string codigoTransacao,
            string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
