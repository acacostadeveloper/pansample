﻿using PAN.Entidades.Agentes.Interno.CRM;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    /// <summary>
    /// Serviço de consulta de segunda via de fatura
    /// </summary>
    [ServiceContract]
    public interface IFaturaPanServico
    {
        /// <summary>
        /// Retorna o arquivo pdf de uma fatura
        /// </summary>
        /// <param name="idFatura">identificador da fatura</param>
        /// <param name="nomeUsuarioCRM">Nome do usuário</param>
        /// <returns>array de bytes contendo o pdf da fatura</returns>
        [OperationContract]
        byte[] ObterPdfFatura(int idFatura, string nomeUsuarioCRM);

        /// <summary>
        /// Retorna uma lisa de faturas
        /// </summary>
        /// <param name="numeroConta">numero da conta do cliente</param>
        /// <param name="nomeUsuarioCRM">Nome do usuário</param>
        /// <returns>lista de faturas</returns>
        [OperationContract]
        IList<FaturaResumidaCliente> ListarFaturas(string numeroConta, string nomeUsuarioCRM);
    }
}
