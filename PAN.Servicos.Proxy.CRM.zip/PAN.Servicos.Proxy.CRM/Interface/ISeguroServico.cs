﻿using PAN.Entidades.CRM;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ISeguroServico
    {
        /// <summary>
        /// Serviço de Aderir Seguros para Cartão Titular e Adicional.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="codigoProduto">Código do produto de seguro</param>
        /// <param name="codigoPlano">Código do plano associado ao seguro</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Seguro AderirSeguros(string numeroCartao, int codigoProduto, string codigoPlano, string nomeOrigem, string codigoAtendente, string textoComplementar,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Cancelar Seguros para Cartão Titular e Adicional.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="codigoProduto">Código do produto de seguro</param>
        /// <param name="codigoPlano">Código do plano associado ao seguro</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="sequenciaProduto">Sequência do produto</param>
        /// <param name="codigoMotivoCancelamento">Motivo do cancelamento do produto</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Seguro CancelarSeguros(string numeroCartao, int codigoProduto, string codigoPlano, string nomeOrigem, string codigoAtendente, string textoComplementar, int sequenciaProduto,
            string codigoMotivoCancelamento, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Parametrizacao de Seguros. 
        /// Permitir a cobrança e controle de Produtos de Pagamento Contínuo tais como: Seguro de Vida, Seguro de Proteção Contra Perda e Roubo, Seguro de Veículos e outros.
        /// </summary>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Seguro ConsultarParametrizacaoSeguros(string codigoLogo, string chaveRestart, string nomeOrigem, string channel, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consultar Seguros. 
        /// Permitir a cobrança e controle de Produtos de Pagamento Contínuos tais como: Seguro de Vida, Seguro de Proteção Contra Perda e Roubo, Seguro de Veículos e outros.
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Chave de Restart</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Seguro ConsultarSegurosCartao(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
