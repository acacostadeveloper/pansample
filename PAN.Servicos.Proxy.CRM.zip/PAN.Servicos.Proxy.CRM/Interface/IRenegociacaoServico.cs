﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IRenegociacaoServico
    {
        /// <summary>
        /// Serviço de Consultar Detalhes de Solicitação Parcelamento Fatura ou Renegociação de Dívida
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroSolicitacao">Número da solicitação do parcelamento de fatura ou renegociação de dividas</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        ParcelamentoFatura ConsultarDetalhesSolicParcFaturaReneDivida(string numeroCartao, long numeroSolicitacao, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consultar Lista de Solicitação Parcelamento Fatura e Renegociação de Dívida
        /// </summary>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Parcelamento ConsultarListaSolicParcFaturaReneDivida(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Consultar Renegociação de Dívida
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        Renegociacao ConsultarRenegociacaoDivida(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem);

        /// <summary>
        /// Simular Renegociação de Dívida
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="valorSolicitado">Valor solicitado</param>
        /// <param name="numeroParcelas">Número  solicitado de parcelas.</param>
        /// <param name="valorEntrada">Valor da entrada a ser utilizada</param>
        /// <returns></returns>
        [OperationContract]
        Renegociacao SimularRenegociacaoDivida(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem,
             decimal valorSolicitado, int numeroParcelas, decimal valorEntrada);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtentende">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="valorSolicitado">Valor solicitado</param>
        /// <param name="numeroParcelas">Número solicitado de parcelas</param>
        /// <param name="valorEntrada">Valor da entrada a ser utilizada</param>
        /// <returns></returns>
        [OperationContract]
        Renegociacao EfetivarRenegociacaoDivida(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem,
            string codigoAtentende, string textoComplementar, decimal valorSolicitado, int numeroParcelas, decimal valorEntrada);
    }
}