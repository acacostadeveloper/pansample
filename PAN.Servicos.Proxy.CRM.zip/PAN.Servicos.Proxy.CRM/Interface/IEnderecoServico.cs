﻿using System.ServiceModel;
using PAN.Entidades.Dados.Cep.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    /// <summary>
    /// Serviço Consulta de Endereços
    /// </summary>
    [ServiceContract]
    public interface IEnderecoServico
    {
        /// <summary>
        /// Consulta endereços na base de dados pelo cep
        /// </summary>
        /// <param name="cep">Número do cep sem traço</param>
        /// <returns>Objeto EnderecoDTO com uma lista de endereços</returns>
        [OperationContract]
        EnderecoDTO BuscarPorCep(string cep, string nomeUsuarioCRM);

        /// <summary>
        /// Consulta endereços na base de dados pelo nome da rua
        /// </summary>
        /// <param name="nomeRua">Nome da rua</param>
        /// <returns>Objeto EnderecoDTO com uma lista de endereços</returns>
        [OperationContract]
        EnderecoDTO BuscarPorNomeDaRua(string nomeRua, string nomeUsuarioCRM);
    }
}
