﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IDesagioServico
    {
        /// <summary>
        /// Operação Consultar Deságio
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroConta">Conta associada ao cartão</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroContrato">Número do contrato de financiamento</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        Desagio ConsultarDesagio(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, string nomeOrigem);
        
        /// <summary>
        /// Operação Efetivar Deságio
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroConta">Conta associada ao cartão</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroContrato">Número do contrato de financiamento</param>
        /// <param name="momentoAntecipa">Momento desejado para pagamento do contrato</param>
        /// <param name="flagDesagioTotal">Indicador de usuário deseja deságio total ou parcial do contrato</param>
        /// <param name="quantidadeParcelas">Quantidade de parcelas</param>
        /// <param name="motivoDesagio">Motivo do deságio</param>
        /// <param name="codigoAtendente">Código do Atendente no sistema do solicitante</param>
        /// <param name="textoComplementar">Texto complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        Desagio EfetivarDesagio(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, string momentoAntecipa,
            string flagDesagioTotal, int quantidadeParcelas, int motivoDesagio, string codigoAtendente, string textoComplementar, string nomeOrigem);
        
        /// <summary>
        /// Operação Simular Deságio
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="numeroConta">Conta associada ao cartão</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="numeroContrato">Número do contrato de financiamento</param>
        /// <param name="momentoAntecipa">Momento desejado para pagamento do contrato</param>
        /// <param name="flagDesagioTotal">Deságio total ou parcial do contrato</param>
        /// <param name="quantidadeParcelas">Quantidade de parcelas </param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        Desagio SimularDesagio(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, string momentoAntecipa,
            string flagDesagioTotal, int quantidadeParcelas, string nomeOrigem);

    }
}
