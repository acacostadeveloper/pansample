﻿using PAN.Entidades.CRM;
using System;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IClienteServico
    {
        /// <summary>
        /// ** Descrever o que este serviço faz e valores esperados
        /// </summary>
        /// <param name="cliente"></param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Cliente AlteracaoDadosCliente(Cliente cliente, string codigoLogo, string codigoLoja, string channel, string nomeUsuario);
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="numeroCliente"></param>
        /// <param name="numeroCartao"></param>
        /// <param name="numeroCPF"></param>
        /// <param name="origem"></param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Cliente ConsultarDadosCliente(string numeroCliente, string numeroCartao, string numeroCPF, string origem, string codigoLogo, string codigoLoja, string channel, string nomeUsuario);
    }
}
