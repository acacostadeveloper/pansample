﻿using PAN.Entidades.CRM;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ITelefoneListaServico
    {
        /// <summary>
        /// Serviço de Consultar Dados Lista Branca
        /// </summary>
        /// <param name="numeroDDI">Número do DDI</param>
        /// <param name="numeroDDD">Número do DDD</param>
        /// <param name="numeroTelefone">Número do Telefone</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Telefones ConsultarDadosListaBranca(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço de Incluir Dados da Lista Branca
        /// </summary>
        /// <param name="numeroDDI">Número do DDI</param>
        /// <param name="numeroDDD">Número do DDD</param>
        /// <param name="numeroTelefone">Número do Telefone</param>
        /// <param name="dataHora">Data e Hora da Inclusão</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Telefone IncluirDadosListaBranca(int numeroDDI, int numeroDDD, string numeroTelefone, DateTime? dataHora, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço de Excluir Dados da Lista Branca
        /// </summary>
        /// <param name="numeroDDI">Número do DDI</param>
        /// <param name="numeroDDD">Número do DDD</param>
        /// <param name="numeroTelefone">Número do Telefone</param>
        /// <param name="dataHora">Data e Hora da Inclusão</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Telefone ExcluirDadosListaBranca(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Consultar Dados da Lista Negra
        /// </summary>
        /// <param name="numeroDDI">Número do DDI</param>
        /// <param name="numeroDDD">Número do DDD</param>
        /// <param name="numeroTelefone">Número do Telefone</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Telefones ConsultarDadosListaNegra(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, 
            string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Incluir Dados da Lista Negra
        /// </summary>
        /// <param name="numeroDDI">Número do DDI</param>
        /// <param name="numeroDDD">Número do DDD</param>
        /// <param name="numeroTelefone">Número do Telefone</param>
        /// <param name="dataHora">Data e Hora da Inclusão</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Telefone IncluirDadosListaNegra(int numeroDDI, int numeroDDD, string numeroTelefone, DateTime? dataHora, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);
        
        /// <summary>
        /// Serviço Excluir Dados da Lista Negra
        /// </summary>
        /// <param name="numeroDDI">Número do DDI</param>
        /// <param name="numeroDDD">Número do DDD</param>
        /// <param name="numeroTelefone">Número do Telefone</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Telefone ExcluirDadosListaNegra(int numeroDDI, int numeroDDD, string numeroTelefone, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario);
    }
}
