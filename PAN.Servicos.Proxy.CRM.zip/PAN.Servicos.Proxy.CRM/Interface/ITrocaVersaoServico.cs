﻿using PAN.Entidades.CRM;
using System.ServiceModel;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ITrocaVersaoServico
    {
        /// <summary>
        /// Serviço de Troca de Versão de produtos
        /// </summary>
        /// <param name="numeroConta">Número da Conta de Origem</param>
        /// <param name="logoContaDestino">Logo da conta de destino</param>
        /// <param name="codigoPCTDestino">PCT da conta de destino</param>
        /// <param name="codigoTipoEmbossingDestino">Tipo de embossing para novos cartões</param>
        /// <param name="codigoCalculoAnuidadeDestino">Definição do cálculo de anuidade da conta de destino</param>
        /// <param name="codigoFormatoPlastico">Define o formato para todos os plásticos de destino</param>
        /// <param name="codigoAtendente">Identificação do atendente</param>
        /// <param name="textoComplementar">Texto complementar </param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        TrocaVersao SolicitarTrocaVersao(string numeroConta, int logoContaDestino, string codigoPCTDestino, int codigoTipoEmbossingDestino, string codigoCalculoAnuidadeDestino, string codigoFormatoPlastico,
            string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consulta Parametro Troca de Versão
        /// </summary>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        TrocaVersao ConsultarParametro(string codigoLogo, string nomeOrigem, string channel, string codigoLoja, string nomeUsuario);
    }
}
