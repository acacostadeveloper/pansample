﻿using System;
using System.ServiceModel;
using PAN.Entidades.CRM;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface ITelesaqueServico
    {
        /// <summary>
        /// Serviço de Consulta de Histórico ás Transações de Telesaque por Período
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="dataInicio">Data Inicial para pesquisa</param>
        /// <param name="dataFim">Data Final da pesquisa</param>
        /// <param name="chaveRestart">Chave de Restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        HistoricosTelesaque ConsultarHistoricoTelesaque(string numeroCartao, DateTime dataInicio, DateTime dataFim, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Efetivar Saque, oferecendo opções diferenciadas de financiamento, combinando parcelas e taxas de juros bem como a opção à vista
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="organizacaoEstabelecimento">Organização do Estabelecimento</param>
        /// <param name="numeroEstabelecimento">Número do Estabelecimento</param>
        /// <param name="tipoTransacao">Tipo de Transação</param>
        /// <param name="valorSaqueSolicitado">Valor de Saque solicitado e que será simulado</param>
        /// <param name="numeroParcelas">Número de Parcelas solicitadas</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoAtendente">Código do atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="codigoBanco">Código do Banco para crédito do telesaque</param>
        /// <param name="codigoAgencia">Código da agencia para crédito do telesaque</param>
        /// <param name="codigoConta">Código da conta para crédito do telesaque</param>
        /// <param name="codigoCompensacao">Código de compensação para crédito do telesaque</param>
        /// <param name="flagProdutoAgregado">Indicador cliente deseja efetivar o telesaque com ou sem produto agregado</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        EfetivaTelesaque EfetivarTelesaque(string numeroCartao, int organizacaoEstabelecimento, int numeroEstabelecimento, string tipoTransacao, decimal valorSaqueSolicitado, int numeroParcelas, string nomeOrigem, string codigoAtendente,
            string textoComplementar, int codigoBanco, string codigoAgencia, string codigoConta, int codigoCompensacao, string flagProdutoAgregado, string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string tipoTelesaque);

        /// <summary>
        /// Serviço de Simular Saque, oferecendo opções diferenciadas de financiamento, combinando parcelas e taxas de juros bem como a opção à vista
        /// </summary>
        /// <param name="numeroCartao">Número do Cartão</param>
        /// <param name="organizacaoEstabelecimento">Organização do Estabelecimento</param>
        /// <param name="numeroEstabelecimento">Número do Estabelecimento</param>
        /// <param name="tipoTransacao">Tipo de Transação</param>
        /// <param name="valorSaqueSolicitado">Valor de Saque solicitado e que será simulado</param>
        /// <param name="numeroParcelas">Número de Parcelas </param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="codigoCompensacao">Código de compensação para crédito do telesaque</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <param name="flagProdutoAgregado">Produto Agregado</param>
        /// <returns></returns>
        [OperationContract]
        SimulaTelesaque SimularTelesaque(string numeroCartao, int organizacaoEstabelecimento, int numeroEstabelecimento, string tipoTransacao, decimal valorSaqueSolicitado, int numeroParcelas, string nomeOrigem, int codigoCompensacao,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string flagProdutoAgregado, string tipoTelesaque);
    }
}
