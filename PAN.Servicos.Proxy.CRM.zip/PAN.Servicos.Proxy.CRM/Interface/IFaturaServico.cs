﻿using System;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using System.ServiceModel;
using PAN.Entidades.CRM.Entidades.Agentes.Interno;

namespace PAN.Servicos.Contrato.CRM
{
    [ServiceContract]
    public interface IFaturaServico
    {
        /// <summary>
        /// Serviço de Cancelar Segunda Fatura
        /// Permitir ao usuário consultar as informações das faturas fechadas.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="dataExtrato">Data do extrato para impressa a 2º via</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Fatura CancelarSegundaViaFatura(string numeroCartao, DateTime dataExtrato, string codigoAtendente, string textoComplementar, string nomeOrigem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consultar Detalhe Fatura Fechada
        /// Permitir ao usuário consultar as informações das faturas fechadas.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="versaoFatura">Versão da Fatura</param>
        /// <param name="chaveRestart">Chave para restart da consulta</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Fatura ConsultarDetalheFaturaFechada(string numeroCartao, int versaoFatura, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, 
            string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Consultar Faturas Abertas
        /// Permitir ao usuário consultar as informações das faturas abertas.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="chaveRestart">Chave de restart</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Fatura ConsultarFaturasAbertas(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, 
            string nomeUsuario);

        /// <summary>
        /// Objetivo Consultar Resumo Fatura Fechada
        /// Permitir ao usuário consultar as informações das faturas fechadas.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="versaoFatura">Versão da Fatura</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Fatura ConsultarResumoFaturaFechada(string numeroCartao, int versaoFatura, string nomeOrigem, string channel, string codigoLogo, 
            string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Serviço de Solicitar Segunda Via Fatura
        /// Permitir ao usuário solicitar a emissão da 2ª via de fatura.
        /// </summary>
        /// <param name="numeroCartao">Número Cartão</param>
        /// <param name="dataExtrato">Data do extrato</param>
        /// <param name="codigoAcao">Código da Ação solicitada</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto Complementar</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário</param>
        /// <returns></returns>
        [OperationContract]
        Fatura SolicitarSegundaViaFatura(string numeroCartao, DateTime dataExtrato, string codigoAcao, string codigoAtendente, string textoComplementar, string nomeOrigem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario);

        /// <summary>
        /// Operação Consultar Cancelamento Parcelamento Fatura
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário que está utilizando o sistema</param>
        /// <param name="numeroConta">Número do cartão</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        [OperationContract]
        ListaParcelamentoFaturaPan ConsultarCancelamentoParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, string nomeOrigem);

        /// <summary>
        /// Operação Consultar Parcelamento Fatura
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário que está utilizando o sistema</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <returns></returns>
        [OperationContract]
        ParcelamentoFatura ConsultarParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem);
        
        /// <summary>
        /// Operação Simular Parcelamento Fatura
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário que está utilizando o sistema</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="valorFinanciavel">Valor Financiável.</param>
        /// <param name="numeroParcelas">Número de Parcelas desejadas.</param>
        /// <param name="valorEntrada">Valor da Entrada do Parcelamento</param>
        /// <param name="valorAntecipacao">Valor da Antecipação do Parcelamento.</param>
        /// <returns></returns>
        [OperationContract]
        ParcelamentoFatura SimularParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao,
            string nomeOrigem, decimal? valorFinanciavel, int numeroParcelas, decimal? valorEntrada, decimal? valorAntecipacao);

        /// <summary>
        /// Operação Efetivar Parcelamento Fatura
        /// </summary>
        /// <param name="channel">Nome identificador do canal origem</param>
        /// <param name="codigoLogo">Número do logo do cartão</param>
        /// <param name="codigoLoja">Número loja</param>
        /// <param name="nomeUsuario">Nome do usuário que está utilizando o sistema</param>
        /// <param name="numeroCartao">Número do cartão</param>
        /// <param name="nomeOrigem">Origem da chamada do serviço</param>
        /// <param name="valorFinanciavel">Valor Financiável</param>
        /// <param name="numeroParcelas">Número de Parcelas desejadas</param>
        /// <param name="valorEntrada">Valor da Entrada do Parcelamento</param>
        /// <param name="valorAntecipacao">Valor da Antecipação do Parcelamento</param>
        /// <param name="codigoAtendente">Identificação do Atendente</param>
        /// <param name="textoComplementar">Texto complementar </param>
        /// <returns></returns>
        [OperationContract]
        ParcelamentoFatura EfetivarParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao,
            string nomeOrigem, decimal? valorFinanciavel, int numeroParcelas, decimal? valorEntrada, decimal? valorAntecipacao, string codigoAtendente, string textoComplementar);

        [OperationContract]
        ListaFatura ConsultarFaturas(string numeroCartao, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario); 
    }
}
