﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class TransacoesServico : ITransacoesServicos
    {
        TransacoesService.TransacoesServicosClient _proxy = new TransacoesService.TransacoesServicosClient();

        
        public Transacoes ConsultarTransacoesArmazenadas(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTransacoes = _proxy.ConsultarTransacoesArmazenadas(numeroCartao, 
                                                                        chaveRestart, 
                                                                        nomeOrigem, 
                                                                        channel, 
                                                                        codigoLogo, 
                                                                        codigoLoja, 
                                                                        nomeUsuario);

                return oTransacoes;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarTransacoesArmazenadas", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Transacoes ConsultarTransacoesDisputa(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTransacoes = _proxy.ConsultarTransacoesDisputa(numeroCartao, 
                                                                    chaveRestart, 
                                                                    nomeOrigem, 
                                                                    channel, 
                                                                    codigoLogo, 
                                                                    codigoLoja, 
                                                                    nomeUsuario);

                return oTransacoes;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarTransacoesDisputa", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
