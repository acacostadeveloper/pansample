﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class DesagioServico : IDesagioServico
    {
        DesagioService.DesagioServicoClient _proxy = new DesagioService.DesagioServicoClient();

        
        public Desagio ConsultarDesagio(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oDesagio = _proxy.ConsultarDesagio( channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario, 
                                                        numeroConta, 
                                                        numeroCartao, 
                                                        numeroContrato, 
                                                        nomeOrigem);

                return oDesagio;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarDesagio", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Desagio EfetivarDesagio(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, string momentoAntecipa,
            string flagDesagioTotal, int quantidadeParcelas, int motivoDesagio, string codigoAtendente, string textoComplementar, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oDesagio = _proxy.EfetivarDesagio(  channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario, 
                                                        numeroConta, 
                                                        numeroCartao, 
                                                        numeroContrato, 
                                                        momentoAntecipa,
                                                        flagDesagioTotal, 
                                                        quantidadeParcelas, 
                                                        motivoDesagio, 
                                                        codigoAtendente, 
                                                        textoComplementar, 
                                                        nomeOrigem);

                return oDesagio;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "EfetivarDesagio", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Desagio SimularDesagio(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, string momentoAntecipa,
            string flagDesagioTotal, int quantidadeParcelas, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oDesagio = _proxy.SimularDesagio(   channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario, 
                                                        numeroConta, 
                                                        numeroCartao, 
                                                        numeroContrato, 
                                                        momentoAntecipa,
                                                        flagDesagioTotal, 
                                                        quantidadeParcelas, 
                                                        nomeOrigem);

                return oDesagio;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SimularDesagio", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
