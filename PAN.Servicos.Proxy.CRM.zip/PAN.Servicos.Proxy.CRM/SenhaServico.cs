﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class SenhaServico : ISenhaServico
    {
        private SenhaService.SenhaServicoClient _proxy = new SenhaService.SenhaServicoClient();

        
        public Senha ConsultarTentativasSenhaInvalida(string numeroCartao, string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSenha = _proxy.ConsultarTentativasSenhaInvalida(   numeroCartao, 
                                                                        codigoAtendente, 
                                                                        textoComplementar, 
                                                                        nomeOrigem, 
                                                                        channel, 
                                                                        codigoLogo, 
                                                                        codigoLoja, 
                                                                        nomeUsuario);

                return oSenha;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarTentativasSenhaInvalida", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Senha AlterarSenha(string numeroConta, string numeroCartaoMascarado, string senhaAtual, string senhaNova, string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSenha = _proxy.AlterarSenha(   numeroConta, 
                                                    numeroCartaoMascarado, 
                                                    senhaAtual, 
                                                    senhaNova, 
                                                    codigoAtendente, 
                                                    textoComplementar, 
                                                    nomeOrigem, 
                                                    channel, 
                                                    codigoLogo, 
                                                    codigoLoja, 
                                                    nomeUsuario);

                return oSenha;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "AlterarSenha", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Senha ValidarSenha(string numeroConta, string numeroCartaoMascarado, string senhaAtual, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSenha = _proxy.ValidarSenha(numeroConta, 
                                                 numeroCartaoMascarado, 
                                                 senhaAtual, 
                                                 nomeOrigem, 
                                                 channel, 
                                                 codigoLogo, 
                                                 codigoLoja, 
                                                 nomeUsuario);

                return oSenha;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ValidarSenha", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Senha DesbloquearSenha(string numeroCartao, string codigoAtendente, string textoComplementar, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oSenha = _proxy.DesbloquearSenha(   numeroCartao, 
                                                        codigoAtendente, 
                                                        textoComplementar, 
                                                        nomeOrigem, 
                                                        channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario);

                return oSenha;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "DesbloquearSenha", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
