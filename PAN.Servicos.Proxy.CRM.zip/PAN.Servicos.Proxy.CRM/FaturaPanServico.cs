﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.Agentes.Interno.CRM;
using log4net;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class FaturaPanServico : IFaturaPanServico
    {
        private FaturaPanService.FaturaPanServicoClient _proxy = new FaturaPanService.FaturaPanServicoClient();

        
        public byte[] ObterPdfFatura(int idFatura, string nomeUsuarioCRM)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);
               
                byte[] fatura = new byte[0];

                return fatura;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "ObterPdfFatura", ex.Message, 3, nomeUsuarioCRM, DateTime.Now);
                throw ex;
            }
        }

        
        public IList<FaturaResumidaCliente> ListarFaturas(string numeroConta, string nomeUsuarioCRM)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                List<FaturaResumidaCliente> listFaturaResumida = new List<FaturaResumidaCliente>();
                
                if(listFaturaResumida != null && listFaturaResumida.Count > 0)
                listFaturaResumida =  new List<FaturaResumidaCliente>();                
                
                return listFaturaResumida;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "ListarFaturas", ex.Message, 3, nomeUsuarioCRM, DateTime.Now);
                throw ex;
            }
        }
    }
}
