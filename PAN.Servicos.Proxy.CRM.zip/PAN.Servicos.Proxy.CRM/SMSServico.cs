﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class SMSServico : ISMSServico
    {
        private SMSService.SMSServicoClient _proxy = new SMSService.SMSServicoClient();

        
        public PacoteSMS AderirPacotesSMS(string numeroCartao, int codigoPacote, string nomeApelido, DateTime horaReceber, string codigoAtendente, string textoComplementar, string origem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oPacoteSMS = _proxy.AderirPacotesSMS(   numeroCartao, 
                                                            codigoPacote, 
                                                            nomeApelido, 
                                                            horaReceber, 
                                                            codigoAtendente, 
                                                            textoComplementar, 
                                                            origem, 
                                                            channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario);

                return oPacoteSMS;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "AderirPacotesSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public PacoteSMS AlterarPacotesSMS(string numeroCartao, int codigoPacote, string nomeApelido, DateTime horaReceber, int numeroPacoteFuturo, string codigoAtendente, string textoComplementar, 
            string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oPacoteSMS = _proxy.AlterarPacotesSMS(numeroCartao, 
                                                          codigoPacote, 
                                                          nomeApelido, 
                                                          horaReceber, 
                                                          numeroPacoteFuturo, 
                                                          codigoAtendente, 
                                                          textoComplementar, 
                                                          origem, 
                                                          channel, 
                                                          codigoLogo, 
                                                          codigoLoja, 
                                                          nomeUsuario);

                return new PacoteSMS();
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "AlterarPacotesSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public PacoteSMS CancelarPacoteSMS(string numeroCartao, int codigoPacote, int codigoMotivoCancel, string codigoAtendente, string textoComplementar, string origem, string channel, 
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oPacoteSMS = _proxy.CancelarPacoteSMS(  numeroCartao, 
                                                            codigoPacote, 
                                                            codigoMotivoCancel, 
                                                            codigoAtendente, 
                                                            textoComplementar, 
                                                            origem, 
                                                            channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario);

                return oPacoteSMS;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "CancelarPacoteSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public RetornoConsultaPacoteSMS ConsultarPacotesSMS(string numeroCartao, string chaveRestart, string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRetornoConsultaPacoteSMS = _proxy.ConsultarPacotesSMS( numeroCartao, 
                                                                            chaveRestart, 
                                                                            origem, 
                                                                            channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oRetornoConsultaPacoteSMS;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "ConsultarPacotesSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public RetornoConsultaPacoteSMS ConsultarParametrizacaoPacotesSMS(string codigoLogo, string chaveRestart, string origem, string channel, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRetornoConsultaPacoteSMS = _proxy.ConsultarParametrizacaoPacotesSMS(codigoLogo, 
                                                                                         chaveRestart, 
                                                                                         origem, 
                                                                                         channel, 
                                                                                         codigoLoja, 
                                                                                         nomeUsuario);

                return oRetornoConsultaPacoteSMS;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "ConsultarParametrizacaoPacotesSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public PacoteSMS SubstituirPacotesSMS(string numeroCartao, int codigoPacote, int numeroPacoteFuturo, string codigoAtendente, string textoComplementar, string origem, string channel, 
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oPacoteSMS = _proxy.SubstituirPacotesSMS(numeroCartao, 
                                                             codigoPacote, 
                                                             numeroPacoteFuturo, 
                                                             codigoAtendente, 
                                                             textoComplementar, 
                                                             origem, 
                                                             channel, 
                                                             codigoLogo, 
                                                             codigoLoja, 
                                                             nomeUsuario);

                return oPacoteSMS;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "SubstituirPacotesSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
