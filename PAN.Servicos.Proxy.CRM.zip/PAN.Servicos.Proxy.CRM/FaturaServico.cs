﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Collections.Generic;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;
using PAN.Entidades.CRM.Entidades.Agentes.Interno;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class FaturaServico : IFaturaServico
    {
        private FaturaService.FaturaServicoClient _proxy = new FaturaService.FaturaServicoClient();

        
        public Fatura CancelarSegundaViaFatura(string numeroCartao, DateTime dataExtrato, string codigoAtendente, string textoComplementar, string nomeOrigem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.CancelarSegundaViaFatura( numeroCartao, 
                                                        dataExtrato, 
                                                        codigoAtendente, 
                                                        textoComplementar, 
                                                        nomeOrigem, 
                                                        channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "CancelarSegundaViaFatura", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Fatura ConsultarDetalheFaturaFechada(string numeroCartao, int versaoFatura, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, 
            string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarDetalheFaturaFechada(numeroCartao, 
                                                            versaoFatura, 
                                                            chaveRestart, 
                                                            nomeOrigem, 
                                                            channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarDetalheFaturaFechada", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Fatura ConsultarFaturasAbertas(string numeroCartao, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, 
            string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarFaturasAbertas(  numeroCartao, 
                                                        chaveRestart, 
                                                        nomeOrigem, 
                                                        channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarFaturasAbertas", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Fatura ConsultarResumoFaturaFechada(string numeroCartao, int versaoFatura, string nomeOrigem, string channel, 
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarResumoFaturaFechada( numeroCartao, 
                                                            versaoFatura, 
                                                            nomeOrigem, 
                                                            channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarResumoFaturaFechada", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Fatura SolicitarSegundaViaFatura(string numeroCartao, DateTime dataExtrato, string codigoAcao, string codigoAtendente, string textoComplementar, string nomeOrigem, 
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.SolicitarSegundaViaFatura(numeroCartao, 
                                                        dataExtrato, 
                                                        codigoAcao, 
                                                        codigoAtendente, 
                                                        textoComplementar, 
                                                        nomeOrigem, 
                                                        channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SolicitarSegundaViaFatura", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }


        public ListaParcelamentoFaturaPan ConsultarCancelamentoParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarCancelamentoParcelamentoFatura(channel,
                                                                      codigoLogo,
                                                                      codigoLoja,
                                                                      nomeUsuario,
                                                                      numeroConta,
                                                                      numeroCartao,
                                                                      nomeOrigem);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarCancelamentoParcelamentoFatura", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
        

        public ParcelamentoFatura ConsultarParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarParcelamentoFatura(  channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario, 
                                                            numeroCartao, 
                                                            nomeOrigem);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarParcelamentoFatura", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public ParcelamentoFatura SimularParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao,
            string nomeOrigem, decimal? valorFinanciavel, int numeroParcelas, decimal? valorEntrada, decimal? valorAntecipacao)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.SimularParcelamentoFatura(channel, 
                                                        codigoLogo, 
                                                        codigoLoja, 
                                                        nomeUsuario, 
                                                        numeroCartao,
                                                        nomeOrigem, 
                                                        valorFinanciavel, 
                                                        numeroParcelas, 
                                                        valorEntrada, 
                                                        valorAntecipacao);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SimularParcelamentoFatura", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }

        }

        
        public ParcelamentoFatura EfetivarParcelamentoFatura(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao,
            string nomeOrigem, decimal? valorFinanciavel, int numeroParcelas, decimal? valorEntrada, decimal? valorAntecipacao, string codigoAtendente, string textoComplementar)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.EfetivarParcelamentoFatura(   channel, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            nomeUsuario, 
                                                            numeroCartao,
                                                            nomeOrigem, 
                                                            valorFinanciavel, 
                                                            numeroParcelas, 
                                                            valorEntrada, 
                                                            valorAntecipacao, 
                                                            codigoAtendente, 
                                                            textoComplementar);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "EfetivarParcelamentoFatura", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }

        }

        
        public ListaFatura ConsultarFaturas(string numeroCartao, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                return _proxy.ConsultarFaturas( numeroCartao, 
                                                nomeOrigem, 
                                                channel, 
                                                codigoLogo, 
                                                codigoLoja, 
                                                nomeUsuario);
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarFaturas", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
