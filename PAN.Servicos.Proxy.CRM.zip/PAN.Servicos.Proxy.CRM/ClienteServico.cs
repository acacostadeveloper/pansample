﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ClienteServico : IClienteServico
    {
        private ClienteService.ClienteServicoClient _proxy = new ClienteService.ClienteServicoClient();

        
        public Cliente AlteracaoDadosCliente(Cliente cliente, string codigoLogo, string codigoLoja, string channel, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oCliente = _proxy.AlteracaoDadosCliente(cliente, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            channel, 
                                                            nomeUsuario);

                return oCliente;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "AlteracaoDadosCliente", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Cliente ConsultarDadosCliente(string numeroCliente, string numeroCartao, string numeroCPF, string origem, string codigoLogo, string codigoLoja, string channel, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oCliente = _proxy.ConsultarDadosCliente(numeroCliente, 
                                                            numeroCartao, 
                                                            numeroCPF, 
                                                            origem, 
                                                            codigoLogo, 
                                                            codigoLoja, 
                                                            channel, 
                                                            nomeUsuario);

                return oCliente;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "ConsultarDadosCliente", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
