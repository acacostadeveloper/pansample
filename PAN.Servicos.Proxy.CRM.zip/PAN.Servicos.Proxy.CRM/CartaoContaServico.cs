﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Collections.Generic;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class CartaoContaServico : ICartaoContaServico
    {
        private CartaoContaService.CartaoContaServicoClient _proxy = new CartaoContaService.CartaoContaServicoClient();

        
        public MonetariosCartaoTitular AlterarDadosMonetariosCartaoTitular(string numeroCartao, string nomeOrigem, string descricaoTextoComplementar, string codigoAtendente, int diaVencimentoFatura,
            string flgDebitoContaCorrente, int? codigoBancoDebitoConta, int? codigoAgenciaDebitoConta, string numeroContaCorrenteDebito, int? codigoBancoTelesaque, int? codigoCompensacaoTelesque,
            int? codigoAgenciaTelesaque, string codigoContaTelesaque, decimal valorLimeteCredito, string flgFaturaEmail, DateTime? dataAvisoFatura, DateTime? dataCancelamentoAvisoFaturaEmail, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario, string faturaVirtual, DateTime? dataAdesaoFaturaVirtual, DateTime? dataCancelamentoAvisoFaturaVirtual)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oMonetariosCartaoTitular = _proxy.AlterarDadosMonetariosCartaoTitular(  numeroCartao, 
                                                                                            nomeOrigem, 
                                                                                            descricaoTextoComplementar, 
                                                                                            codigoAtendente, 
                                                                                            diaVencimentoFatura,
                                                                                            flgDebitoContaCorrente, 
                                                                                            codigoBancoDebitoConta, 
                                                                                            codigoAgenciaDebitoConta, 
                                                                                            numeroContaCorrenteDebito, 
                                                                                            codigoBancoTelesaque, 
                                                                                            codigoCompensacaoTelesque,
                                                                                            codigoAgenciaTelesaque, 
                                                                                            codigoContaTelesaque, 
                                                                                            valorLimeteCredito, 
                                                                                            flgFaturaEmail, 
                                                                                            dataAvisoFatura, 
                                                                                            dataCancelamentoAvisoFaturaEmail, 
                                                                                            channel,
                                                                                            codigoLogo, 
                                                                                            codigoLoja, 
                                                                                            nomeUsuario, 
                                                                                            faturaVirtual, 
                                                                                            dataAdesaoFaturaVirtual, 
                                                                                            dataCancelamentoAvisoFaturaVirtual);

                return oMonetariosCartaoTitular;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "AlterarDadosMonetariosCartaoTitular", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public InformacaoCartao ConsultarInformacoesCartao(string numeroCartao, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oInformacaoCartao = _proxy.ConsultarInformacoesCartao(  numeroCartao, 
                                                                            nomeOrigem, 
                                                                            channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oInformacaoCartao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarInformacoesCartao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Cartoes ConsultarCartaoNome(string origem, string cpf, string nomeCliente, string numeroCartaoTitular, string chaveResetart, string codigoLoja, string codigoLogo, string channel, string nomeUsuario)
        {

            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oCartoes = _proxy.ConsultarCartaoNome(  origem, 
                                                            cpf, 
                                                            nomeCliente, 
                                                            numeroCartaoTitular, 
                                                            chaveResetart, 
                                                            codigoLoja, 
                                                            codigoLogo, 
                                                            channel, 
                                                            nomeUsuario);
                return oCartoes;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "ConsultarCartaoNome", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }

        }

        
        public Conta ConsultarInformacoesConta(string numeroCartao, string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oConta = _proxy.ConsultarInformacoesConta(  numeroCartao, 
                                                                origem, 
                                                                channel, 
                                                                codigoLogo, 
                                                                codigoLoja, 
                                                                nomeUsuario);

                return oConta;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "ConsultarInformacoesConta", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public EnvioCartoes ConsultarEnvioCartoes(string numeroCpfCgc, string numeroCartao, int numeroAr, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oEnvioCartoes = _proxy.ConsultarEnvioCartoes(   numeroCpfCgc, 
                                                                    numeroCartao, 
                                                                    numeroAr, 
                                                                    nomeOrigem, 
                                                                    channel, 
                                                                    codigoLogo, 
                                                                    codigoLoja, 
                                                                    nomeUsuario);

                return oEnvioCartoes;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarEnvioCartoes", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public CartaoAdicional IncluirCartaoAdicional(string numeroConta, string nomeEmbossing, string codigoSexoPortador, string flgCobraTarifa, string codigoTipoCartao, string flgDependente,
            decimal? valorLimeiteDependente, string nomeOrigem, string codigoAtendente, string textoComplementar, string flagCartaoVirtual, long numeroUnico, string channel, string codigoLogo,
            string codigoLoja, string nomeUsuario, string codigoLojaVenda, string codigoVendedor, string cpfCartaoAdicional, DateTime? dataNascimentoCartaoAdicional)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oCartaoAdicional = _proxy.IncluirCartaoAdicional(   numeroConta, 
                                                                        nomeEmbossing, 
                                                                        codigoSexoPortador, 
                                                                        flgCobraTarifa, 
                                                                        codigoTipoCartao, 
                                                                        flgDependente,
                                                                        valorLimeiteDependente, 
                                                                        nomeOrigem, 
                                                                        codigoAtendente, 
                                                                        textoComplementar, 
                                                                        flagCartaoVirtual, 
                                                                        numeroUnico, 
                                                                        channel, 
                                                                        codigoLogo,
                                                                        codigoLoja, 
                                                                        nomeUsuario, 
                                                                        codigoLojaVenda, 
                                                                        codigoVendedor, 
                                                                        cpfCartaoAdicional, 
                                                                        dataNascimentoCartaoAdicional);

                return oCartaoAdicional;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "IncluirCartaoAdicional", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public ManterDadosCartao ManterDadosCartao(string numeroCartao, string nomeEmbossing, string codigoSexoPortador, decimal? valorLimiteDependente, string flagCobraTarifa, string codigoAcaoEmbossing,
            int? quantidadeCartoesSolicitados, string nomeOrigem, string codigoAtendente, string textoComplementar, string flagIndicaDependente, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oManterDadosCartao = _proxy.ManterDadosCartao(numeroCartao, 
                                                                    nomeEmbossing, 
                                                                    codigoSexoPortador, 
                                                                    valorLimiteDependente, 
                                                                    flagCobraTarifa, 
                                                                    codigoAcaoEmbossing,
                                                                    quantidadeCartoesSolicitados, 
                                                                    nomeOrigem, 
                                                                    codigoAtendente, 
                                                                    textoComplementar, 
                                                                    flagIndicaDependente, 
                                                                    channel, 
                                                                    codigoLogo, 
                                                                    codigoLoja, 
                                                                    nomeUsuario);

                return oManterDadosCartao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ManterDadosCartao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public CartoesContas ConsultarCartoesConta(string numeroCartao, string nomeOrigem, string chaveRestart, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oCartoesContas = _proxy.ConsultarCartoesConta(  numeroCartao, 
                                                                    nomeOrigem, 
                                                                    chaveRestart, 
                                                                    channel, 
                                                                    codigoLogo, 
                                                                    codigoLoja, 
                                                                    nomeUsuario);

                return oCartoesContas;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarCartoesConta", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public BloqueioDesbloqueioContaCartao BloquearConta(string numeroCartao, string codigoBloqueio, string nomeOrigem, string codigoAtendente, string textoComplementar, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oBloqueioDesbloqueioContaCartao = _proxy.BloquearConta( numeroCartao, 
                                                                            codigoBloqueio, 
                                                                            nomeOrigem, 
                                                                            codigoAtendente, 
                                                                            textoComplementar, 
                                                                            channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);
                return oBloqueioDesbloqueioContaCartao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "BloquearConta", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public BloqueioDesbloqueioContaCartao DesbloquearConta(string numeroCartao, string numeroRgTitular, int tipoDocumento, string documentoTitular, DateTime dataNascimentoTitular, string nomeOrigem, string codigoAtendente, string textoComplementar,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oBloqueioDesbloqueioContaCartao = _proxy.DesbloquearConta(  numeroCartao, 
                                                                                numeroRgTitular, 
                                                                                tipoDocumento, 
                                                                                documentoTitular, 
                                                                                dataNascimentoTitular, 
                                                                                nomeOrigem, 
                                                                                codigoAtendente, 
                                                                                textoComplementar,
                                                                                channel, 
                                                                                codigoLogo, 
                                                                                codigoLoja, 
                                                                                nomeUsuario);

                return oBloqueioDesbloqueioContaCartao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "DesbloquearConta", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public BloqueioDesbloqueioContaCartao BloquearCartao(string numeroCartao, string codigoBloqueio, string nomeOrigem, string codigoAtendente, string textoComplementar, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oBloqueioDesbloqueioContaCartao = _proxy.BloquearCartao(numeroCartao, 
                                                                            codigoBloqueio, 
                                                                            nomeOrigem, 
                                                                            codigoAtendente, 
                                                                            textoComplementar, 
                                                                            channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oBloqueioDesbloqueioContaCartao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "BloquearCartao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public BloqueioDesbloqueioContaCartao DesbloquearCartao(string numeroCartao, string numeroRGTitular, int tipoDocumento, string documentoTitular, DateTime dataNascimentoTitular, string nomeOrigem, string codigoAtendente, string textoComplementar,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oBloqueioDesbloqueioContaCartao = _proxy.DesbloquearCartao( numeroCartao, 
                                                                                numeroRGTitular, 
                                                                                tipoDocumento, 
                                                                                documentoTitular, 
                                                                                dataNascimentoTitular, 
                                                                                nomeOrigem, 
                                                                                codigoAtendente, 
                                                                                textoComplementar,
                                                                                channel, 
                                                                                codigoLogo, 
                                                                                codigoLoja, 
                                                                                nomeUsuario);

                return oBloqueioDesbloqueioContaCartao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "DesbloquearCartao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
