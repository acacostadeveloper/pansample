﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class AutorizacaoServico : IAutorizacaoServico
    {
        private AutorizacaoService.AutorizacaoServicoClient _proxy = new AutorizacaoService.AutorizacaoServicoClient();

        
        public DetalheAutorizacao ConsultarDetalhesAutorizacao(string numeroCartao, DateTime dataHoraAutorizacao, string codigoLogAutorizacao, string codigoIdentificacaoRegistro, string nomeOrigem,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oDetalheAutorizacao = _proxy.ConsultarDetalhesAutorizacao(  numeroCartao, 
                                                                                dataHoraAutorizacao, 
                                                                                codigoLogAutorizacao, 
                                                                                codigoIdentificacaoRegistro, 
                                                                                nomeOrigem,
                                                                                channel, 
                                                                                codigoLogo, 
                                                                                codigoLoja, 
                                                                                nomeUsuario);

                return oDetalheAutorizacao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarDetalhesAutorizacao", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public ListaAutorizacoes ConsultarAutorizacoes(string numeroCartao, DateTime dataInicial, DateTime dataFinal, string codigoRequisicao, string codigoTransacao,
            string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oListaAutorizacoes = _proxy.ConsultarAutorizacoes(  numeroCartao, 
                                                                        dataInicial, 
                                                                        dataFinal, 
                                                                        codigoRequisicao, 
                                                                        codigoTransacao,
                                                                        chaveRestart, 
                                                                        nomeOrigem, 
                                                                        channel, 
                                                                        codigoLogo, 
                                                                        codigoLoja, 
                                                                        nomeUsuario);
                return oListaAutorizacoes;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarAutorizacoes", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

    }
}
