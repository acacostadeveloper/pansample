﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class AtendimentoServico : IAtendimentoServico
    {
        private AtendimentoService.AtendimentoServicoClient _proxy = new AtendimentoService.AtendimentoServicoClient();

        
        public RegistroAtendimento ConsultarRegistroAtendimentoNumeroCaso(string numeroCartao, string numeroCaso, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRegistroAtendimento = _proxy.ConsultarRegistroAtendimentoNumeroCaso(  numeroCartao, 
                                                                                            numeroCaso, 
                                                                                            chaveRestart, 
                                                                                            nomeOrigem, 
                                                                                            channel, 
                                                                                            codigoLogo, 
                                                                                            codigoLoja, 
                                                                                            nomeUsuario);

                return oRegistroAtendimento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarRegistroAtendimentoNumeroCaso", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public RegistroAtendimento ConsultarRegistroAtendimentoPeriodo(string numeroCartao, DateTime dataInicio, DateTime dataFim, string chaveRestart, string nomeOrigem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRegistroAtendimento = _proxy.ConsultarRegistroAtendimentoPeriodo(  numeroCartao, 
                                                                                        dataInicio, 
                                                                                        dataFim, 
                                                                                        chaveRestart, 
                                                                                        nomeOrigem, 
                                                                                        channel, 
                                                                                        codigoLogo, 
                                                                                        codigoLoja, 
                                                                                        nomeUsuario);

                return oRegistroAtendimento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarRegistroAtendimentoPeriodo", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public AcaoAtendimento ConsultarAcoesAtendimento(string acao, string origem, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oAcaoAtendimento = _proxy.ConsultarAcoesAtendimento(acao, 
                                                                        origem, 
                                                                        channel, 
                                                                        codigoLogo, 
                                                                        codigoLoja, 
                                                                        nomeUsuario);

                return oAcaoAtendimento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(origem, "ConsultarAcoesAtendimento", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public RegistroAtendimento IncluirResgistroAtendimento(string numeroCartao, string codigoAcao, string codigoSequenciaAcao, DateTime dataHoraEnvioSolicitacao,
            string descricaoHitorico1, string descricaoHitorico2, string descricaoHistorico3, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRegistroAtendimento = _proxy.IncluirResgistroAtendimento(  numeroCartao, 
                                                                                codigoAcao, 
                                                                                codigoSequenciaAcao, 
                                                                                dataHoraEnvioSolicitacao,
                                                                                descricaoHitorico1, 
                                                                                descricaoHitorico2, 
                                                                                descricaoHistorico3, 
                                                                                channel, 
                                                                                codigoLogo, 
                                                                                codigoLoja, 
                                                                                nomeUsuario);

                return oRegistroAtendimento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "IncluirResgistroAtendimento", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

    }
}
