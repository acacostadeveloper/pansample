﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class TelefoneListaServico : ITelefoneListaServico
    {
        TelefoneListaService.TelefoneListaServicoClient _proxy = new TelefoneListaService.TelefoneListaServicoClient();

        
        public Telefones ConsultarDadosListaBranca(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTelefones = _proxy.ConsultarDadosListaBranca(numeroDDI, 
                                                                  numeroDDD, 
                                                                  numeroTelefone, 
                                                                  channel, 
                                                                  codigoLogo, 
                                                                  codigoLoja, 
                                                                  nomeUsuario);

                return oTelefones;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "ConsultarDadosListaBranca", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Telefone IncluirDadosListaBranca(int numeroDDI, int numeroDDD, string numeroTelefone, DateTime? dataHora, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTelefone = _proxy.IncluirDadosListaBranca(numeroDDI, 
                                                               numeroDDD, 
                                                               numeroTelefone, 
                                                               dataHora, 
                                                               channel, 
                                                               codigoLogo, 
                                                               codigoLoja, 
                                                               nomeUsuario);

                return oTelefone;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "IncluirDadosListaBranca", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Telefone ExcluirDadosListaBranca(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTelefone = _proxy.ExcluirDadosListaBranca(numeroDDI, 
                                                               numeroDDD, 
                                                               numeroTelefone, 
                                                               channel, 
                                                               codigoLogo, 
                                                               codigoLoja, 
                                                               nomeUsuario);

                return oTelefone;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "ExcluirDadosListaBranca", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Telefones ConsultarDadosListaNegra(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTelefones = _proxy.ConsultarDadosListaNegra(numeroDDI, 
                                                                 numeroDDD, 
                                                                 numeroTelefone, 
                                                                 channel, 
                                                                 codigoLogo, 
                                                                 codigoLoja, 
                                                                 nomeUsuario);

                return oTelefones;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "ConsultarDadosListaNegra", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Telefone IncluirDadosListaNegra(int numeroDDI, int numeroDDD, string numeroTelefone, DateTime? dataHora, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTelefone = _proxy.IncluirDadosListaNegra(numeroDDI, 
                                                              numeroDDD, 
                                                              numeroTelefone, 
                                                              dataHora, 
                                                              channel, 
                                                              codigoLogo, 
                                                              codigoLoja, 
                                                              nomeUsuario);

                return oTelefone;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "IncluirDadosListaNegra", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Telefone ExcluirDadosListaNegra(int numeroDDI, int numeroDDD, string numeroTelefone, string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oTelefone = _proxy.ExcluirDadosListaNegra(numeroDDI, 
                                                              numeroDDD, 
                                                              numeroTelefone, 
                                                              channel, 
                                                              codigoLogo, 
                                                              codigoLoja, 
                                                              nomeUsuario);

                return new Telefone();
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("", "ExcluirDadosListaNegra", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
