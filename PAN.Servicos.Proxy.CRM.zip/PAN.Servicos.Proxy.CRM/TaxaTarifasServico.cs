﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class TaxaTarifasServico : ITaxaTarifasServico
    {
        TaxaTarifasService.TaxaTarifasServicoClient _proxy = new TaxaTarifasService.TaxaTarifasServicoClient();

        
        public ParametrosTaxasTarifas ConsultarTaxasTarifas(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string tarifaSaquePCT, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oParametrosTaxasTarifas = _proxy.ConsultarTaxasTarifas(channel, 
                                                                           codigoLogo, 
                                                                           codigoLoja, 
                                                                           nomeUsuario, 
                                                                           tarifaSaquePCT, 
                                                                           nomeOrigem);

                return oParametrosTaxasTarifas;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SubstituirPacotesSMS", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
