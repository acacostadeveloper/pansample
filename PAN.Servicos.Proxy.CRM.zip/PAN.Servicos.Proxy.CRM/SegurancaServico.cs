﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;
using PAN.Servicos.Proxy.CRM.Helper;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class SegurancaServico : ISegurancaServico
    {
        public string GetToken(string userName, string password)
        {
            try
            {
                string usr = CryptographyHelper.EncryptString(CryptographyHelper.DecryptString(userName, CryptographyHelper.KeyType.PublicKey), CryptographyHelper.KeyType.PrivateKey);
                string pwd = CryptographyHelper.EncryptString(CryptographyHelper.DecryptString(password, CryptographyHelper.KeyType.PublicKey), CryptographyHelper.KeyType.PrivateKey);

                string issued = UnixDateTimeHelper.GetIntDate(DateTime.Now).ToString();
                string expire = UnixDateTimeHelper.GetIntDate(DateTime.Now.AddMinutes(120)).ToString();

                var payload = new Dictionary<string, object>()
                {
                    {"aud", WebConfigurationManager.AppSettings["Audience"]},  
                    {"usr", usr},
                    {"pwd", pwd},
                    {"iat", issued},
                    {"exp", expire}
                };

                string token = JsonWebToken.Encode(payload, WebConfigurationManager.AppSettings["PrivateKey"], JwtHashAlgorithm.RS256);

                token = CryptographyHelper.EncryptString(token, CryptographyHelper.KeyType.PrivateKey);

                return token;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado("Unknow", "GetToken", ex.Message, 3, userName, DateTime.Now);
                throw ex;
            }
        }
    }
}
