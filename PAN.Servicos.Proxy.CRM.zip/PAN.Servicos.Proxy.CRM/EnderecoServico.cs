﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.Dados.Cep.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class EnderecoServico : IEnderecoServico
    {
        private EnderecoService.EnderecoServicoClient _proxy = new EnderecoService.EnderecoServicoClient();

        
        public EnderecoDTO BuscarPorCep(string cep, string nomeUsuarioCRM)
        {
            var oEnderecoDTO = new EnderecoDTO();
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                oEnderecoDTO = _proxy.BuscarPorCep(cep, nomeUsuarioCRM);

                return oEnderecoDTO;
            }
            catch (Exception ex)
            {
                oEnderecoDTO.StatusSucesso = false;
                oEnderecoDTO.MensagemRetorno = ex.Message;
                Log.Configurar();
                Log.InfoErroCertificado("", "BuscarPorCep", ex.Message, 3, nomeUsuarioCRM, DateTime.Now);
                return oEnderecoDTO;
            }

        }

        
        public EnderecoDTO BuscarPorNomeDaRua(string nomeRua, string nomeUsuarioCRM)
        {
            var oEnderecoDTO = new EnderecoDTO();
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                oEnderecoDTO = _proxy.BuscarPorNomeDaRua(nomeRua, nomeUsuarioCRM);

                return oEnderecoDTO;
            }
            catch (Exception ex)
            {
                oEnderecoDTO.StatusSucesso = false;
                oEnderecoDTO.MensagemRetorno = ex.Message;
                Log.Configurar();
                Log.InfoErroCertificado("", "BuscarPorNomeDaRua", ex.Message, 3, nomeUsuarioCRM, DateTime.Now);
                return oEnderecoDTO;
            }
        }
    }
}
