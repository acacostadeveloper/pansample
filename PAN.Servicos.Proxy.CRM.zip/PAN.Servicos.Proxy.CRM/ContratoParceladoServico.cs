﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using System.Collections.Generic;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class ContratoParceladoServico : IContratoParceladoServico
    {
        private ContratoParceladoService.ContratoParceladoServicoClient _proxy = new ContratoParceladoService.ContratoParceladoServicoClient();

        
        public ContratoParcelado ManterContratosParcelados(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroConta, string numeroCartao, Int64 numeroContrato, DateTime? dataVencimentoParcela, string tipoManutencao, string funcaoSolicitada,
            int motivoCancelamento, string codigoAtendente, string textoComplementar, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oContratoParcelado = _proxy.ManterContratosParcelados(  channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario, 
                                                                            numeroConta, 
                                                                            numeroCartao, 
                                                                            numeroContrato, 
                                                                            dataVencimentoParcela, 
                                                                            tipoManutencao, 
                                                                            funcaoSolicitada,
                                                                            motivoCancelamento, 
                                                                            codigoAtendente, 
                                                                            textoComplementar, 
                                                                            nomeOrigem);

                return oContratoParcelado;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ManterContratosParcelados", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
