﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class FinanciamentoServico : IFinanciamentoServico
    {
        FinanciamentoService.FinanciamentoServicoClient _proxy = new FinanciamentoService.FinanciamentoServicoClient();

        
        public Financiamento ConsultarListaContratosAtivos(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oFinanciamento = _proxy.ConsultarListaContratosAtivos(  numeroCartao, 
                                                                            chaveRestart, 
                                                                            nomeOrigem, 
                                                                            channel,
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oFinanciamento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarListaContratosAtivos", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Financiamento ConsultarListaContratosInativos(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oFinanciamento = _proxy.ConsultarListaContratosInativos(numeroCartao, 
                                                                            chaveRestart, 
                                                                            nomeOrigem, 
                                                                            channel,
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oFinanciamento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarListaContratosInativos", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Financiamento ConsultarListaTodosContratos(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oFinanciamento = _proxy.ConsultarListaTodosContratos(   numeroCartao, 
                                                                            chaveRestart, 
                                                                            nomeOrigem, 
                                                                            channel,
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oFinanciamento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarListaTodosContratos", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Financiamento ConsultarDetalhesFinanciamento(string numeroCartao, string chaveRestart, string nomeOrigem, long numeroFinanciamento,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oFinanciamento = _proxy.ConsultarDetalhesFinanciamento( numeroCartao, 
                                                                            chaveRestart, 
                                                                            nomeOrigem, 
                                                                            numeroFinanciamento,
                                                                            channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oFinanciamento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarDetalhesFinanciamento", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Financiamento ConsultarParcelasFinanciamento(string numeroCartao, string chaveRestart, string nomeOrigem, long numeroFinanciamento,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oFinanciamento = _proxy.ConsultarParcelasFinanciamento( numeroCartao, 
                                                                            chaveRestart, 
                                                                            nomeOrigem, 
                                                                            numeroFinanciamento,
                                                                            channel, 
                                                                            codigoLogo, 
                                                                            codigoLoja, 
                                                                            nomeUsuario);

                return oFinanciamento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarParcelasFinanciamento", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
