﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class InclusaoDadosUraServico : IInclusaoDadosUraServico
    {
        private InclusaoDadosUraService.InclusaoDadosUraServicoClient _proxy = new InclusaoDadosUraService.InclusaoDadosUraServicoClient();

        
        public RegistroInclusaoDadosURA IncluirDadosURA(string nomeOrigem, string nomeUsuario, string numeroCartao, string numeroTelefone, int numeroDDI, int numeroDDD, int idEvento, string flagTelefone, int callId, DateTime data, double valorLimiteDeCredito)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRegistroInclusaoDadosURA = _proxy.IncluirDadosURA( nomeOrigem, 
							                                            nomeUsuario, 
							                                            numeroCartao, 
							                                            numeroTelefone, 
							                                            numeroDDI, 
							                                            numeroDDD, 
							                                            idEvento, 
							                                            flagTelefone, 
							                                            callId, 
							                                            data, 
							                                            valorLimiteDeCredito);

                return oRegistroInclusaoDadosURA ;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "IncluirDadosURA", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }
    }
}
