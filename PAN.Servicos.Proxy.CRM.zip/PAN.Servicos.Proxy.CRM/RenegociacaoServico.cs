﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using log4net;
using PAN.Servicos.Contrato.CRM;
using PAN.Entidades.CRM;
using PAN.Infra.Logger.CRM;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using PAN.Infra.Helpers.CRM;

namespace PAN.Servicos.Proxy.CRM
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class RenegociacaoServico : IRenegociacaoServico
    {
        private RenegociacaoService.RenegociacaoServicoClient _proxy = new RenegociacaoService.RenegociacaoServicoClient();

        
        public ParcelamentoFatura ConsultarDetalhesSolicParcFaturaReneDivida(string numeroCartao, long numeroSolicitacao, string nomeOrigem,
            string channel, string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oParcelamentoFatura = _proxy.ConsultarDetalhesSolicParcFaturaReneDivida(numeroCartao, 
                                                                                            numeroSolicitacao, 
                                                                                            nomeOrigem,
                                                                                            channel, 
                                                                                            codigoLogo, 
                                                                                            codigoLoja, 
                                                                                            nomeUsuario);

                return oParcelamentoFatura;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarDetalhesSolicParcFaturaReneDivida", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Parcelamento ConsultarListaSolicParcFaturaReneDivida(string numeroCartao, string chaveRestart, string nomeOrigem, string channel,
            string codigoLogo, string codigoLoja, string nomeUsuario)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oParcelamento = _proxy.ConsultarListaSolicParcFaturaReneDivida(numeroCartao, 
                                                                                   chaveRestart, 
                                                                                   nomeOrigem, 
                                                                                   channel,
                                                                                   codigoLogo, 
                                                                                   codigoLoja, 
                                                                                   nomeUsuario);

                return oParcelamento;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarListaSolicParcFaturaReneDivida", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Renegociacao ConsultarRenegociacaoDivida(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRenegociacao = _proxy.ConsultarRenegociacaoDivida(channel, 
                                                                       codigoLogo, 
                                                                       codigoLoja, 
                                                                       nomeUsuario, 
                                                                       numeroCartao, 
                                                                       nomeOrigem);

                return oRenegociacao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "ConsultarRenegociacaoDivida", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }
        }

        
        public Renegociacao SimularRenegociacaoDivida(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem,
             decimal valorSolicitado, int numeroParcelas, decimal valorEntrada)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRenegociacao = _proxy.SimularRenegociacaoDivida(   channel, 
                                                                        codigoLogo, 
                                                                        codigoLoja, 
                                                                        nomeUsuario, 
                                                                        numeroCartao, 
                                                                        nomeOrigem,
                                                                        valorSolicitado, 
                                                                        numeroParcelas, 
                                                                        valorEntrada);

                return oRenegociacao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "SimularRenegociacaoDivida", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }

        }

        
        public Renegociacao EfetivarRenegociacaoDivida(string channel, string codigoLogo, string codigoLoja, string nomeUsuario, string numeroCartao, string nomeOrigem,
            string codigoAtentende, string textoComplementar, decimal valorSolicitado, int numeroParcelas, decimal valorEntrada)
        {
            try
            {
                string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

                auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

                PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper aut = new PAN.Servicos.Proxy.CRM.Helper.AuthorizeHelper();
                aut.Authorize(auth);

                var oRenegociacao = _proxy.EfetivarRenegociacaoDivida(  channel, 
                                                                        codigoLogo, 
                                                                        codigoLoja, 
                                                                        nomeUsuario, 
                                                                        numeroCartao, 
                                                                        nomeOrigem,
                                                                        codigoAtentende, 
                                                                        textoComplementar, 
                                                                        valorSolicitado, 
                                                                        numeroParcelas, 
                                                                        valorEntrada);

                return oRenegociacao;
            }
            catch (Exception ex)
            {
                Log.Configurar();
                Log.InfoErroCertificado(nomeOrigem, "EfetivarRenegociacaoDivida", ex.Message, 3, nomeUsuario, DateTime.Now);
                throw ex;
            }

        }
    }
}
