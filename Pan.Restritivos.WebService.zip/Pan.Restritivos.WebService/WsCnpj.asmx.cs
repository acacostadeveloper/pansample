﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de CNPJ
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/wscnpj/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsCnpj : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(Cnpj))]
        public Cnpj Obter(string nrCnpj)
        {
            try
            {
                BllCnpj _bll = new BllCnpj();
                Cnpj _Cnpj = new Cnpj();
                _Cnpj.nrCnpj = nrCnpj;

                return _bll.Obter(_Cnpj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
