﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Data.SqlClient;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de Telefone
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/WsTelefone/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsTelefone : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(Telefone))]
        public Telefone Obter(int nrTelefone, int nrDDD)
        {
            try
            {
                BllTelefone _bll = new BllTelefone();
                Telefone _Telefone = new Telefone();
                _Telefone.nrTelefone = nrTelefone;
                _Telefone.nrDDD = nrDDD;

                return _bll.Obter(_Telefone);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
