﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Data.SqlClient;
using System.Xml.Serialization;
using System.Web.Services.Protocols;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de CPF
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/wscpf/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsCpf : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(Cpf))]
        public Cpf Obter(string nrCpf)
        {
            try
            {
                BllCpf _bll = new BllCpf();
                Cpf _cpf = new Cpf();
                _cpf.nrCpf = nrCpf;
                return _bll.Obter(_cpf);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
