﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de Código de barra
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/WsCodigoBarra/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsCodigoBarra : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(CodigoBarra))]
        public CodigoBarra Obter(string codBarra)
        {
            try
            {
                BllCodigoBarra _bll = new BllCodigoBarra();
                CodigoBarra _CodigoBarra = new CodigoBarra();
                _CodigoBarra.codBarra = codBarra;

                return _bll.Obter(_CodigoBarra);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
