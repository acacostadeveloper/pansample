﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Data.SqlClient;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de Endereço
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/WsEndereco/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsEndereco : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(Endereco))]
        public Endereco Obter(string nrCEP, string nrEndereco, string txComplemento)
        {
            try
            {
                BllEndereco _bll = new BllEndereco();
                Endereco _Endereco = new Endereco();
                _Endereco.nrCEP = nrCEP;
                _Endereco.nrEndereco = nrEndereco;
                _Endereco.txComplemento = txComplemento;

                return _bll.Obter(_Endereco);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
