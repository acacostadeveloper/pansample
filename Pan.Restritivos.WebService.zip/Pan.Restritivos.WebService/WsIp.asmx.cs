﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Data.SqlClient;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de IP
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/WsIp/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsIp : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(Ip))]
        public Ip Obter(string nrIP)
        {
            try
            {
                BllIp _bll = new BllIp();
                Ip _Ip = new Ip();
                _Ip.nrIP = nrIP;                

                return _bll.Obter(_Ip);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
