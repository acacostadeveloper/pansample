﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Data.SqlClient;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de Linha digitável
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/WsLinhaDigitavel/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsLinhaDigitavel : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(LinhaDigitavel))]
        public LinhaDigitavel Obter(string nrLinhaDigitavel)
        {
            try
            {
                BllLinhaDigitavel _bll = new BllLinhaDigitavel();
                LinhaDigitavel _LinhaDigitavel = new LinhaDigitavel();
                _LinhaDigitavel.nrLinhaDigitavel = nrLinhaDigitavel;

                return _bll.Obter(_LinhaDigitavel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
