﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Pan.Restritivos.Business.Concrete;
using Pan.Restritivos.Model.Sistema;
using System.Data.SqlClient;
using System.Xml.Serialization;

namespace Pan.Restritivos.WebService
{
    /// <summary>
    /// WebService que expõe mêtodo de consulta a base de Dado Bancário
    /// Utilizado por sistemas internos
    /// </summary>
    [WebService(Namespace = "http://restritivos.bancopan.com.br/WsDadoBancario/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class WsDadoBancario : System.Web.Services.WebService
    {
        [WebMethod]
        [XmlInclude(typeof(DadoBancario))]
        public DadoBancario Obter(int nrAgencia, int nrBanco, int nrConta)
        {
            try
            {
                BllDadoBancario _bll = new BllDadoBancario();
                DadoBancario _DadoBancario = new DadoBancario();
                _DadoBancario.nrAgencia = nrAgencia;
                _DadoBancario.nrBanco = nrBanco;
                _DadoBancario.nrConta = nrConta;

                return _bll.Obter(_DadoBancario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
