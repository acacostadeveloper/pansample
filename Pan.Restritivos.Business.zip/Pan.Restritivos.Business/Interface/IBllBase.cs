﻿using Pan.Restritivos.Model.Configuracao;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Interface
{
    /// <summary>
    /// Interface genérica para definição do gerenciamento de bases restritivos  
    /// </summary>
    /// <typeparam name="T">Entidade utlizada pela classe que impementa a interface</typeparam>
    public interface IBllBase<T>
    {
        T Alterar(T item);
        List<T> Importar(Arquivo item);
        bool Inativar(T item);
        T Inserir(T item);
        List<T> Listar(T item);
        List<T> ListarLog(int id);
        T Obter(T item );
        bool Validar(T item);
        bool ValidarImportacao(T item);
    }
}
