﻿using Pan.Restritivos.Model;
using Pan.Restritivos.Model.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de Token.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllToken
    {
        private String _keyCrypto;
        BllUsuario ibllusuario;
       
        public BllToken() 
        {
            ibllusuario = new BllUsuario();
            _keyCrypto = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");
        }
    }
}
