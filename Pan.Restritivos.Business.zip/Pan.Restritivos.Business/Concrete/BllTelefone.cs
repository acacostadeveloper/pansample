﻿using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Business.Utils;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de telefone.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllTelefone : IBllBase<Telefone>
    {
        DalTelefone _repository;

        List<Motivo> listaMotivo;
        List<Peso> listaPeso;

        public BllTelefone()
        {
            _repository = new DalTelefone();
        }


        public Telefone Alterar(Telefone item)
        {
            try
            {
                item.dtManutencao = DateTime.Now;
                return _repository.Alterar(item);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Telefone> Importar(Arquivo item)
        {

            List<Telefone> list = new List<Telefone>();
            try
            {

                ExcelManagement<Telefone> obj = new ExcelManagement<Telefone>();
                list = obj.read(item);
                if (list.Count > 0)
                {
                    DalMotivoAlerta _dalMotivo = new DalMotivoAlerta();
                    DalPesoAlerta _dalPeso = new DalPesoAlerta();
                    this.listaMotivo = _dalMotivo.Listar(new Motivo());
                    this.listaPeso = _dalPeso.Listar(new Peso());

                    list.ForEach(x =>
                    {
                        x.idUsuarioManutencao = item.idUsuarioManutencao;
                        x.nmUsuarioManutencao = item.NomeUsuario;
                        x.dtManutencao = DateTime.Now;
                        this.ValidarImportacao(x);
                        if (string.IsNullOrEmpty(x.txErro))
                            this.Inserir(x);
                    });
                }
                else
                    throw new customException("Arquivo vazio");
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return list;
        }
       

        public bool Inativar(Telefone item)
        {
            try
            {
                return _repository.Inativar(item);
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Telefone Inserir(Telefone item)
        {
            try
            {
                item.blnAtivo = true;
                if (Validar(item) == false)
                {
                    return item = _repository.Inserir(item);
                }

                return item;

            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Telefone> Listar(Telefone item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Telefone> ListarLog(int id)
        {
            try
            {
                return _repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Telefone Obter(Telefone item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Telefone item)
        {
            bool ret = false;
            try
            {
                DalTelefone _dalTelefone = new DalTelefone();

                if (_dalTelefone.Validar(item) == true)
                {
                    ret = true;
                }
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(Telefone item)
        {
            bool ret = true;
            try
            {

                if (!String.IsNullOrEmpty(item.codMotivo))
                {
                    Motivo _motivo = this.listaMotivo.Select(x => x).Where(x => x.codMotivo == item.codMotivo).FirstOrDefault();
                    if (_motivo == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Motivo não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idMotivo = _motivo.idMotivo;
                        item.txMotivo = _motivo.txMotivo;
                    }
                }
                //3 - validar peso
                if (!String.IsNullOrEmpty(item.codPeso))
                {
                    Peso _peso = this.listaPeso.Select(x => x).Where(x => x.codPeso == item.codPeso).FirstOrDefault();
                    if (_peso == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Peso não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idPeso = _peso.idPeso;
                        item.txPeso = _peso.txPeso;
                    }
                }


                if (string.IsNullOrEmpty(item.txErro))
                {
                    if (this.Validar(item) == true)
                    {
                        item.bnlErro = true;
                        item.txErro += "Telefone já cadastrado na base" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaInicio.Date < DateTime.Now.Date)
                    {
                        item.bnlErro = true;
                        item.txErro += "Data inicio não pode menor que a data atual" + Environment.NewLine;
                        ret = false;
                    }
                    //4 - validar datas
                    if (item.dtVigenciaFim != DateTime.MinValue)
                    {
                        if (item.dtVigenciaInicio > item.dtVigenciaFim)
                        {
                            item.bnlErro = true;
                            item.txErro += "Data inicio maior que data fim" + Environment.NewLine;
                            ret = false;
                        }

                    }
                    else { ret = false; }
                }

            }
            catch (Exception ex)
            {                
                throw ex;
            }

            return ret;
        }
    }
}
