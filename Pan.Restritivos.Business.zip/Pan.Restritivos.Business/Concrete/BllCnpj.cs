﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

using Excel;
using System.Data;
using System.Text.RegularExpressions;
using Pan.Restritivos.Business.Utils;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de CNPJ.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllCnpj : IBllBase<Cnpj>
    {
        DalCnpj _repository;

        List<Motivo> listaMotivo;
        List<Peso> listaPeso;

        public BllCnpj()
        {
            _repository = new DalCnpj();
        }


        public Cnpj Alterar(Cnpj item)
        {
            try
            {
                item.dtManutencao = DateTime.Now;
                return _repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Cnpj> Importar(Arquivo item)
        {

            List<Cnpj> list = new List<Cnpj>(); ;
            try
            {
                ExcelManagement<Cnpj> obj = new ExcelManagement<Cnpj>();
                list = obj.read(item);
                if (list.Count > 0)
                {

                    DalMotivoAlerta _dalMotivo = new DalMotivoAlerta();
                    DalPesoAlerta _dalPeso = new DalPesoAlerta();
                    this.listaMotivo = _dalMotivo.Listar(new Motivo());
                    this.listaPeso = _dalPeso.Listar(new Peso());

                    list.ForEach(x =>
                    {
                        x.idUsuarioManutencao = item.idUsuarioManutencao;
                        x.nmUsuarioManutencao = item.NomeUsuario;
                        x.dtManutencao = DateTime.Now;
                        this.ValidarImportacao(x);
                        if (string.IsNullOrEmpty(x.txErro))
                            this.Inserir(x);
                    });
                }
                else
                    throw new customException("Arquivo vazio");
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return list;
        }

        public bool Inativar(Cnpj item)
        {
            try
            {
                return _repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Cnpj Inserir(Cnpj item)
        {
            try
            {
                item.blnAtivo = true;
                return _repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Cnpj> Listar(Cnpj item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Cnpj> ListarLog(int id)
        {
            try
            {
                return _repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Cnpj Obter(Cnpj item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Cnpj item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Cnpj item)
        {
            bool ret = true;
            try
            {

                if (!String.IsNullOrEmpty(item.codMotivo))
                {
                    Motivo _motivo = this.listaMotivo.Select(x => x).Where(x => x.codMotivo == item.codMotivo).FirstOrDefault();
                    if (_motivo == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Motivo não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idMotivo = _motivo.idMotivo;
                        item.txMotivo = _motivo.txMotivo;
                    }
                }

                if (!String.IsNullOrEmpty(item.codPeso))
                {
                    Peso _peso = this.listaPeso.Select(x => x).Where(x => x.codPeso == item.codPeso).FirstOrDefault();
                    if (_peso == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Peso não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idPeso = _peso.idPeso;
                        item.txPeso = _peso.txPeso;
                    }
                }

                if (String.IsNullOrEmpty(item.txErro))
                {

                    //1 - validar Cnpj existe
                    DalCnpj _dalCnpj = new DalCnpj();
                    if (_dalCnpj.Obter(new Cnpj() { nrCnpj = item.nrCnpj }) != null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Cnpj já cadastrado na base" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaInicio.Date < DateTime.Now.Date)
                    {
                        item.bnlErro = true;
                        item.txErro += "Data inicio não pode ser menor que a data atual" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaFim != DateTime.MinValue)
                        if (item.dtVigenciaInicio > item.dtVigenciaFim)
                        {
                            item.bnlErro = true;
                            item.txErro += "Data inicio maior que data fim" + Environment.NewLine;
                            ret = false;
                        }
                }
                else
                    ret = false;
            }
            catch (Exception ex)
            {                
                throw ex;
            }

            return ret;
        }
    }
}
