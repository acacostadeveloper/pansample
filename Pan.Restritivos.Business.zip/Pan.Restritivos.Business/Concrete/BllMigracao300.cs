﻿using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model.Configuracao;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Calsse negócio que define metôdos para importação de base 300
    /// </summary>
    public class BllMigracao300
    {
        DalMigracao300 _dal;

        public BllMigracao300()
        {
            _dal = new DalMigracao300();
        }

        public bool Processar()
        {
            int countRestritivos = 0;
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.AppendLine("Iniciando processamento: " + DateTime.Now.ToString());
                
                //Buscando registros na base 300
                _dal.OpenConnection(ConfigurationManager.ConnectionStrings["base300"].ConnectionString);
                  
                List<Migracao300> list = _dal.BuscarBase();

                _dal.CloseConnection();

                _dal.OpenConnection(ConfigurationManager.ConnectionStrings["baseRestritivos"].ConnectionString);
                sb.AppendLine("Quantidade de resgistros encontrados na base 300: " + list.Count.ToString());

                //Salvando na tabela temporaria para tratar os registros
                _dal.OpenTransaction();             
                foreach (var item in list)
                {
                    _dal.ImportarBase(item);
                }                

                //Tratar e salvar os registros na base de Restritivos 
                countRestritivos = _dal.SalvarImportcao();
                sb.AppendLine("Quantidade de resgistros salvos na base de restritivos: " + countRestritivos.ToString());
                _dal.CommitTransaction();
                _dal.CloseConnection();
                sb.AppendLine("Processamento finalizado com sucesso: " + DateTime.Now.ToString());
                return true;
            }
            catch (Exception ex)
            {
                _dal.RoolbackTransaction();
                _dal.CloseConnection();
                SalvarErro(ex);
                throw ex;
            }
        }

        public static void SalvarLog(string str)
        {
            var diretorio = ConfigurationManager.AppSettings["pathLog"].ToString();
            string nomeArq;

            nomeArq = "Log_" + DateTime.Now.ToString("yyyyMMdd_HHmmss").ToString();

            if (!System.IO.Directory.Exists(diretorio))
                System.IO.Directory.CreateDirectory(diretorio);

            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(diretorio + nomeArq + ".txt", true))
            {
                sw.WriteLine(str);
                sw.Flush();
                sw.Close();
            }
        }

        public static void SalvarErro(Exception ex)
        {
            var diretorioUpload = ConfigurationManager.AppSettings["pathLog"].ToString();
            string nomeArq = DateTime.Now.ToString("yyyyMMdd");

            if (!System.IO.Directory.Exists(diretorioUpload))
                System.IO.Directory.CreateDirectory(diretorioUpload);

            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(diretorioUpload + nomeArq + ".txt", true))
            {

                sw.WriteLine(Environment.NewLine + "============================ Exception ============================");

                sw.WriteLine("Message: " + ex.Message);
                sw.WriteLine("Source: " + ex.Source);
                sw.WriteLine("StackTrace: " + ex.StackTrace);
                sw.Flush();
                sw.Close();
            }
        }

    }
}
