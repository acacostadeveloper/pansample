﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

using Excel;
using System.Data;
using System.Text.RegularExpressions;
using Pan.Restritivos.Business.Utils;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de CPF.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllCpf : IBllBase<Cpf>
    {
        DalCpf _repository;

        List<Motivo> listaMotivo;
        List<Peso> listaPeso;

        public BllCpf()
        {
            _repository = new DalCpf();
        }


        public Cpf Alterar(Cpf item)
        {
            try
            {
                item.dtManutencao = DateTime.Now;
                return _repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Cpf> Importar(Arquivo item)
        {
            Log.salvar("bll.Importar");
            List<Cpf> list = new List<Cpf>();
            try
            {

                ExcelManagement<Cpf> obj = new ExcelManagement<Cpf>();
                list = obj.read(item);

                Log.salvar("bll.Importar - list.count" + list.Count.ToString());

                if (list.Count > 0)
                {
                    DalMotivoAlerta _dalMotivo = new DalMotivoAlerta();
                    DalPesoAlerta _dalPeso = new DalPesoAlerta();
                    this.listaMotivo = _dalMotivo.Listar(new Motivo());
                    this.listaPeso = _dalPeso.Listar(new Peso());

                    foreach (var it in list)
                    {
                        Log.salvar(JsonConvert.SerializeObject(it));
                    }

                    foreach (var x in list)
                    {   
                        x.idUsuarioManutencao = item.idUsuarioManutencao;
                        x.nmUsuarioManutencao = item.NomeUsuario;
                        x.dtManutencao = DateTime.Now;
                        this.ValidarImportacao(x);
                        if (string.IsNullOrEmpty(x.txErro))
                            this.Inserir(x);
                    }
                }
                else
                    throw new customException("Arquivo vazio");
            }
            catch (customException ex)
            {
                Log.salvar(ex);
                throw ex;
            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
            return list;
        }

        public bool Inativar(Cpf item)
        {
            try
            {

                return _repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Cpf Inserir(Cpf item)
        {
            try
            {
                if (Validar(item))
                {
                    item.blnAtivo = true;
                    item = _repository.Inserir(item);
                }

                return item;
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Cpf> Listar(Cpf item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Cpf> ListarLog(int id)
        {
            try
            {
                return _repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Cpf Obter(Cpf item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Cpf item)
        {
            bool ret = true;
            try
            {
                DalCpf _dalCpf = new DalCpf();

                if (_dalCpf.Obter(new Cpf() { nrCpf = item.nrCpf }) != null)
                {
                    ret = false;
                    throw new customException("Cpf já cadastrado na base");
                }

                if (Validacao.validarCpf(item.nrCpf) == false)
                {
                    ret = false;
                    throw new customException("Cpf inválido");
                }
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(Cpf item)
        {
            bool ret = true;

            try
            {
                if (!String.IsNullOrEmpty(item.codMotivo))
                {
                    Motivo _motivo = this.listaMotivo.Select(x => x).Where(x => x.codMotivo == item.codMotivo).FirstOrDefault();
                    if (_motivo == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Motivo não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idMotivo = _motivo.idMotivo;
                        item.txMotivo = _motivo.txMotivo;
                    }
                }

                if (!String.IsNullOrEmpty(item.codPeso))
                {
                    Peso _peso = this.listaPeso.Select(x => x).Where(x => x.codPeso == item.codPeso).FirstOrDefault();
                    if (_peso == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Peso não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idPeso = _peso.idPeso;
                        item.txPeso = _peso.txPeso;
                    }
                }

                if (String.IsNullOrEmpty(item.txErro))
                {

                    if (Validacao.validarCpf(item.nrCpf) == false)
                    {
                        item.bnlErro = true;
                        item.txErro += "Cpf inválido" + Environment.NewLine;
                        ret = false;
                    }

                    DalCpf _dalCpf = new DalCpf();
                    if (_dalCpf.Obter(new Cpf() { nrCpf = item.nrCpf }) != null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Cpf já cadastrado na base" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaInicio.Date < DateTime.Now.Date)
                    {
                        item.bnlErro = true;
                        item.txErro += "Data inicio não pode ser menor que a data atual" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaFim != DateTime.MinValue)
                        if (item.dtVigenciaInicio > item.dtVigenciaFim)
                        {
                            item.bnlErro = true;
                            item.txErro += "Data inicio maior que data fim" + Environment.NewLine;
                            ret = false;
                        }
                }
                else
                    ret = false;

            }
            catch (Exception ex)
            {
                Log.salvar(ex);
                throw ex;
            }
            return ret;
        }
    }
}
