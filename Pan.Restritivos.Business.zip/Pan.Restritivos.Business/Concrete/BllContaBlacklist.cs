﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

using Excel;
using System.Data;
using System.Text.RegularExpressions;
using Pan.Restritivos.Business.Utils;
using Pan.Restritivos.Data.Repositories.Sistema;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de Dado bancário.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllContaBlacklist : IBllBase<BllContaBlacklist>
    {
        DalContaBlacklist _repository;

        public BllContaBlacklist()
        {
            _repository = new DalContaBlacklist();
        }

        
        public ContaBlacklist Alterar(ContaBlacklist item)
        {
            try
            {
                //item.dtManutencao = DateTime.Now;
                return _repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BllContaBlacklist Alterar(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public List<ContaBlacklist> Importar(Arquivo item)
        {

            List<ContaBlacklist> list = new List<ContaBlacklist>(); ;
            try
            {
                ExcelManagement<ContaBlacklist> obj = new ExcelManagement<ContaBlacklist>();
                list = obj.read(item);


                _repository.Importar(list);

                if (list.Count > 0)
                {

                    list.ForEach(x =>
                    {

                        //x.idUsuarioManutencao = item.idUsuarioManutencao;
                        //x.nmUsuarioManutencao = item.NomeUsuario;
                        //x.dtManutencao = DateTime.Now;
                        this.ValidarImportacao(x);
                        //if (string.IsNullOrEmpty(x.txErro))
                        this.Inserir(x);
                    });
                }
                else
                    throw new customException("Arquivo vazio");
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return list;
        }

        public bool Inativar(ContaBlacklist item)
        {
            try
            {
                return _repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inativar(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public ContaBlacklist Inserir(ContaBlacklist item)
        {
            try
            {
                if (Validar(item))
                {
                    //item.blnAtivo = true;
                    item = _repository.Inserir(item);
                }

                return item;
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BllContaBlacklist Inserir(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public List<ContaBlacklist> Listar(ContaBlacklist item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<BllContaBlacklist> Listar(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public List<ContaBlacklist> ListarLog(int id)
        {
            try
            {
                return _repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ContaBlacklist Obter(ContaBlacklist item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BllContaBlacklist Obter(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public bool Validar(ContaBlacklist item)
        {
            bool ret = true;
            try
            {
                DalContaBlacklist _dalDadoBancario = new DalContaBlacklist();
                ContaBlacklist _DadoBancarion = new ContaBlacklist()
                {
                    nrAgencia = item.nrAgencia,
                    nrConta = item.nrConta,
                    nrBanco = item.nrBanco,
                };

                if (_dalDadoBancario.Obter(_DadoBancarion) != null)
                {
                    ret = false;
                    throw new customException("Dado Bancario já cadastrado na base");
                }
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool Validar(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(ContaBlacklist item)
        {
            bool ret = true;
            try
            {

                //if (!String.IsNullOrEmpty(item.codMotivo))
                //{
                //    //Motivo _motivo = this.listaMotivo.Select(x => x).Where(x => x.codMotivo == item.codMotivo).FirstOrDefault();
                //    //if (_motivo == null)
                //    //{
                //    //    item.bnlErro = true;
                //    //    item.txErro += "Motivo não encontrado" + Environment.NewLine;
                //    //    ret = false;
                //    //}
                //    //else
                //    //{
                //    //    item.idMotivo = _motivo.idMotivo;
                //    //    item.txMotivo = _motivo.txMotivo;
                //    //}
                //}

                //if (!String.IsNullOrEmpty(item.codPeso))
                //{
                //    Peso _peso = this.listaPeso.Select(x => x).Where(x => x.codPeso == item.codPeso).FirstOrDefault();
                //    if (_peso == null)
                //    {
                //        item.bnlErro = true;
                //        item.txErro += "Peso não encontrado" + Environment.NewLine;
                //        ret = false;
                //    }
                //    else
                //    {
                //        item.idPeso = _peso.idPeso;
                //        item.txPeso = _peso.txPeso;
                //    }
                //}


                //if (String.IsNullOrEmpty(item.txErro))
                //{
                //    DalContaBlacklist _dalDadoBancario = new DalContaBlacklist();
                //    ContaBlacklist _DadoBancarion = new ContaBlacklist()
                //    {
                //        nrAgencia = item.nrAgencia,
                //        nrConta = item.nrConta,
                //        nrBanco = item.nrBanco,
                //    };

                //    if (_dalDadoBancario.Obter(_DadoBancarion) != null)
                //    {
                //        item.bnlErro = true;
                //        item.txErro += "Dado Bancario já cadastrado na base" + Environment.NewLine;
                //        ret = false;
                //    }


                //    if (Validacao.validarCpf(item.nrCPFCNPJ) == false)
                //    {
                //        item.bnlErro = true;
                //        item.txErro += "Cpf/CNPJ inválido" + Environment.NewLine;
                //        ret = false;
                //    }

                //    if (item.dtVigenciaInicio.Date < DateTime.Now.Date)
                //    {
                //        item.bnlErro = true;
                //        item.txErro += "Data inicio não pode ser menor que a data atual" + Environment.NewLine;
                //        ret = false;
                //    }

                //    if (item.dtVigenciaFim != DateTime.MinValue)
                //        if (item.dtVigenciaInicio > item.dtVigenciaFim)
                //        {
                //            //item.bnlErro = true;
                //            //item.txErro += "Data inicio maior que data fim" + Environment.NewLine;
                //            ret = false;
                //        }
                //}
                //else
                //    ret = false;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }

            return ret;
        }

        public bool ValidarImportacao(BllContaBlacklist item)
        {
            throw new NotImplementedException();
        }

        List<BllContaBlacklist> IBllBase<BllContaBlacklist>.Importar(Arquivo item)
        {
            throw new NotImplementedException();
        }

        List<BllContaBlacklist> IBllBase<BllContaBlacklist>.ListarLog(int id)
        {
            throw new NotImplementedException();
        }
    }
}
