﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

using Excel;
using System.Data;
using System.Text.RegularExpressions;
using Pan.Restritivos.Business.Utils;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de Dado bancário.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllDadoBancario : IBllBase<DadoBancario>
    {
        DalDadoBancario _repository;

        List<Motivo> listaMotivo;
        List<Peso> listaPeso;

        public BllDadoBancario()
        {
            _repository = new DalDadoBancario();
        }

        
        public DadoBancario Alterar(DadoBancario item)
        {
            try
            {
                item.dtManutencao = DateTime.Now;
                return _repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DadoBancario> Importar(Arquivo item)
        {

            List<DadoBancario> list = new List<DadoBancario>(); ;
            try
            {
                ExcelManagement<DadoBancario> obj = new ExcelManagement<DadoBancario>();
                list = obj.read(item);
                if (list.Count > 0)
                {

                    DalMotivoAlerta _dalMotivo = new DalMotivoAlerta();
                    DalPesoAlerta _dalPeso = new DalPesoAlerta();
                    this.listaMotivo = _dalMotivo.Listar(new Motivo());
                    this.listaPeso = _dalPeso.Listar(new Peso());

                    list.ForEach(x =>
                    {
                        x.idUsuarioManutencao = item.idUsuarioManutencao;
                        x.nmUsuarioManutencao = item.NomeUsuario;
                        x.dtManutencao = DateTime.Now;
                        this.ValidarImportacao(x);
                        if (string.IsNullOrEmpty(x.txErro))
                            this.Inserir(x);
                    });
                }
                else
                    throw new customException("Arquivo vazio");
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return list;
        }

        public bool Inativar(DadoBancario item)
        {
            try
            {
                return _repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DadoBancario Inserir(DadoBancario item)
        {
            try
            {
                if (Validar(item))
                {
                    item.blnAtivo = true;
                    item = _repository.Inserir(item);
                }

                return item;
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DadoBancario> Listar(DadoBancario item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DadoBancario> ListarLog(int id)
        {
            try
            {
                return _repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DadoBancario Obter(DadoBancario item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(DadoBancario item)
        {
            bool ret = true;
            try
            {
                DalDadoBancario _dalDadoBancario = new DalDadoBancario();
                DadoBancario _DadoBancarion = new DadoBancario()
                {
                    nrAgencia = item.nrAgencia,
                    nrConta = item.nrConta,
                    nrBanco = item.nrBanco,
                };

                if (_dalDadoBancario.Obter(_DadoBancarion) != null)
                {
                    ret = false;
                    throw new customException("Dado Bancario já cadastrado na base");
                }
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(DadoBancario item)
        {
            bool ret = true;
            try
            {

                if (!String.IsNullOrEmpty(item.codMotivo))
                {
                    Motivo _motivo = this.listaMotivo.Select(x => x).Where(x => x.codMotivo == item.codMotivo).FirstOrDefault();
                    if (_motivo == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Motivo não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idMotivo = _motivo.idMotivo;
                        item.txMotivo = _motivo.txMotivo;
                    }
                }

                if (!String.IsNullOrEmpty(item.codPeso))
                {
                    Peso _peso = this.listaPeso.Select(x => x).Where(x => x.codPeso == item.codPeso).FirstOrDefault();
                    if (_peso == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Peso não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idPeso = _peso.idPeso;
                        item.txPeso = _peso.txPeso;
                    }
                }


                if (String.IsNullOrEmpty(item.txErro))
                {
                    DalDadoBancario _dalDadoBancario = new DalDadoBancario();
                    DadoBancario _DadoBancarion = new DadoBancario()
                    {
                        nrAgencia = item.nrAgencia,
                        nrConta = item.nrConta,
                        nrBanco = item.nrBanco,
                    };

                    if (_dalDadoBancario.Obter(_DadoBancarion) != null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Dado Bancario já cadastrado na base" + Environment.NewLine;
                        ret = false;
                    }


                    if (Validacao.validarCpf(item.nrCPFCNPJ) == false)
                    {
                        item.bnlErro = true;
                        item.txErro += "Cpf/CNPJ inválido" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaInicio.Date < DateTime.Now.Date)
                    {
                        item.bnlErro = true;
                        item.txErro += "Data inicio não pode ser menor que a data atual" + Environment.NewLine;
                        ret = false;
                    }

                    if (item.dtVigenciaFim != DateTime.MinValue)
                        if (item.dtVigenciaInicio > item.dtVigenciaFim)
                        {
                            item.bnlErro = true;
                            item.txErro += "Data inicio maior que data fim" + Environment.NewLine;
                            ret = false;
                        }
                }
                else
                    ret = false;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }

            return ret;
        }
    }
}
