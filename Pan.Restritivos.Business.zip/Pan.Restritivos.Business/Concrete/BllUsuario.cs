﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using System.IO;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de usuário.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllUsuario : IBllBase<Usuario>
    {
        DalUsuario _repository;

        public BllUsuario()
        {
            _repository = new DalUsuario();
        }

        public Usuario Find(int id)
        {
            try
            {
                return _repository.getuser(id);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Usuario> Listar(Usuario item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool RemoveAcesso(UsuarioItemAcesso UsuarioItemAcesso)
        {
            try
            {
                return _repository.RemoverAcesso(UsuarioItemAcesso);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void Remove(Usuario item)
        {
            try
            {
                _repository.Inativar(item);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public int getIdUserbyLogin(string login)
        {
            try
            {
                return _repository.getIdUserbyLogin(login);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Usuario getuser(int iduser)
        {
            try
            {
                return _repository.getuser(iduser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool verificaUsuarioAtivo(string login)
        {
            try
            {
                return _repository.verificaUsuarioAtivo(login);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void iniciarSessao(int sessionID, string login, string token, DateTime dtUltimaRequisicao)
        {
            try
            {
                _repository.iniciarSessao(sessionID, login, token, dtUltimaRequisicao);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void limparSessao(int sessionID, string login)
        {
            try
            {
                _repository.limparSessao(login, sessionID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public CustomToken obterSessao(int sessionID, string login)
        {
            try
            {
                return _repository.obterSessao(login, sessionID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Acessos> getaccesspage(int idusuario)
        {
            try
            {
                return _repository.getaccesspage(idusuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Acessos> ListaFuncionalidades()
        {
            try
            {
                return _repository.ListaFuncionalidades();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void atualizarSessao(int sessionID, string login, string token, DateTime dtUltimaRequisicao)
        {
            try
            {
                //EGS 30.04.2018 Se não fosse informado SessionId na chamada do Token, estava zerando a sessão
                if (sessionID != 0)
                {
                    _repository.atualizarSessao(sessionID, login, token, dtUltimaRequisicao);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Usuario Alterar(Usuario item)
        {
            Usuario ret = null;
            try
            {
                ret = _repository.Alterar(item);

                _repository.ExcluirItemAcesso(ret.idUsuario);
                
                foreach (var ItemAcesso in item.Acessos)
                {
                    ItemAcesso.idUsuario = ret.idUsuario;

                    _repository.InserirItemAcesso(new UsuarioItemAcesso()
                                    {
                                        blnAlterar = ItemAcesso.blnAlterar,
                                        blnConsultar = ItemAcesso.blnConsultar,
                                        blnInativar = ItemAcesso.blnInativar,
                                        blnIncluir = ItemAcesso.blnIncluir,
                                        idItemAcesso = ItemAcesso.idItemAcesso,
                                        idUsuario = ItemAcesso.idUsuario,
                                        blnImportar = ItemAcesso.blnImportar,
                                        idUsuarioItemAcesso = ItemAcesso.idUsuarioItemAcesso
                                    });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public Usuario Inserir(Usuario item)
        {
            Usuario ret = null;
            try
            {
                ret = _repository.Inserir(item);

                foreach (var ItemAcesso in item.Acessos)
                {
                    ItemAcesso.idUsuario = ret.idUsuario;

                    _repository.InserirItemAcesso(new UsuarioItemAcesso()
                    {
                        blnAlterar = ItemAcesso.blnAlterar,
                        blnConsultar = ItemAcesso.blnConsultar,
                        blnInativar = ItemAcesso.blnInativar,
                        blnIncluir = ItemAcesso.blnIncluir,
                        idItemAcesso = ItemAcesso.idItemAcesso,
                        blnImportar = ItemAcesso.blnImportar,
                        idUsuario = ItemAcesso.idUsuario
                    });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Usuario> Importar(Arquivo item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Usuario item)
        {
            try
            {
                return _repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public List<Usuario> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Usuario Obter(Usuario item)
        {
            throw new NotImplementedException();
        }

        public bool Validar(Usuario item)
        {
            throw new NotImplementedException();
        }

        public bool ValidarImportacao(Usuario item)
        {
            throw new NotImplementedException();
        }
    }
}
