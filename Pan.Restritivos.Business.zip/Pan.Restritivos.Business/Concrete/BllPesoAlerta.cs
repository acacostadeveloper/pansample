﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de peso de alerta.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllPesoAlerta : IBllBase<Peso>
    {
        DalPesoAlerta _repository;

        public BllPesoAlerta()
        {
            _repository = new DalPesoAlerta();
        }


        public Peso Alterar(Peso item)
        {
            try
            {
                if (!Validar(item))
                {
                    item.dtManutencao = DateTime.Now;
                    return _repository.Alterar(item);
                } // EGS 30.05.2018 Não dar essa mensagem, confunde o usuario..
                else
                    throw new customException("O registro não pode ser excluído, existe vínculo com outras bases.");
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }          
        }

        public List<Peso> Importar(Arquivo item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Peso item)
        {
            try
            {
                if (!Validar(item))
                {
                    _repository.Inativar(item);
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Peso Inserir(Peso item)
        {
            try
            {
                return _repository.Inserir(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Peso> Listar(Peso item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Peso> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Peso Obter(Peso item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(Peso item)
        {
            try
            {
                return _repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(Peso item)
        {
            throw new NotImplementedException();
        }
    }
}
