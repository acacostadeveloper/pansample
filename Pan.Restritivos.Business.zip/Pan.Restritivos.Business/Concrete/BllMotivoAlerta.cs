﻿using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de motivo de alerta.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllMotivoAlerta : IBllBase<Motivo>
    {
        DalMotivoAlerta _repository;

        public BllMotivoAlerta()
        {
            _repository = new DalMotivoAlerta();
        }

        public Motivo Alterar(Motivo item)
        {
            try
            {
                if(item.blnAtivo == true)
                {
                    item.dtManutencao = DateTime.Now;
                    return _repository.Alterar(item);
                }
                else if (!Validar(item))
                {
                    item.dtManutencao = DateTime.Now;
                    return _repository.Alterar(item);
                } // EGS 30.05.2018 Não dar essa mensagem, confunde o usuario..
                else
                    throw new customException("O registro não pode ser excluído, existe vínculo com outras bases.");
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            } 
        }

        public List<Motivo> Importar(Arquivo item)
        {
            throw new NotImplementedException();
        }

        public bool Inativar(Motivo item)
        {
            try
            {
                if (!Validar(item))
                {
                    _repository.Inativar(item);
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Motivo Inserir(Motivo item)
        {
            Motivo ret = null;
            try
            {
                ret = _repository.Inserir(item);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public List<Motivo> Listar(Motivo item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Motivo> ListarLog(int id)
        {
            throw new NotImplementedException();
        }

        public Motivo Obter(Motivo item)
        {
            throw new NotImplementedException();
        }

        public bool Validar(Motivo item)
        {
            try
            {
                return _repository.Validar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidarImportacao(Motivo item)
        {
            throw new NotImplementedException();
        }
    }
}
