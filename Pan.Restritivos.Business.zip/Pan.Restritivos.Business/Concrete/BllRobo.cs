﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

using Excel;
using System.Data;
using System.Text.RegularExpressions;
using Pan.Restritivos.Business.Utils;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos para o robo de atualização de vigência.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllRobo 
    {
        DalRobo _repository;

        public BllRobo()
        {
            _repository = new DalRobo();
        }

        public int UpdateVigencia()
        {
            try
            {
                return _repository.UpdateVigencia();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
