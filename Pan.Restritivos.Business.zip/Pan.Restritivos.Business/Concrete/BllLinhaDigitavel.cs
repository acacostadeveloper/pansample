﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Restritivos.Business.Interface;
using Pan.Restritivos.Model.User;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model;
using Pan.Restritivos.Model.Configuracao;
using Pan.Restritivos.Model.Sistema;
using System.IO;

using Excel;
using System.Data;
using System.Text.RegularExpressions;
using Pan.Restritivos.Business.Utils;

namespace Pan.Restritivos.Business.Concrete
{
    /// <summary>
    /// Camada de business com regras e tratamentos de linha digitável.
    /// Utilizado por todas as camadas que fazem uso de regras de negôcio ou acesso a dados    
    /// </summary>
    public class BllLinhaDigitavel : IBllBase<LinhaDigitavel>
    {
        DalLinhaDigitavel _repository;

        List<Motivo> listaMotivo;
        List<Peso> listaPeso;

        public BllLinhaDigitavel()
        {
            _repository = new DalLinhaDigitavel();
        }


        public LinhaDigitavel Alterar(LinhaDigitavel item)
        {
            try
            {
                item.dtManutencao = DateTime.Now;
                return _repository.Alterar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<LinhaDigitavel> Importar(Arquivo item)
        {

            List<LinhaDigitavel> list = new List<LinhaDigitavel>(); ;

            ExcelManagement<LinhaDigitavel> obj = new ExcelManagement<LinhaDigitavel>();
            var lista = obj.read(item);

            list = lista.Select(x => x).Where(x => (string.IsNullOrEmpty(x.txErro))).ToList();

            DalMotivoAlerta _dalMotivo = new DalMotivoAlerta();
            DalPesoAlerta _dalPeso = new DalPesoAlerta();
            this.listaMotivo = _dalMotivo.Listar(new Motivo());
            this.listaPeso = _dalPeso.Listar(new Peso());

            list.ForEach(x =>
            {
                x.idUsuarioManutencao = item.idUsuarioManutencao;
                x.nmUsuarioManutencao = item.NomeUsuario;
                this.ValidarImportacao(x);
                if (string.IsNullOrEmpty(x.txErro))
                    this.Inserir(x);
            });

            return list;
        }

        public bool Inativar(LinhaDigitavel item)
        {
            try
            {
                return _repository.Inativar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LinhaDigitavel Inserir(LinhaDigitavel item)
        {
            try
            {
                item.blnAtivo = true;
                if (Validar(item) == false)
                {
                    return item = _repository.Inserir(item);
                }
                return item;
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<LinhaDigitavel> Listar(LinhaDigitavel item)
        {
            try
            {
                return _repository.Listar(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<LinhaDigitavel> ListarLog(int id)
        {
            try
            {
                return _repository.ListarLog(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LinhaDigitavel Obter(LinhaDigitavel item)
        {
            try
            {
                return _repository.Obter(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Validar(LinhaDigitavel item)
        {
            bool ret = false;
            try
            {
                DalLinhaDigitavel _DalCodigoBarra = new DalLinhaDigitavel();

                if (_DalCodigoBarra.Validar(item) == true)
                {
                    ret = true;
                    throw new customException("Linha digitável já cadastrado na base");
                }
            }
            catch (customException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ret;
        }

        public bool ValidarImportacao(LinhaDigitavel item)
        {
            bool ret = true;

            try
            {
                if (!String.IsNullOrEmpty(item.codMotivo))
                {
                    Motivo _motivo = this.listaMotivo.Select(x => x).Where(x => x.codMotivo == item.codMotivo).FirstOrDefault();
                    if (_motivo == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Motivo não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idMotivo = _motivo.idMotivo;
                        item.txMotivo = _motivo.txMotivo;
                    }
                }

                if (!String.IsNullOrEmpty(item.codPeso))
                {
                    Peso _peso = this.listaPeso.Select(x => x).Where(x => x.codPeso == item.codPeso).FirstOrDefault();
                    if (_peso == null)
                    {
                        item.bnlErro = true;
                        item.txErro += "Peso não encontrado" + Environment.NewLine;
                        ret = false;
                    }
                    else
                    {
                        item.idPeso = _peso.idPeso;
                        item.txPeso = _peso.txPeso;
                    }
                }


                if (String.IsNullOrEmpty(item.txErro))
                {
                    DalLinhaDigitavel _dalLinhaDigitavel = new DalLinhaDigitavel();
                    if (_dalLinhaDigitavel.Obter(new LinhaDigitavel() { nrLinhaDigitavel = item.nrLinhaDigitavel }) != null)
                    {
                        item.bnlErro = true;
                        item.txErro += "LinhaDigitavel já cadastrado na base" + Environment.NewLine;
                        ret = false;
                    }
                }
                else
                    ret = false;

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ret;
        }
    }
}
