﻿using Excel;
using Pan.Restritivos.Data.Dal;
using Pan.Restritivos.Model.Configuracao;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Utils
{
    /// <summary>
    /// Classe tratamento de arquivos xlsx
    /// </summary>
    /// <typeparam name="T">Tipo de entidade para qual o arquivo deve ser convertido</typeparam>
    public class ExcelManagement<T>
    {

        public List<T> read(Arquivo item)
        {
            Log.salvar("ExcelManagement.read");
            List<T> tempList = new List<T>();

            try
            {
                string base64Data = Regex.Match(item.arq, @"data:application/(?<type>.+?),(?<data>.+)").Groups["data"].Value;

                if (String.IsNullOrEmpty(base64Data))
                {
                    throw new Exception("O tipo de arquivo não é suportado.");
                }

                var binData = Convert.FromBase64String(base64Data);
                IExcelDataReader excelReader;
                using (var stream = new MemoryStream(binData))
                {
                    excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);

                    excelReader.IsFirstRowAsColumnNames = true;
                    DataSet result = excelReader.AsDataSet();
                    if (result.Tables.Count > 0)
                    {
                        var tempDataRows = result.Tables[0].Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is System.DBNull));

                        if (tempDataRows.Count() > 0)
                        {
                            DataTable tempRows = tempDataRows.CopyToDataTable();
                            List<LayoutImportacao> lstLayoit = obterLayout(item.tipoBase);
                            DataColumn[] tempCol = new DataColumn[tempRows.Columns.Count];
                            tempRows.Columns.CopyTo(tempCol, 0);

                            foreach (var col in tempCol)
                            {
                                if (lstLayoit.Select(x => x).Where(x => x.coluna.Trim() == col.ColumnName.Trim()).Count() == 0)
                                {
                                    tempRows.Columns.Remove(col);
                                }
                                else
                                    col.ColumnName = col.ColumnName.Trim();
                            }

                            //Validação do header
                            lstLayoit.ForEach(x =>
                            {
                                if (!tempRows.Columns.Contains(x.coluna.Trim()))
                                    throw new Exception("layout invalido");
                            });

                            foreach (DataRow row in tempRows.Rows)
                            {
                                T obj = default(T);
                                obj = Activator.CreateInstance<T>();

                                lstLayoit.ForEach(x =>
                                {
                                    var value = row[x.coluna];
                                    PropertyInfo prop = obj.GetType().GetProperties().Select(y => y).Where(y => y.Name == x.coluna).FirstOrDefault();

                                    if (value != null && value != DBNull.Value)
                                    {
                                        Type tempType = prop.PropertyType;

                                        if (((Type)tempType.UnderlyingSystemType).Name == "Nullable`1")
                                        {
                                            var val = Convert.ChangeType(value, Nullable.GetUnderlyingType(tempType));
                                            prop.SetValue(obj, val, null);
                                        }
                                        else
                                        {
                                            var val = Convert.ChangeType(value, tempType);
                                            prop.SetValue(obj, val, null);
                                        }


                                    }
                                    else
                                    {
                                        if (x.obrigatorio)
                                        {
                                            PropertyInfo propTxErro = obj.GetType().GetProperties().Select(y => y).Where(y => y.Name == "txErro").FirstOrDefault();
                                            PropertyInfo propbnlErro = obj.GetType().GetProperties().Select(y => y).Where(y => y.Name == "bnlErro").FirstOrDefault();
                                            propTxErro.SetValue(obj, "Campos obrigatorios sem valor");
                                            propbnlErro.SetValue(obj, true);
                                        }
                                    }
                                });
                                tempList.Add(obj);
                            }
                        }
                        excelReader.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                Log.salvar("ExcelManagement.read - catch");
                Log.salvar(ex);
                throw ex;
            }
            return tempList;
        }

        public List<LayoutImportacao> obterLayout(string pBase)
        {
            try
            {
                DalLayoutImportacao _dal = new DalLayoutImportacao();
                return _dal.Listar(pBase);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

    }
}
