﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Restritivos.Business.Utils
{
    /// <summary>
    /// classe para validação em geral
    /// </summary>
    public class Validacao
    {

        public static bool validarCpf(string cpf)
        {
            if (cpf.Length < 11)
                return false;

            int multiplicador = 10;

            List<char> cpfArr = cpf.ToList();
            
            double cpfMultiplicado = 0;
            int digUm;
            int digDois;

            for (int i = 0; i < 9; i++)
            {
                cpfMultiplicado += Convert.ToInt32(cpfArr[i].ToString()) * multiplicador;
                multiplicador--;
            }

            cpfMultiplicado = (cpfMultiplicado % 11);
            if (cpfMultiplicado < 2)
                digUm = 0;
            else
                digUm = 11 - Convert.ToInt32(cpfMultiplicado);

            
            cpfMultiplicado = 0;
            multiplicador = 11;

            cpfArr.Add(Convert.ToChar(digUm));

            for (int i = 0; i < 10; i++)
            {
                cpfMultiplicado += Convert.ToInt32(cpfArr[i].ToString()) * multiplicador;
                multiplicador--;
            }

            cpfMultiplicado = (cpfMultiplicado % 11);
            if (cpfMultiplicado < 2)
                digDois = 0;
            else
                digDois = 11 - Convert.ToInt32(cpfMultiplicado);


            if (Convert.ToInt32(cpf[9].ToString()) == digUm && Convert.ToInt32(cpf[10].ToString()) == digDois)
                return true;
            else
                return false;

            
        }
    }
}
