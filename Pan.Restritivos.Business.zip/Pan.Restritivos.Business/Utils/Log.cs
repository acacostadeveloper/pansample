﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Web;

namespace Pan.Restritivos.Business.Utils
{
    /// <summary>
    /// Classe para gerenciamento de log
    /// </summary>
    public static class Log
    {
        public static void salvar(Exception ex)
        {
            try
            {
                var diretorioUpload = ConfigurationManager.AppSettings["pathLog"].ToString();
                string nomeArq = DateTime.Now.ToString("yyyyMMdd");

                if (!System.IO.Directory.Exists(diretorioUpload))
                    System.IO.Directory.CreateDirectory(diretorioUpload);

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(diretorioUpload + nomeArq + ".txt", true))
                {
                    ClaimsPrincipal objClaims = System.Security.Claims.ClaimsPrincipal.Current;

                    sw.WriteLine(Environment.NewLine + "============================ Exception ============================");

                    sw.WriteLine("Message: " + ex.Message);
                    sw.WriteLine("Source: " + ex.Source);
                    sw.WriteLine("StackTrace: " + ex.StackTrace);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (IOException)
            {
                salvar(ex);
            }
            catch (Exception)
            {
                salvar(ex);               
            }
        }

        public static void salvar(string str)
        {
            try
            {
            var diretorioUpload = ConfigurationManager.AppSettings["pathLog"].ToString();
            string nomeArq = DateTime.Now.ToString("yyyyMMdd");

            if (!System.IO.Directory.Exists(diretorioUpload))
                System.IO.Directory.CreateDirectory(diretorioUpload);

            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(diretorioUpload + nomeArq + ".txt", true))
            {
                ClaimsPrincipal objClaims = System.Security.Claims.ClaimsPrincipal.Current;

                sw.WriteLine(Environment.NewLine + "============================ Exception ============================");
                sw.WriteLine(str);
                sw.Flush();
                sw.Close();
            }
            }
            catch (IOException)
            {
                salvar(str);
            }
            catch (Exception ex)
            {
                salvar(ex);               
            }
        }
    }
}